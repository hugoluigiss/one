module.exports = {
    printWidth: 80,
    tabWidth: 4,
    trailingComma: "none",
    jsxBracketSameLine: true,
    bracketSpacing: false,
};
