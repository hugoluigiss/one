<?php

return [
    'subscription_description' => 'Stake subscription',
    'operator_subscription_description' => 'Stake subscription from :name',
    'redemption_description' => 'Stake redemption',
    'operator_redemption_description' => 'Stake redemption to :name',
];
