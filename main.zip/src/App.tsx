import { BrowserRouter as Router } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { ChakraProvider } from '@chakra-ui/react';
import theme from './styles/themes/chakraBase';
import Routes from './routes';

import AppProvider from './context';

function App(): JSX.Element {
  return (
    <ChakraProvider theme={theme}>
      <Router>
        <AppProvider>
          <Routes />
        </AppProvider>
        <ToastContainer autoClose={3000} />
      </Router>
    </ChakraProvider>
  );
}

export default App;
