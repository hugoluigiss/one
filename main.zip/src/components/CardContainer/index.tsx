import { Stack } from '@chakra-ui/react';
import React from 'react';

interface CardProps {
  children: React.ReactNode;
  [x: string]: any;
}

export default function CardContainer({ children, ...rest }: CardProps) {
  return (
    <Stack
      borderRadius="19px"
      bg="cardBg.500"
      borderColor="cardBorder.500"
      borderWidth="1px"
      p="20px 12px"
      transition="200ms"
      {...rest}
    >
      {children}
    </Stack>
  );
}
