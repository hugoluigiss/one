/* eslint-disable react/jsx-curly-newline */
/* eslint-disable react/jsx-wrap-multilines */
import {
  Heading,
  Stack,
  Skeleton,
  Text,
  HStack,
  StackDivider,
  useDisclosure,
  SlideFade,
  Box,
  Collapse,
  Button,
} from '@chakra-ui/react';
import Axios from 'axios';
import { useCallback, useEffect, useState } from 'react';
import CurrencyWithIcon from '../Utils/CurrencyWithIcon';
import useGet from '../../hooks/useGet';
import { CoinsType } from '../../services/apitypes';
import { ReactComponent as VarianceUp } from '../../assets/icons/variance-up.svg';
import { ReactComponent as VarianceDown } from '../../assets/icons/variance-down.svg';
// import WithdrawAction from './WithdrawAction';
// import ApplyAction from './ApplyAction';
import { formatPrice } from '../../utils/format';
import { ActionTypes } from './props';
import WithdrawAction from './WithdrawAction';

interface IOption {
  name: string;
  value: number;
  interval: string;
}
const options: IOption[] = [
  { name: '24h', value: 24, interval: 'hour' },
  { name: '7d', value: 7, interval: 'day' },
  { name: '30d', value: 30, interval: 'day' },
  { name: '90d', value: 90, interval: 'day' },
  { name: '1a', value: 366, interval: 'day' },
];
// const date = new Date().getDate();
// const withdrawDay = date === 1 || date === 15;

export default function CryptoCard({
  coin,
  collapse,
  color,
}: {
  coin: CoinsType;
  collapse: boolean;
  color: string;
}): JSX.Element {
  const [period] = useState<IOption>(options[0]);
  const [variance, setVariance] = useState(0);
  const { isOpen, onOpen } = useDisclosure();
  const {
    isOpen: contentOpen,
    onOpen: onOpenContent,
    onClose: onCloseContent,
  } = useDisclosure({
    defaultIsOpen: true,
  });
  const [content, setContent] = useState<ActionTypes>('');

  const [{ data, loading }] = useGet<{
    coin: string;
    current_balance: string;
    conversion_to_brl: string;
    balance_converted_to_brl: string;
  }>('/customer/balance/coin', {
    coin,
    card: 'comission',
  });

  const [{ data: open }] = useGet<{
    isOpen: boolean;
  }>('/customer/withdrawal/is_open', {
    type: 'partner',
  });

  const getData = useCallback(async (url: string) => {
    const response = await Axios.get(url);

    const { length } = response.data.Data.Data;
    const firstClose = response.data.Data.Data[0].close;
    const lastClose = response.data.Data.Data[length - 1].close;
    const calcVariance = (lastClose / firstClose - 1.0) * 100;

    setVariance(calcVariance);
  }, []);

  const getFixation = (_coin: CoinsType) => {
    return _coin === 'USDT' ? 2 : 5;
  };

  const shouldBeOpen = (type: ActionTypes): boolean => {
    return !contentOpen && content === type;
  };

  const openOrCollapsed = (): string => {
    const heightNormal = isOpen ? '550px' : '210px';

    return collapse ? '83px' : heightNormal;
  };

  useEffect(() => {
    const url = `https://min-api.cryptocompare.com/data/v2/histo${
      period.interval
    }?fsym=${coin}&tsym=BRL&limit=${period.value}${
      period.value === 2000 ? '&allData=true' : ''
    }`;

    getData(url);
  }, [coin, getData, period]);

  const [cryptoName, setCryptoName] = useState('');
  useEffect(() => {
    if (coin === 'BTC') setCryptoName('Bitcoin');
    if (coin === 'ETH') setCryptoName('Ethereum');
    if (coin === 'BNB') setCryptoName('Bnb');
    if (coin === 'USDT') setCryptoName('USDT');
  }, [coin]);

  return (
    <Stack
      minW="357px"
      h={openOrCollapsed()}
      borderRadius="19px"
      bg="cardBg.500"
      borderColor="cardBorder.500"
      borderWidth="1px"
      py={collapse ? '8px' : '18px'}
      px="12px"
      transition="300ms"
      overflow="hidden"
      position="relative"
    >
      <Box width="100%" height="100%" position="absolute" top={0} left={0} />
      <HStack w="full" justifyContent="space-between" mt="0 !important">
        <CurrencyWithIcon iconName={coin} currency={cryptoName} color={color} />

        <Stack spacing={0} color={color}>
          <Text fontSize="sm">1 {coin}</Text>
          <Text fontSize="sm">
            R$ {formatPrice(Number(data?.conversion_to_brl || 0))}
          </Text>
        </Stack>

        <Stack spacing={0}>
          <Collapse in={!collapse} animateOpacity>
            <HStack>
              {variance > 0 ? <VarianceUp /> : <VarianceDown />}
              <Text color="white">{Math.abs(variance).toFixed(2)}%</Text>
            </HStack>
          </Collapse>
          <Collapse in={collapse} animateOpacity>
            <Stack spacing={0} alignItems="center">
              <Text fontSize="sm" color="white">
                Comissão
              </Text>
              <Skeleton isLoaded={!loading} mt={0}>
                <Heading color="white" size="md">
                  {Number(data?.current_balance || '0').toFixed(
                    getFixation(coin),
                  )}{' '}
                  {coin}
                </Heading>
              </Skeleton>
              <Text fontSize="sm" color="white" alignSelf="center">
                R${' '}
                {formatPrice(
                  Number(data?.conversion_to_brl || 0) *
                    Number(data?.current_balance || 0),
                )}
              </Text>
            </Stack>
          </Collapse>
        </Stack>
      </HStack>

      <SlideFade in={!collapse} offsetY="20px">
        <Stack
          wrap="wrap"
          justifyContent="space-between"
          divider={<StackDivider borderColor="cardBorder.500" />}
          spacing={6}
        >
          <Stack
            alignItems="center"
            borderColor="cardBorder.500"
            borderTop="1px"
            h="128px"
          >
            <Stack spacing={0} alignItems="center">
              <Text fontSize="sm" color="white">
                Comissão
              </Text>
              <Skeleton isLoaded={!loading} mt={0}>
                <Heading color="white" size="lg">
                  {Number(data?.current_balance || '0').toFixed(
                    getFixation(coin),
                  )}{' '}
                  {coin}
                </Heading>
              </Skeleton>
              <Text fontSize="sm" color="white" alignSelf="center">
                R${' '}
                {formatPrice(
                  Number(data?.conversion_to_brl || 0) *
                    Number(data?.current_balance || 0),
                )}
              </Text>
            </Stack>
            {open && open.isOpen && (
              <HStack mt={4} spacing={3}>
                <Button
                  borderRadius="4px"
                  border="1px"
                  borderColor="cardBorder.500"
                  colorScheme="brandBlack"
                  size="sm"
                  onClick={() => {
                    onOpen();
                    onCloseContent();
                    setContent('withdraw');
                  }}
                >
                  SACAR
                </Button>
              </HStack>
            )}
          </Stack>

          {shouldBeOpen('withdraw') && (
            <Stack zIndex={10}>
              <WithdrawAction
                coin={coin}
                onOpenAction={() => {
                  // onCloseContent();
                }}
                onCloseAction={() => {
                  onOpenContent();
                }}
              />
            </Stack>
          )}
        </Stack>
      </SlideFade>
    </Stack>
  );
}
