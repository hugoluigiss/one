import styled from 'styled-components';
import { Box } from '@chakra-ui/react';

export const Container = styled(Box)`
  position: relative;
`;

export const BgCoin = styled.div`
  position: absolute;

  width: 100%;
  height: 100%;
`;
