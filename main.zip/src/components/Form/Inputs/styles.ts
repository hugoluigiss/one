import styled, { css } from 'styled-components';
import { ReactComponent as EyeCloseIcon } from '../../../assets/icons/eyeclose.svg';
import { ReactComponent as EyeOpenIcon } from '../../../assets/icons/eyeopen.svg';

interface inputProps {
  isDark?: boolean;
}
export const Container = styled.div<inputProps>`
  display: flex;
  flex-direction: column;
  width: 100%;
  margin: 10px 0;

  input {
    background: transparent;
    border: solid 1px #707070;

    color: ${props => (props.isDark ? '#1A202C' : '#fff')};
    padding: 12px;
    outline: none;
    font-size: 16px;

    ${props =>
      props.isDark &&
      css`
        border-radius: 0.375rem;
      `};
  }
  input::placeholder {
    color: ${props => (props.isDark ? '#1A202C' : '#fff')};
  }

  input:disabled {
    background: #eee;
    cursor: not-allowed;
    color: #525252;
  }

  label {
    color: #fff;
    font-size: 14px;
    margin: 0 0 10px 0;
  }

  .inputPasswordContainer {
    display: flex;
    align-items: center;

    background: transparent;
    border: none;
    color: #fff;
    outline: none;
    font-size: 16px;
    transition: 300ms all;
    border: 1px solid rgba(168, 170, 180, 1) !important;

    .inputPassword {
      border: none !important;
    }

    input {
      background: transparent;
      padding: 12px;
      width: 90%;
      border: none;
    }
  }

  .tiny16 {
    flex-shrink: 1.6;
  }

  .tiny14 {
    flex-shrink: 1.4;
  }

  .tiny12 {
    flex-shrink: 1.2;
  }
`;

export const EyeClose = styled(EyeCloseIcon)`
  width: 10%;
  transition: 300ms all;
  cursor: pointer;
`;

export const EyeOpen = styled(EyeOpenIcon)`
  width: 10%;
  transition: 300ms all;
  cursor: pointer;
`;
