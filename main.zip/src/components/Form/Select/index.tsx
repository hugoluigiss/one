import { SelectHTMLAttributes } from 'react';

import Container from './styles';

interface InputProps extends SelectHTMLAttributes<HTMLSelectElement> {
  errorText?: string;
  error?: boolean;
  dark?: boolean;
  children: React.ReactNode;
}

export default function Select({
  dark,
  errorText,
  children,
  ...rest
}: InputProps): JSX.Element {
  return (
    <Container isDark={dark}>
      <select {...rest}>{children}</select>
      {errorText && <span style={{ color: 'red' }}>{errorText}</span>}
    </Container>
  );
}
