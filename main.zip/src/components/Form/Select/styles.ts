import styled, { css } from 'styled-components';

interface inputProps {
  isDark?: boolean;
}
export default styled.div<inputProps>`
  display: flex;
  flex-direction: column;
  width: fit-content;
  margin: 10px 0;

  select {
    background: transparent;
    border: solid 1px #707070;

    color: ${props => (props.isDark ? '#1A202C' : '#fff')};
    padding: 12px;
    outline: none;
    font-size: 16px;

    ${props =>
      props.isDark &&
      css`
        border-radius: 0.375rem;
      `};
  }
  input::placeholder {
    color: ${props => (props.isDark ? '#1A202C' : '#fff')};
  }
  select:disabled {
    background: #eee;
    cursor: not-allowed;
    color: #525252;
  }

  label {
    color: #fff;
    font-size: 14px;
    margin: 0 0 10px 0;
  }

  .tiny16 {
    flex-shrink: 1.6;
  }

  .tiny14 {
    flex-shrink: 1.4;
  }

  .tiny12 {
    flex-shrink: 1.2;
  }
`;
