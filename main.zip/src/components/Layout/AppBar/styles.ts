import styled from 'styled-components';

import { ReactComponent as Notification } from '../../../assets/icons/notification.svg';

interface AppbarProps {
  isCollapsed?: boolean;
}
export const Container = styled.div<AppbarProps>`
  background: #1f2128;
  height: 86px;

  display: flex;
  align-items: center;
  justify-content: space-between;

  position: fixed;
  right: 0;
  top: 0;

  box-sizing: border-box;
  z-index: 10;

  transition: 200ms;
  margin-left: ${props => (props.isCollapsed ? 120 : 262)}px;
  width: calc(100vw - ${props => (props.isCollapsed ? 120 : 262)}px);
`;

export const AppbarContainer = styled.div`
  background: #1f2128;

  height: 86px;
  width: inherit;

  display: flex;
  align-items: center;
  justify-content: space-between;

  position: fixed;
  right: 0;
  top: 0;

  transition: 200ms;
`;

interface AppBarProps {
  isCollapsed?: boolean;
}
export const LeftContainer = styled.div<AppBarProps>`
  margin-left: 38px;

  position: relative;
  padding-left: 30px;

  display: flex;
  align-items: center;
  transition: 200ms;
`;

interface ItemMenuProps {
  isCollapsed?: boolean;
}
export const MenuTrigger = styled.div<ItemMenuProps>`
  position: absolute;
  overflow: hidden;
  right: -38px;

  width: 30px;
  height: 30px;
  border-radius: 8px;

  background: #ff7a00;

  cursor: pointer;

  &::after {
    content: '';
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    transition: 200ms;

    background-repeat: no-repeat;
    background-position: center;
    // background-image: url();
    transform: rotate(${props => (props.isCollapsed ? '180deg' : '0deg')});
  }
`;

export const CenterContainer = styled.div`
  width: 100%;
  display: flex;
  padding-left: 58px;

  align-items: center;
`;

export const UserLink = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;

  cursor: pointer;
  overflow: hidden;

  height: 52px;
  width: 30%;
  max-width: 463px;
  border-radius: 100px;
  padding: 0 26px;

  background: #ffffff1f;
  border: 1px solid #ffffff33;

  font-family: 'Lato';

  span {
    color: #fff;
    font-size: 14px;
  }
`;

export const CenterInfo = styled.div`
  display: flex;
  justify-content: space-between;
  margin-left: 29px;
`;

export const Info = styled.div`
  display: flex;
  align-items: center;

  margin-right: 12px;

  span {
    font-size: 14px;
    font-weight: 400;

    margin-right: 8px;

    color: #ff7a00;
  }

  p {
    font-size: 14px;
    font-weight: 500;

    color: #d7dadd;
  }

  &::before {
    content: 'i';
    background: #e5e8ed;
    border-radius: 50%;
    width: 12px;
    height: 12px;
    text-align: center;
    margin-right: 6px;
  }
`;

export const RightContainer = styled.div`
  display: flex;
  align-items: center;
  margin-right: 38px;
`;

export const ActionBox = styled.div`
  display: flex;
  align-items: center;

  padding-right: 29px;

  border-right: 1px solid #fff;

  height: 38px;
`;

export const NotifContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-left: 22px;
  position: relative;
  cursor: pointer;
`;

export const NotifIcon = styled(Notification)`
  height: 21px;
  width: 21px;
`;

export const NotifBadge = styled.div`
  background: #eee;
  position: absolute;
  left: 14px;
  top: 0px;
  width: 14px;
  height: 14px;

  font-size: 10px;
  text-align: center;
  color: #212626;
`;

export const ProfileBox = styled.div`
  display: flex;
  align-items: center;
  font-size: 14px;
  height: 100%;
  padding-left: 22px;
`;

export const ProfileAction = styled.div`
  user-select: none;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: 0.3s;
  position: relative;
`;

export const ProfileInfo = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  min-width: 160px;
`;
