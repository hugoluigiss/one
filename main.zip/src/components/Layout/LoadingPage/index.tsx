import { ScaleFade } from '@chakra-ui/react';
import { Container, LogoAnimated } from './styles';
import Logo from '../../Logo';

export default function LoadingPage(): JSX.Element {
  return (
    <Container>
      <ScaleFade initialScale={0.6} in>
        <LogoAnimated>
          <Logo />
        </LogoAnimated>
      </ScaleFade>
    </Container>
  );
}
