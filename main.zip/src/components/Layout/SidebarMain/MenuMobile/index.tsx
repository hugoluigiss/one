import { useAuth } from '../../../../hooks/useAuth';
import useGet from '../../../../hooks/useGet';
import { getMyUnilevel } from '../../../../services/apitypes';
import {
  Container,
  ItemMenu,
  Dashboard,
  Extract,
  Contracts,
  Clients,
  SingOutContainer,
  SignOut,
} from './styles';

export default function MenuMobile(): JSX.Element {
  const { setToken } = useAuth();
  const [{ data }] = useGet<getMyUnilevel>('/unilevel');

  const getTitleLabel = (): string => {
    const title = data && data.show_consultants ? 'Consultores' : 'Locadores';

    return data && data.show_managers ? 'Unidades' : title;
  };

  return (
    <Container>
      <ItemMenu to="/dashboard">
        <Dashboard />
        <span>Dashboard</span>
      </ItemMenu>

      <ItemMenu to="/extract">
        <Extract />
        <span>Extrato</span>
      </ItemMenu>

      <ItemMenu to="/contracts">
        <Contracts />
        <span>Contratos</span>
      </ItemMenu>

      <ItemMenu to="/clients">
        <Clients />
        <span>{getTitleLabel()}</span>
      </ItemMenu>

      <SingOutContainer
        onClick={async () => {
          setToken(null);
        }}
      >
        <SignOut />
      </SingOutContainer>
    </Container>
  );
}
