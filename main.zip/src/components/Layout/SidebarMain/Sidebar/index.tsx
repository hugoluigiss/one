import { Stack, Tooltip } from '@chakra-ui/react';
import { useAuth } from '../../../../hooks/useAuth';
import useGet from '../../../../hooks/useGet';
import Logo from '../../../Logo';
import { getMyUnilevel } from '../../../../services/apitypes';
import {
  Container,
  Content,
  Toggle,
  ItemMenu,
  Dashboard,
  Extract,
  Contracts,
  Clients,
  SingOutContainer,
  SignOut,
} from './styles';

interface AppbarProps {
  collapse: [boolean, React.Dispatch<React.SetStateAction<boolean>>];
}

export default function Sidebar({ collapse }: AppbarProps): JSX.Element {
  const [isCollapsed, setIsCollapsed] = collapse;
  const [{ data }] = useGet<getMyUnilevel>('/unilevel');

  const { setToken } = useAuth();

  const handleMenu = (): void => {
    setIsCollapsed(!isCollapsed);
  };

  const getTitleLabel = (): string => {
    const title = data && data.show_consultants ? 'Consultores' : 'Locadores';

    return data && data.show_managers ? 'Unidades' : title;
  };

  return (
    <Container isCollapsed={!!isCollapsed}>
      <Stack pb="2" alignItems="center">
        <Logo collapse={!!isCollapsed} />
        <Toggle onClick={handleMenu} collapse={!!isCollapsed} />
      </Stack>

      <Content>
        <Tooltip label="Dashboard">
          <ItemMenu to="/dashboard">
            <Dashboard />
            <span>Dashboard</span>
          </ItemMenu>
        </Tooltip>

        <Tooltip label="Extrato">
          <ItemMenu to="/extract">
            <Extract />
            <span>Extrato</span>
          </ItemMenu>
        </Tooltip>

        <Tooltip label="Contratos">
          <ItemMenu to="/contracts">
            <Contracts />
            <span>Contratos</span>
          </ItemMenu>
        </Tooltip>

        <Tooltip label={getTitleLabel()}>
          <ItemMenu to="/clients">
            <Clients />
            <span>{getTitleLabel()}</span>
          </ItemMenu>
        </Tooltip>

        <SingOutContainer
          onClick={async () => {
            setToken(null);
          }}
        >
          <SignOut />
          <span>Sair</span>
        </SingOutContainer>
      </Content>
    </Container>
  );
}
