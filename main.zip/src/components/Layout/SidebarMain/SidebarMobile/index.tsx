import { Skeleton } from '@chakra-ui/react';
import { useAuth } from '../../../../hooks/useAuth';
import useGet from '../../../../hooks/useGet';
import { getMe, getMyUnilevel } from '../../../../services/apitypes';
import { ProfileInfo } from '../../AppBar/styles';
import {
  Container,
  TopContainer,
  InfoContainer,
  Content,
  ItemMenu,
  Dashboard,
  Extract,
  Clients,
  SignOut,
} from './styles';

interface AppbarProps {
  collapse: [boolean, React.Dispatch<React.SetStateAction<boolean>>];
  me: getMe | undefined;
}

export default function Sidebar({ collapse, me }: AppbarProps): JSX.Element {
  const [isCollapsed] = collapse;
  const { setToken } = useAuth();
  const [{ data }] = useGet<getMyUnilevel>('/unilevel');

  const getTitleLabel = (): string => {
    const title = data && data.show_consultants ? 'Consultores' : 'Locadores';

    return data && data.show_managers ? 'Unidades' : title;
  };

  return (
    <Container isCollapsed={isCollapsed}>
      <TopContainer>
        <InfoContainer>
          <ProfileInfo>
            <h5>
              {/* <Skeleton isLoaded={!!me}>Olá, {me?.name}</Skeleton> */}
            </h5>
            <h6>
              <Skeleton isLoaded={!!me}>{me?.email}</Skeleton>
            </h6>
          </ProfileInfo>
        </InfoContainer>
      </TopContainer>

      <Content>
        <ItemMenu to="/dashboard">
          <Dashboard />
          <span>Dashboard</span>
        </ItemMenu>

        <ItemMenu to="/extract">
          <Extract />
          <span>Extrato</span>
        </ItemMenu>

        <ItemMenu to="/clients">
          <Clients />

          <span>{getTitleLabel()}</span>
        </ItemMenu>

        <SignOut
          onClick={async () => {
            setToken(null);
          }}
        >
          <span>Sair</span>
        </SignOut>
      </Content>
    </Container>
  );
}
