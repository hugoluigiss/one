import { ReactComponent as LogoHorizontal } from '../../assets/icons/logos/logo-horizontal.svg';
import { ReactComponent as LogoIcon } from '../../assets/icons/logos/logo.svg';

interface LogoProps {
  collapse?: boolean;
}

export default function Logo({ collapse = false }: LogoProps) {
  return collapse ? (
    <LogoIcon width={70} height={108} style={{ maxWidth: '64%' }} />
  ) : (
    <LogoHorizontal width={200} height={117} style={{ maxWidth: '54%' }} />
  );
}
