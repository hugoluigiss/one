import styled from 'styled-components';

export default styled.div`
  background-color: #fff;
  border-radius: 4px;
  margin: 0 8px;
  padding: 2px 6px;
  color: #262626;
  font-size: 12px;
  height: fit-content;
`;
