import styled from 'styled-components';

export const Container = styled.div`
  width: 100%;
  height: 40px;
  padding: 8px 10px;
  background-color: #1d2330;
  border: none;

  display: flex;
  align-items: center;

  position: relative;

  .leftBlur {
    left: 0;
    width: 36px;
    height: 40px;
    position: absolute;
    background: linear-gradient(90deg, #1d2330, #1d2330, #f5f5f500);
  }
  .rightBlur {
    right: 0;
    width: 36px;
    height: 40px;
    position: absolute;
    background: linear-gradient(-90deg, #1d2330, #1d2330, #f5f5f500);
  }
`;

export const ContentContainer = styled.div`
  height: 40px;
  overflow: hidden;
  box-sizing: border-box;
  border-radius: 4px;
  text-align: right;
  line-height: 14px;
  block-size: 62px;
  font-size: 12px;
  font-feature-settings: normal;
  text-size-adjust: 100%;
  padding: 1px;
  margin: 0px;
  width: 100%;
`;

export const Content = styled.div`
  height: 40px;
  padding: 0px;
  margin: 0px;
  width: 100%;
  margin-top: 10px;

  iframe {
    border: 0;
    margin: 0;
    padding: 0;
  }
`;
