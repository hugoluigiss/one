import styled from 'styled-components';

import { ReactComponent as Copy } from '../../assets/icons/copy.svg';

const CopyIcon = styled(Copy)`
  height: 15px;
  width: 15px;

  min-height: 15px;
`;

export default CopyIcon;
