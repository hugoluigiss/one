import Tag from '../../Tag';
import Container from './styles';

interface CurrencyProps extends React.HTMLAttributes<HTMLElement> {
  value?: string;
  symbol?: string;
}

export default function CurrencySymbolTag({
  value,
  symbol,
  ...rest
}: CurrencyProps) {
  return (
    <Container {...rest}>
      {value || 0}
      {symbol && <Tag>{symbol}</Tag>}
    </Container>
  );
}
