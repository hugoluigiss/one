import styled from 'styled-components';

interface CoinProps {
  color: string;
}
export default styled.div<CoinProps>`
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${({ color }) => color || '#fff'};
  transition: 200ms;

  .icon {
    height: 20px;
    width: 20px;
    background-size: contain;
    background-repeat: no-repeat;
    background-position: center;
    fill: ${({ color }) => color || '#fff'};
    transition: 200ms;
  }

  .labelInfo {
    text-align: start;
    margim: 4px 0;
    margin-left: 7px;

    h1 {
      font-weight: 600;
      margin: 0;
    }

    h2 {
      margin: 0;
      font-weight: 500;
      font-size: 9px;
      text-transform: uppercase;
    }
  }
`;
