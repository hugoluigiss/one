/* eslint-disable import/no-duplicates */
import React from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import Container from './styles';

type DateWithHourProps = {
  dateValue: any;
  hour?: boolean;
};

const DateWithHour: React.FC<DateWithHourProps> = ({
  dateValue,
  hour = true,
}: DateWithHourProps) => {
  return (
    <Container>
      <h3>{format(new Date(dateValue), 'dd/MM/yyyy', { locale: ptBR })}</h3>
      {hour && (
        <div>
          |<span>{format(new Date(dateValue), 'kk:mm', { locale: ptBR })}</span>
        </div>
      )}
    </Container>
  );
};

export default DateWithHour;
