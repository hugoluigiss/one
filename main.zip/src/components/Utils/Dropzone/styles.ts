import styled from 'styled-components';

export default styled.div`
  width: 60%;
  height: 200px;

  border-radius: 5px;
  background: white;

  border: 1px solid black;
  color: #666360;


  display: flex;
  justify-content: center;
  align-items: center;
  /* margin-top: 48px; */
  outline: 0;
  cursor: pointer;

  img {
    width: 50%;
    object-fit: contain;
  }

  p {
    width: calc(100% - 60px);
    height: calc(100% - 60px);
    border-radius: 5px;
    border: 1px dashed;
    border-color: black};
    color: black;

    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    color: #4A4A4A;
    text-align: center;
    font-size: 12px;
  }

  p svg {
    width: 24px;
    height: 24px;
    margin-bottom: 8px;
    color: #4A4A4A;
  }
`;
