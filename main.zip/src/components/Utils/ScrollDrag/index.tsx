import { HStack } from '@chakra-ui/react';
import { useRef } from 'react';
import { useDraggable } from 'react-use-draggable-scroll';

interface ScrollProps {
  children: React.ReactNode;
  [x: string]: any;
}

export default function ScrollDrag({ children, ...rest }: ScrollProps) {
  const ref =
    useRef<HTMLDivElement>() as React.MutableRefObject<HTMLInputElement>;
  const { events } = useDraggable(ref, {
    applyRubberBandEffect: true,
  });

  return (
    <HStack
      role="presentation"
      overflowX="auto"
      ref={ref}
      {...events}
      {...rest}
    >
      {children}
    </HStack>
  );
}
