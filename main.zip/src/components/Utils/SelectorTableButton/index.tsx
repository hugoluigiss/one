/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React, { useState } from 'react';

import { Container, ModalSelector } from './styles';

interface IOption {
  name: string;
  value: number;
  interval: string;
}

interface IProps {
  options: IOption[];
  setSelectedOption: (option: IOption) => void;
  selectedOption: IOption;
}

const SelectorTableButton: React.FC<IProps> = ({
  options,
  setSelectedOption,
  selectedOption,
}: IProps) => {
  const [isCollapse, setIsCollapse] = useState(false);

  const handleMenu = (): void => {
    setIsCollapse(!isCollapse);
  };

  return (
    <Container>
      <div onClick={handleMenu} className="buttonSelector">
        <span>{selectedOption.name}</span>
        <div className="icon" />
      </div>

      <ModalSelector className={isCollapse ? 'modalSelectorCollapsed' : ''}>
        {options.map(option => (
          <a
            key={option.name}
            onClick={() => {
              setSelectedOption(option);
              handleMenu();
            }}
          >
            {option.name}
          </a>
        ))}
      </ModalSelector>
    </Container>
  );
};

export default SelectorTableButton;
