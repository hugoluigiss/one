import styled from 'styled-components';

export const Container = styled.div`
  display: flex;
  margin-left: 10px;
  position: relative;
  .buttonSelector {
    border: 1.2px solid rgba(255, 255, 255, 0.1);
    border-radius: 4px;
    padding: 5px 8px;
    display: flex;
    align-items: center;
    user-select: none;
    cursor: pointer;
    transition: 200ms;

    span {
      color: rgba(255, 255, 255, 0.7);
      font-size: 12px;
      font-weight: 600;
    }
    .icon {
      height: 8px;
      width: 8px;
      margin-left: 4px;
      background-position: center;
      background-size: contain;
      background-repeat: no-repeat;
      background-image: url('../../../assets/icons/arrow-down-icon.svg');
    }
  }
  .buttonSelector:hover {
    border: 1.2px solid rgba(255, 255, 255, 0.1);
    background-color: rgba(255, 255, 255, 0.02);
    transition: 200ms;
  }
`;

export const ModalSelector = styled.div`
  position: absolute;
  top: 28px;
  right: 0;
  background: var(--primary-bg-dark-color);
  width: 140px;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  transition: 200ms all;
  opacity: 0;
  visibility: hidden;
  z-index: 100;

  a {
    color: #fff;
    padding: 12px;
    text-decoration: none;
    font-weight: 600;
    font-size: 12px;
    cursor: pointer;
    border-bottom: solid 1px rgba(255, 255, 255, 0.2);
  }
  a:hover {
    background: var(--secondary-bg-color);
    border-radius: 4px;
  }
  a:last-child {
    border-bottom: none;
  }
  .modalSelectorCollapsed {
    transition: 200ms all;
    opacity: 1;
    visibility: visible;
  }
`;
