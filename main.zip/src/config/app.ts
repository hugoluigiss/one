export default {
  api_url: process.env.REACT_APP_API_URL || 'https://api.onealliance.com.br',
  local_storage_token_key: '@onealliance-partner:token',
} as {
  api_url: string;
  local_storage_token_key: string;
};
