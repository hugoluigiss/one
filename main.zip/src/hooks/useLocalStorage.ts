/* eslint-disable import/prefer-default-export */
import { useCallback, useEffect, useState } from 'react';

export function useLocalStorage<T>(
  key: string,
  defaultValue?: any,
): [T, React.Dispatch<React.SetStateAction<T>>, () => void] {
  const [value, setValue] = useState<T>(() => {
    const jsonValue = localStorage.getItem(key);
    if (jsonValue !== null) return JSON.parse(jsonValue) as T;
    if (typeof defaultValue === 'function') return defaultValue() as T;

    return defaultValue as T;
  });

  useEffect(() => {
    if (value === undefined) return localStorage.removeItem(key);
    return localStorage.setItem(key, JSON.stringify(value));
  }, [key, value]);

  const remove = useCallback(() => {
    setValue(undefined as unknown as T);
  }, []);

  return [value, setValue, remove];
}
