import { useCallback, useEffect, useState } from 'react';
import api from '../services/api';
import { useAuth } from './useAuth';

/* eslint-disable import/prefer-default-export */

interface IFileResponse {
  data?: {
    file_url: string;
    filename: string;
  };
}

export function useUploadFile(): [
  React.Dispatch<React.SetStateAction<File | null>>,
  (
    | {
        file_url: string;
        filename: string;
      }
    | undefined
  ),
  string,
  boolean,
] {
  const [file, setFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState('0%');
  const [uploading, setUploading] = useState(false);
  const { token } = useAuth();

  const [fileInfo, setFileInfo] = useState<{
    file_url: string;
    filename: string;
  }>();

  const handleUpload = useCallback(
    async (toUpload: File) => {
      const data = new FormData();
      data.append('file', toUpload);
      try {
        setUploading(true);
        api.defaults.headers.common.authorization = `Bearer ${token}` || '';
        const response = await api.post<IFileResponse>('/files', data, {
          onUploadProgress: event => {
            setUploadProgress(
              `${Math.round((event.loaded * 100) / event.total)}%`,
            );
          },
        });
        const { data: info } = response.data;
        if (info?.filename) setFileInfo(info);
        setUploading(false);
      } catch {}
    },
    [token],
  );

  useEffect(() => {
    if (!file) return;
    handleUpload(file);
  }, [file, handleUpload]);

  return [setFile, fileInfo, uploadProgress, uploading];
}
