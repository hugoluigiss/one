import {
  SimpleGrid,
  Button,
  FormControl,
  FormLabel,
  HStack,
  Stack,
  Heading,
} from '@chakra-ui/react';
import { Form, Formik, FormikProps } from 'formik';
import { toast } from 'react-toastify';
import { useCallback, useEffect, useState } from 'react';

import axios from 'axios';
import {
  addressSchema,
  IAddressFormData,
} from '../../../../../utils/form-validation-schemas';

import Input from '../../../../../components/Form/Inputs/InputText';
// import { useUploadFile } from '../../../../../hooks/useUploadFile';
import Upload from '../../../../../components/Form/Upload';

import stepProps from '../props';

interface AddressProps {
  cep: string;
  logradouro: string;
  complemento: string;
  bairro: string;
  localidade: string;
  uf: string;
  ibge: string;
  gia: string;
  ddd: string;
  siafi: string;
}

export default function UserAddressDetails({
  nextStep,
  signupData,
  setSignupdata,
}: stepProps) {
  const [filename, setFileName] = useState<string>();

  const [timeoutRef, setTimeoutRef] = useState<number>();
  const [cepApiInfo, setCepApitInfo] = useState<AddressProps>();

  useEffect(() => {
    if (signupData.company_document.status !== 'rejected')
      setFileName(signupData.company_address.file_name);
  }, [signupData]);

  const fetchCepInfo = useCallback(
    (inputValue: string) => {
      if (inputValue.length < 8) return;

      clearTimeout(timeoutRef);
      const timeout = 0;
      window.setTimeout(() => {
        axios
          .get(`https://viacep.com.br/ws/${inputValue}/json/`)
          .then((res: any) => {
            setCepApitInfo(res.data);
          })
          .catch(() => {
            // console.log(err);
          });
      }, 1000);
      setTimeoutRef(timeout);
    },
    [timeoutRef],
  );

  const FormPiece = (
    <Formik
      enableReinitialize
      initialValues={{
        city: cepApiInfo?.localidade || signupData.company_address.city || '',
        complement:
          cepApiInfo?.complemento ||
          signupData.company_address.complement ||
          '',
        district:
          cepApiInfo?.bairro || signupData.company_address.district || '',
        number: signupData.company_address.number || '',
        state: cepApiInfo?.uf || signupData.company_address.state || '',
        street:
          cepApiInfo?.logradouro || signupData.company_address.street || '',
        zip_code: cepApiInfo?.cep || signupData.company_address.zip_code || '',
      }}
      validationSchema={addressSchema}
      onSubmit={(values, actions) => {
        if (!filename) {
          toast.error('Anexe seu comprovante de residência');
          actions.setSubmitting(false);
          return;
        }
        setSignupdata({
          ...signupData,
          company_address: {
            ...values,
            file_name: filename,
            user_id: signupData.company_address.user_id,
          },
        });

        nextStep();
      }}
    >
      {({
        values,
        errors,
        isSubmitting,
        handleChange,
      }: FormikProps<IAddressFormData>) => (
        <Form>
          <SimpleGrid columns={3} spacing={10}>
            <FormControl isRequired w={40}>
              <FormLabel>CEP</FormLabel>
              <Input
                disabled={isSubmitting}
                name="zip_code"
                value={values.zip_code || ''}
                onChange={async e => {
                  handleChange(e);
                  const { value } = e.target;

                  fetchCepInfo(value);
                }}
                placeholder="CEP"
                errorText={errors.zip_code}
              />
            </FormControl>

            <FormControl isRequired>
              <FormLabel>Rua</FormLabel>
              <Input
                disabled={isSubmitting}
                name="street"
                value={values.street}
                onChange={handleChange}
                placeholder="Rua"
                errorText={errors.street}
              />
            </FormControl>

            <FormControl isRequired w="120px">
              <FormLabel>Número</FormLabel>
              <Input
                disabled={isSubmitting}
                name="number"
                value={values.number}
                onChange={handleChange}
                placeholder="Número"
                errorText={errors.number}
              />
            </FormControl>
          </SimpleGrid>

          <SimpleGrid columns={4} spacing={10}>
            <FormControl>
              <FormLabel>Estado</FormLabel>
              <Input
                disabled={!!cepApiInfo?.uf}
                name="state"
                value={values.state || ''}
                onChange={handleChange}
                placeholder="UF"
                errorText={errors.state}
              />
            </FormControl>
            <FormControl isRequired>
              <FormLabel>Cidade</FormLabel>
              <Input
                disabled={!!cepApiInfo?.localidade}
                name="city"
                value={values.city || ''}
                onChange={handleChange}
                placeholder="Cidade"
                errorText={errors.city}
              />
            </FormControl>
            <FormControl isRequired>
              <FormLabel>Bairro</FormLabel>
              <Input
                disabled={isSubmitting}
                name="district"
                value={values.district || ''}
                onChange={handleChange}
                placeholder="Bairro"
                errorText={errors.district}
              />
            </FormControl>

            <FormControl>
              <FormLabel>Complemento</FormLabel>
              <Input
                disabled={isSubmitting}
                name="complement"
                value={values.complement || ''}
                onChange={handleChange}
                errorText={errors.complement}
              />
            </FormControl>
          </SimpleGrid>

          <Stack>
            <span>Comprovante de residência</span>

            <Upload setFileName={setFileName} />
          </Stack>

          <Stack m={4}>
            <Button
              type="submit"
              colorScheme="brandGray"
              alignSelf="center"
              borderRadius="0"
              w="280px"
            >
              Avançar
            </Button>
          </Stack>
        </Form>
      )}
    </Formik>
  );

  return (
    <Stack>
      <Stack alignItems="center">
        <HStack color="white" m={4}>
          <Heading fontSize="lg">Endereço da Empresa</Heading>
        </HStack>
        <Stack maxWidth="603px" color="white">
          {FormPiece}
        </Stack>
      </Stack>
    </Stack>
  );
}
