import { Button, Collapse, Stack } from '@chakra-ui/react';
// import useGet from '../../../../../../hooks/useGet';
import { useHistory } from 'react-router-dom';

import { Container, Header, Content } from './styles';

export default function FinishAccountConfirmation() {
  const history = useHistory();

  const handleSubmit = () => {
    history.push('/');
  };

  return (
    <Container>
      <Content>
        <Header stretched>
          <h3>
            Cadastro concluído com sucesso, você já pode acessar a plataforma
          </h3>
        </Header>
        <Collapse in animateOpacity>
          <Stack m={4}>
            <Button
              onClick={handleSubmit}
              isLoading={false}
              colorScheme="brandGray"
              alignSelf="center"
              borderRadius="0"
              w="280px"
            >
              Avançar
            </Button>
          </Stack>
        </Collapse>
      </Content>
    </Container>
  );
}
