import styled from 'styled-components';
import { ReactComponent as LockColored } from '../../../../../../assets/icons/lockColored.svg';

export const Container = styled.div`
  width: 100%;
`;

export const Header = styled.div<{ stretched?: boolean }>`
  display: flex;
  align-items: flex-end;
  margin-top: 26px;

  margin-bottom: ${props => (props.stretched ? '24px' : '48px')};
`;

export const AvatarContainer = styled.div`
  margin-right: 24px;
`;

export const Content = styled.div<{ justify?: string; maxWidth?: string }>`
  display: flex;
  flex-direction: column;
  justify-content: ${props => props.justify || 'flex-start'};
  max-width: ${props => props.maxWidth || 'unset'};

  h2 {
    font-size: 20px;
    margin-bottom: 10px;
  }
`;

export const Line = styled.div`
  display: flex;
  margin-bottom: 24px;

  > div:not(:last-child) {
    margin-right: 28px;
  }

  > button {
    margin: 0 24px 0 0;
    width: 100%;
    text-transform: none;
    padding: 0;
  }
`;

export const LockIcon = styled(LockColored)`
  stroke: #2b2a7e;
  margin-right: 12px;
`;
