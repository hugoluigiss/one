/* eslint-disable jsx-a11y/label-has-associated-control */
import { Formik, Form, FormikProps } from 'formik';
import { Stack } from '@chakra-ui/react';
import { useEffect } from 'react';
import PropagateLoader from 'react-spinners/PropagateLoader';
import ButtonPrimary from '../../../components/ButtonPrimary';
import InputPassword from '../../../components/Form/Inputs/InputPassword';
import Input from '../../../components/Form/Inputs/InputText';
import Logo from '../../../components/Logo';

import {
  formSignInSchema,
  ISignInFormData,
} from '../../../utils/form-validation-schemas';

import { FormBox, FormLink } from '../styles';
import { useAuth } from '../../../hooks/useAuth';
import usePost from '../../../hooks/usePost';

export default function SignIn(): JSX.Element {
  const { setToken } = useAuth();
  const [{ data, loading }, makePost] = usePost<{ token: string }>(
    '/signin/partner',
  );

  useEffect(() => {
    if (data) {
      setToken(data.token);
    }
  }, [data, setToken]);

  return (
    <>
      <Logo />

      <FormBox>
        <Formik
          initialValues={{ username_or_email: '', password: '' }}
          validationSchema={formSignInSchema}
          onSubmit={(values: ISignInFormData) => makePost({ ...values })}
        >
          {({
            touched,
            errors,
            handleChange,
          }: FormikProps<ISignInFormData>) => (
            <Form>
              <label htmlFor="username_or_email">E-mail ou usuário</label>
              <Input
                disabled={loading}
                name="username_or_email"
                onChange={handleChange}
                placeholder="E-mail ou usuário"
                errorText={
                  touched.username_or_email ? errors.username_or_email : ''
                }
              />

              <label htmlFor="password">Senha</label>
              <InputPassword
                errorText={touched.password ? errors.password : ''}
                disabled={loading}
                name="password"
                onChange={handleChange}
                placeholder="Digite sua senha"
              />
              <Stack mt="16px" alignItems="flex-end">
                <FormLink to="forgot-password">Esqueci a senha</FormLink>
              </Stack>

              <Stack mt="72px">
                <ButtonPrimary type="submit" disabled={loading}>
                  {loading ? (
                    <PropagateLoader color="white" loading />
                  ) : (
                    'ACESSAR'
                  )}
                </ButtonPrimary>
              </Stack>
            </Form>
          )}
        </Formik>
      </FormBox>
    </>
  );
}
