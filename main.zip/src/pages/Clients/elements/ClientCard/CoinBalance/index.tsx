/* eslint-disable react/jsx-wrap-multilines */
import { Text, HStack } from '@chakra-ui/react';
import CurrencyWithIcon from '../../../../../components/Utils/CurrencyWithIcon';
import { CoinsType } from '../../../../../services/apitypes';

function CryptoCard({
  coin,
  balance,
  color = '#fff',
}: {
  coin: CoinsType;
  balance: string;
  color?: string;
}): JSX.Element {
  return (
    <HStack m={0}>
      <CurrencyWithIcon collapsed color={color} iconName={coin} />
      <Text>{balance}</Text>
    </HStack>
  );
}

export default CryptoCard;
