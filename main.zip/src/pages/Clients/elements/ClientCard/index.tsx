import { Avatar, HStack, Stack, Text, Flex, Divider } from '@chakra-ui/react';
import React from 'react';
import { CoinsType, Unilevel } from '../../../../services/apitypes';
// import useGet from '../../../../hooks/useGet';
import CoinBalance from './CoinBalance';
import CardContainer from '../../../../components/CardContainer';
import ScrollDrag from '../../../../components/Utils/ScrollDrag';
import { getColorByCoin } from '../../../../utils/CryptoColors';

interface CardProps {
  userInfo: Unilevel;
  selected?: boolean;
}

const ClientCard: React.FC<CardProps> = ({ userInfo, selected = false }) => {
  // const [{ data: coins }] = useGet<CoinsType[]>('/coins');
  const coins: CoinsType[] = ['USDT', 'BTC', 'ETH', 'BNB'];

  const getBalance = (coin: string): string => {
    if (!userInfo.user.user_downlines_balance) return '0';

    const parsedCoin = coin.toLowerCase();
    return userInfo.user.user_downlines_balance[parsedCoin];
  };

  return (
    <CardContainer
      w="365px"
      pb={0}
      background={selected ? 'transparent' : 'cardBg.500'}
    >
      <Flex flexDirection="column" h="full">
        <HStack className="header" flex={1} pl="25px" color="text.500" mb={4}>
          <Avatar
            name={userInfo.user.personal_document?.first_name}
            size="xl"
          />

          <Stack spacing={0}>
            {userInfo.type !== 'customer' && (
              <Text fontSize="lg">{userInfo.user.username}</Text>
            )}
            <Text fontSize="md">
              Nome: {userInfo.user.personal_document?.first_name}
            </Text>
            <Text fontSize="md">Tel: {userInfo.user.phone_number}</Text>
            <Text fontSize="sm">{userInfo.user.email}</Text>
          </Stack>
        </HStack>

        <Divider borderColor="cardBorder.500" />

        <ScrollDrag my={3}>
          {coins &&
            coins.map(coin => (
              <CoinBalance
                key={coin}
                coin={coin}
                color={getColorByCoin(coin)}
                balance={getBalance(coin)}
              />
            ))}
        </ScrollDrag>
      </Flex>
    </CardContainer>
  );
};

export default ClientCard;
