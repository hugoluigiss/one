import styled from 'styled-components';

export default styled.div`
  .normal {
    width: 365px;
    height: 277px;
  }

  .medium {
    width: 328px;
    height: 249px;
  }

  .small {
    width: 290px;
    height: 220px;
  }

  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;
  text-align: center;
  overflow: hidden;
  position: relative;
  background-color: var(--color-card-primary);
  margin: 0 8px;

  .header {
    padding: 21px 20px 12px 20px;
    display: flex;
    width: 100%;
    height: 100%;

    .avatar {
      margin-right: 16px;
    }

    .headerInfo {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      justify-content: center;
      width: 100%;

      h3 {
        color: #1a1b21;
        font-size: 16px;
        font-weight: 500;
        margin-bottom: 8px;
        text-align: start;
      }
      .normal {
        font-size: 16px;
        width: auto;
        height: auto;
      }

      .medium {
        font-size: 14px;
        width: auto;
        height: auto;
      }

      .small {
        font-size: 14px;
        width: auto;
        height: auto;
      }

      span {
        font-size: 16px;
        color: #a8aab4;
        font-weight: 500;
        margin-bottom: 4px;
      }
    }
  }

  span {
    color: #262629;
    font-size: 12px;
    font-weight: 600;
    b {
      font-weight: 800;
    }
  }

  h2 {
    margin: 16px 0;
    font-weight: 600;
    span {
      font-size: 16px;
      font-weight: 400;
    }
    color: #262629;
    font-size: 26px;
  }

  .bottom {
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    border-top: 1px solid #e9ecef;
    padding: 0 20px;
    padding-top: 12px;

    .line {
      display: flex;
      margin: 6px 0;
      position: relative;

      .planSmallIcon {
        width: 18px;
        height: 18px;
        margin-right: 14px;
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        background-image: url('../../../assets/icons/smallIcon.svg');
      }

      .planSelectIcon {
        width: 18px;
        height: 18px;
        margin-right: 14px;
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        background-image: url('../../../assets/icons/selectIcon.svg');
      }

      p {
        font-size: 16px;
        font-weight: 500;
        color: #7b8195;

        span {
          font-size: 16px;
          font-weight: 600;
        }
      }

      .statusBadge {
        width: 13px;
        height: 13px;
        border-radius: 50%;
        margin-left: 4px;
      }
      .green {
        background: #0e8937;
      }
      .gray {
        background: #7b8195;
      }
      .red {
        background: #e1343e;
      }
    }

    button {
      width: 81px;
      height: 29px;
      font-size: 12px;
      text-transform: none;
      padding: 0;
      margin: auto;
      margin-bottom: 16px;
    }
  }
`;
