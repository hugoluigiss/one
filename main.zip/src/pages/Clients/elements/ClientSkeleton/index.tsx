import { Skeleton, Box } from '@chakra-ui/react';
import React from 'react';

const ClientSkeleton: React.FC = () => {
  return (
    <Box w="365px" h="201px" bgColor="whiteAlpha.800">
      <Skeleton />
    </Box>
  );
};

export default ClientSkeleton;
