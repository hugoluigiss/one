// import ReactFlagsSelect from 'react-flags-select';
import {
  Heading,
  Button,
  // Avatar,
  // FormControl,
  // FormLabel,
  HStack,
  // Skeleton,
  Stack,
  // SimpleGrid,
} from '@chakra-ui/react';
import { Form, Formik, FormikProps } from 'formik';
import { useEffect } from 'react';
import { toast } from 'react-toastify';
import {
  ISignupGuestFormData,
  // IPFFormData,
  // ISignupStep1FormData,
  // pfSchema,
  signupStep1Schema,
} from '../../../../../utils/form-validation-schemas';
import Input from '../../../../../components/Form/Inputs/InputText';
// import Upload from '../../../../../components/Form/Upload';
import { stepPropsVerification } from '../props';
import usePost from '../../../../../hooks/usePost';
import { getMyUnilevel } from '../../../../../services/apitypes';
import useGet from '../../../../../hooks/useGet';

export default function GuestCreation({ nextStep }: stepPropsVerification) {
  const [{ data: myUnilevel }] = useGet<getMyUnilevel>('/unilevel');
  const [{ data, loading }, createGuest] = usePost<{ id: string }>(
    '/signup/guest-account',
  );

  useEffect(() => {
    if (data && data.id) {
      toast.success(
        'Conta criada com sucesso, senha de acesso enviada para o email',
      );
      if (nextStep) nextStep();
    }
  }, [data, nextStep]);

  return (
    <Stack>
      <Stack alignItems="center">
        <HStack color="white" m={4}>
          <Heading fontSize="lg">Informe o e-mail</Heading>
        </HStack>
        <Stack maxWidth="603px" color="white">
          {myUnilevel && (
            <Formik
              initialValues={{ email: '', phone_number: '' }}
              validationSchema={signupStep1Schema}
              onSubmit={values => {
                createGuest({ ...values, indicator_code: myUnilevel.id });
                // setSignupdata({
                //   ...signupData,
                //   indicator_code: myUnilevel.id,
                //   email: values.email,
                // });
              }}
            >
              {({
                touched,
                errors,
                handleChange,
              }: FormikProps<ISignupGuestFormData>) => (
                <Form>
                  <Input
                    disabled={loading}
                    name="email"
                    onChange={handleChange}
                    placeholder="Digite o e-mail do cliente"
                    errorText={touched.email ? errors.email : ''}
                  />
                  <Input
                    disabled={loading}
                    name="phone_number"
                    onChange={handleChange}
                    placeholder="Digite um telefone para contato do cliente"
                    errorText={touched.phone_number ? errors.phone_number : ''}
                  />

                  <Button
                    type="submit"
                    isLoading={loading}
                    colorScheme="brandGray"
                    alignSelf="center"
                    borderRadius="0"
                    w="280px"
                  >
                    ENVIAR
                  </Button>
                </Form>
              )}
            </Formik>
          )}
        </Stack>
      </Stack>
    </Stack>
  );
}
