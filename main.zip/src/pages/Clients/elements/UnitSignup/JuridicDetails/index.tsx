import {
  Text,
  Button,
  FormControl,
  FormLabel,
  Heading,
  HStack,
  Stack,
  SimpleGrid,
} from '@chakra-ui/react';
import { toast } from 'react-toastify';
import { Form, Formik, FormikProps } from 'formik';
import { useCallback, useEffect, useState } from 'react';

import axios from 'axios';

import {
  IPJFormData,
  pjSchema,
} from '../../../../../utils/form-validation-schemas';

import Input from '../../../../../components/Form/Inputs/InputText';

import Upload from '../../../../../components/Form/Upload';
import usePost from '../../../../../hooks/usePost';
import { stepPropsVerification } from '../props';

interface AddressProps {
  CNPJ: string;
  'RAZAO SOCIAL': string;
  'NOME FANTASIA': string;
}

export default function JuridicDetails({
  nextStep,
  setSignupdata,
  signupData,
  type,
}: stepPropsVerification) {
  const [{ data, loading }, checkCNPJ] = usePost<string>('/signup/cnpj');

  useEffect(() => {
    if (data && nextStep) {
      nextStep();
    }
  }, [data, nextStep]);

  const [cnpjFilename, setCnpjFilename] = useState<string>();
  const [corporateFileName, setCorporateFilename] = useState<string>();

  const [timeoutRef, setTimeoutRef] = useState<number>();
  const [CnpjApiInfo, setCnpjApiInfo] = useState<AddressProps>();

  const fetchCnpjInfo = useCallback(
    (inputValue: string) => {
      if (inputValue.length < 14) return;

      clearTimeout(timeoutRef);
      const timeout = window.setTimeout(() => {
        axios
          .get(
            `https://api-publica.speedio.com.br/buscarcnpj?cnpj=${inputValue}`,
          )
          .then((res: any) => {
            setCnpjApiInfo(res.data);
          })
          .catch(() => {
            // console.log(err);
          });
      }, 1000);
      setTimeoutRef(timeout);
    },
    [timeoutRef],
  );

  const FormPiece = (
    <Formik
      enableReinitialize
      initialValues={{
        cnpj: CnpjApiInfo?.CNPJ || '',
        company_name: CnpjApiInfo?.['RAZAO SOCIAL'] || '',
        fantasy_name: CnpjApiInfo?.['NOME FANTASIA'] || '',
      }}
      validationSchema={pjSchema}
      onSubmit={(values, actions) => {
        if (!cnpjFilename || !corporateFileName) {
          toast.error('Selecione seus documentos');
          actions.setSubmitting(false);
          return;
        }
        setSignupdata({
          ...signupData,
          company_document: {
            cnpj: values.cnpj,
            cnpj_file: cnpjFilename,
            social_contract_file: corporateFileName,
            company_name: values.company_name,
            fantasy_name: values.fantasy_name,
          },
        });

        checkCNPJ({ cnpj: values.cnpj, type });
        // addUserInfo({
        //   cnpj: cnpjFilename,
        //   company_name: values.company_name,
        //   social_contract: corporateFileName,
        //   fantasy_name: values.fantasy_name,
        //   value: values.value,
        // });
        // nextStep();
      }}
    >
      {({ values, errors, handleChange }: FormikProps<IPJFormData>) => (
        <Form>
          <SimpleGrid columns={3} spacing={10}>
            <FormControl isRequired>
              <FormLabel>CNPJ</FormLabel>
              <Input
                disabled={loading}
                name="cnpj"
                value={values.cnpj}
                onChange={async e => {
                  if (e.target.value.length > 18) return;

                  const maskedEvent = e;
                  maskedEvent.target.value = e.target.value
                    .replace(/\D/g, '')
                    .replace(
                      /^(\d{0,2})(\d{0,3})(\d{0,3})(\d{0,4})(\d{0,2}$)/,
                      '$1.$2.$3/$4-$5',
                    );

                  handleChange(maskedEvent);
                  const { value } = e.target;

                  fetchCnpjInfo(value.replace(/\D/g, ''));
                }}
                placeholder="Digite o CNPJ"
                errorText={errors.cnpj}
              />
            </FormControl>

            <FormControl isRequired>
              <FormLabel>Razão Social</FormLabel>
              <Input
                disabled={loading}
                name="company_name"
                value={values.company_name}
                onChange={handleChange}
                placeholder="Razão social"
                errorText={errors.company_name}
              />
            </FormControl>

            <FormControl isRequired>
              <FormLabel>Nome Fantasia</FormLabel>
              <Input
                name="fantasy_name"
                disabled={loading}
                value={values.fantasy_name}
                onChange={handleChange}
                placeholder="Nome fantasia"
                errorText={errors.fantasy_name}
              />
            </FormControl>
          </SimpleGrid>

          <SimpleGrid columns={2} spacing={10}>
            <div>
              <span>CNPJ</span>
              <Upload setFileName={setCnpjFilename} />
            </div>
            <div>
              <span>Contrato Social</span>
              <Upload setFileName={setCorporateFilename} />
            </div>
          </SimpleGrid>

          <Text textAlign="center" color="whiteAlpha.600">
            Verificar se consta os CNAEs 123, 456 ou 789
          </Text>

          <Stack m={4}>
            <Button
              type="submit"
              isLoading={loading}
              colorScheme="brandGray"
              alignSelf="center"
              borderRadius="0"
              w="280px"
            >
              Avançar
            </Button>
          </Stack>
        </Form>
      )}
    </Formik>
  );

  return (
    <Stack>
      <Stack alignItems="center">
        <HStack color="white" m={4}>
          <Heading fontSize="lg">Dados da Empresa</Heading>
        </HStack>
        <Stack maxWidth="603px" color="white">
          {FormPiece}
        </Stack>
      </Stack>
    </Stack>
  );
}
