// import ReactFlagsSelect from 'react-flags-select';
import {
  Heading,
  Button,
  // Avatar,
  FormControl,
  FormLabel,
  HStack,
  Stack,
  SimpleGrid,
} from '@chakra-ui/react';
import { toast } from 'react-toastify';
import { Form, Formik, FormikProps } from 'formik';
import { useEffect, useState } from 'react';

import {
  IPFFormData,
  pfSchema,
} from '../../../../../utils/form-validation-schemas';
import usePost from '../../../../../hooks/usePost';

import Input from '../../../../../components/Form/Inputs/InputText';
import Upload from '../../../../../components/Form/Upload';
import { stepPropsVerification } from '../props';

export default function UserDetails({
  nextStep,
  setSignupdata,
  signupData,
  type,
}: stepPropsVerification) {
  const [{ data, loading }, checkCPF] = usePost<string>('/signup/cpf');

  useEffect(() => {
    if (data) {
      if (nextStep) nextStep();
    }
  }, [data, nextStep]);

  const [front, setFront] = useState<string>();
  const [back, setBack] = useState<string>();

  const [selfie, setSelfie] = useState<string>();

  const FormPiece = (
    <Formik
      enableReinitialize
      initialValues={{
        birthdate: signupData.personal_document.birthdate,
        cpf: signupData.personal_document.cpf,
        first_name: signupData.personal_document.first_name,
        last_name: '',
        phone_number: signupData.phone_number,
      }}
      validationSchema={pfSchema}
      onSubmit={(values, actions) => {
        if (!values.birthdate) {
          actions.setSubmitting(false);
          return;
        }
        if (!back || !front || !selfie) {
          toast.error('Selecione seus documentos');
          actions.setSubmitting(false);
          return;
        }

        const nameParts: string[] = values.first_name.split(' ');
        const first_name: string = nameParts.shift() || '';
        const last_name = nameParts.join(' ');
        setSignupdata({
          ...signupData,
          personal_document: {
            birthdate: values.birthdate,
            cpf: values.cpf,
            first_name,
            last_name,
            back,
            selfie,
            front,
          },
          phone_number: values.phone_number,
        });

        checkCPF({ cpf: values.cpf, type });
      }}
    >
      {({
        values,
        errors,
        isSubmitting,
        handleChange,
      }: FormikProps<IPFFormData>) => (
        <Form>
          <SimpleGrid columns={1} spacing={10}>
            <FormControl isRequired>
              <FormLabel>Nome completo</FormLabel>
              <Input
                disabled={isSubmitting}
                name="first_name"
                value={values.first_name}
                onChange={handleChange}
                placeholder="Digite seu nome"
                errorText={errors.first_name}
              />
            </FormControl>
          </SimpleGrid>

          <SimpleGrid columns={3} spacing={10}>
            <HStack>
              <FormControl isRequired>
                <FormLabel>CPF</FormLabel>
                <Input
                  name="cpf"
                  disabled={isSubmitting}
                  value={values.cpf}
                  onChange={async e => {
                    if (e.target.value.length > 15) return;

                    const maskedEvent = e;
                    maskedEvent.target.value = e.target.value
                      .replace(/\D/g, '')
                      .replace(
                        /^(\d{0,3})(\d{0,3})(\d{0,3})(\d{0,2})/,
                        '$1.$2.$3-$4',
                      );

                    handleChange(maskedEvent);
                  }}
                  placeholder="Número do CPF"
                  errorText={errors.cpf}
                />
              </FormControl>
            </HStack>
            <FormControl isRequired>
              <FormLabel>Telefone</FormLabel>
              <Input
                disabled={loading}
                name="phone_number"
                type="tel"
                onChange={async e => {
                  const maskedEvent = e;
                  maskedEvent.target.value = e.target.value
                    .replace(/\D/g, '')
                    .replace(/^(\d{0,2})(\d{0,5})(\d{0,4}$)/, '($1) $2-$3');

                  handleChange(maskedEvent);
                }}
                placeholder="Digite seu telefone"
                errorText={errors.phone_number}
              />
            </FormControl>
            <FormControl isRequired>
              <FormLabel>Nascimento</FormLabel>
              <Input
                name="birthdate"
                type="date"
                disabled={isSubmitting}
                value={values.birthdate}
                onChange={handleChange}
                errorText={errors.birthdate}
              />
            </FormControl>
          </SimpleGrid>

          <SimpleGrid columns={3} spacing={10}>
            <div>
              <span>Documento Frente</span>
              <Upload setFileName={setFront} />
            </div>
            <div>
              <span>Documento Verso</span>
              <Upload setFileName={setBack} />
            </div>
            <div>
              <span>Selfie com documento</span>
              <Upload setFileName={setSelfie} />
            </div>
          </SimpleGrid>

          <Stack m={4}>
            <Button
              type="submit"
              isLoading={loading}
              colorScheme="brandGray"
              alignSelf="center"
              borderRadius="0"
              w="280px"
            >
              Avançar
            </Button>
          </Stack>
        </Form>
      )}
    </Formik>
  );

  return (
    <Stack>
      <Stack alignItems="center">
        <HStack color="white" m={4}>
          <Heading fontSize="lg">Dados Pessoais</Heading>
        </HStack>
        <Stack maxWidth="603px" color="white">
          {FormPiece}
        </Stack>
      </Stack>
    </Stack>
  );
}
