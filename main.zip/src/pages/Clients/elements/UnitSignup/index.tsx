import {
  useDisclosure,
  Button,
  Collapse,
  HStack,
  Stack,
  Text,
  // CloseButton,
} from '@chakra-ui/react';

// import { Step, Steps, useSteps } from 'chakra-ui-steps';
import { useCallback, useEffect, useState } from 'react';
// import { toast } from 'react-toastify';
// import UserAddressDetails from './UserAddressDetails';
// import UserDetails from './UserDetails';
import EmailVerification from './EmailVerification';
// import CodeConfirmation from './CodeConfirmation';
// import JuridicDetails from './JuridicDetails';
// import JuridicAddressDetails from './JuridicAddressDetails';
import { ISignupData } from './props';
import { UnilevelTypes } from '../../../../services/apitypes';
import GuestCreation from './GuestCreation';
// import usePost from '../../../../hooks/usePost';

export default function UnitSignup({
  type,
  canAddConsultant,
}: {
  type: UnilevelTypes;
  canAddConsultant?: boolean;
}) {
  const { isOpen, onToggle } = useDisclosure();
  const { isOpen: openIsConsultant, onToggle: toggleIsConsultant } =
    useDisclosure({ defaultIsOpen: true });
  // const { reset, activeStep } = useSteps({
  //   initialStep: 0,
  // });
  // const [isJuridic, setIsJuridic] = useState(false);
  const [isConsultant, setIsConsultant] = useState(false);
  // const [sendData, setSendData] = useState(false);

  const [signupData, setSignupdata] = useState<ISignupData>({
    email: '',
    code: '',
    indicator_code: '',
    phone_number: '',
    personal_document: {
      back: '',
      front: '',
      selfie: '',
      birthdate: '',
      cpf: '',
      first_name: '',
      last_name: '',
    },
    personal_address: {
      city: '',
      complement: '',
      district: '',
      file_name: '',
      number: '',
      state: '',
      street: '',
      zip_code: '',
    },
    company_address: {
      city: '',
      complement: '',
      district: '',
      file_name: '',
      number: '',
      state: '',
      street: '',
      zip_code: '',
    },
    company_document: {
      company_name: '',
      fantasy_name: '',
      cnpj: '',
      cnpj_file: '',
      social_contract_file: '',
    },
  });

  useEffect(() => {
    if (type === 'root' || type === 'manager') {
      setIsConsultant(true);
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  const handleIsAddingUser = useCallback(
    (newConsultant: boolean) => {
      setIsConsultant(newConsultant);

      toggleIsConsultant();
      onToggle();
    },
    [toggleIsConsultant, onToggle],
  );

  const goBack = useCallback(() => {
    toggleIsConsultant();
    onToggle();
  }, [toggleIsConsultant, onToggle]);

  // const handleSelectClientType = useCallback(
  //   (juridic: boolean) => {
  //     // if (juridic) setIsJuridic(juridic);

  //     toggleSteps();
  //   },
  //   [toggleSteps],
  // );

  const getTypeToSignup = (
    indicatorType: string,
    signAsConsultant: boolean,
  ): UnilevelTypes => {
    if (indicatorType === 'root') return 'manager';
    if (indicatorType === 'manager') return 'consultant';
    if (signAsConsultant) return 'consultant';

    return 'customer';
  };

  const getTextByType = (accType: string) => {
    if (accType === 'root') return 'Cadastrar Unidade';
    if (accType === 'manager') return 'Cadastrar Consultor';

    return 'Cadastrar Locador';
  };

  return (
    <>
      <Collapse in={!isOpen}>
        <HStack w="full" justifyContent="center">
          {canAddConsultant && type === 'consultant' ? (
            <Collapse in={openIsConsultant}>
              <Stack alignItems="center">
                <Text color="white">
                  Deseja cadastrar um Locador ou um Consultor?
                </Text>
                <HStack>
                  <Button
                    colorScheme="brandGray"
                    onClick={() => handleIsAddingUser(false)}
                  >
                    Locador
                  </Button>
                  <Button
                    colorScheme="brandGray"
                    onClick={() => handleIsAddingUser(true)}
                  >
                    Consultor
                  </Button>
                </HStack>
              </Stack>
            </Collapse>
          ) : (
            <Button mt={4} onClick={onToggle} colorScheme="brandGray">
              {getTextByType(type)}
            </Button>
          )}
        </HStack>
      </Collapse>
      <Collapse in={isOpen} animateOpacity>
        <Stack mt={8} color="white">
          {isConsultant && (
            <EmailVerification
              setSignupdata={setSignupdata}
              signupData={signupData}
              type={getTypeToSignup(type, isConsultant)}
            />
          )}
          {!isConsultant && (
            <GuestCreation
              setSignupdata={setSignupdata}
              signupData={signupData}
              type={getTypeToSignup(type, isConsultant)}
            />
          )}
          <Stack mt={4}>
            <Button variant="link" onClick={goBack}>
              Voltar
            </Button>
          </Stack>
        </Stack>
      </Collapse>
    </>
  );
}
