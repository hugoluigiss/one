/* eslint-disable no-nested-ternary */
/* eslint-disable react/jsx-curly-newline */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import { CopyIcon } from '@chakra-ui/icons';
import {
  // Heading,
  Stack,
  Text,
  HStack,
  Button,
  // InputGroup,
  // InputLeftElement,
  // Input,
} from '@chakra-ui/react';
// import { useState } from 'react';
import ScrollContainer from 'react-indiana-drag-scroll';
import { toast } from 'react-toastify';
import useGet from '../../hooks/useGet';
import {
  getMyUnilevel,
  getMyPermissions,
  Unilevel,
} from '../../services/apitypes';
import ClientCard from './elements/ClientCard';
import ClientSkeleton from './elements/ClientSkeleton';
import UnitSignup from './elements/UnitSignup';

import Scroll from './styles';

interface SelectionsProps {
  manager: string | undefined;
  consultant: string | undefined;
}

export default function Clients() {
  const [{ data: indication }] = useGet<getMyPermissions[]>(
    '/profile/indication_permissions',
  );
  const [{ data: myUnilevel }] = useGet<getMyUnilevel>('/unilevel');

  const [{ data: manager, loading: loadingManagers }] = useGet<{
    id: string;
    user: {
      username: string;
    };
    directs: Unilevel[];
  }>('/unilevel/directs', { type: 'manager' });

  const [
    { data: consultant, loading: loadingConsultants },
    refetchConsultants,
  ] = useGet<{
    id: string;
    user: {
      username: string;
    };
    directs: Unilevel[];
  }>('/unilevel/directs', { type: 'consultant' });

  const [{ data: customer, loading: loadingCustomers }, refetchCustomers] =
    useGet<{
      id: string;
      user: {
        username: string;
      };
      directs: Unilevel[];
    }>('/unilevel/directs', { type: 'customer' });

  // const [selections, setSelections] = useState<SelectionsProps>({
  //   manager: '',
  //   consultant: '',
  // });

  const copyUserLink = (link: string): void => {
    navigator.clipboard.writeText(link);
    toast.info('Link copiado com sucesso!');
  };

  // const getTitleLabel = (): string => {
  //   const title =
  //     myUnilevel && myUnilevel.show_consultants ? 'Consultores' : 'Locadores';

  //   return myUnilevel && myUnilevel.show_managers ? 'UNIDADES' : title;
  // };

  return (
    <Stack spacing="29px">
      <HStack justifyContent="space-between">
        {/* <Heading color="whiteAlpha.800">{getTitleLabel()}</Heading> */}

        {/* <HStack>
          <InputGroup>
            <InputLeftElement pointerEvents="none">
              <SearchIcon color="gray.300" />
            </InputLeftElement>
            <Input
              type="username"
              placeholder="Buscar"
              color="white"
              background="transparent"
            />
          </InputGroup>
          <Button colorScheme="brandGray">Ok</Button>
        </HStack> */}
      </HStack>

      {manager && manager.directs.length > 0 && (
        <Stack color="white">
          <HStack>
            <Text>UNIDADES</Text>
          </HStack>
          <Scroll>
            <ScrollContainer horizontal vertical={false} className="scroll">
              <HStack spacing="24px">
                {manager &&
                  manager.directs.map(direct => (
                    <div
                      key={direct.id}
                      onClick={() => {
                        refetchConsultants(s => ({
                          ...s,
                          user_id: direct.user_id,
                        }));
                        refetchCustomers(s => ({
                          ...s,
                          user_id: direct.user_id,
                        }));
                        // if (myUnilevel.type === 'consultant') return;
                        // selectManager({ user_id: direct.id });
                        // selectConsultant({ user_id: '' });
                        // setSelections({ manager: direct.id, consultant: '' });
                      }}
                    >
                      <ClientCard userInfo={direct} selected />
                    </div>
                  ))}
              </HStack>
            </ScrollContainer>
          </Scroll>
        </Stack>
      )}
      {loadingManagers && <ClientSkeleton />}

      {consultant && consultant.directs.length > 0 && (
        <Stack color="white">
          <HStack>
            <Text fontSize="lg" fontWeight="700">
              {`CONSULTORES DE ${consultant?.user.username}`}
            </Text>
          </HStack>
          <Scroll>
            <ScrollContainer horizontal vertical={false} className="scroll">
              <HStack spacing="24px">
                {consultant &&
                  consultant.directs.map(direct => (
                    <div
                      key={direct.id}
                      onClick={() => {
                        // refetchConsultants(s => ({
                        //   ...s,
                        //   user_id: direct.user_id,
                        // }));
                        refetchCustomers(s => ({
                          ...s,
                          user_id: direct.user_id,
                        }));
                        // selectConsultant({ user_id: direct.id });
                        // setSelections(state => ({
                        //   manager: state.manager,
                        //   consultant: direct.id,
                        // }));
                      }}
                    >
                      <ClientCard userInfo={direct} selected />
                    </div>
                  ))}
              </HStack>
            </ScrollContainer>
          </Scroll>

          {/* {myUnilevel &&
            indication &&
            directs &&
            directs[0]?.type !== 'manager' && (
              <UnitSignup
                type={myUnilevel.type}
                canAddConsultant={
                  indication.filter(
                    permission => permission.type === 'consultant',
                  )[0]?.has_permission
                }
              />
            )} */}
        </Stack>
      )}
      {loadingConsultants && <ClientSkeleton />}

      {/* {myUnilevel &&
        consultants?.length === 0 &&
        myUnilevel.type === 'manager' && (
          <Stack color="white">
            <HStack>
              <Text fontSize="lg" fontWeight="700">
                CONSULTORES
              </Text>
            </HStack>

            {myUnilevel &&
              indication &&
              consultants &&
              consultants[0]?.type !== 'consultant' && (
                <UnitSignup
                  type={myUnilevel.type}
                  canAddConsultant={
                    indication.filter(
                      permission => permission.type === 'consultant',
                    )[0]?.has_permission
                  }
                />
              )}
          </Stack>
        )} */}

      {myUnilevel && (
        <Stack color="white">
          <HStack>
            <Text fontSize="lg" fontWeight="700">
              {`LOCADORES DE ${customer?.user.username}`}
            </Text>
            {myUnilevel.type === 'consultant' && (
              <Button
                colorScheme="brandGray"
                rightIcon={<CopyIcon />}
                onClick={() => copyUserLink(myUnilevel.indication_link || '')}
              >
                Copiar Link
              </Button>
            )}
          </HStack>
          <Scroll>
            <ScrollContainer horizontal vertical={false} className="scroll">
              <HStack spacing="24px">
                {customer &&
                  customer.directs.map(direct => (
                    <div key={direct.id}>
                      <ClientCard userInfo={direct} />
                    </div>
                  ))}
              </HStack>
            </ScrollContainer>
          </Scroll>

          {/* {myUnilevel &&
            indication &&
            consultants &&
            consultants[0]?.type !== 'consultant' && (
              <UnitSignup
                type={myUnilevel.type}
                canAddConsultant={
                  indication.filter(
                    permission => permission.type === 'consultant',
                  )[0]?.has_permission
                }
              />
            )} */}
        </Stack>
      )}
      {loadingCustomers && <ClientSkeleton />}

      {myUnilevel && indication && (
        <UnitSignup
          type={myUnilevel.type}
          canAddConsultant={
            indication.filter(permission => permission.type === 'consultant')[0]
              ?.has_permission
          }
        />
      )}

      {/* {myUnilevel &&
        customers?.length === 0 &&
        myUnilevel.type === 'consultant' && (
          <Stack color="white">
            <HStack>
              <Text fontSize="lg" fontWeight="700">
                Locadores
              </Text>
              <Button
                colorScheme="brandGray"
                rightIcon={<CopyIcon />}
                onClick={() => copyUserLink(myUnilevel.indication_link || '')}
              >
                Copiar Link
              </Button>
            </HStack>

            {myUnilevel &&
              indication &&
              consultants &&
              consultants[0]?.type !== 'consultant' && (
                <UnitSignup
                  type={myUnilevel.type}
                  canAddConsultant={
                    indication.filter(
                      permission => permission.type === 'consultant',
                    )[0]?.has_permission
                  }
                />
              )}
          </Stack>
        )} */}
    </Stack>
  );
}
