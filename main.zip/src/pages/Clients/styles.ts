import styled from 'styled-components';

export default styled.div`
  .scroll {
    display: flex;
    flex-direction: row;
  }
`;
