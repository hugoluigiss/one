/* eslint-disable jsx-a11y/control-has-associated-label */
/* eslint-disable import/no-duplicates */
import { useEffect, useState } from 'react';
// import { MdCancel, MdDownload } from 'react-icons/md';
// import formatDistance from 'date-fns/formatDistance';
// import formatDistanceToNow from 'date-fns/formatDistanceToNow';
// import { ptBR } from 'date-fns/locale';

// import { useTranslation } from 'react-i18next';
// import { DatePicker, LocalizationProvider } from '@mui/lab';
// import ptLocale from 'date-fns/locale/pt-BR';
// import AdapterDateFns from '@mui/lab/AdapterDateFns';
// import { TextFieldProps, TextField } from '@mui/material';
import { HStack, Box, Heading, Stack } from '@chakra-ui/react';
import { useParams } from 'react-router-dom';
import DateWithHour from '../../../../components/Utils/DateWithHour';
// import ButtonPrimary from '../../../../components/ButtonPrimary';
// import DownloadIcon from '../UtilsComponents/DownloadIcon';
// import SelectorTableButton from '../../../../components/Utils/SelectorTableButton';

// import { formatPrice, formatAmount } from '~/utils/format';

import { Container, SeeMoreButton } from './styles';
import CurrencyWithIcon from '../../../../components/Utils/CurrencyWithIcon';
import useGet from '../../../../hooks/useGet';
import { CoinsType, ContractType } from '../../../../services/apitypes';
import ButtonPrimary from '../../../../components/ButtonPrimary';
import { getColorByCoin } from '../../../../utils/CryptoColors';
import ScrollDrag from '../../../../components/Utils/ScrollDrag';
import { formatPrice } from '../../../../utils/format';
// import DateWithoutHour from '../../../../components/Utils/DateWithoutHour';

const limit = 10000;
interface RouteParams {
  coinParam: CoinsType;
}

export default function ContractsTable() {
  const { coinParam } = useParams<RouteParams>();
  const [coinFilter, setCoinFilter] = useState<CoinsType | undefined>();
  // const [{ data: coins, loading }] = useGet<CoinsType[]>('/customer/coins');
  const coins = ['USDT', 'BTC', 'ETH', 'BNB'];

  const [{ data }, setParams, params] = useGet<{
    count: string;
    applications: ContractType[];
  }>('/customer/application/partner', {
    limit,
    offset: 0,
    coin: coinParam || coinFilter || '',
  });

  const [contracts, setContracts] = useState<ContractType[]>([]);

  const selectCoin = (coin: CoinsType): void => {
    setContracts([]);
    setCoinFilter(state => (state === coin ? undefined : coin));
    if (coinFilter === coin) setParams({ limit, offset: 0 });
  };

  useEffect(() => {
    if (data) setContracts(t => [...t, ...data.applications]);
  }, [data]);

  useEffect(() => {
    if (coinFilter) {
      setParams({ limit, offset: 0, coin: coinFilter });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [coinFilter]);

  const getType = (type: string) => {
    if (type === 'one_year') return '1 Ano';
    if (type === 'two_years') return '2 Anos';

    return type;
  };

  return (
    <Container>
      <div className="header">
        <h3>Contratos</h3>
        <div className="headerinline">
          <HStack spacing={4}>
            {coins &&
              coins.map(coin => (
                <Box key={coin} onClick={() => selectCoin(coin as CoinsType)}>
                  <CurrencyWithIcon
                    collapsed
                    iconName={coin.toLowerCase() as CoinsType}
                    currency={coin}
                    color={
                      coinFilter === coin
                        ? getColorByCoin(coin as CoinsType)
                        : '#9B9B9B'
                    }
                  />
                </Box>
              ))}
            {/* <Text color="#979daf">ATIVO</Text>
            <Select
              color="white"
              size="sm"
              onChange={v => {
                setContracts([]);
                setParams(s => ({ ...s, coin: v.target.value, offset: 0 }));
              }}
            >
              <option label="..." />
              {coins &&
                coins.map(coin => (
                  <option key={coin} label={coin}>
                    {coin}
                  </option>
                ))}
            </Select> */}
          </HStack>
          {/* <HStack>
            <Text color="white">MÊS</Text>
            <Select size="sm" placeholder="ABR - 2022" color="white" />
          </HStack> */}
          {/* <LocalizationProvider dateAdapter={AdapterDateFns} locale={ptLocale}>
            <DatePicker
              className="monthPicker"
              views={['year', 'month']}
              minDate={new Date('2018-03-01')}
              maxDate={new Date()}
              value={value}
              onChange={(newValue: React.SetStateAction<Date | null>) => {
                setValue(newValue);
              }}
              renderInput={(
                params: JSX.IntrinsicAttributes & TextFieldProps,
              ) => <TextField {...params} helperText={null} size="small" />}
            />
          </LocalizationProvider> */}
        </div>
      </div>

      <ScrollDrag className="tableContainer">
        <table>
          <thead>
            <tr>
              <th className="sm" />
              <th>Cliente</th>
              <th>Email</th>
              {/* {myUnilevel?.type !== 'consultant' && <th>Consultor</th>} */}
              <th>Assinatura do Cliente</th>
              {/* <th>Assinatura da Empresa</th> */}
              <th>Tipo</th>
              <th>Valor</th>
              {/* <th>Vigência</th> */}
            </tr>
          </thead>
          <div className="table-scroll">
            <tbody>
              {contracts &&
                contracts.map(transaction => (
                  <tr key={transaction.sequence}>
                    <td className="sm">
                      <CurrencyWithIcon
                        iconName={transaction.coin.toLowerCase() as CoinsType}
                        currency={transaction.coin}
                        color={getColorByCoin(transaction.coin as CoinsType)}
                      />
                    </td>
                    <td>
                      {transaction.user.personal_document?.first_name}{' '}
                      {transaction.user.personal_document?.last_name}
                    </td>
                    <td>{transaction.user.email}</td>
                    {/* {myUnilevel?.type !== 'consultant' && (
                      <td>Nome de Consultor</td>
                    )} */}
                    <td>
                      <DateWithHour dateValue={transaction.signed_at} />
                    </td>
                    {/* <td>
                      {transaction.admin_signed_at ? (
                        <DateWithHour dateValue={transaction.admin_signed_at} />
                      ) : (
                        'Sem informação'
                      )}
                    </td> */}
                    <td>{getType(transaction?.type)}</td>
                    <td>{formatPrice(Number(transaction?.amount || '0'))}</td>
                    {/* <td>
                      {`${transaction.created_at.getDate()}/${transaction.created_at.getMonth()}/${
                        transaction.created_at.getFullYear() + 1
                      }`}
                    </td> */}
                  </tr>
                ))}
            </tbody>
          </div>
        </table>
      </ScrollDrag>
      {data && data.count === '0' && (
        <Stack alignItems="center" color="text.500">
          <Heading>
            Nenhum contrato encontrado {coinFilter && `para ${coinFilter}`}
          </Heading>
        </Stack>
      )}
      {data && Number(data.count) >= limit && (
        <SeeMoreButton>
          <ButtonPrimary
            onPress={() => {
              setParams({ ...params, offset: Number(params.offset) + 1 });
            }}
          >
            Ver mais
          </ButtonPrimary>
        </SeeMoreButton>
      )}
    </Container>
  );
}
