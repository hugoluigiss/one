import styled from 'styled-components';

export const Container = styled.div`
  .header {
    border-bottom: 1px solid rgba($color: #fff, $alpha: 0.08);
    box-sizing: border-box;
    display: flex;
    align-items: center;
    padding: 0 12px;
    position: sticky;
    top: 0;
    display: flex;
    justify-content: space-between;
    z-index: 4;
    margin-bottom: 24px;

    h3 {
      color: #fff;
      font-weight: 500;
      text-transform: uppercase;
      font-size: 14px;
    }

    .headerinline {
      display: flex;
    }
  }

  .table-scroll {
    overflow-y: auto;
    position: relative;

    padding-right: 12px;
  }
  .tableContainer {
    height: 100%;
    box-sizing: content-box;
    overflow-x: auto;
    overflow-y: hidden;
    position: relative;

    .badge {
      color: #656464;
      padding: 6px 8px;
      border-radius: 27px;
      margin-right: 4px;
    }

    .up {
      background-size: contain;
      background-repeat: no-repeat;
      background-position: center;
      background-image: url('./icons/chart-up.svg');
    }

    .down {
      background-size: contain;
      background-repeat: no-repeat;
      background-position: center;
      background-image: url('./icons/chart-down.svg');
    }

    .link {
      margin: auto;
      width: 20px;
      height: 14px;
      background-size: contain;
      background-repeat: no-repeat;
      background-position: center;
      background-image: url('./icons/link.svg');
    }

    table {
      color: #fbfbfb;
      border-collapse: separate;
      border-spacing: 0 0.7em;

      min-width: 1400px;
    }
    thead,
    tbody tr {
      display: table;
      table-layout: fixed;
      width: 100%;
    }
    th {
      background: transparent;
      color: #fbfbfb;
      font-size: 14px;
      text-transform: uppercase;
    }
    tr {
      background-color: transparent;
    }
    tbody {
      display: block;
      max-height: 896px;

      padding-top: 16px;
      padding-bottom: 40px;

      tr td:first-child {
        border-top-left-radius: 10px;
        border-bottom-left-radius: 10px;

        border: none;
        background: transparent;
      }
      tr td:nth-child(2) {
        border-top-left-radius: 10px;
        border-bottom-left-radius: 10px;

        border-left: solid 1px #3d404b;
      }
      tr td:last-child {
        border-top-right-radius: 10px;
        border-bottom-right-radius: 10px;

        border-right: solid 1px #3d404b;
        margin-right: 8px;
      }
    }
    td {
      position: relative;
      line-height: unset;
      border-top: solid 1px #3d404b;
      border-bottom: solid 1px #3d404b;
      background: #0f0f12;

      height: 52px;
      margin-bottom: 16px;
    }
  }

  .sm {
    width: 120px;
  }
`;

export const SeeMoreButton = styled.div`
  display: flex;
  justify-content: center;
  align-self: center;
  padding: 22px 0;
`;

export const TopBlur = styled.div`
  top: 60px;
  width: calc(100% - 12px);
  height: 40px;
  position: absolute;
  background: linear-gradient(180deg, #1f2128, #1f2128, #f5f5f500);
  margin: 0 !important;
`;

export const BottomBlur = styled(TopBlur)`
  top: unset;
  bottom: 0;
  background: linear-gradient(0deg, #1f2128, #1f2128, #f5f5f500);
`;
