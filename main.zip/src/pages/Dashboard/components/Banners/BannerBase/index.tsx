import { BannerProps } from '../props';
import { Container, Image, TextContent } from '../styles';

function BannerBase({ image, title, subtitle }: BannerProps): JSX.Element {
  return (
    <Container>
      {image && <Image url={image} />}
      <TextContent>
        <h3>{title}</h3>
        <h4>{subtitle}</h4>
      </TextContent>
    </Container>
  );
}

export default BannerBase;
