import { BannerProps } from '../props';
import { Container } from '../styles';

function BannerBase({ image, link }: BannerProps): JSX.Element {
  const handleClick = () => {
    window.open(link, '_blank');
  };

  return <Container image={image} onClick={handleClick} />;
}

export default BannerBase;
