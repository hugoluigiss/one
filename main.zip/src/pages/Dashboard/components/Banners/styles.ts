import styled from 'styled-components';
import bannerimg from '../../../../assets/images/banner.png';

interface ContainerProps {
  image?: string;
}
export const Container = styled.div<ContainerProps>`
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;

  cursor: pointer;

  background-size: cover;
  background-repeat: no-repeat;
  background-position: top;
  background-image: url(${props => props.image || bannerimg});

  @media (max-width: 1280px) {
    overflow-y: auto;
  }

  @media (max-width: 727px) {
    flex-wrap: wrap;
  }
`;

interface ImageProps {
  url?: string;
}
export const Image = styled.div<ImageProps>`
  width: 387px;
  height: 100%;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  background-image: url(${props => props.url || bannerimg});
`;

export const TextContent = styled.div`
  width: 100%;
  max-width: 480px;
  margin-left: 27px;

  h3 {
    font-family: 'Poppins';

    font-size: 36px;
    font-weight: 400;
    line-height: 41px;
    color: #fff;

    margin: 0 0 18px 0;

    span {
      color: #ff7a00;
    }
  }

  h4 {
    font-family: 'Lato';
    font-weight: 300;
    font-size: 24px;
    line-height: 29px;
    color: #ffffff;

    margin: 0;
  }
`;
