import { useCallback, useEffect, useState } from 'react';
import Axios from 'axios';

import {
  create,
  setTheme,
  XYChart,
  DateAxis,
  ValueAxis,
  XYCursor,
  animatedTheme,
  darkTheme,
  LineSeries,
  color,
} from '../../../../plugins/amcharts4';

import { ChartContainer } from './styles';
import colors from '../../../../utils/CryptoColors';

interface IChartData {
  date: string;
  value: number;
}

interface IParams {
  interval: string;
  value: number;
  coins: any[];
}

export default function Chart({ interval, value, coins }: IParams) {
  const [newChart, setNewChart] = useState<any[][]>([]);
  const [chartData, setChartData] = useState<any[]>([]);

  const getData = useCallback(
    async (url: string, coin: any, index: number) => {
      const response = await Axios.get(url);
      const nChart = response.data.Data.Data.map((item: any) => {
        return {
          [coin]: (item.close / item.open - 1.0) * 100,
          date: new Date(item.time * 1000),
        };
      });

      const allNewData = newChart;
      allNewData[index] = nChart;

      setNewChart(allNewData);
      const merge: any[] = [];

      if (allNewData.length > 0 && allNewData.length === coins.length) {
        for (let i = 0; i < allNewData.length; i += 1) {
          for (let j = 0; j < allNewData[i].length; j += 1) {
            merge[j] = {
              ...allNewData[i][j],
              ...merge[j],
            };
          }
        }

        setChartData(merge);
      }
    },
    [coins.length, newChart],
  );

  useEffect(() => {
    coins.forEach((coin, i) => {
      const url = `https://min-api.cryptocompare.com/data/v2/histo${interval}?fsym=${coin}&tsym=BRL&limit=${value}${
        value === 2000 ? '&allData=true' : ''
      }`;

      getData(url, coin, i);
    });
  }, [interval, value, coins, getData]);

  useEffect(() => {
    let chart: XYChart;
    function createGraph(): void {
      // Themes begin
      setTheme(animatedTheme);
      setTheme(darkTheme);
      // Create chart instance
      chart = create('coin-chart', XYChart);

      // Add data
      chart.data = chartData;

      chart.background.opacity = 0;
      // Create axes
      const categoryAxis = chart.xAxes.push(new DateAxis());
      categoryAxis.renderer.grid.template.disabled = true;
      categoryAxis.tooltipDateFormat =
        interval === 'hour' ? 'HH:mm' : 'dd/MM/yyyy';

      // Create value axis
      const valueAxis = chart.yAxes.push(new ValueAxis());
      // valueAxis.renderer.labels.template.disabled = true;
      valueAxis.renderer.grid.template.disabled = true;
      valueAxis.cursorTooltipEnabled = false;

      coins.map((coin, i) => {
        // Create series
        const series = chart.series.push(new LineSeries());
        series.smoothing = 'monotoneX';
        series.dataFields.valueY = coin;
        series.dataFields.dateX = 'date';
        series.strokeWidth = 2;
        series.tooltipText = `${coin}: {valueY}%[/]`;
        series.stroke = color(colors[i]);

        if (series.tooltip) {
          series.tooltip.getFillFromObject = false;
          series.tooltip.background.fill = color(colors[i]);
        }

        return [];
      });

      chart.cursor = new XYCursor();
    }

    if (chartData.length > 0) createGraph();

    return () => {
      if (chart) chart.dispose();
    };
  }, [chartData, coins, interval]);

  // console.log(loading);
  // if (loading) return <div />;

  return <ChartContainer id="coin-chart" />;
}
