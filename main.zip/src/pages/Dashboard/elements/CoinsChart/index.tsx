/* eslint-disable jsx-a11y/iframe-has-title */
import React from 'react';

import { Container, ContentContainer, Content } from './styles';

const CoinsCarousel: React.FC = () => {
  return (
    <Container>
      <ContentContainer>
        <Content>
          <iframe
            src="https://widget.coinlib.io/widget?type=chart&theme=dark&coin_id=859&pref_coin_id=3315"
            width="100%"
            height="536px"
            scrolling="auto"
            marginWidth={0}
            marginHeight={0}
            frameBorder="0"
          />
        </Content>
      </ContentContainer>
    </Container>
  );
};

export default CoinsCarousel;
