import styled from 'styled-components';

export const Container = styled.div`
  width: 100%;
  padding: 8px 10px;
  // background-color: #1d2330;
  border: none;

  display: flex;
  justify-content: flex-start;
  align-items: center;
  overflow-x: hidden;
  overflow-y: hidden;
`;

export const ContentContainer = styled.div`
  height: 470px;
  background-color: #1d2330;
  overflow: hidden;
  box-sizing: border-box;
  border: none;
  border-radius: 4px;
  text-align: right;
  line-height: 14px;
  font-size: 12px;
  font-feature-settings: normal;
  text-size-adjust: 100%;
  padding: 1px;
  padding: 0px;
  margin: 0px;
  width: 100%;
`;

export const Content = styled.div`
  height: 540px;
  padding: 0px;
  margin: 0px;
  width: 100%;

  iframe {
    border: 0;
    margin: 0;
    padding: 0;
  }
`;
