import { Box } from '@chakra-ui/react';
import { Container } from './styles';
import OscillationChart from './components/OscillationChart';
import CardContainer from '../../components/CardContainer';
// import CryptoNews from './elements/CryptoNews';

export default function Dashboard() {
  return (
    <Container spacing="41px">
      <CardContainer>
        <Box>
          <OscillationChart />
        </Box>
      </CardContainer>

      {/* <CardContainer>
        <Stack direction="row" justify="space-between">
          <Heading size="md" color="#fff">
            CRIPTONOTÍCIAS
          </Heading>
        </Stack>

        <Box mt="21px">
          <CryptoNews />
        </Box>
      </CardContainer> */}
    </Container>
  );
}
