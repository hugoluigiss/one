export interface ISignupData {
  email?: string;
  code?: string;
  phone_number?: string;
  indicator_code?: string;
  personal_document: {
    front: string;
    back: string;
    selfie: string;
    birthdate: string;
    first_name: string;
    last_name: string;
    cpf: string;
    user_id?: string;
    status?: string;
  };
  personal_address: {
    city: string;
    district: string;
    number: string;
    state: string;
    street: string;
    zip_code: string;
    complement: string;
    file_name: string;
    user_id?: string;
    status?: string;
  };
  company_document: {
    cnpj: string;
    company_name: string;
    fantasy_name: string;
    cnpj_file: string;
    social_contract_file: string;
    user_id?: string;
    status?: string;
  };
  company_address: {
    city: string;
    district: string;
    number: string;
    state: string;
    street: string;
    zip_code: string;
    complement: string;
    file_name: string;
    user_id?: string;
    status?: string;
  };
}

export interface IUpdateData {
  user_id: string;
  status: string;
  personal_document_approved: boolean;
  company_document_approved: boolean;
  personal_address_approved: boolean;
  company_address_approved: boolean;
  personal_document: {
    user_id: string;
    status: string;
    first_name: string;
    last_name: string;
    cpf: string;
    birthdate: string;
    selfie: string;
    back: string;
    front: string;
    back_url: string;
    front_url: string;
    selfie_url: string;
  };
  personal_address: {
    user_id: string;
    zip_code: string;
    state: string;
    city: string;
    district: string;
    street: string;
    number: string;
    complement: string;
    file_name: string;
    status: string;
    type: string;
    file_url: string;
  };
  company_document: {
    user_id: string;
    status: string;
    cnpj: string;
    company_name: string;
    fantasy_name: string;
    cnpj_file: string;
    cnpj_url: string;
    social_contract_file: string;
    social_contract_url: string;
  };
  company_address: {
    user_id: string;
    zip_code: string;
    state: string;
    city: string;
    district: string;
    street: string;
    number: string;
    complement: string;
    file_name: string;
    status: string;
    type: string;
    file_url: string;
  };
}

export default interface stepProps {
  nextStep: () => void;
  setSignupdata: (d: ISignupData) => void;
  signupData: ISignupData;
}

export interface stepUpdateProps {
  nextStep: () => void;
  setSignupdata: (d: IUpdateData) => void;
  signupData: IUpdateData;
}
