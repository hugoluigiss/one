import { Stack, Heading, HStack } from '@chakra-ui/react';
import Logo from '../../components/Logo';
import useGet from '../../hooks/useGet';
import { User } from '../../services/apitypes';
import Profile from '../Profile';
import PartnerConfirmation from './elements/PartnerConfirmation';

export default function Layout() {
  const [{ data: me }] = useGet<User>('/profile/me');

  if (me?.account.status === 'approved') return <Profile />;

  return (
    <Stack alignItems="center" spacing={29} color="white">
      <Logo />

      <Heading>Confirmação de documentos</Heading>
      <HStack justifyContent="center" w="full" spacing={29}>
        <PartnerConfirmation />
        {/* <LoadingPage /> */}
      </HStack>
    </Stack>
  );
}
