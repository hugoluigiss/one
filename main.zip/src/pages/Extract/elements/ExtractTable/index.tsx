/* eslint-disable jsx-a11y/control-has-associated-label */
import React, { useEffect, useState } from 'react';

// import { useTranslation } from 'react-i18next';
// import { DatePicker, LocalizationProvider } from '@mui/lab';
// import ptLocale from 'date-fns/locale/pt-BR';
// import AdapterDateFns from '@mui/lab/AdapterDateFns';
// import { TextFieldProps, TextField } from '@mui/material';
import { HStack, IconButton, Box, Stack, Heading } from '@chakra-ui/react';
import { GoLink } from 'react-icons/go';
import DateWithHour from '../../../../components/Utils/DateWithHour';
// import ButtonPrimary from '../../../../components/ButtonPrimary';
// import DownloadIcon from '../UtilsComponents/DownloadIcon';
// import SelectorTableButton from '../../../../components/Utils/SelectorTableButton';

// import { formatPrice, formatAmount } from '~/utils/format';

import { Container, SeeMoreButton } from './styles';
import CurrencyWithIcon from '../../../../components/Utils/CurrencyWithIcon';
import useGet from '../../../../hooks/useGet';
import { BalanceTransfer, CoinsType } from '../../../../services/apitypes';
import ButtonPrimary from '../../../../components/ButtonPrimary';
import ScrollDrag from '../../../../components/Utils/ScrollDrag';
import { getColorByCoin } from '../../../../utils/CryptoColors';

const limit = 5;

const ExtractTable: React.FC = () => {
  // const [{ data: coins }] = useGet<CoinsType[]>('/coins');
  const coins = ['USDT', 'BTC', 'ETH', 'BNB'];
  const [{ data }, setParams, params] = useGet<BalanceTransfer[]>(
    '/balance/statement',
    {
      limit: 10,
      offset: 0,
    },
  );

  const [transfers, setTransfers] = useState<BalanceTransfer[]>([]);
  const [coinFilter, setCoinFilter] = useState<CoinsType | undefined>();

  const selectCoin = (coin: CoinsType): void => {
    setCoinFilter(state => (state === coin ? undefined : coin));
  };

  useEffect(() => {
    if (data) setTransfers(t => [...t, ...data]);
  }, [data]);

  return (
    <Container>
      <div className="header">
        <h3>Extrato</h3>
        <div className="headerinline">
          <HStack spacing={4}>
            {coins &&
              coins.map(coin => (
                <Box key={coin} onClick={() => selectCoin(coin as CoinsType)}>
                  <CurrencyWithIcon
                    collapsed
                    iconName={coin.toLowerCase() as CoinsType}
                    currency={coin}
                    color={
                      coinFilter === coin
                        ? getColorByCoin(coin as CoinsType)
                        : '#9B9B9B'
                    }
                  />
                </Box>
              ))}
            {/* <Text color="#979daf">ATIVO</Text>
            <Select
              color="white"
              size="sm"
              onChange={v => {
                setTransfers([]);
                setParams(s => ({ ...s, coin: v.target.value, offset: 0 }));
              }}
            >
              <option label="..." />
              {coins &&
                coins.map(coin => (
                  <option key={coin} label={coin}>
                    {coin}
                  </option>
                ))}
            </Select> */}
          </HStack>
          {/* <HStack>
            <Text color="white">MÊS</Text>
            <Select size="sm" placeholder="ABR - 2022" color="white" />
          </HStack> */}
          {/* <LocalizationProvider dateAdapter={AdapterDateFns} locale={ptLocale}>
            <DatePicker
              className="monthPicker"
              views={['year', 'month']}
              minDate={new Date('2018-03-01')}
              maxDate={new Date()}
              value={value}
              onChange={(newValue: React.SetStateAction<Date | null>) => {
                setValue(newValue);
              }}
              renderInput={(
                params: JSX.IntrinsicAttributes & TextFieldProps,
              ) => <TextField {...params} helperText={null} size="small" />}
            />
          </LocalizationProvider> */}
        </div>
      </div>

      <ScrollDrag className="tableContainer">
        <table>
          <thead>
            <tr>
              <th />
              <th>ID</th>
              <th>Data e hora</th>
              <th>Valor</th>
              <th>Taxa cobrada</th>
              <th>Saldo</th>
              {/* <th>Canal</th> */}
              <th>Tipo</th>
              <th>Status</th>
              <th>Descrição</th>
              <th>TXID</th>
            </tr>
          </thead>
          <div className="table-scroll">
            <tbody>
              {transfers &&
                transfers
                  .filter(t => (coinFilter ? t.coin === coinFilter : true))
                  .map(transaction => (
                    <tr key={transaction.sequence}>
                      <td>
                        <CurrencyWithIcon
                          iconName={transaction.coin.toLowerCase() as CoinsType}
                          currency={transaction.coin}
                          color={getColorByCoin(transaction.coin as CoinsType)}
                        />
                      </td>
                      <td>#{transaction.sequence}</td>
                      <td>
                        <DateWithHour dateValue={transaction.created_at} />
                      </td>
                      <td>{transaction.net_value}</td>
                      <td>{transaction.fee_value}</td>
                      <td>{transaction.current_balance}</td>
                      {/* <td>{transaction.channel}</td> */}
                      <td>
                        <span
                          className={`badge ${
                            transaction.type === 'credit' ? 'up' : 'down'
                          }`}
                        />
                        {transaction.type === 'credit' ? 'Entrada' : 'Saída'}
                      </td>
                      <td>{transaction.status}</td>
                      <td>{transaction.description}</td>
                      <td>
                        <a
                          href={transaction.txid}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <IconButton
                            aria-label="Ver transação"
                            background="transparent"
                            colorScheme="brandBlack"
                            icon={<GoLink />}
                          />
                        </a>
                      </td>
                    </tr>
                  ))}
              <Box h="30px" />
            </tbody>
          </div>
        </table>
        {/* <TopBlur />
        <BottomBlur /> */}
      </ScrollDrag>
      {((data &&
        data.filter(t => (coinFilter ? t.coin === coinFilter : true)).length ===
          0) ||
        !data) && (
        <Stack alignItems="center" color="text.500">
          <Heading>
            Nenhuma transação encontrada {coinFilter && `para ${coinFilter}`}
          </Heading>
        </Stack>
      )}
      {data && data.length >= limit && (
        <SeeMoreButton>
          <ButtonPrimary
            onPress={() => {
              setParams({ ...params, offset: Number(params.offset) + 1 });
            }}
          >
            Ver mais
          </ButtonPrimary>
        </SeeMoreButton>
      )}
    </Container>
  );
};

export default ExtractTable;
