import { Box, Text } from '@chakra-ui/react';
import React, { InputHTMLAttributes } from 'react';
import ReactFlagsSelect from 'react-flags-select';

import CountryInputCompactContainer from './styles';

interface Props extends InputHTMLAttributes<HTMLInputElement> {
  country: string;
  setCountry: React.Dispatch<React.SetStateAction<string>>;
  label?: string;
}

const CountryFlagSelect: React.FC<Props> = ({
  country,
  setCountry,
  label,
  ...rest
}) => {
  return (
    <Box {...rest}>
      {label && <Text>{label}</Text>}

      <CountryInputCompactContainer>
        <ReactFlagsSelect
          id="country"
          selected={country}
          onSelect={selectedCode => setCountry(selectedCode)}
          className="inputSelectCustom"
          searchable
          fullWidth={false}
          searchPlaceholder="Pesquise pelo nome do país"
          customLabels={{ BR: 'Brasil' }}
        />
      </CountryInputCompactContainer>
    </Box>
  );
};

export default CountryFlagSelect;
