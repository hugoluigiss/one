import { Box, Input, Text } from '@chakra-ui/react';
import React, { InputHTMLAttributes } from 'react';
import ReactFlagsSelect from 'react-flags-select';

import CountryInputCompactContainer from './styles';

interface Props extends InputHTMLAttributes<HTMLInputElement> {
  country: string;
  setCountry: React.Dispatch<React.SetStateAction<string>>;
  name: string;
  label?: string;
}

const PhoneWithFlagSelect: React.FC<Props> = ({
  country,
  setCountry,
  name,
  label,
  ...rest
}) => {
  return (
    <Box {...rest}>
      {label && <Text>{label}</Text>}

      <CountryInputCompactContainer>
        <ReactFlagsSelect
          id="phone_country"
          selected={country}
          onSelect={selectedCode => setCountry(selectedCode)}
          className="inputSelectCustom"
          searchable
          fullWidth={false}
          searchPlaceholder="Pesquise pelo nome do país"
          customLabels={{ BR: 'Brasil' }}
        />
        <Input name={name} variant="unstyled" />
      </CountryInputCompactContainer>
    </Box>
  );
};

export default PhoneWithFlagSelect;
