import styled, { css } from 'styled-components';
import { ReactComponent as User } from '../../../../assets/icons/profile/user.svg';
import { ReactComponent as Lock } from '../../../../assets/icons/profile/lock.svg';
import { ReactComponent as Wallet } from '../../../../assets/icons/profile/wallet.svg';
import { ReactComponent as Document } from '../../../../assets/icons/profile/document.svg';
import { ReactComponent as Address } from '../../../../assets/icons/address-menu.svg';
import { ReactComponent as UserJuridic } from '../../../../assets/icons/profile/user-juridic.svg';

export const Container = styled.div`
  width: 273px;
  min-height: 600px;

  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;

  background-color: var(--color-card-primary);
`;

export const UserIcon = styled(User)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  stroke: ${props => (props.color ? props.color : '#8b8d93')};
  transition: all 0.3s ease;
`;
export const LockIcon = styled(Lock)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  stroke: ${props => (props.color ? props.color : '#8b8d93')};
  transition: all 0.3s ease;
`;
export const AddressIcon = styled(Address)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  stroke: ${props => (props.color ? props.color : '#8b8d93')};
  transition: all 0.3s ease;
`;
export const WalletIcon = styled(Wallet)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  stroke: ${props => (props.color ? props.color : '#8b8d93')};
  transition: all 0.3s ease;
  fill: ${props => (props.color ? props.color : '#8b8d93')};
`;
export const DocumentIcon = styled(Document)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  stroke: ${props => (props.color ? props.color : '#8b8d93')};
  transition: all 0.3s ease;
`;
export const UserJuridicIcon = styled(UserJuridic)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  stroke: ${props => (props.color ? props.color : '#8b8d93')};
  transition: all 0.3s ease;
`;

export const PageName = styled.span<{ selected?: boolean }>`
  margin-left: 20px;
  color: #a8aab4;
  transition: all 0.3s ease;
`;

export const NavLink = styled.div<{ selected?: boolean }>`
  width: 100%;
  padding: 12px 24px;

  display: flex;
  align-items: center;

  transition: all 0.3s ease;
  cursor: pointer;

  background: transparent;

  &:hover {
    background-color: rgba(0, 0, 0, 0.1);
  }

  ${props =>
    props.selected &&
    css`
      background: ${props.selected
        ? 'linear-gradient(#1c1c1c, #3e3e3e)'
        : 'transparent'};

      ${PageName} {
        color: ${props.selected ? '#fff' : '#a8aab4'};
      }

      svg {
        fill: ${props.selected ? '#fff' : '#a8aab4'};
        stroke: ${props.selected ? '#fff' : '#a8aab4'};
      }
    `}
`;

export const SingOut = styled.div`
  margin: 20px 0 34px 27px;

  color: #a8aab4;
  cursor: pointer;
  width: fit-content;
`;
