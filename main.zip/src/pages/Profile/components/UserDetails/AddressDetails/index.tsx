import {
  Badge,
  Box,
  // Button,
  FormControl,
  FormLabel,
  HStack,
  SimpleGrid,
  Skeleton,
  Stack,
} from '@chakra-ui/react';
import { Form, Formik, FormikProps } from 'formik';
// import { toast } from 'react-toastify';
import { useCallback, useState } from 'react';
import axios from 'axios';
import { Container, Header, Content, AddressIcon } from '../styles';
import {
  addressSchema,
  IAddressFormData,
} from '../../../../../utils/form-validation-schemas';

import Input from '../../../../../components/Form/Inputs/InputText';
// import { useUploadFile } from '../../../../../hooks/useUploadFile';
// import Upload from '../../../../../components/Form/Upload';
import { UserAddress } from '../../../../../services/apitypes';
import useGet from '../../../../../hooks/useGet';

interface AddressProps {
  cep: string;
  logradouro: string;
  complemento: string;
  bairro: string;
  localidade: string;
  uf: string;
  ibge: string;
  gia: string;
  ddd: string;
  siafi: string;
}

export default function AddressDetails() {
  // const [filename, setFileName] = useState<string>();
  const [timeoutRef, setTimeoutRef] = useState<number>();
  const [cepApiInfo, setCepApiInfo] = useState<AddressProps>();

  const [{ data: address, loading: loadingAddress }] = useGet<UserAddress>(
    '/profile/infoProfileAddress',
  );

  const fetchCepInfo = useCallback(
    (inputValue: string) => {
      if (inputValue.length < 8) return;

      clearTimeout(timeoutRef);
      const timeout = 0;
      window.setTimeout(() => {
        axios
          .get(`https://viacep.com.br/ws/${inputValue}/json/`)
          .then((res: any) => {
            setCepApiInfo(res.data);
          })
          .catch(() => {
            // console.log(err);
          });
      }, 1000);
      setTimeoutRef(timeout);
    },
    [timeoutRef],
  );

  const FormPiece = (
    <Formik
      enableReinitialize
      initialValues={{
        zip_code: address?.zip_code || cepApiInfo?.cep || '',
        district: address?.district || cepApiInfo?.bairro || '',
        state: address?.state || cepApiInfo?.uf || '',
        city: address?.city || cepApiInfo?.localidade || '',
        street: address?.street || cepApiInfo?.logradouro || '',
        number: address?.number || '',
        complement: address?.complement || '',
      }}
      validationSchema={addressSchema}
      onSubmit={() => {
        // if (!filename) {
        //   toast.error('Anexe seu comprovante de endereco');
        //   actions.setSubmitting(false);
        //   return;
        // }
        // addUserAddress({ ...values, file_name: filename });
      }}
    >
      {({ values, errors, handleChange }: FormikProps<IAddressFormData>) => (
        <Form>
          <SimpleGrid columns={[1, 1, 2]} spacing={10}>
            <FormControl isRequired w={40}>
              <FormLabel>CEP</FormLabel>
              <Input
                dark
                disabled
                name="zip_code"
                value={values.zip_code || ''}
                onChange={async e => {
                  handleChange(e);
                  const { value } = e.target;

                  fetchCepInfo(value);
                }}
                placeholder="Digite seu CEP"
                errorText={errors.zip_code}
              />
            </FormControl>
          </SimpleGrid>

          <SimpleGrid columns={[1, 1, 2]} spacing={10}>
            <FormControl isRequired>
              <FormLabel>Bairro</FormLabel>
              <Input
                dark
                disabled
                name="district"
                value={values.district || ''}
                onChange={handleChange}
                placeholder="Informe seu bairro"
                errorText={errors.district}
              />
            </FormControl>

            <FormControl isRequired>
              <FormLabel>Cidade</FormLabel>
              <Input
                dark
                disabled
                name="city"
                value={values.city || ''}
                onChange={handleChange}
                placeholder="Informe sua cidade"
                errorText={errors.city}
              />
            </FormControl>

            <FormControl>
              <FormLabel>Estado</FormLabel>
              <Input
                dark
                disabled
                name="state"
                value={values.state || ''}
                onChange={handleChange}
                placeholder="UF"
                errorText={errors.state}
              />
            </FormControl>
          </SimpleGrid>

          <SimpleGrid columns={[1, 1, 2]} spacing={10}>
            <FormControl isRequired>
              <FormLabel>Rua</FormLabel>
              <Input
                dark
                disabled
                name="street"
                value={values.street}
                onChange={handleChange}
                placeholder="Informe sua rua"
                errorText={errors.street}
              />
            </FormControl>

            <FormControl isRequired w="120px">
              <FormLabel>Número</FormLabel>
              <Input
                dark
                disabled
                name="number"
                value={values.number}
                onChange={handleChange}
                placeholder="Número"
                errorText={errors.number}
              />
            </FormControl>

            <FormControl>
              <FormLabel>Complemento</FormLabel>
              <Input
                dark
                disabled
                name="complement"
                value={values.complement || ''}
                onChange={handleChange}
                errorText={errors.complement}
              />
            </FormControl>
          </SimpleGrid>

          <SimpleGrid columns={[1, 1, 2]} spacing={10}>
            <Stack>
              <span>Comprovante de residência</span>
              {address?.status === 'rejected' && (
                <Stack>
                  <Badge colorScheme="red" w="fit-content">
                    Comprovante Rejeitado, por favor envie, novamente
                  </Badge>
                </Stack>
              )}
              <Box w="300px">
                <img
                  width="100%"
                  height="auto"
                  src={address?.file_url}
                  alt="Comprovante residencia"
                />
              </Box>
            </Stack>
          </SimpleGrid>

          {/* {(!address || address.status === 'rejected') && (
            <Button type="submit" isLoading={loading}>
              Salvar
            </Button>
          )} */}
        </Form>
      )}
    </Formik>
  );

  const loadingForm = (
    <Stack spacing={30}>
      <Skeleton h={50} w={300} />
      <HStack>
        <Skeleton h={50} w={300} />
        <Skeleton h={50} w={300} />
        <Skeleton h={50} w={300} />
      </HStack>

      <HStack>
        <Skeleton h={50} w={300} />
        <Skeleton h={50} w={150} />
        <Skeleton h={50} w={300} />
      </HStack>
    </Stack>
  );

  return (
    <Container>
      <Content>
        <Header stretched>
          <AddressIcon />

          <h3>Endereço</h3>
        </Header>
        <Content maxWidth="603px">
          {loadingAddress ? loadingForm : FormPiece}
        </Content>
      </Content>
    </Container>
  );
}
