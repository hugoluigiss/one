// import ReactFlagsSelect from 'react-flags-select';
import {
  Badge,
  Box,
  // Avatar,
  FormControl,
  FormLabel,
  HStack,
  SimpleGrid,
  Skeleton,
  Stack,
} from '@chakra-ui/react';
import { Form, Formik, FormikProps } from 'formik';
import {
  Container,
  Header,
  // AvatarContainer,
  Content,
  // CameraIcon,
  UserIcon,
} from '../styles';
// import PhoneWithFlagSelect from '../../PhoneWithFlagSelect';
import {
  IPFFormData,
  pfSchema,
} from '../../../../../utils/form-validation-schemas';
import useGet from '../../../../../hooks/useGet';
import {
  UserContact,
  // pfDocumentsTypes,
  UserPfDocument,
} from '../../../../../services/apitypes';
import Input from '../../../../../components/Form/Inputs/InputText';
// import Select from '../../../../../components/Form/Select';
// import { useUploadFile } from '../../../../../hooks/useUploadFile';

export default function ProfileDetails() {
  const [{ data: userDocument, loading: loadingDocs }] = useGet<UserPfDocument>(
    '/profile/infoProfileDocument',
  );
  const [{ data: userContact }] = useGet<UserContact>('/profile/infoProfile');
  // const [{ data: docTypes }] = useGet<pfDocumentsTypes>('/documents/pf/types');

  const FormPiece = (
    <Formik
      enableReinitialize
      initialValues={{
        first_name: userDocument?.first_name || '',
        last_name: userDocument?.last_name || '',
        cpf: userDocument?.cpf || '',
        phone_number: userDocument?.phone_number || '',
        birthdate: userDocument?.birthdate || '',
      }}
      validationSchema={pfSchema}
      onSubmit={() => {
        // if (!values.birthdate) {
        //   actions.setSubmitting(false);
        //   return;
        // }
        // if (!back || !front || !selfie) {
        //   toast.error('Selecione seus documentos');
        //   actions.setSubmitting(false);
        //   return;
        // }
        // const date = values.birthdate.split('-');
        // addUserInfo({
        //   ...values,
        //   birth_year: date[0],
        //   birth_month: (parseInt(date[1], 10) - 1).toString(),
        //   birth_day: date[2],
        //   back,
        //   front,
        //   selfie,
        // });
      }}
    >
      {({ values, errors, handleChange }: FormikProps<IPFFormData>) => (
        <Form>
          <SimpleGrid columns={[1, 1, 2]} spacing={10}>
            <FormControl isRequired>
              <FormLabel>Nome</FormLabel>
              <Input
                dark
                disabled
                name="first_name"
                value={values.first_name}
                onChange={handleChange}
                placeholder="Digite seu nome"
                errorText={errors.first_name}
              />
            </FormControl>
            <FormControl isRequired>
              <FormLabel>Sobrenome</FormLabel>
              <Input
                dark
                disabled
                name="last_name"
                value={values.last_name}
                onChange={handleChange}
                placeholder="Digite seu sobrenome"
                errorText={errors.last_name}
              />
            </FormControl>
          </SimpleGrid>

          <SimpleGrid columns={[1, 1, 2]} spacing={10}>
            <FormControl isRequired>
              <FormLabel>Email</FormLabel>
              <Input
                dark
                disabled
                name="email"
                type="email"
                value={userContact?.email}
                placeholder="Email não informado"
              />
            </FormControl>
            <FormControl isRequired>
              <FormLabel>Telefone</FormLabel>
              <Input
                dark
                errorText={errors.phone_number}
                disabled
                name="phone_number"
                type="tel"
                value={userContact?.phone_number}
                placeholder="Telefone não informado"
              />
            </FormControl>
          </SimpleGrid>

          <SimpleGrid columns={[1, 1, 2]} spacing={10}>
            <FormControl isRequired>
              <FormLabel>Documento</FormLabel>
              <Input
                dark
                name="value"
                disabled
                value={values.cpf}
                onChange={handleChange}
                placeholder="Documento não encontrado"
                errorText={errors.cpf}
              />
            </FormControl>
            <FormControl isRequired>
              <FormLabel>Nascimento</FormLabel>
              <Input
                dark
                name="birthdate"
                type="date"
                disabled
                value={values.birthdate}
                onChange={handleChange}
                errorText={errors.birthdate}
              />
            </FormControl>
            {/* <FormControl>
              <FormLabel>Gênero</FormLabel>
              <Select dark name="gender" disabled>
                {options.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </Select>
            </FormControl> */}
          </SimpleGrid>

          {userDocument?.status === 'rejected' && (
            <Stack>
              <Badge colorScheme="red" w="fit-content">
                Documento Rejeitado, por favor envie, novamente
              </Badge>
            </Stack>
          )}

          <SimpleGrid columns={[1, 1, 2, 3]} spacing={10}>
            <FormControl>
              <span>Documento Frente</span>
              <Box w="300px">
                <img
                  width="100%"
                  height="auto"
                  src={userDocument?.front_url}
                  alt="Frente do documento"
                />
              </Box>
            </FormControl>
            <FormControl>
              <span>Documento Verso</span>
              <Box w="300px">
                <img
                  width="100%"
                  height="auto"
                  src={userDocument?.back_url}
                  alt="verso do documento"
                />
              </Box>
            </FormControl>
            <FormControl>
              <span>Selfie com documento</span>
              <Box w="300px">
                <img
                  width="100%"
                  height="auto"
                  src={userDocument?.selfie_url}
                  alt="Selfie com documento"
                />
              </Box>
            </FormControl>
          </SimpleGrid>
        </Form>
      )}
    </Formik>
  );

  const loadingForm = (
    <Stack spacing={30}>
      <HStack>
        <Skeleton h={50} w={300} />
        <Skeleton h={50} w={300} />
      </HStack>

      <HStack>
        <Skeleton h={50} w={300} />
        <Skeleton h={50} w={150} />
      </HStack>
      <HStack>
        <Skeleton h={50} w={300} />
      </HStack>
    </Stack>
  );

  return (
    <Container>
      <Content>
        <Header stretched>
          <UserIcon />

          <h3>Informações pessoais</h3>
        </Header>
        <Content maxWidth="603px">
          {loadingDocs ? loadingForm : FormPiece}
        </Content>
      </Content>
    </Container>
  );
}
