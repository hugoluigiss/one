import styled from 'styled-components';

export const Container = styled.div`
  width: 100%;
  height: fit-content;
  margin-right: 30px;

  display: flex;
  flex-direction: column;
`;

export const Card = styled.div`
  width: 100%;

  padding: 32px;
  margin-bottom: 32px;

  background: var(--color-card-secondary);

  display: flex;
  font-size: 16px;
  font-weight: 500;
`;

export const Footer = styled.div`
  text-align: end;

  button {
    margin-top: 0;
  }
`;
