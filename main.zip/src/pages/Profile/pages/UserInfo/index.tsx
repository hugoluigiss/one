import ProfileDetails from '../../components/UserDetails/ProfileDetails';

import { Card, Container } from './styles';

export default function UserInfo() {
  return (
    <Container>
      <Card>
        <ProfileDetails />
      </Card>
    </Container>
  );
}
