import { Container, BgOverlay, BoxContainer, ActionBox } from './styles';

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}): JSX.Element {
  return (
    <Container>
      <BgOverlay />

      <BoxContainer>
        <ActionBox>{children}</ActionBox>
      </BoxContainer>
    </Container>
  );
}
