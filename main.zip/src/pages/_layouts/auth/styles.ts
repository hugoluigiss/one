import styled from 'styled-components';
import bg from '../../../assets/images/bg-image.png';

export const Container = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;

  width: 100%;
  position: relative;
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  background-image: url(${bg});
`;

export const BgOverlay = styled.div``;

export const BoxContainer = styled.div`
  width: 100%;
  min-height: 100vh;
  display: flex;
  justify-content: flex-end;
  align-items: center;
`;
export const ActionBox = styled.div`
  max-width: 703px;
  width: 100%;
  padding: 20px 20px;
  box-sizing: border-box;
  height: 100%;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  background: #00000096;

  h1 {
    color: #fff;
    font-size: 24px;
    margin: 40px 0 0 0;
    text-align: center;
  }
`;
