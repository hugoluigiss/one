import styled from 'styled-components';

interface InternContentProps {
  isCollapsed?: boolean;
  mobileWidth?: number;
}
export const InternContent = styled.div<InternContentProps>`
  margin-left: ${props => (props.isCollapsed ? 120 : 257)}px;
  width: calc(100vw - ${props => (props.isCollapsed ? 120 : 257)}px);
  min-height: calc(100vh - 80px);

  overflow-x: hidden;
  display: flex;
  flex-direction: column;
  transition: 200ms;

  background: #0f0f12;

  @media (max-width: ${props => props.mobileWidth || 99999}px) {
    margin-left: 0;
    width: 100vw;
  }
`;

export const Content = styled.div`
  min-height: calc(100vh - 33px - 21px - 58px - 51px - 4px);

  padding: 21px 40px 58px 40px;
`;
