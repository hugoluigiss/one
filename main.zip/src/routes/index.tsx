import { Switch } from 'react-router-dom';
import Dashboard from '../pages/Dashboard';
import Extract from '../pages/Extract';
import Clients from '../pages/Clients';
import DocumentConfirmation from '../pages/DocumentConfirmation';
import AccountConfirmation from '../pages/Auth/AccountConfirmation';
import ForgotPassword from '../pages/Auth/ForgotPassword';

import SignIn from '../pages/Auth/Signin';

import Route from './Route';
import AccountCreation from '../pages/AccountCreation';
import Contracts from '../pages/Contracts';

export default function Routes(): JSX.Element {
  return (
    <Switch>
      <Route path="/" exact component={SignIn} />
      <Route path="/forgot-password" exact component={ForgotPassword} />
      <Route path="/dashboard" exact component={Dashboard} isPrivate />
      <Route path="/extract" exact component={Extract} isPrivate />
      <Route path="/clients" exact component={Clients} isPrivate />
      <Route
        path="/contracts/:coinParam"
        exact
        component={Contracts}
        isPrivate
      />
      <Route path="/contracts" exact component={Contracts} isPrivate />
      <Route
        path="/profile/:id"
        exact
        component={DocumentConfirmation}
        isPrivate
      />
      <Route
        path="/account-creation/:token_id"
        exact
        component={AccountCreation}
      />
      <Route
        path="/account-confirmation/:account_id"
        exact
        component={AccountConfirmation}
      />
      <Route
        path="/confirmation/:account_id"
        exact
        component={DocumentConfirmation}
      />
      <Route component={Dashboard} />
    </Switch>
  );
}
