/* eslint-disable no-underscore-dangle */
import { toast } from 'react-toastify';
import app from '../config/app';
import { IBody } from '../hooks/usePost';

class FetchApi {
  private static _instance: FetchApi;

  private baseUrl = '';

  private requestsQueues: { [key: string]: Promise<any>[] } = {};

  private requestsResponses: { [key: string]: any } = {};

  private constructor() {
    if (!FetchApi._instance) {
      this.baseUrl = app.api_url;
      this.requestsQueues = {};
      this.requestsResponses = {};
      FetchApi._instance = this;
    }
    return FetchApi._instance;
  }

  static getInstance() {
    if (this._instance) return this._instance;
    this._instance = new FetchApi();
    return this._instance;
  }

  // eslint-disable-next-line class-methods-use-this
  private headers(token: string | null): HeadersInit {
    const header: HeadersInit = {
      'Content-type': 'application/json; charset=UTF-8',
    };

    if (token) header.Authorization = `Bearer ${token}`;

    return header;
  }

  public async get<T>(data: {
    path: string;
    params?: { [key: string]: string | number };
    token: string | null;
  }): Promise<{ error?: { message: string; status: number }; data?: T }> {
    const { path, params } = data;
    const url = new URL(`${this.baseUrl}${path[0] === '/' ? '' : '/'}${path}`);

    if (params)
      Object.keys(params).forEach(key =>
        url.searchParams.append(key, String(params[key])),
      );

    const fullUrl = url.toString();

    if (!this.requestsQueues[fullUrl]) this.requestsQueues[fullUrl] = [];

    if (this.requestsQueues[fullUrl].length > 0) {
      await Promise.race(this.requestsQueues[fullUrl]);
      return this.requestsResponses[fullUrl];
    }

    const promise = new Promise(resolve => {
      fetch(fullUrl, { method: 'GET', headers: this.headers(data.token) })
        .then(r => r.json())
        .then(response => {
          resolve(response);
        })
        .catch(() => toast.error('Verifique sua conexao com a internet'));
    });

    this.requestsQueues[fullUrl].push(promise);
    const result = await promise;

    this.requestsResponses[fullUrl] = result;
    setTimeout(() => delete this.requestsResponses[fullUrl], 100);
    this.requestsQueues[fullUrl] = [];

    return result as T;
  }

  public async post<T>(data: {
    path: string;
    body: IBody;
    token: string | null;
  }): Promise<{ error?: { message: string; status: number }; data?: T }> {
    const { path, body } = data;
    const fullUrl = `${this.baseUrl}${path[0] === '/' ? '' : '/'}${path}`;

    if (!this.requestsQueues[fullUrl]) this.requestsQueues[fullUrl] = [];

    if (this.requestsQueues[fullUrl].length > 0) {
      await Promise.race(this.requestsQueues[fullUrl]);
      return this.requestsResponses[fullUrl];
    }

    const promise = new Promise(resolve => {
      fetch(fullUrl, {
        method: 'POST',
        body: JSON.stringify(body),
        headers: this.headers(data.token),
      })
        .then(r => r.json())
        .then(response => resolve(response))
        .catch(() => toast.error('Verifique sua conexao com a internet'));
    });

    this.requestsQueues[fullUrl].push(promise);

    const result = await promise;

    this.requestsResponses[fullUrl] = result;
    setTimeout(() => delete this.requestsResponses[fullUrl], 100);
    this.requestsQueues[fullUrl] = [];
    return result as T;
  }
}

export default FetchApi;
