import axios from 'axios';
import app from '../config/app';

const api = axios.create({
  baseURL: app.api_url,
});

export default api;
