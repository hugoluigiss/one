export type getMe = {
  created_at: Date;
  email: string;
  id: string;
  is_admin: boolean;
  phone_number: string;
  sequence: number;
  updated_at: Date;
};
export interface BaseModel {
  id: string;
  sequence: number;
  created_at: Date;
  deleted_at?: Date;
}

export type StatusType = 'pending' | 'approved' | 'rejected';

export interface UserPersonalDocument extends BaseModel {
  user_id: string;
  status: StatusType;
  first_name: string;
  last_name: string;
  cpf: string;
  birthdate: string;
  selfie: string;
  back: string;
  front: string;
}

export interface UserCompanyDocument extends BaseModel {
  user_id: string;
  status: StatusType;
  company_name: string;
  fantasy_name: string;
  cnpj: string;
  social_contract_file: string;
  cnpj_file: string;
}

export interface UserBalance extends BaseModel {
  [x: string]: any;
}
export interface UserAccount extends BaseModel {
  id: string;
  user_id: string;
  status: StatusType;
  personal_document_approved: string;
  company_document_approved: string;
  personal_address_approved: string;
  company_address_approved: string;
  created_by_id: string;
}
export interface User extends BaseModel {
  email: string;
  phone_number: string;
  type: UnilevelTypes;
  username: string;

  readonly personal_document?: UserPersonalDocument;
  readonly company_document?: UserCompanyDocument;
  readonly user_downlines_balance?: UserBalance;
  readonly account: UserAccount;
}

export interface Unilevel extends BaseModel {
  user_id: string;
  path: string;
  higher_sequence: number;
  depth: number;
  type: UnilevelTypes;

  higher?: Unilevel;

  user: User;
}

export type UnilevelTypes = 'customer' | 'manager' | 'consultant' | 'root';
export type getMyUnilevel = {
  id: string;
  user_id: string;
  path: string;
  higher_sequence: number;
  depth: number;
  type: UnilevelTypes;
  show_consultants: boolean;
  show_customers: boolean;
  show_managers: boolean;
  indication_link: string;
};
export type getMyPermissions = {
  id: string;
  user_id: string;
  sequence: number;
  type: UnilevelTypes;
  has_permission: boolean;
};

export type CoinsType = 'BTC' | 'ETH' | 'BNB' | 'USDT';

export type getCoinBalance = {
  balance_converted_to_brl: string;
  conversion_to_brl: number;
  user_id: string;
  balance: string;
  coin: CoinsType;
};

export type BalanceTransfer = {
  coin: CoinsType;
  balance_id: string;
  previus_balance: string;
  current_balance: string;
  total_value: string;
  fee_value: string;
  net_value: string;
  description: string;
  type: 'credit' | 'debit';
  id: string;
  sequence: number;
  status: string;
  txid: string;
  created_at: Date;
  updated_at: Date;
  channel: string;
};

export type getMyDirects = {
  id: string;
  username: string;
  phone_number: string;
  email: string;
  type: UnilevelTypes;
};

export type getApplicationsResume = {
  total_brl_applied: string;
  total_brl_income: string;
  percentage: string;
};

export type CoinTradeParam = {
  coin_from: CoinsType;
  coin_to: CoinsType;
  percentage_fee_value: string;
};

export type CoinTrade = {
  debit: BalanceTransfer;
  credit: BalanceTransfer;
};

export type UserApplication = {
  user_id: string;
  coin: CoinsType;
  coin_amount: string;
  income_amount: string;
  ended_at: Date;
  is_active: boolean;
};

export type MakeApplication = {
  application: UserApplication;
  debit: BalanceTransfer;
};

export type getApplicationCoin = {
  applied: string;
  income: string;
  percentage: string;
};

export type UserCoinWallet = {
  user_id: string;
  coin: CoinsType;
  address: string;
  network: string;
};

export type IncomeWithdrawalType = {
  user_id: string;
  coin: CoinsType;
  coin_amount: string;
};

export type pfDocumentsTypes = ['rg', 'cnh', 'rne'];

export type UserFile = {
  user_id: string;
  filename: string;
  status: 'active' | 'innactive';
};

export type UserContact = {
  email: string;
  phone_number: string;
};

export type UserDocumentstatusTypes = 'pending' | 'approved' | 'rejected';
export type UserPfDocument = {
  user_id: string;
  status: UserDocumentstatusTypes;
  first_name: string;
  last_name: string;
  cpf: string;
  phone_number: string;
  birth_day?: number;
  birth_month?: number;
  birth_year?: number;
  birthdate: string;
  selfie: string;
  selfie_url?: string;
  back: string;
  back_url?: string;
  front: string;
  front_url?: string;
};

export type UserPjDocument = {
  id: string;
  user_id: string;
  status: UserDocumentstatusTypes;
  company_name: string;
  fantasy_name: string;
  value: string;
  cnpj: string;
  social_contract: string;
  cnpj_url: string;
  social_contract_url: string;
};

export type AddressStatusType = 'pending' | 'approved' | 'rejected';
export type AddressType = 'pf' | 'pj';
export type UserAddress = {
  id: string;
  user_id: string;
  zip_code: string;
  state: string;
  city: string;
  district: string;
  street: string;
  number: string;
  complement?: string;
  file_name: string;
  file_url?: string;
  status: AddressStatusType;
};

export type UserTwoFa = {
  user_id: string;
  secret: string;
  qrcode: string;
};

export enum ApplicationType {
  OneYear = 'one_year',
  TwoYears = 'two_years',
  One90 = 'one90',
  One180 = 'one180',
}

export type ContractType = {
  id: string;
  sequence: number;
  file_url?: string;
  signature_key?: string;
  signed_at: Date;
  admin_signed_at: Date;
  type: ApplicationType;
  coin: CoinsType;
  amount: string;
  txid: string;
  created_at: Date;
  user: User;
};
