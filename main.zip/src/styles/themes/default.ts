export default {
  title: 'default',

  colors: {
    primary: '#A17725',
    secundary: '#000',

    boxBackground: '#fff',
    background: '#f5f5f5',
    text: '#777',
    textSecondary: '#fff',
    hover: '#a8aab4',
  },

  fontSize: {
    normal: '14px',
    large: '18px',
  },

  borderRadius: '4px',
};
