import { CoinsType } from '../services/apitypes';

const colors = [
  '#50B7D0',
  '#E58155',
  '#966CE6',
  '#8AB13F',
  '#F31F4F',
  '#2962ff',
];

export default colors;

export const getColorByCoin = (coin: CoinsType): string => {
  if (coin === 'USDT') return colors[0];
  if (coin === 'BTC') return colors[1];
  if (coin === 'ETH') return colors[2];
  if (coin === 'BNB') return colors[3];

  return colors[4];
};
