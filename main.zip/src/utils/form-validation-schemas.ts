/* eslint-disable import/prefer-default-export */
import * as Yup from 'yup';

export function TestaCPF(strCPF = '') {
  const parsedCPF = strCPF.replace(/\D/g, '');
  let Soma;
  let Resto;
  Soma = 0;
  if (parsedCPF === '00000000000') return false;

  for (let i = 1; i <= 9; i += 1)
    Soma += parseInt(parsedCPF.substring(i - 1, i), 10) * (11 - i);
  Resto = (Soma * 10) % 11;

  if (Resto === 10 || Resto === 11) Resto = 0;
  if (Resto !== parseInt(parsedCPF.substring(9, 10), 10)) return false;

  Soma = 0;
  for (let i = 1; i <= 10; i += 1)
    Soma += parseInt(parsedCPF.substring(i - 1, i), 10) * (12 - i);
  Resto = (Soma * 10) % 11;

  if (Resto === 10 || Resto === 11) Resto = 0;
  if (Resto !== parseInt(parsedCPF.substring(10, 11), 10)) return false;

  return true;
}

export interface ISignInFormData {
  username_or_email: string;
  password: string;
}
export const formSignInSchema = Yup.object().shape({
  username_or_email: Yup.string().required('E-mail ou usuário obrigatório'),
  password: Yup.string().required('Senha obrigatória'),
});

export interface IForgotPasswordFormData {
  email: string;
  code: string;
  password: string;
  confirm_password: string;
}
export const formFotgotPasswordSchema = Yup.object().shape({
  email: Yup.string()
    .required('E-mail obrigatório')
    .email('Digite um e-mail válido'),
  code: Yup.string()
    .required('Codigo obrigatório')
    .length(6, 'Deve possuir 6 digitos'),
  password: Yup.string()
    .required('Senha obrigatória')
    .min(8, 'Senha deve ter no mínimo 8 caracteres'),
  confirm_password: Yup.string().when('password', (p: string, field: any) =>
    p
      ? field
          .required('A confirmação de senha é obrigatória')
          .oneOf(
            [Yup.ref('password')],
            'A senha e a confirmação deve ser idênticas',
          )
      : field,
  ),
});

export interface ISignupStep1FormData {
  email: string;
}
export const signupStep1Schema = Yup.object().shape({
  email: Yup.string()
    .required('E-mail obrigatório')
    .email('Digite um e-mail válido'),
});
export interface ISignupGuestFormData {
  email: string;
  phone_number: string;
}
export const signupGuestSchema = Yup.object().shape({
  email: Yup.string()
    .required('E-mail obrigatório')
    .email('Digite um e-mail válido'),
  phone: Yup.string()
    .required('Telefone é obrigatório')
    .email('Digite um telefone válido'),
});

export interface ISignupStep2FormData {
  token_id: string;
  phone_number: string;
  password: string;
  password_confirmation: string;
}
export const signupStep2Schema = Yup.object().shape({
  token_id: Yup.string().required('Código é obrigatório'),
  phone_number: Yup.string().required('Telefone é obrigatório'),
  // .min(14, 'Deve ter no mínimo 11 digitos'),
  password: Yup.string()
    .required('Senha obrigatória')
    .min(8, 'Senha deve ter no mínimo 8 caracteres'),
  password_confirmation: Yup.string().when(
    'password',
    (p: string, field: any) =>
      p
        ? field
            .required('A confirmação de senha é obrigatória')
            .oneOf(
              [Yup.ref('password')],
              'A senha e a confirmação deve ser idênticas',
            )
        : field,
  ),
});

export interface IPFFormData {
  birthdate: string;
  first_name: string;
  last_name: string;
  cpf: string;
  phone_number: string;
}
export const pfSchema = Yup.object().shape({
  birthdate: Yup.date().required('Data de nascimento é obrigatória'),
  first_name: Yup.string()
    .required('Nome completo é obrigatório')
    .test(
      'is-full-name',
      'Digite seu nome completo',
      value => !!value?.split(' ')[1],
    ),
  phone_number: Yup.string().required('Telefone é obrigatório'),
  cpf: Yup.string()
    .required('CPF é obrigatório')
    .test('cpf-is-valid', 'O CPF deve ser válido', value => TestaCPF(value)),
});

export interface IPFUpdateData {
  birthdate: string;
  first_name: string;
  last_name: string;
  cpf: string;
}
export const pfUpdateSchema = Yup.object().shape({
  birthdate: Yup.date().required('Data de nascimento é obrigatória'),
  first_name: Yup.string()
    .required('Nome completo é obrigatório')
    .test(
      'is-full-name',
      'Digite seu nome completo',
      value => !!value?.split(' ')[1],
    ),
  cpf: Yup.string()
    .required('CPF é obrigatório')
    .test('cpf-is-valid', 'O CPF deve ser válido', value => TestaCPF(value)),
});

export interface IPFCreateData {
  birthdate: string;
  first_name: string;
  last_name: string;
  cpf: string;
  phone_number: string;
}
export const pfCreateSchema = Yup.object().shape({
  birthdate: Yup.date().required('Data de nascimento é obrigatória'),
  first_name: Yup.string().required('Nome é obrigatório'),
  phone_number: Yup.string().required('Nome é obrigatório'),
  cpf: Yup.string()
    .required('CPF é obrigatório')
    .test('cpf-is-valid', 'O CPF deve ser válido', value => TestaCPF(value)),
});

export interface IAddressFormData {
  city: string;
  district: string;
  number: string;
  state: string;
  street: string;
  zip_code: string;
  complement: string;
}
export const addressSchema = Yup.object().shape({
  city: Yup.string().required('cidade é obrigatória'),
  district: Yup.string().required('Bairro é obrigatório'),
  number: Yup.string().required('O número é obrigatório'),
  state: Yup.string().required('Estado é obrigatório'),
  street: Yup.string().required('Rua é obrigatória'),
  zip_code: Yup.string().required('CEP é obrigatório'),
});

export interface IAuthConfirmationFormData {
  password: string;
  password_confirmation: string;
}
export const AuthConfirmationSchema = Yup.object().shape({
  password: Yup.string().required('A senha é obrigatória'),
  password_confirmation: Yup.string().when(
    'password',
    (p: string, field: any) =>
      p
        ? field
            .required('A confirmação de senha é obrigatória')
            .oneOf(
              [Yup.ref('password')],
              'A senha e a confirmação deve ser idênticas',
            )
        : field,
  ),
});
export interface IPJFormData {
  cnpj: string;
  company_name: string;
  fantasy_name: string;
}
export const pjSchema = Yup.object().shape({
  cnpj: Yup.string().required('CNPJ é obrigatório'),
  company_name: Yup.string().required('Razão social é obrigatório'),
  fantasy_name: Yup.string().required('Nome fantasia é obrigatório'),
});
