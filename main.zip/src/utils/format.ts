export const { format: formatPrice } = new Intl.NumberFormat('pt-BR', {
  minimumFractionDigits: 2,
});

export const { format: formatAmount } = new Intl.NumberFormat('en-US', {
  minimumFractionDigits: 4,
  maximumFractionDigits: 8,
});

export const cleanNumber = (number: number | string): number => {
  if (typeof number === 'number') {
    return number;
  }

  return Number(number.toString().replace(/[^0-9-]/g, ''));
};

export const normalizeValue = (number: number | string): number => {
  let safeNumber = number;

  if (typeof number === 'string') {
    safeNumber = cleanNumber(number);

    if (safeNumber % 1 !== 0) {
      safeNumber = safeNumber.toFixed(2);
    }
  } else {
    // all input numbers must be a float point (for the cents portion). This is a fallback in case of integer ones.
    safeNumber = Number.isInteger(number)
      ? Number(number) * 10 ** 2
      : number.toFixed(2);
  }

  // divide it by 10 power the maximum fraction digits.
  return cleanNumber(safeNumber) / 10 ** 2;
};

export const formatHash = (value: string): string =>
  value.slice(0, 10).concat('...');

export const formatLargeNumbers = (value: number): string | number => {
  if (Math.abs(value) > 999999) {
    return `${(Math.sign(value) * (Math.abs(value) / 1000000)).toFixed(1)}M`;
  }

  if (Math.abs(value) > 999) {
    return `${(Math.sign(value) * (Math.abs(value) / 1000)).toFixed(1)}k`;
  }

  return Math.sign(value) * Math.abs(value);
};
