interface IApplicationConfig {
  mode: string;
  port: number;
  backend: {
    host: string;
  };
  frontend: {
    host: string;
  };
}

export default {
  mode: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT),

  backend: {
    host: process.env.APP_API_URL,
  },

  frontend: {
    host: process.env.APP_CLIENT_URL,
  },
} as IApplicationConfig;
