interface IBinanceWallet {
  api_secret: string;
  api_key: string;
  url: string;
}

export default {
  api_key: process.env.BINANCE_WALLET_API_KEY,
  api_secret: process.env.BINANCE_WALLET_API_SECRET,
  url: process.env.BINANCE_WALLET_API_URL,
} as IBinanceWallet;
