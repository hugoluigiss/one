interface IBnbConfig {
  host: string;
  secret_phrase: string;
  hdpath: string;
  // chain: 'mainnet' | 'rinkeby';
  etherscan_api_key: string;
  crypto_compare_api_key: string;
}

export default {
  host: process.env.BNB_HOST,
  secret_phrase: process.env.ETH_SECRET_SEED,
  hdpath: process.env.ETH_HD_PATH,
  // chain: process.env.BNB_CHAIN || 'mainnet',
  etherscan_api_key: process.env.BNB_ETHERSCAN_API_KEY,
  crypto_compare_api_key: process.env.CRYPTO_COMPARE_API_KEY,
} as IBnbConfig;
