interface ICafConfig {
  token: string;
  report: string;
}

export default {
  token: process.env.CAF_ACCESS_TOKEN,
  report: process.env.CAF_REPORT,
} as ICafConfig;
