interface IXrpConfig {
  network: 'testnet' | 'mainnet';
  address: string;
  secret: string;
  host: string;
}
export default {
  network: process.env.XRP_NETWORK || 'testnet',
  address: process.env.XRP_ADDRESS || 'rEaoQcJEhiWHDsqktxnzCNu3Jc8tKurfe8',
  secret: process.env.XRP_SECRET || 'ssv5jYu8msUTfAXsiM4V1MBytNuFy',
  host: process.env.XRP_HOST || 'wss://s.altnet.rippletest.net',
} as IXrpConfig;
