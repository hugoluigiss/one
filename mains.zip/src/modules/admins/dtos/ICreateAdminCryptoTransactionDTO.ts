export default interface ICreateAdminCryptoTransactionDTO {
  coin_id: string;
  txid: string;
  address_to: string;
  type: 'deposit' | 'withdrawal';
  fee_network?: string;
  value: string;
}
