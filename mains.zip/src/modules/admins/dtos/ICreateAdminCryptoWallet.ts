export default interface ICreateAdminCryptoWallet {
  coin_id: string;
  address: string;
}
