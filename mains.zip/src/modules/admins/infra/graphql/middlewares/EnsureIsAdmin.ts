/* eslint-disable import/prefer-default-export */
import { AuthenticationError } from 'apollo-server-express';
import { MiddlewareInterface, NextFn, ResolverData } from 'type-graphql';

import { MyContext } from '../../../../../shared/infra/graphql/Context';
import AdminsRepository from '../../typeorm/repositories/AdminsRepository';

export default class EnsureIsAdmin implements MiddlewareInterface<MyContext> {
  async use(
    { context }: ResolverData<MyContext>,
    next: NextFn,
  ): Promise<NextFn> {
    const { client_id } = context;
    if (!client_id) throw new AuthenticationError('Não autorizado');

    const adminsRepository = new AdminsRepository();

    const isAdmin = await adminsRepository.findById(client_id);
    if (!isAdmin) throw new AuthenticationError('Não autorizado');

    context.admin_id = client_id;
    return next();
  }
}
