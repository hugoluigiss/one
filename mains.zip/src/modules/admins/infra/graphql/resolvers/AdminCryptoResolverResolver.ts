import { container } from 'tsyringe';
import { Arg, Mutation, Query, Resolver, UseMiddleware } from 'type-graphql';
import BigNumber from 'bignumber.js';
import CreateAdminCryptoWithdrawalService from '../../../services/CreateAdminCryptoWithdrawalService';
import CheckCoinAddressService from '../../../../coins/services/CheckCoinAddressService';
import GetCustomerCoinWalletBalanceService from '../../../../coins/services/GetCustomerCoinWalletBalanceService';
import ListAllCustomersService from '../../../../customers/services/ListAllCustomersService';
import GetCoinValueConversionService from '../../../../coins/services/GetCoinValueConversionService';
import GetAdminCryptoWalletService from '../../../services/GetAdminCryptoWalletService';
import AdminCryptoWallet from '../../typeorm/entities/AdminCryptoWallet';
import EnsureIsAdmin from '../middlewares/EnsureIsAdmin';

@Resolver()
export default class AdminCryptoResolverResolver {
  @Query(() => AdminCryptoWallet)
  @UseMiddleware(EnsureIsAdmin)
  async GetAdminCryptoWallet(
    @Arg('coin_symbol') coin_symbol: 'BTC' | 'ETH' | 'BNB' | 'USDT',
  ): Promise<AdminCryptoWallet> {
    const getAdminCryptoWalletService = container.resolve(
      GetAdminCryptoWalletService,
    );
    const wallet = await getAdminCryptoWalletService.execute({
      coin_symbol,
    });

    const getCoinValueConversionService = container.resolve(
      GetCoinValueConversionService,
    );
    wallet.brl_balance = await getCoinValueConversionService.execute({
      from: wallet.coin.symbol,
      to: 'BRL',
      value: wallet.balance,
    });

    const listAllCustomersService = container.resolve(ListAllCustomersService);
    const customers = await listAllCustomersService.execute();

    const getCustomerCoinWalletBalanceService = container.resolve(
      GetCustomerCoinWalletBalanceService,
    );

    const balances = await Promise.all(
      customers.map(customer =>
        getCustomerCoinWalletBalanceService.execute({
          coin_symbol,
          customer_id: customer.id,
        }),
      ),
    );

    const total_customers_balance = balances.reduce(
      (acc, curr) => new BigNumber(acc).plus(curr),
      new BigNumber('0'),
    );

    wallet.total_customers_balance = total_customers_balance.toFixed();

    wallet.total_customers_brl_balance =
      await getCoinValueConversionService.execute({
        from: wallet.coin.symbol,
        to: 'BRL',
        value: wallet.total_customers_balance,
      });

    return wallet;
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async CreateAdminCryptoWithdrawal(
    @Arg('address_to') address_to: string,
    @Arg('amount') amount: string,
    @Arg('coin_symbol') coin_symbol: 'BTC' | 'ETH' | 'USDT',
    @Arg('dest_flag', { nullable: true }) dest_flag: number,
  ): Promise<string> {
    const checkCoinAddressService = container.resolve(CheckCoinAddressService);
    await checkCoinAddressService.execute({ address: address_to, coin_symbol });

    const createAdminCryptoWithdrawalService = container.resolve(
      CreateAdminCryptoWithdrawalService,
    );
    await createAdminCryptoWithdrawalService.execute({
      address_to,
      amount,
      coin_symbol,
      dest_flag: dest_flag ? String(dest_flag) : undefined,
    });

    return 'success';
  }
}
