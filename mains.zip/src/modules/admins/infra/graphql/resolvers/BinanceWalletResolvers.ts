import { container } from 'tsyringe';
import { Arg, Mutation, Query, Resolver, UseMiddleware } from 'type-graphql';
import EnsureIsAdmin from '../middlewares/EnsureIsAdmin';
import BinanceCoin from '../../../../../shared/container/providers/BinanceApiProvider/dtos/BinanceCoin';
import GetBinanceCoinsService from '../../../../binance/services/GetBinanceCoinsService';
import CreateBinanceCoinConversionService from '../../../../binance/services/CreateBinanceCoinConversionService';
import GetBinanceSymbolService from '../../../../binance/services/GetBinanceSymbolService';
import GetBinanceSymbolPriceService from '../../../../binance/services/GetBinanceSymbolPriceService';
import GetBinanceCoinsDepositAddressService from '../../../../binance/services/GetBinanceCoinsDepositAddressService';
import DepositAddress from '../../../../../shared/container/providers/BinanceApiProvider/dtos/DepositAddress';
import CreateBinanceCoinwithdrawnService from '../../../../binance/services/CreateBinanceCoinwithdrawnService';
import GetAdminCryptoWalletService from '../../../services/GetAdminCryptoWalletService';

@Resolver()
export default class BinanceWalletResolvers {
  @Query(() => [BinanceCoin])
  @UseMiddleware(EnsureIsAdmin)
  async getBinanceCoins(): Promise<BinanceCoin[]> {
    return container.resolve(GetBinanceCoinsService).execute();
  }

  @Query(() => DepositAddress)
  @UseMiddleware(EnsureIsAdmin)
  async getBinanceCoinDepositAddress(
    @Arg('coin') coin: 'BTC' | 'ETH' | 'USDT' | 'BRL',
  ): Promise<DepositAddress> {
    return container
      .resolve(GetBinanceCoinsDepositAddressService)
      .execute({ coin });
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async createBinanceCoinSwap(
    @Arg('amount') amount: number,
    @Arg('from') from: 'BTC' | 'ETH' | 'USDT' | 'BRL',
    @Arg('to') to: 'BTC' | 'ETH' | 'USDT' | 'BRL',
  ): Promise<string> {
    const symbol = new GetBinanceSymbolService().execute({ from, to });
    await container
      .resolve(CreateBinanceCoinConversionService)
      .execute({ amount, from, to, symbol });
    return 'success';
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async createBinanceCoinTransferToExchange(
    @Arg('amount') amount: number,
    @Arg('coin') coin: 'BTC' | 'ETH',
  ): Promise<string> {
    const wallet = await container
      .resolve(GetAdminCryptoWalletService)
      .execute({ coin_symbol: coin });

    await container.resolve(CreateBinanceCoinwithdrawnService).execute({
      address: wallet.address,
      addressTag: wallet.addressTag,
      amount,
      coin,
    });
    return 'success';
  }

  @Query(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async getBinancePriceConversion(
    @Arg('from') from: 'BTC' | 'ETH' | 'USDT' | 'BRL',
    @Arg('to') to: 'BTC' | 'ETH' | 'USDT' | 'BRL',
  ): Promise<string> {
    const symbol = new GetBinanceSymbolService().execute({ from, to });
    return container
      .resolve(GetBinanceSymbolPriceService)
      .execute({ from, to, symbol });
  }
}
