import { container } from 'tsyringe';
import { Arg, Mutation, Query, Resolver, UseMiddleware } from 'type-graphql';
import ConfirmBrlDepositService from '../../../../deposits/services/ConfirmBrlDepositService';
import ListAllCustomerBrlDepositsService from '../../../../deposits/services/ListAllCustomersBrlDepositsService';
import RefuseBrlDepositService from '../../../../deposits/services/RefuseBrlDepositService';
import PaginationType from '../../../../../shared/infra/graphql/types/PaginationType';
import EnsureIsAdmin from '../middlewares/EnsureIsAdmin';

@Resolver()
export default class AdminBrlDepositsResolvers {
  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async ConfirmCustomerBrlDeposit(
    @Arg('deposit_id') deposit_id: string,
  ): Promise<string> {
    const confirmBrlDepositService = container.resolve(
      ConfirmBrlDepositService,
    );
    await confirmBrlDepositService.execute({ deposit_id });
    return 'success';
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async RefuseCustomerBrlDeposit(
    @Arg('deposit_id') deposit_id: string,
  ): Promise<string> {
    const refuseBrlDepositService = container.resolve(RefuseBrlDepositService);
    await refuseBrlDepositService.execute({ deposit_id });
    return 'success';
  }

  @Query(() => PaginationType)
  @UseMiddleware(EnsureIsAdmin)
  async GetCustomersBrlDeposits(
    @Arg('limit', { nullable: true }) limit: number,
    @Arg('offset', { nullable: true }) offset: number,
    @Arg('customer_id', { nullable: true }) customer_id: string,
    @Arg('status', { nullable: true })
    status: 'pending' | 'confirmed' | 'rejected',
  ): Promise<PaginationType> {
    const listAllCustomerBrlDepositsService = container.resolve(
      ListAllCustomerBrlDepositsService,
    );
    const { count, deposits } = await listAllCustomerBrlDepositsService.execute(
      {
        limit,
        offset,
        customer_id,
        status,
      },
    );

    return {
      edges: { brl_deposits: deposits },
      totalCount: count,
      pageInfo: {
        hasNextPage: limit ? count > limit + limit * (offset || 0) : false,
        hasPrevPage: offset > 0,
      },
    };
  }
}
