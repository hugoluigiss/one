import { container } from 'tsyringe';
import { Arg, Mutation, Query, Resolver, UseMiddleware } from 'type-graphql';
import { FileUpload, GraphQLUpload } from 'graphql-upload';
import PaginationType from '../../../../../shared/infra/graphql/types/PaginationType';
import ListAllCustomersBrlWithdrawalsService from '../../../../withdrawals/services/ListAllCustomersBrlWithdrawalsService';
import SaveFileToTmpFolder from '../../../../../shared/container/providers/StorageProvider/middlewares/SaveFileTmpFolder';
import ConfirmBrlWithdrawalService from '../../../../withdrawals/services/ConfirmBrlWithdrawalService';
import RefuseBrlWithdrawalService from '../../../../withdrawals/services/RefuseBrlWithdrawalService';
import EnsureIsAdmin from '../middlewares/EnsureIsAdmin';

@Resolver()
export default class AdminBrlWithdrawalsResolver {
  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async ConfirmCustomerBrlWithdrawal(
    @Arg('withdrawal_id') withdrawal_id: string,
    @Arg('file', () => GraphQLUpload, { nullable: true }) file?: FileUpload,
  ): Promise<string> {
    let file_name: string | undefined;
    if (file) {
      const saveFileToTmpFolder = new SaveFileToTmpFolder();
      file_name = await saveFileToTmpFolder.execute(file);
    }

    const confirmBrlWithdrawalService = container.resolve(
      ConfirmBrlWithdrawalService,
    );
    await confirmBrlWithdrawalService.execute({
      withdrawal_id,
      file_name: file_name || undefined,
    });

    return 'success';
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async RefuseCustomerBrlWithdrawal(
    @Arg('withdrawal_id') withdrawal_id: string,
    @Arg('comment', { nullable: true }) comment?: string,
  ): Promise<string> {
    const refuseBrlWithdrawalService = container.resolve(
      RefuseBrlWithdrawalService,
    );
    await refuseBrlWithdrawalService.execute({ withdrawal_id, comment });
    // const refuseBrlDepositService = container.resolve(RefuseBrlDepositService);
    // await refuseBrlDepositService.execute({ deposit_id });
    return 'success';
  }

  @Query(() => PaginationType)
  @UseMiddleware(EnsureIsAdmin)
  async GetCustomersBrlWithdrawals(
    @Arg('limit', { nullable: true }) limit: number,
    @Arg('offset', { nullable: true }) offset: number,
    @Arg('customer_id', { nullable: true }) customer_id: string,
    @Arg('status', { nullable: true })
    status: 'pending' | 'confirmed' | 'rejected',
  ): Promise<PaginationType> {
    const listAllCustomersBrlWithdrawalsService = container.resolve(
      ListAllCustomersBrlWithdrawalsService,
    );
    const { count, deposits } =
      await listAllCustomersBrlWithdrawalsService.execute({
        limit,
        offset,
        customer_id,
        status,
      });

    return {
      edges: { brl_withdrawals: deposits },
      totalCount: count,
      pageInfo: {
        hasNextPage: limit ? count > limit + limit * (offset || 0) : false,
        hasPrevPage: offset > 0,
      },
    };
  }
}
