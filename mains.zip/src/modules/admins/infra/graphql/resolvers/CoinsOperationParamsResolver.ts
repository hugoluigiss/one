import { container } from 'tsyringe';
import { Arg, Mutation, Query, Resolver, UseMiddleware } from 'type-graphql';
import UpdateCoinOperationParamService from '../../../../coins/services/UpdateCoinOperationParamService';
import GetAllCoinsOperationsParamsWithFilterService from '../../../../coins/services/GetAllCoinsOperationsParamsWithFilterService';
import CoinOperationParam from '../../../../coins/infra/typeorm/entities/CoinOperationParam';
import EnsureIsAdmin from '../middlewares/EnsureIsAdmin';

@Resolver()
export default class CoinsOperationParamsResolver {
  @Query(() => [CoinOperationParam])
  @UseMiddleware(EnsureIsAdmin)
  async GetAllCoinsOperationParamsWithFilter(
    @Arg('customer_type', { nullable: true }) customer_type?: 'PF' | 'PJ',
    @Arg('operation', { nullable: true })
    operation?: 'buy' | 'sell' | 'deposit' | 'withdrawal' | 'brl_transfer',
    @Arg('has_complience', { nullable: true }) has_complience?: boolean,
  ): Promise<CoinOperationParam[]> {
    const getAllCoinsOperationsParamsWithFilterService = container.resolve(
      GetAllCoinsOperationsParamsWithFilterService,
    );
    const param = await getAllCoinsOperationsParamsWithFilterService.execute({
      customer_type,
      has_complience,
      operation,
    });

    return param;
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async UpdateCoinOperationParam(
    @Arg(`id`) id: string,
    @Arg(`fixed_fee_brl_value`, { nullable: true })
    fixed_fee_brl_value?: string,
    @Arg(`max_brl_value`, { nullable: true }) max_brl_value?: string,
    @Arg(`min_brl_value`, { nullable: true }) min_brl_value?: string,
    @Arg(`percentage_fee_value`, { nullable: true })
    percentage_fee_value?: string,
    @Arg(`validity_period_days`, { nullable: true })
    validity_period_days?: number,
  ): Promise<string> {
    const updateCoinOperationParamService = container.resolve(
      UpdateCoinOperationParamService,
    );
    await updateCoinOperationParamService.execute({
      id,
      fixed_fee_brl_value,
      max_brl_value,
      min_brl_value,
      percentage_fee_value,
      validity_period_days,
    });
    return 'success';
  }
}
