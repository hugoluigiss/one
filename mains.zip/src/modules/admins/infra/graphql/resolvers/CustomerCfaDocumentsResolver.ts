import { container } from 'tsyringe';

import { Resolver, UseMiddleware, Mutation, Arg, Query } from 'type-graphql';
import PaginationType from '../../../../../shared/infra/graphql/types/PaginationType';
import EnsureIsAdmin from '../middlewares/EnsureIsAdmin';

import GetCustomerPendingAnalysisCfaService from '../../../../caf/services/GetCustomerPendingAnalysisCfaService';
import GetCustomerPreProcessedCfaService from '../../../../caf/services/GetCustomerPreProcessedCfaService';
import ApproveCustomerCfaDocumentsService from '../../../../caf/services/ApproveCustomerCfaDocumentsService';
import ReproveCustomerCfaDocumentsService from '../../../../caf/services/ReproveCustomerCfaDocumentsService';

@Resolver()
export default class CfaDocumentsResolver {
  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async ApproveCustomerCfaDocument(
    @Arg('customer_id') customer_id: string,
  ): Promise<string> {
    const approveCustomerCfaDocumentsService = container.resolve(
      ApproveCustomerCfaDocumentsService,
    );
    await approveCustomerCfaDocumentsService.execute(customer_id);

    return 'Documentos enviados ao combate a fraude';
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async ReproveCustomerCfaDocument(
    @Arg('customer_id') customer_id: string,
  ): Promise<string> {
    const reproveCustomerCfaDocumentsService = container.resolve(
      ReproveCustomerCfaDocumentsService,
    );
    await reproveCustomerCfaDocumentsService.execute(customer_id);

    return 'Documentos rejeitados com sucesso';
  }

  @Query(() => PaginationType)
  @UseMiddleware(EnsureIsAdmin)
  async GetCustomerPendingCfaDocuments(
    @Arg('limit', { nullable: true }) limit?: number,
    @Arg('offset', { nullable: true }) offset?: number,
    @Arg('order', { nullable: true }) order?: 'ASC' | 'DESC',
  ): Promise<PaginationType> {
    const getCustomerPendingAnalysisCfaService = container.resolve(
      GetCustomerPendingAnalysisCfaService,
    );

    const { count, cafDocuments } =
      await getCustomerPendingAnalysisCfaService.execute({
        limit,
        offset,
        order,
      });
    return {
      totalCount: count,
      edges: {
        cafDocuments,
      },
      pageInfo: {
        hasNextPage: limit ? count > limit + limit * (offset || 0) : false,
        hasPrevPage: (offset || 0) > 0,
      },
    };
  }

  @Query(() => PaginationType)
  @UseMiddleware(EnsureIsAdmin)
  async GetCustomerPreProcessedCfaDocuments(
    @Arg('limit', { nullable: true }) limit?: number,
    @Arg('offset', { nullable: true }) offset?: number,
    @Arg('order', { nullable: true }) order?: 'ASC' | 'DESC',
  ): Promise<PaginationType> {
    const getCustomerPreProcessedCfaService = container.resolve(
      GetCustomerPreProcessedCfaService,
    );

    const { count, cafDocuments } =
      await getCustomerPreProcessedCfaService.execute({
        limit,
        offset,
        order,
      });
    return {
      totalCount: count,
      edges: {
        cafDocuments,
      },
      pageInfo: {
        hasNextPage: limit ? count > limit + limit * (offset || 0) : false,
        hasPrevPage: (offset || 0) > 0,
      },
    };
  }
}
