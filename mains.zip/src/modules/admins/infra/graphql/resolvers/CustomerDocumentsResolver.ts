import { container } from 'tsyringe';
import { Arg, Mutation, Query, Resolver, UseMiddleware } from 'type-graphql';
import ApproveCustomerDocumentCopyService from '../../../../customers/services/ApproveCustomerDocumentCopyService';
import ListAllCustomerDocumentsService from '../../../../customers/services/ListAllCustomerDocumentsService';
import ReproveCustomerDocumentCopyService from '../../../../customers/services/ReproveCustomerDocumentCopyService';
import PaginationType from '../../../../../shared/infra/graphql/types/PaginationType';
import EnsureIsAdmin from '../middlewares/EnsureIsAdmin';

@Resolver()
export default class CustomerDocumentsResolver {
  @Query(() => PaginationType)
  @UseMiddleware(EnsureIsAdmin)
  async GetCustomersDocuments(
    @Arg('customer_id', { nullable: true }) customer_id?: string,
    @Arg('limit', { nullable: true }) limit?: number,
    @Arg('offset', { nullable: true }) offset?: number,
    @Arg('has_complience', { nullable: true }) has_complience?: boolean,
  ): Promise<PaginationType> {
    const listAllCustomerDocumentsService = container.resolve(
      ListAllCustomerDocumentsService,
    );

    const { count, documents } = await listAllCustomerDocumentsService.execute({
      offset,
      limit,
      customer_id,
      has_complience,
    });

    return {
      totalCount: count,
      edges: {
        documents,
      },
      pageInfo: {
        hasNextPage: limit ? count > limit + limit * (offset || 0) : false,
        hasPrevPage: (offset || 0) > 0,
      },
    };
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async ApproveCustomerDocumentCopy(
    @Arg('document_copy_id') document_copy_id: string,
  ): Promise<string> {
    const approveCustomerDocumentCopyService = container.resolve(
      ApproveCustomerDocumentCopyService,
    );

    await approveCustomerDocumentCopyService.execute({ document_copy_id });
    return 'success';
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async ReproveCustomerDocumentCopy(
    @Arg('document_copy_id') document_copy_id: string,
    @Arg('admin_answear') admin_answear: string,
  ): Promise<string> {
    const reproveCustomerDocumentCopyService = container.resolve(
      ReproveCustomerDocumentCopyService,
    );

    await reproveCustomerDocumentCopyService.execute({
      document_copy_id,
      admin_answear,
    });
    return 'success';
  }
}
