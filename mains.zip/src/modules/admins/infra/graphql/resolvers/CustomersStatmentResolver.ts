import { container } from 'tsyringe';
import { Arg, Query, Resolver, UseMiddleware } from 'type-graphql';
import { CoinsType } from 'src/modules/coins/infra/typeorm/entities/Coin';
import GetCustomerStatmentService from '../../../../coins/services/GetCustomerStatmentService';
import PaginationType from '../../../../../shared/infra/graphql/types/PaginationType';
import EnsureIsAdmin from '../middlewares/EnsureIsAdmin';
import CustomerCoinWallet from '../../../../coins/infra/typeorm/entities/CustomerCoinWallet';
import GetCustomerCoinsWalletsService from '../../../../coins/services/GetCustomerCoinsWalletsService';
import GetCustomerCoinWalletBalanceService from '../../../../coins/services/GetCustomerCoinWalletBalanceService';

@Resolver()
export default class CustomersStatmentResolver {
  @Query(() => PaginationType)
  @UseMiddleware(EnsureIsAdmin)
  async GetCustomersStatments(
    @Arg('coin_symbol', { nullable: true }) coin_symbol?: CoinsType,
    @Arg('limit', { nullable: true }) limit?: number,
    @Arg('offset', { nullable: true }) offset?: number,
    @Arg('status', { nullable: true }) status?: string,
    @Arg('operation', { nullable: true })
    operation?: 'buy' | 'deposit' | 'withdrawal',
  ): Promise<PaginationType> {
    const getCustomerStatmentService = container.resolve(
      GetCustomerStatmentService,
    );
    const { count, transactions } = await getCustomerStatmentService.execute({
      coin_symbol,
      limit: limit || 10,
      offset,
      status,
      operation,
    });
    return {
      edges: {
        transactions,
      },
      pageInfo: {
        hasNextPage: limit ? count > limit + limit * (offset || 0) : false,
        hasPrevPage: (offset || 0) > 0,
      },
      totalCount: count,
    };
  }

  @Query(() => [CustomerCoinWallet])
  @UseMiddleware(EnsureIsAdmin)
  async GetCustomerCoinWallets(
    @Arg('customer_id') customer_id: string,
  ): Promise<CustomerCoinWallet[]> {
    const getCustomerCoinsWalletsService = container.resolve(
      GetCustomerCoinsWalletsService,
    );

    const wallets = await getCustomerCoinsWalletsService.execute({
      customer_id,
    });

    const getCustomerCoinWalletBalanceService = container.resolve(
      GetCustomerCoinWalletBalanceService,
    );

    const walletsWithBalance = await Promise.all(
      wallets.map(async w => ({
        ...w,
        balance: await getCustomerCoinWalletBalanceService.execute({
          coin_symbol: w.coin.symbol,
          customer_id,
        }),
      })),
    );

    return walletsWithBalance as CustomerCoinWallet[];
  }
}
