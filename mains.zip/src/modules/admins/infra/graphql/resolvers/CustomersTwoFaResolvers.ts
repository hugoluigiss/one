import { container } from 'tsyringe';
import { Arg, Mutation, Query, Resolver, UseMiddleware } from 'type-graphql';
import GetCustomersWithPaginationService from '../../../../customers/services/GetCustomersWithPaginationService';
import PaginationType from '../../../../../shared/infra/graphql/types/PaginationType';
import EnsureIsAdmin from '../middlewares/EnsureIsAdmin';
import DestroyTwoFaService from '../../../../customers/services/DestroyTwoFaService';

@Resolver()
export default class CustomersTwoFaResolvers {
  @Query(() => PaginationType)
  @UseMiddleware(EnsureIsAdmin)
  async GetAllCustomers(
    @Arg('limit', { nullable: true }) limit?: number,
    @Arg('offset', { nullable: true }) offset?: number,
    @Arg('order', { nullable: true }) order?: 'ASC' | 'DESC',
  ): Promise<PaginationType> {
    const getCustomersWithPaginationService = container.resolve(
      GetCustomersWithPaginationService,
    );
    const { count, customers } =
      await getCustomersWithPaginationService.execute({
        limit,
        offset,
        order,
      });
    return {
      totalCount: count,
      edges: {
        customers,
      },
      pageInfo: {
        hasNextPage: limit ? count > limit + limit * (offset || 0) : false,
        hasPrevPage: (offset || 0) > 0,
      },
    };
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsAdmin)
  async DeleteTwoFa(@Arg('customer_id') customer_id: string): Promise<string> {
    const destroyTwoFaService = container.resolve(DestroyTwoFaService);
    await destroyTwoFaService.execute({ customer_id });
    return 'success';
  }
}
