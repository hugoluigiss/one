import { container } from 'tsyringe';
import { Resolver, Mutation, Arg } from 'type-graphql';
import CreateAdminSessionService from '../../../services/CreateAdminSessionService';
import AdminSession from '../types/AdminSession';

@Resolver()
export default class AdminSignInResolver {
  @Mutation(() => AdminSession)
  async CreateAdminSession(
    @Arg('email') email: string,
    @Arg('password') password: string,
  ): Promise<AdminSession> {
    const createAdminSessionService = container.resolve(
      CreateAdminSessionService,
    );
    const { token, admin } = await createAdminSessionService.execute({
      email,
      password,
    });
    return { admin, token };
  }
}
