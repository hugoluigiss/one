import SignInResolver from './SignInResolver';
import BrlDepositsResolver from './BrlDepositsResolver';
import BrlWithdrawalsResolver from './BrlWithdrawalsResolver';
import CustomerDocumentsResolver from './CustomerDocumentsResolver';
import AdminCryptoResolverResolver from './AdminCryptoResolverResolver';
import CustomersTwoFaResolvers from './CustomersTwoFaResolvers';
import CoinsOperationParamsResolver from './CoinsOperationParamsResolver';
import CustomersStatmentResolver from './CustomersStatmentResolver';
import CustomerCfaDocumentsResolver from './CustomerCfaDocumentsResolver';
import BinanceWalletResolvers from './BinanceWalletResolvers';

export default [
  CustomersStatmentResolver,
  CoinsOperationParamsResolver,
  SignInResolver,
  BrlDepositsResolver,
  BrlWithdrawalsResolver,
  CustomerDocumentsResolver,
  AdminCryptoResolverResolver,
  CustomersTwoFaResolvers,
  CustomerCfaDocumentsResolver,
  BinanceWalletResolvers,
];
