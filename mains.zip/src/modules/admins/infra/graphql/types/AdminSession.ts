import { ObjectType, Field } from 'type-graphql';
import Admin from '../../typeorm/entities/Admin';

@ObjectType()
class AdminSession {
  @Field()
  token: string;

  @Field(() => Admin)
  admin: Admin;
}

export default AdminSession;
