import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity('admins_crypto_transactions')
class AdminCryptoTransaction {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  txid: string;

  @Column()
  coin_id: string;

  @Column()
  address_to: string;

  @Column()
  value: string;

  @Column()
  fee_network?: string;

  @Column()
  type: 'deposit' | 'withdrawal';

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}

export default AdminCryptoTransaction;
