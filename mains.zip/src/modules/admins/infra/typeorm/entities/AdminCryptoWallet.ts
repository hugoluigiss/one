import { Field, ObjectType } from 'type-graphql';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import Coin from '../../../../coins/infra/typeorm/entities/Coin';

const { format: FormatBrl } = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL',
});

@ObjectType()
@Entity('admins_crypto_wallets')
class AdminCryptoWallet {
  @Field()
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Field()
  @Column()
  address: string;

  @Field()
  @Column()
  coin_id: string;

  @Field(() => Coin)
  @OneToOne(() => Coin, { eager: true })
  @JoinColumn({ name: 'coin_id' })
  coin: Coin;

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;

  @Field()
  balance: string;

  @Field()
  brl_balance: string;

  @Field()
  total_customers_balance: string;

  @Field()
  total_customers_brl_balance: string;

  addressTag: string;

  @Field(() => String)
  get total_customers_brl_balance_formatted(): string {
    return FormatBrl(Number(this.total_customers_brl_balance));
  }

  @Field(() => String)
  get brl_balance_formatted(): string {
    return FormatBrl(Number(this.brl_balance));
  }
}
export default AdminCryptoWallet;
