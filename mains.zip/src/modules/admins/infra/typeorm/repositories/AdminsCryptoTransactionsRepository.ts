import ICreateAdminCryptoTransactionDTO from 'src/modules/admins/dtos/ICreateAdminCryptoTransactionDTO';
import IAdminsCryptoTransactionsRepository from 'src/modules/admins/repositories/IAdminsCryptoTransactionsRepository';
import { getRepository, Repository } from 'typeorm';
import AdminCryptoTransaction from '../entities/AdminCryptoTransaction';

class AdminsCryptoTransactionsRepository
  implements IAdminsCryptoTransactionsRepository
{
  private ormRepository: Repository<AdminCryptoTransaction>;

  constructor() {
    this.ormRepository = getRepository(AdminCryptoTransaction);
  }

  public async create({
    coin_id,
    address_to,
    txid,
    type,
    fee_network,
    value,
  }: ICreateAdminCryptoTransactionDTO): Promise<AdminCryptoTransaction> {
    const transaction = this.ormRepository.create({
      coin_id,
      address_to,
      txid,
      type,
      fee_network,
      value,
    });
    await this.ormRepository.save(transaction);
    return transaction;
  }
}

export default AdminsCryptoTransactionsRepository;
