import ICreateAdminCryptoWallet from 'src/modules/admins/dtos/ICreateAdminCryptoWallet';
import IAdminsCryptoWalletsRepository from 'src/modules/admins/repositories/IAdminsCryptoWalletsRepository';
import { getRepository, Repository } from 'typeorm';
import AdminCryptoWallet from '../entities/AdminCryptoWallet';

class AdminsCryptoWalletsRepository implements IAdminsCryptoWalletsRepository {
  private ormRepository: Repository<AdminCryptoWallet>;

  constructor() {
    this.ormRepository = getRepository(AdminCryptoWallet);
  }

  public async create({
    address,
    coin_id,
  }: ICreateAdminCryptoWallet): Promise<AdminCryptoWallet> {
    const wallet = this.ormRepository.create({ address, coin_id });
    await this.ormRepository.save(wallet);
    return wallet;
  }

  public async findByCoinId(
    coin_id: string,
  ): Promise<AdminCryptoWallet | undefined> {
    return this.ormRepository.findOne({
      where: {
        coin_id,
      },
    });
  }
}
export default AdminsCryptoWalletsRepository;
