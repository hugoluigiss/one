import { container } from 'tsyringe';
import AdminsCryptoTransactionsRepository from '../infra/typeorm/repositories/AdminsCryptoTransactionsRepository';
import AdminsCryptoWalletsRepository from '../infra/typeorm/repositories/AdminsCryptoWalletsRepository';
import AdminsRepository from '../infra/typeorm/repositories/AdminsRepository';
import IAdminsCryptoTransactionsRepository from '../repositories/IAdminsCryptoTransactionsRepository';
import IAdminsCryptoWalletsRepository from '../repositories/IAdminsCryptoWalletsRepository';
import IAdminsRepository from '../repositories/IAdminsRepository';

container.registerSingleton<IAdminsRepository>(
  'AdminsRepository',
  AdminsRepository,
);

container.registerSingleton<IAdminsCryptoWalletsRepository>(
  'AdminsCryptoWalletsRepository',
  AdminsCryptoWalletsRepository,
);

container.registerSingleton<IAdminsCryptoTransactionsRepository>(
  'AdminsCryptoTransactionsRepository',
  AdminsCryptoTransactionsRepository,
);
