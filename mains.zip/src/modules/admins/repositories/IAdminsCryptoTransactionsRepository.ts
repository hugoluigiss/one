import ICreateAdminCryptoTransactionDTO from '../dtos/ICreateAdminCryptoTransactionDTO';
import AdminCryptoTransaction from '../infra/typeorm/entities/AdminCryptoTransaction';

export default interface IAdminsCryptoTransactionsRepository {
  create(
    data: ICreateAdminCryptoTransactionDTO,
  ): Promise<AdminCryptoTransaction>;
}
