import ICreateAdminCryptoWallet from 'src/modules/admins/dtos/ICreateAdminCryptoWallet';
import AdminCryptoWallet from '../infra/typeorm/entities/AdminCryptoWallet';

export default interface IAdminsCryptoWalletsRepository {
  create(data: ICreateAdminCryptoWallet): Promise<AdminCryptoWallet>;
  findByCoinId(coin_id: string): Promise<AdminCryptoWallet | undefined>;
}
