import Admin from '../infra/typeorm/entities/Admin';

export default interface IAdminsRepository {
  findByEmail(email: string): Promise<Admin | undefined>;
  findById(id: string): Promise<Admin | undefined>;
}
