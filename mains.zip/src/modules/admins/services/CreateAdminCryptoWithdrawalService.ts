/* eslint-disable no-console */
import { ApolloError } from 'apollo-server-express';
import BigNumber from 'bignumber.js';
import { inject, injectable } from 'tsyringe';
import ICryptoProvider from '../../../shared/container/providers/CryptoProvider/models/ICryptoProvider';
import ICoinsRepository from '../../coins/repositories/ICoinsRepository';
import AdminCryptoTransaction from '../infra/typeorm/entities/AdminCryptoTransaction';
import IAdminsCryptoTransactionsRepository from '../repositories/IAdminsCryptoTransactionsRepository';

interface IParams {
  coin_symbol: 'BTC' | 'ETH' | 'BNB' | 'USDT';
  address_to: string;
  amount: string;
  dest_flag?: string;
}

interface IMap {
  amounts: {
    [key: string]: string;
  };
  subtractFeeFrom: string[];
}

@injectable()
class CreateAdminCryptoWithdrawalService {
  constructor(
    @inject('AdminsCryptoTransactionsRepository')
    private adminsCryptoTransactionsRepository: IAdminsCryptoTransactionsRepository,

    @inject('CoinsRepository')
    private coinsRepository: ICoinsRepository,

    @inject('BitcoinProvider')
    private bitcoinProvider: ICryptoProvider,

    @inject('EthereumProvider')
    private ethereumProvider: ICryptoProvider, // @inject('RippleProvider') // private rippleProvider: ICryptoProvider,

    @inject('BnbProvider')
    private bnbProvider: ICryptoProvider, // @inject('RippleProvider') // private rippleProvider: ICryptoProvider,
  ) {}

  public async execute({
    coin_symbol,
    address_to,
    amount,
  }: // dest_flag,
  IParams): Promise<AdminCryptoTransaction> {
    const coin = await this.coinsRepository.findBySymbol(coin_symbol);
    if (!coin) throw new ApolloError(`Moeda ${coin_symbol} não encontrada`);

    try {
      let transaction: AdminCryptoTransaction = {} as AdminCryptoTransaction;

      if (coin_symbol === 'BTC') {
        const map: IMap = {} as IMap;
        map.amounts = {};
        map.amounts[address_to] = new BigNumber(amount).toFixed(7);
        map.subtractFeeFrom = [address_to];
        const txid = await this.bitcoinProvider.sendMany({ ...map });
        transaction = await this.adminsCryptoTransactionsRepository.create({
          address_to,
          coin_id: coin.id,
          type: 'withdrawal',
          txid,
          value: amount,
        });
      }

      if (coin_symbol === 'ETH') {
        const txid = await this.ethereumProvider.sendToAddress({
          amount,
          subtract_fee_from_amount: true,
          address: address_to,
        });
        transaction = await this.adminsCryptoTransactionsRepository.create({
          address_to,
          coin_id: coin.id,
          type: 'withdrawal',
          txid,
          value: amount,
        });
      }

      if (coin_symbol === 'BNB') {
        const txid = await this.bnbProvider.sendToAddress({
          amount,
          subtract_fee_from_amount: true,
          address: address_to,
        });
        transaction = await this.adminsCryptoTransactionsRepository.create({
          address_to,
          coin_id: coin.id,
          type: 'withdrawal',
          txid,
          value: amount,
        });
      }

      return transaction;
    } catch (err) {
      console.log(err);
      throw new ApolloError('Erro no processamento');
    }
  }
}
export default CreateAdminCryptoWithdrawalService;
