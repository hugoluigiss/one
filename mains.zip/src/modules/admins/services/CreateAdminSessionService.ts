import { sign } from 'jsonwebtoken';
import { inject, injectable } from 'tsyringe';

import { ApolloError } from 'apollo-server-express';
import authConfig from '../../../config/auth';

import IHashProvider from '../../../shared/container/providers/HashProvider/models/IHashProvider';
import IAdminsRepository from '../repositories/IAdminsRepository';
import AdminSession from '../infra/graphql/types/AdminSession';

interface IRequest {
  email: string;
  password: string;
}

@injectable()
class CreateAdminSessionService {
  constructor(
    @inject('AdminsRepository')
    private adminsRepository: IAdminsRepository,

    @inject('HashProvider')
    private hashProvider: IHashProvider,
  ) {}

  public async execute({ email, password }: IRequest): Promise<AdminSession> {
    const admin = await this.adminsRepository.findByEmail(email);

    if (!admin) {
      throw new ApolloError('E-mail ou senha incorretos');
    }

    const passwordMatched = await this.hashProvider.compareHash(
      password,
      admin.password_hash,
    );

    if (!passwordMatched) {
      throw new ApolloError('E-mail ou senha incorretos');
    }

    const { secret, expiresIn } = authConfig.jwt;

    const token = sign({ subject: admin.id }, secret, {
      expiresIn,
    });

    return { admin, token };
  }
}

export default CreateAdminSessionService;
