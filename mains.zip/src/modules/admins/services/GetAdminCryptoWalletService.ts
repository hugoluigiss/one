import { ApolloError } from 'apollo-server-express';
import { CoinsType } from 'src/modules/coins/infra/typeorm/entities/Coin';
import ICoinsRepository from 'src/modules/coins/repositories/ICoinsRepository';
import ICryptoProvider from 'src/shared/container/providers/CryptoProvider/models/ICryptoProvider';
import { inject, injectable } from 'tsyringe';
import AdminCryptoWallet from '../infra/typeorm/entities/AdminCryptoWallet';
import IAdminsCryptoWalletsRepository from '../repositories/IAdminsCryptoWalletsRepository';

interface IParams {
  coin_symbol: CoinsType;
}

@injectable()
class GetAdminCryptoWalletService {
  constructor(
    @inject('AdminsCryptoWalletsRepository')
    private adminsCryptoWalletsRepository: IAdminsCryptoWalletsRepository,

    @inject('CoinsRepository')
    private coinsRepository: ICoinsRepository,

    @inject('BitcoinProvider')
    private bitcoinProvider: ICryptoProvider,

    @inject('EthereumProvider')
    private ethereumProvider: ICryptoProvider,

    @inject('BnbProvider')
    private bnbProvider: ICryptoProvider,
  ) {}

  public async execute({ coin_symbol }: IParams): Promise<AdminCryptoWallet> {
    const coin = await this.coinsRepository.findBySymbol(coin_symbol);
    if (!coin) throw new ApolloError(`Moeda ${coin_symbol} não encontrada`);

    let wallet = await this.adminsCryptoWalletsRepository.findByCoinId(coin.id);

    if (!wallet) {
      let address: string | null;
      switch (coin_symbol) {
        case 'BTC':
          address = await this.bitcoinProvider.createNewAddress();
          break;
        case 'ETH':
          address = await this.ethereumProvider.createNewAddress(0);
          break;
        case 'BNB':
          address = await this.bnbProvider.createNewAddress(0);
          break;
        case 'USDT':
          address = await this.bnbProvider.createNewAddress(0);
          break;

        default:
          address = null;
      }
      if (!address)
        throw new ApolloError(
          `Endereço não encontrado para moeda ${coin_symbol}`,
        );
      wallet = await this.adminsCryptoWalletsRepository.create({
        coin_id: coin.id,
        address,
      });
    }

    let balance: string;

    switch (coin_symbol) {
      case 'BTC':
        balance = await this.bitcoinProvider.getBalance();
        break;
      case 'ETH':
        balance = await this.ethereumProvider.getBalance(wallet.address);
        break;

      case 'BNB':
        balance = await this.bnbProvider.getBalance(wallet.address);
        break;

      default:
        balance = '0';
    }

    wallet.addressTag = '';

    wallet.balance = balance;

    return wallet;
  }
}
export default GetAdminCryptoWalletService;
