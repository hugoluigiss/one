export default interface ICreateCustomerBankAccountDTO {
  customer_id: string;
  bank_id: string;
  agency: string;
  account: string;
  pix?: string;
}
