import { container } from 'tsyringe';
import { Resolver, Query } from 'type-graphql';
import ListAllBanksService from '../../../services/ListAllBanksService';
import Bank from '../../typeorm/entities/Bank';

@Resolver()
export default class BankResolver {
  @Query(() => [Bank])
  async GetAllBanks(): Promise<Bank[]> {
    const listAllBanksService = container.resolve(ListAllBanksService);
    return listAllBanksService.execute();
  }
}
