import BanksResolver from './BanksResolver';

export default [BanksResolver];
