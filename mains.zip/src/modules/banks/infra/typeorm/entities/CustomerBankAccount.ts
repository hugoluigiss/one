// import Customer from '@modules/customers/infra/typeorm/entities/Customer';
import { Field, ObjectType } from 'type-graphql';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  // ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import Bank from './Bank';

@ObjectType()
@Entity('customers_banks_accounts')
class CustomerBankAccount {
  @Field()
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  customer_id: string;

  // @Field(() => Customer)
  // @ManyToOne(() => Customer)
  // @JoinColumn({ name: 'customer_id' })
  // customer: Customer;

  @Column()
  bank_id: string;

  @Field(() => Bank)
  @OneToOne(() => Bank, { eager: true })
  @JoinColumn({ name: 'bank_id' })
  bank: Bank;

  @Field()
  @Column()
  account: string;

  @Field()
  @Column()
  agency: string;

  @Field({ nullable: true })
  @Column()
  pix: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
export default CustomerBankAccount;
