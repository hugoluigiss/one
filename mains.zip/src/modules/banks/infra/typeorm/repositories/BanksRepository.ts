import { getRepository, Repository } from 'typeorm';

import Bank from '../entities/Bank';
import IBanksRepository from '../../../repositories/IBanksRepository';

class BanksRepository implements IBanksRepository {
  private ormRepository: Repository<Bank>;

  constructor() {
    this.ormRepository = getRepository(Bank);
  }

  public async findById(id: string): Promise<Bank | undefined> {
    const finded = await this.ormRepository.findOne(id);
    return finded;
  }

  public async findAll(): Promise<Bank[]> {
    return this.ormRepository.find();
  }
}

export default BanksRepository;
