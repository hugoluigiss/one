import { getRepository, Repository } from 'typeorm';

import ICustomersBanksAccountsRepository from '../../../repositories/ICustomersBanksAccountsRepository';
import ICreateCustomerBankAccountDTO from '../../../dtos/ICreateCustomerBankAccountDTO';

import CustomerBankAccount from '../entities/CustomerBankAccount';

class CustomersBanksAccountsRepository
  implements ICustomersBanksAccountsRepository
{
  private ormRepository: Repository<CustomerBankAccount>;

  constructor() {
    this.ormRepository = getRepository(CustomerBankAccount);
  }

  public async findById(id: string): Promise<CustomerBankAccount | undefined> {
    return this.ormRepository.findOne({ where: { id } });
  }

  public async findAllByCustomerId(
    customer_id: string,
  ): Promise<CustomerBankAccount[]> {
    const finded = await this.ormRepository.find({ where: { customer_id } });
    return finded;
  }

  public async findByCustomerIdAndBankId(
    customer_id: string,
    bank_id: string,
  ): Promise<CustomerBankAccount | undefined> {
    return this.ormRepository.findOne({ where: { customer_id, bank_id } });
  }

  public async create({
    account,
    agency,
    bank_id,
    customer_id,
    pix,
  }: ICreateCustomerBankAccountDTO): Promise<CustomerBankAccount> {
    const bankAccount = this.ormRepository.create({
      account,
      agency,
      bank_id,
      customer_id,
      pix,
    });
    await this.ormRepository.save(bankAccount);
    return bankAccount;
  }

  public async save(
    account: CustomerBankAccount,
  ): Promise<CustomerBankAccount> {
    return this.ormRepository.save(account);
  }
}

export default CustomersBanksAccountsRepository;
