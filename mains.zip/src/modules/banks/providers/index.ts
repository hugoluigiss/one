import { container } from 'tsyringe';
import BanksRepository from '../infra/typeorm/repositories/BanksRepository';
import CustomersBanksAccountsRepository from '../infra/typeorm/repositories/CustomersBanksAccountsRepository';
import IBanksRepository from '../repositories/IBanksRepository';
import ICustomersBanksAccountsRepository from '../repositories/ICustomersBanksAccountsRepository';

container.registerSingleton<IBanksRepository>(
  'BanksRepository',
  BanksRepository,
);

container.registerSingleton<ICustomersBanksAccountsRepository>(
  'CustomersBanksAccountsRepository',
  CustomersBanksAccountsRepository,
);
