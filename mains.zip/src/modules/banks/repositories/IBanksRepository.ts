import Bank from '../infra/typeorm/entities/Bank';

export default interface IBanksRepository {
  findById(bank_id: string): Promise<Bank | undefined>;
  findAll(): Promise<Bank[]>;
}
