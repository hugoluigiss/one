import ICreateCustomerBankAccountDTO from '../dtos/ICreateCustomerBankAccountDTO';
import CustomerBankAccount from '../infra/typeorm/entities/CustomerBankAccount';

export default interface ICustomersBanksAccountsRepository {
  create(data: ICreateCustomerBankAccountDTO): Promise<CustomerBankAccount>;
  save(account: CustomerBankAccount): Promise<CustomerBankAccount>;
  findByCustomerIdAndBankId(
    customer_id: string,
    bank_id: string,
  ): Promise<CustomerBankAccount | undefined>;
  findAllByCustomerId(customer_id: string): Promise<CustomerBankAccount[]>;
  findById(id: string): Promise<CustomerBankAccount | undefined>;
}
