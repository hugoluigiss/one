import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import ICreateCustomerBankAccountDTO from '../dtos/ICreateCustomerBankAccountDTO';
import CustomerBankAccount from '../infra/typeorm/entities/CustomerBankAccount';
import ICustomersBanksAccountsRepository from '../repositories/ICustomersBanksAccountsRepository';

@injectable()
class CreateCustomerBankAccountService {
  constructor(
    @inject('CustomersBanksAccountsRepository')
    private customersBanksAccountsRepository: ICustomersBanksAccountsRepository,
  ) {}

  public async execute({
    bank_id,
    agency,
    account,
    customer_id,
    pix,
  }: ICreateCustomerBankAccountDTO): Promise<CustomerBankAccount> {
    const alreadyHas =
      await this.customersBanksAccountsRepository.findByCustomerIdAndBankId(
        customer_id,
        bank_id,
      );
    if (alreadyHas)
      throw new ApolloError('Usuário ja possui conta cadastrada no banco');
    const bankAccount = await this.customersBanksAccountsRepository.create({
      pix,
      customer_id,
      account,
      agency,
      bank_id,
    });
    return bankAccount;
  }
}
export default CreateCustomerBankAccountService;
