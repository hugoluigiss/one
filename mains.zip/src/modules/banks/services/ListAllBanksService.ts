import { inject, injectable } from 'tsyringe';

import IBanksRepository from '../repositories/IBanksRepository';
import Bank from '../infra/typeorm/entities/Bank';

import ICacheProvider from '../../../shared/container/providers/CacheProvider/models/ICacheProvider';

@injectable()
class ListAllBanksService {
  constructor(
    @inject('BanksRepository')
    private banksRepository: IBanksRepository,

    @inject('CacheProvider')
    private cacheProvider: ICacheProvider,
  ) {}

  async execute(): Promise<Bank[]> {
    const key = `banks-list:`;
    let banks = await this.cacheProvider.recover<Bank[]>(key);

    if (!banks) {
      banks = await this.banksRepository.findAll();

      await this.cacheProvider.save(key, banks);
    }
    return banks;
  }
}
export default ListAllBanksService;
