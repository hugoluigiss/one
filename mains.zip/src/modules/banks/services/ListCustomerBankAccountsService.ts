import { inject, injectable } from 'tsyringe';
import CustomerBankAccount from '../infra/typeorm/entities/CustomerBankAccount';
import ICustomersBanksAccountsRepository from '../repositories/ICustomersBanksAccountsRepository';

@injectable()
class ListCustomerBankAccountsService {
  constructor(
    @inject('CustomersBanksAccountsRepository')
    private customersBanksAccountsRepository: ICustomersBanksAccountsRepository,
  ) {}

  public async execute(customer_id: string): Promise<CustomerBankAccount[]> {
    const resutlt =
      await this.customersBanksAccountsRepository.findAllByCustomerId(
        customer_id,
      );

    return resutlt;
  }
}
export default ListCustomerBankAccountsService;
