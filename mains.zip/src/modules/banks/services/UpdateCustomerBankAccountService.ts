import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import CustomerBankAccount from '../infra/typeorm/entities/CustomerBankAccount';
import ICustomersBanksAccountsRepository from '../repositories/ICustomersBanksAccountsRepository';

interface IParams {
  bank_id: string;
  agency: string;
  account: string;
  customer_id: string;
  pix?: string;
}

@injectable()
class UpdateCustomerBankAccountService {
  constructor(
    @inject('CustomersBanksAccountsRepository')
    private customersBanksAccountsRepository: ICustomersBanksAccountsRepository,
  ) {}

  public async execute({
    bank_id,
    agency,
    account,
    customer_id,
    pix,
  }: IParams): Promise<CustomerBankAccount> {
    const alreadyHas =
      await this.customersBanksAccountsRepository.findByCustomerIdAndBankId(
        customer_id,
        bank_id,
      );
    if (!alreadyHas) throw new ApolloError('Conta nao encontrada');

    alreadyHas.account = account;
    alreadyHas.agency = agency;
    alreadyHas.pix = pix || '';
    return alreadyHas;
  }
}
export default UpdateCustomerBankAccountService;
