import BigNumber from 'bignumber.js';
import { inject, injectable } from 'tsyringe';
import IBinanceWallet from '../../../shared/container/providers/BinanceApiProvider/models/IBinanceWallet';

@injectable()
class CreateBinanceCoinConversionService {
  constructor(
    @inject('BinanceWallet')
    private binanceWallet: IBinanceWallet,
  ) {}

  public async execute({
    amount,
    from,
    to,
    symbol,
  }: {
    from: 'BTC' | 'ETH' | 'USDT' | 'BRL';
    to: 'BTC' | 'ETH' | 'USDT' | 'BRL';
    amount: number;
    symbol: string;
  }): Promise<void> {
    const allCoins = await this.binanceWallet.getAllCoins();

    const btc = allCoins.find(c => c.coin === 'BTC');

    const type = 'MARKET';

    const eth = allCoins.find(c => c.coin === 'ETH');
    // trocar ETH para BTC
    if (from === 'ETH' && to === 'BTC') {
      const side = 'SELL';
      const quantity = new BigNumber(
        Math.min(amount, Number(eth?.free || 0)),
      ).toFixed(4, 1);
      await this.binanceWallet.createOrder({ type, symbol, side, quantity });
      return;
    }
    // trocar BTC para ETH
    if (from === 'BTC' && to === 'ETH') {
      const side = 'BUY';
      const quoteOrderQty = new BigNumber(
        Math.min(amount, Number(btc?.free || 0)),
      ).toFixed(4, 1);
      await this.binanceWallet.createOrder({
        type,
        symbol,
        side,
        quoteOrderQty,
      });
      return;
    }

    // const xrp = allCoins.find(c => c.coin === 'XRP');
    // // trocar XRP para BTC
    // if (from === 'XRP' && to === 'BTC') {
    //   const side = 'SELL';
    //   const quantity = new BigNumber(
    //     Math.min(amount, Number(xrp?.free || 0)),
    //   ).toFixed(4, 1);
    //   await this.binanceWallet.createOrder({ type, symbol, side, quantity });
    //   return;
    // }
    // trocar BTC para XRP
    // if (from === 'BTC' && to === 'XRP') {
    //   const side = 'BUY';
    //   const quoteOrderQty = new BigNumber(
    //     Math.min(amount, Number(btc?.free || 0)),
    //   ).toFixed(4, 1);
    //   await this.binanceWallet.createOrder({
    //     type,
    //     symbol,
    //     side,
    //     quoteOrderQty,
    //   });
    //   return;
    // }

    const usdt = allCoins.find(c => c.coin === 'USDT');
    // trocar BTC para USDT
    if (from === 'BTC' && to === 'USDT') {
      const side = 'SELL';
      const quantity = new BigNumber(
        Math.min(amount, Number(btc?.free || 0)),
      ).toFixed(4, 1);
      await this.binanceWallet.createOrder({ type, symbol, side, quantity });
      return;
    }
    // trocar USDT para BTC
    if (from === 'USDT' && to === 'BTC') {
      const side = 'BUY';
      const quoteOrderQty = new BigNumber(
        Math.min(amount, Number(usdt?.free || 0)),
      ).toFixed(4, 1);
      await this.binanceWallet.createOrder({
        type,
        symbol,
        side,
        quoteOrderQty,
      });
      return;
    }

    const brl = allCoins.find(c => c.coin === 'BRL');
    // trocar BTC para BRL
    if (from === 'BTC' && to === 'BRL') {
      const side = 'SELL';
      const quantity = new BigNumber(
        Math.min(amount, Number(btc?.free || 0)),
      ).toFixed(4, 1);
      await this.binanceWallet.createOrder({ type, symbol, side, quantity });
      return;
    }
    // trocar BRL para BTC
    if (from === 'BRL' && to === 'BTC') {
      const side = 'BUY';
      const quoteOrderQty = new BigNumber(
        Math.min(amount, Number(brl?.free || 0)),
      ).toFixed(4, 1);
      await this.binanceWallet.createOrder({
        type,
        symbol,
        side,
        quoteOrderQty,
      });
      return;
    }

    // trocar XRP para ETH
    // if (from === 'XRP' && to === 'ETH') {
    //   const side = 'SELL';
    //   const quantity = new BigNumber(
    //     Math.min(amount, Number(xrp?.free || 0)),
    //   ).toFixed(4, 1);
    //   await this.binanceWallet.createOrder({ type, symbol, side, quantity });
    //   return;
    // }
    // // trocar ETH para XRP
    // if (from === 'ETH' && to === 'XRP') {
    //   const side = 'BUY';
    //   const quoteOrderQty = new BigNumber(
    //     Math.min(amount, Number(eth?.free || 0)),
    //   ).toFixed(4, 1);
    //   await this.binanceWallet.createOrder({
    //     type,
    //     symbol,
    //     side,
    //     quoteOrderQty,
    //   });
    //   return;
    // }

    // trocar ETH para USDT
    if (from === 'ETH' && to === 'USDT') {
      const side = 'SELL';
      const quantity = new BigNumber(
        Math.min(amount, Number(eth?.free || 0)),
      ).toFixed(4, 1);
      await this.binanceWallet.createOrder({ type, symbol, side, quantity });
      return;
    }
    // trocar USDT para ETH
    if (from === 'USDT' && to === 'ETH') {
      const side = 'BUY';
      const quoteOrderQty = new BigNumber(
        Math.min(amount, Number(usdt?.free || 0)),
      ).toFixed(4, 1);
      await this.binanceWallet.createOrder({
        type,
        symbol,
        side,
        quoteOrderQty,
      });
      return;
    }

    // trocar ETH para BRL
    if (from === 'ETH' && to === 'BRL') {
      const side = 'SELL';
      const quantity = new BigNumber(
        Math.min(amount, Number(eth?.free || 0)),
      ).toFixed(4, 1);
      await this.binanceWallet.createOrder({ type, symbol, side, quantity });
      return;
    }
    // trocar BRL para ETH
    if (from === 'BRL' && to === 'ETH') {
      const side = 'BUY';
      const quoteOrderQty = new BigNumber(
        Math.min(amount, Number(brl?.free || 0)),
      ).toFixed(4, 1);
      await this.binanceWallet.createOrder({
        type,
        symbol,
        side,
        quoteOrderQty,
      });
      return;
    }

    // trocar XRP para USDT
    // if (from === 'XRP' && to === 'USDT') {
    //   const side = 'SELL';
    //   const quantity = new BigNumber(
    //     Math.min(amount, Number(xrp?.free || 0)),
    //   ).toFixed(4, 1);
    //   await this.binanceWallet.createOrder({ type, symbol, side, quantity });
    //   return;
    // }
    // // trocar USDT para XRP
    // if (from === 'USDT' && to === 'XRP') {
    //   const side = 'BUY';
    //   const quoteOrderQty = new BigNumber(
    //     Math.min(amount, Number(usdt?.free || 0)),
    //   ).toFixed(4, 1);
    //   await this.binanceWallet.createOrder({
    //     type,
    //     symbol,
    //     side,
    //     quoteOrderQty,
    //   });
    //   return;
    // }

    // trocar XRP para BRL
    // if (from === 'XRP' && to === 'BRL') {
    //   const side = 'SELL';
    //   const quantity = new BigNumber(
    //     Math.min(amount, Number(xrp?.free || 0)),
    //   ).toFixed(4, 1);
    //   await this.binanceWallet.createOrder({ type, symbol, side, quantity });
    //   return;
    // }
    // // trocar BRL para XRP
    // if (from === 'BRL' && to === 'XRP') {
    //   const side = 'BUY';
    //   const quoteOrderQty = new BigNumber(
    //     Math.min(amount, Number(brl?.free || 0)),
    //   ).toFixed(4, 1);
    //   await this.binanceWallet.createOrder({
    //     type,
    //     symbol,
    //     side,
    //     quoteOrderQty,
    //   });
    //   return;
    // }

    // trocar USDT para BRL
    if (from === 'USDT' && to === 'BRL') {
      const side = 'SELL';
      const quantity = new BigNumber(
        Math.min(amount, Number(usdt?.free || 0)),
      ).toFixed(4, 1);
      await this.binanceWallet.createOrder({ type, symbol, side, quantity });
      return;
    }
    // trocar BRL para USDT
    if (from === 'BRL' && to === 'USDT') {
      const side = 'BUY';
      const quoteOrderQty = new BigNumber(
        Math.min(amount, Number(brl?.free || 0)),
      ).toFixed(4, 1);
      await this.binanceWallet.createOrder({
        type,
        symbol,
        side,
        quoteOrderQty,
      });
      return;
    }

    throw new Error('Nao implementado');
  }
}

export default CreateBinanceCoinConversionService;
