import { inject, injectable } from 'tsyringe';
import IBinanceWallet from '../../../shared/container/providers/BinanceApiProvider/models/IBinanceWallet';

@injectable()
class CreateBinanceCoinwithdrawnService {
  constructor(
    @inject('BinanceWallet')
    private binanceWallet: IBinanceWallet,
  ) {}

  public async execute({
    coin,
    address,
    addressTag,
    amount,
  }: {
    coin: 'BTC' | 'ETH';
    address: string;
    addressTag: string;
    amount: number;
  }): Promise<void> {
    await this.binanceWallet.createWithdraw({
      coin,
      address,
      addressTag,
      amount,
    });
  }
}

export default CreateBinanceCoinwithdrawnService;
