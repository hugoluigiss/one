import { injectable } from 'tsyringe';
import DepositAddress from '../../../shared/container/providers/BinanceApiProvider/dtos/DepositAddress';

@injectable()
class GetBinanceCoinsDepositAddressService {
  public async execute({ coin }: { coin: string }): Promise<DepositAddress> {
    const deposit = new DepositAddress();
    if (coin === 'BTC') {
      deposit.address = '1DCpGDVDMSnUKC1XLJwtfCidLkxzbnez7f';
      deposit.coin = 'BTC';
      deposit.tag = '';
      deposit.url =
        'https://blockchair.com/bitcoin/address/1DCpGDVDMSnUKC1XLJwtfCidLkxzbnez7f';
      return deposit;
    }

    if (coin === 'ETH' || coin === 'USDT') {
      deposit.address = '0xfd6ee5dfa70519c61501982b3963d19bdeb966f0';
      deposit.coin = coin;
      deposit.tag = '';
      deposit.url =
        'https://etherscan.io/address/0xfd6ee5dfa70519c61501982b3963d19bdeb966f0';
      return deposit;
    }

    // if (coin === 'XRP') {
    //   deposit.coin = 'XRP';
    //   deposit.address = 'rEb8TK3gBgk5auZkwc6sHnwrGVJH8DuaLh';
    //   deposit.url =
    //     'https://bithomp.com/explorer/rEb8TK3gBgk5auZkwc6sHnwrGVJH8DuaLh';
    //   deposit.tag = '607989538';
    //   return deposit;
    // }

    throw new Error('Moeda invalida');
  }
}

export default GetBinanceCoinsDepositAddressService;
