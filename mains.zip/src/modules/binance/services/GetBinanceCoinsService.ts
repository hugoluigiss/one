import { inject, injectable } from 'tsyringe';
import BinanceCoin from '../../../shared/container/providers/BinanceApiProvider/dtos/BinanceCoin';
import IBinanceWallet from '../../../shared/container/providers/BinanceApiProvider/models/IBinanceWallet';

@injectable()
class GetBinanceCoinsService {
  constructor(
    @inject('BinanceWallet')
    private binanceWallet: IBinanceWallet,
  ) {}

  public async execute(): Promise<BinanceCoin[]> {
    const allCoins = await this.binanceWallet.getAllCoins();

    return allCoins.filter(c => ['BTC', 'ETH', 'USDT', 'BRL'].includes(c.coin));
  }
}

export default GetBinanceCoinsService;
