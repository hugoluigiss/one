import BigNumber from 'bignumber.js';
import { inject, injectable } from 'tsyringe';
import IBinanceWallet from '../../../shared/container/providers/BinanceApiProvider/models/IBinanceWallet';

@injectable()
class GetBinanceSymbolPriceService {
  constructor(
    @inject('BinanceWallet')
    private binanceWallet: IBinanceWallet,
  ) {}

  public async execute({
    from,
    to,
    symbol,
  }: {
    from: 'BTC' | 'ETH' | 'USDT' | 'BRL';
    to: 'BTC' | 'ETH' | 'USDT' | 'BRL';
    symbol: string;
  }): Promise<string> {
    const price = await this.binanceWallet.getSymbolPrice(symbol);

    if (
      (from === 'BRL' && to === 'BTC') ||
      (from === 'USDT' && to === 'BTC') ||
      (from === 'BTC' && to === 'ETH') ||
      (from === 'USDT' && to === 'ETH') ||
      (from === 'BRL' && to === 'ETH') ||
      (from === 'BRL' && to === 'USDT')
    )
      return new BigNumber(1).dividedBy(price.price).toFixed();

    return price.price;
  }
}

export default GetBinanceSymbolPriceService;
