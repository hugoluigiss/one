class GetBinanceSymbolService {
  public execute({
    from,
    to,
  }: {
    from: 'BTC' | 'ETH' | 'USDT' | 'BRL';
    to: 'BTC' | 'ETH' | 'USDT' | 'BRL';
  }): string {
    if (
      (from === 'BRL' && to === 'BTC') ||
      (from === 'USDT' && to === 'BTC') ||
      (from === 'BTC' && to === 'ETH') ||
      (from === 'USDT' && to === 'ETH') ||
      (from === 'BRL' && to === 'ETH') ||
      (from === 'BRL' && to === 'USDT')
    )
      return `${to}${from}`;

    return `${from}${to}`;
  }
}

export default GetBinanceSymbolService;
