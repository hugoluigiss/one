import ICoinsRepository from 'src/modules/coins/repositories/ICoinsRepository';
import ICoinsTransactionsRepository from 'src/modules/coins/repositories/ICoinsTransactionsRepository';
import ICryptoCoinsTransactionsRepository from 'src/modules/coins/repositories/ICryptoCoinsTransactionsRepository';
import ICustomersCoinsWalletsRepository from 'src/modules/coins/repositories/ICustomersCoinsWalletsRepository';
import ICacheProvider from 'src/shared/container/providers/CacheProvider/models/ICacheProvider';
import ICryptoProvider from 'src/shared/container/providers/CryptoProvider/models/ICryptoProvider';
import { inject, injectable } from 'tsyringe';

interface ILastVerifiedBlockNumber {
  lastVerifiedBlockNumber: number;
}
interface IBlockTransaction {
  to: string;
  from: string;
  gas: string;
  gasPrice: string;
  eth_amount: string;
  hash: string;
  blockHash: string;
  blockNumber: string;
}
@injectable()
class VerifyBnbNewBlocksService {
  constructor(
    @inject('BnbProvider')
    private bnbProvider: ICryptoProvider,

    @inject('CacheProvider')
    private cacheProvider: ICacheProvider,

    @inject('CustomersCoinsWalletsRepository')
    private customersCoinsWalletsRepository: ICustomersCoinsWalletsRepository,

    @inject('CryptoCoinsTransactionsRepository')
    private cryptoCoinsTransactionsRepository: ICryptoCoinsTransactionsRepository,

    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,

    @inject('CoinsRepository')
    private coinsRepository: ICoinsRepository,
  ) {}

  public async execute(): Promise<void> {
    const bnb = await this.coinsRepository.findBySymbol('BNB');
    if (!bnb) throw new Error('Erro inesperado, moeda bnb não encontrada');

    try {
      const currentBlockNumber = await this.bnbProvider.getCurrentBlockNumber();

      const lastVerified =
        await this.cacheProvider.recover<ILastVerifiedBlockNumber>(
          `bnb-last-verified-block_number:`,
        );
      // console.log({ lastVerified });
      let lastVerifiedBlockNumber = lastVerified
        ? lastVerified.lastVerifiedBlockNumber
        : currentBlockNumber - 1;

      // console.log({
      //   lastVerifiedBlockNumber,
      //   currentBlockNumber,
      // });

      const getTransactionsByBlockNumber = async (
        transactions: IBlockTransaction[],
      ): Promise<IBlockTransaction[]> => {
        const blockTransactions =
          await this.bnbProvider.getAllTransactionsByBlockNumber<
            IBlockTransaction[]
          >(lastVerifiedBlockNumber);

        lastVerifiedBlockNumber += 1;

        transactions.push(...blockTransactions);

        if (lastVerifiedBlockNumber > currentBlockNumber) return transactions;

        await new Promise(r => setTimeout(r, 2000));

        return getTransactionsByBlockNumber(transactions);
      };

      const allBlocksTransactions = await getTransactionsByBlockNumber([]);

      await Promise.all(
        allBlocksTransactions.map(async transaction => {
          const address = transaction.to || '';
          const customerWallet =
            await this.customersCoinsWalletsRepository.findByAddress(address);
          if (customerWallet) {
            const alreadyExists =
              await this.cryptoCoinsTransactionsRepository.findCryptoTransaction(
                {
                  address_to: address,
                  txid: transaction.hash,
                  type: 'deposit',
                },
              );

            const block_height = parseInt(transaction.blockNumber, 16);
            const confirmations = currentBlockNumber - block_height + 1;

            if (!alreadyExists) {
              const coinTransaction =
                await this.coinsTransactionsRepository.create({
                  coin_id: bnb.id,
                  customer_id: customerWallet.customer_id,
                  description: 'Depósito em BNB',
                  fee_value: '0',
                  net_value: transaction.eth_amount,
                  status: confirmations >= 3 ? 'confirmed' : 'pending',
                  total_value: transaction.eth_amount,
                  type: 'input',
                  operation: 'deposit',
                });
              await this.cryptoCoinsTransactionsRepository.create({
                address_to: address,
                type: 'deposit',
                txid: transaction.hash,
                transaction_id: coinTransaction.id,
                blockhash: transaction.blockHash,
                confirmations,
                block_height,
              });
            }
          }
        }),
      );

      const unconfirmedTransactions =
        await this.cryptoCoinsTransactionsRepository.findUnconfirmedTransactions(
          {
            coin_id: bnb.id,
          },
        );

      await Promise.all(
        unconfirmedTransactions.map(async unconfirmed => {
          if (unconfirmed.block_height) {
            const confirmations = currentBlockNumber - unconfirmed.block_height;

            if (confirmations >= 3) {
              await this.cryptoCoinsTransactionsRepository.save({
                ...unconfirmed,
                confirmations,
              });
              const { transaction } = unconfirmed;
              transaction.status = 'confirmed';
              await this.coinsTransactionsRepository.save(transaction);
            }
          }
        }),
      );

      await this.cacheProvider.save(`bnb-last-verified-block_number:`, {
        lastVerifiedBlockNumber,
      });
    } catch (err) {
      throw new Error('Erro na verificação de blocos de bnb');
    }
  }
}
export default VerifyBnbNewBlocksService;
