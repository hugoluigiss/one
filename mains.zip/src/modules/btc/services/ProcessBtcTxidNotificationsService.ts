import { inject, injectable } from 'tsyringe';
import ICryptoProvider from '../../../shared/container/providers/CryptoProvider/models/ICryptoProvider';
import ICoinsTransactionsRepository from '../../coins/repositories/ICoinsTransactionsRepository';
import ICryptoCoinsTransactionsRepository from '../../coins/repositories/ICryptoCoinsTransactionsRepository';
import ICustomersCoinsWalletsRepository from '../../coins/repositories/ICustomersCoinsWalletsRepository';
import ICoinsRepository from '../../coins/repositories/ICoinsRepository';

interface IParams {
  txid: string;
}

@injectable()
class ProcessBtcTxidNotificationsService {
  constructor(
    @inject('BitcoinProvider')
    private bitcoinProvider: ICryptoProvider,

    @inject('CustomersCoinsWalletsRepository')
    private customersCoinsWalletsRepository: ICustomersCoinsWalletsRepository,

    @inject('CryptoCoinsTransactionsRepository')
    private cryptoCoinsTransactionsRepository: ICryptoCoinsTransactionsRepository,

    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,

    @inject('CoinsRepository')
    private coinsRepository: ICoinsRepository,
  ) {}

  public async execute({ txid }: IParams): Promise<void> {
    try {
      const btcTransaction =
        await this.bitcoinProvider.getTransactionByTxid<BitcoinCore.Transaction>(
          txid,
        );
      const btc = await this.coinsRepository.findBySymbol('BTC');
      if (!btc) throw new Error('Erro inesperado, moeda btc não encontrada');

      const { details, confirmations, blockhash } = btcTransaction;

      await Promise.all(
        details.map(async detail => {
          if (detail.category === 'receive') {
            const customerWallet =
              await this.customersCoinsWalletsRepository.findByAddress(
                detail.address,
              );
            if (customerWallet) {
              const alreadyExists =
                await this.cryptoCoinsTransactionsRepository.findCryptoTransaction(
                  {
                    address_to: detail.address,
                    txid: btcTransaction.txid,
                    type: 'deposit',
                  },
                );
              if (alreadyExists) {
                alreadyExists.confirmations = confirmations;
                alreadyExists.blockhash = blockhash;
                await this.cryptoCoinsTransactionsRepository.save(
                  alreadyExists,
                );
              } else {
                const coinTransaction =
                  await this.coinsTransactionsRepository.create({
                    coin_id: btc.id,
                    customer_id: customerWallet.customer_id,
                    description: 'Depósito em BTC',
                    fee_value: '0',
                    net_value: String(
                      detail.category === 'receive'
                        ? detail.amount
                        : detail.amount * -1,
                    ),
                    status: 'pending',
                    total_value: String(
                      detail.category === 'receive'
                        ? detail.amount
                        : detail.amount * -1,
                    ),
                    type: 'input',
                    operation: 'deposit',
                  });
                await this.cryptoCoinsTransactionsRepository.create({
                  address_to: detail.address,
                  type: 'deposit',
                  txid,
                  transaction_id: coinTransaction.id,
                  blockhash,
                  confirmations,
                });
              }
            }
          } else {
            const cryptoWithdrawal =
              await this.cryptoCoinsTransactionsRepository.findCryptoTransaction(
                {
                  address_to: detail.address,
                  txid: btcTransaction.txid,
                  type: 'withdrawal',
                },
              );
            if (cryptoWithdrawal) {
              cryptoWithdrawal.blockhash = blockhash;
              cryptoWithdrawal.confirmations = confirmations;
              await this.cryptoCoinsTransactionsRepository.save(
                cryptoWithdrawal,
              );
            }
          }
        }),
      );
    } catch (err) {
      console.log(err);
      throw new Error('Erro em gettransaction btc');
    }
  }
}
export default ProcessBtcTxidNotificationsService;
