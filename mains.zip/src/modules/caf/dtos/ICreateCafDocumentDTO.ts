export default interface ICreateCafDocumentDTO {
  customer_id: string;
  front: string;
  back: string;
  selfie: string;
  type: 'cnh' | 'rne' | 'rg';
  cpf?: string;
}
