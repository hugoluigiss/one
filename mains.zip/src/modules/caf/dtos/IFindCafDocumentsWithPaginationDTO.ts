export default interface IFindCafDocumentsWithPaginationDTO {
  limit?: number;
  offset?: number;
  order?: 'ASC' | 'DESC';
}
