import CafDocument from '../infra/typeorm/entities/CafDocument';

export default interface IFindCafDocumentsWithPaginationResponseDTO {
  cafDocuments: CafDocument[];
  count: number;
}
