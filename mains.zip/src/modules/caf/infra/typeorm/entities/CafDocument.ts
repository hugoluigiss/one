import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

import { Field, ObjectType } from 'type-graphql';
import upload from '../../../../../config/upload';
import app from '../../../../../config/app';
import Customer from '../../../../customers/infra/typeorm/entities/Customer';

@ObjectType()
@Entity('caf_customers_documents')
class CafDocument {
  @Field()
  @PrimaryGeneratedColumn()
  id: string;

  @Field()
  @Column()
  customer_id: string;

  @Field(() => Customer, { nullable: true })
  @OneToOne(() => Customer, { eager: true })
  @JoinColumn({ name: 'customer_id' })
  customer: Customer;

  @Column()
  front: string;

  @Field(() => String)
  get front_url(): string {
    return upload.driver === 's3'
      ? `https://${upload.config.aws.bucket}.s3.${upload.config.aws.region}.amazonaws.com/${this.front}`
      : `${app.backend.host}/files/${this.front}`;
  }

  @Column()
  back: string;

  @Field(() => String)
  get back_url(): string {
    return upload.driver === 's3'
      ? `https://${upload.config.aws.bucket}.s3.${upload.config.aws.region}.amazonaws.com/${this.back}`
      : `${app.backend.host}/files/${this.back}`;
  }

  @Column()
  selfie: string;

  @Field(() => String)
  get selfie_url(): string {
    return upload.driver === 's3'
      ? `https://${upload.config.aws.bucket}.s3.${upload.config.aws.region}.amazonaws.com/${this.selfie}`
      : `${app.backend.host}/files/${this.selfie}`;
  }

  @Column()
  type: 'cnh' | 'rne' | 'rg';

  @Field()
  @Column()
  status: 'EM ANÁLISE' | 'PENDENTE' | 'APROVADO' | 'REPROVADO' | 'PROCESSANDO';

  @Field(() => String, { nullable: true })
  @Column()
  cpf?: string;

  @Field(() => String, { nullable: true })
  @Column()
  name?: string;

  @Field(() => String, { nullable: true })
  @Column()
  fraud?: boolean;

  @Field(() => String, { nullable: true })
  @Column()
  birth_date?: string;

  @Field(() => String, { nullable: true })
  @Column()
  execution?: string;

  @Field(() => String, { nullable: true })
  @Column()
  report?: string;

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;
}
export default CafDocument;
