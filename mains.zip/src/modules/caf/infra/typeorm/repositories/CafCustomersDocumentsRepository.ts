import { getRepository, In, IsNull } from 'typeorm';
import IFindCafDocumentsWithPaginationResponseDTO from 'src/modules/caf/dtos/IFindCafDocumentsWithPaginationResponseDTO';
import IFindCafDocumentsWithPaginationDTO from 'src/modules/caf/dtos/IFindCafDocumentsWithPaginationDTO';
import ICreateCafDocumentDTO from '../../../dtos/ICreateCafDocumentDTO';
import ICafCustomersDocumentsRepository from '../../../repositories/ICafCustomersDocumentsRepository';
import CafDocument from '../entities/CafDocument';

class CafCustomersDocumentsRepository
  implements ICafCustomersDocumentsRepository
{
  constructor(private ormRepository = getRepository(CafDocument)) {}

  public async create({
    back,
    customer_id,
    front,
    selfie,
    type,
    cpf,
  }: ICreateCafDocumentDTO): Promise<CafDocument> {
    const document = this.ormRepository.create({
      back,
      customer_id,
      front,
      selfie,
      type,
      cpf,
      status: 'EM ANÁLISE',
    });

    await this.ormRepository.save(document);

    return document;
  }

  public async findNotDelivered(): Promise<CafDocument[]> {
    return this.ormRepository.find({
      where: {
        execution: IsNull(),
        report: IsNull(),
        status: 'PROCESSANDO',
      },
    });
  }

  public async findNotFinished(): Promise<CafDocument[]> {
    return this.ormRepository.find({
      where: {
        status: 'PROCESSANDO',
      },
    });
  }

  public async save(document: CafDocument): Promise<CafDocument> {
    return this.ormRepository.save(document);
  }

  public async findNotReproved(
    customer_id: string,
  ): Promise<CafDocument | undefined> {
    return this.ormRepository.findOne({
      where: {
        customer_id,
        status: In(['EM ANÁLISE', 'PROCESSANDO', 'APROVADO']),
      },
    });
  }

  public async findApproved(
    customer_id: string,
  ): Promise<CafDocument | undefined> {
    return this.ormRepository.findOne({
      where: {
        customer_id,
        status: 'APROVADO',
      },
    });
  }

  public async findAllPendingAnalysisCafDocumentsWithPagination({
    limit,
    offset,
    order,
  }: IFindCafDocumentsWithPaginationDTO): Promise<IFindCafDocumentsWithPaginationResponseDTO> {
    const query = this.ormRepository.createQueryBuilder(
      'caf_customers_documents',
    );

    if (limit) {
      query.limit(limit);
      if (offset) query.offset(limit * offset);
    }

    query.leftJoinAndSelect('caf_customers_documents.customer', 'customer');

    query.orderBy('caf_customers_documents.created_at', order || 'ASC');

    query.where('caf_customers_documents.status = :status', {
      status: 'EM ANÁLISE',
    });

    const cafDocuments = await query.getMany();
    const count = await query.getCount();

    return { cafDocuments, count };
  }

  public async findAllPreProcessedCafDocumentsWithPagination({
    limit,
    offset,
    order,
  }: IFindCafDocumentsWithPaginationDTO): Promise<IFindCafDocumentsWithPaginationResponseDTO> {
    const query = this.ormRepository.createQueryBuilder(
      'caf_customers_documents',
    );

    if (limit) {
      query.limit(limit);
      if (offset) query.offset(limit * offset);
    }

    query.leftJoinAndSelect('caf_customers_documents.customer', 'customer');

    query.orderBy('caf_customers_documents.created_at', order || 'ASC');

    query.where('caf_customers_documents.status != :status', {
      status: 'EM ANÁLISE',
    });

    const cafDocuments = await query.getMany();
    const count = await query.getCount();

    return { cafDocuments, count };
  }

  public async findPendingAnalysis(
    customer_id: string,
  ): Promise<CafDocument | undefined> {
    return this.ormRepository.findOne({
      where: {
        customer_id,
        status: 'EM ANÁLISE',
      },
    });
  }
}
export default CafCustomersDocumentsRepository;
