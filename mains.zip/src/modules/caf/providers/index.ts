import { container } from 'tsyringe';
import CafCustomersDocumentsRepository from '../infra/typeorm/repositories/CafCustomersDocumentsRepository';
import ICafCustomersDocumentsRepository from '../repositories/ICafCustomersDocumentsRepository';

container.registerSingleton<ICafCustomersDocumentsRepository>(
  'CafCustomersDocumentsRepository',
  CafCustomersDocumentsRepository,
);
