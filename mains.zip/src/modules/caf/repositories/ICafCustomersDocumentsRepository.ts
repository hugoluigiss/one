import ICreateCafDocumentDTO from '../dtos/ICreateCafDocumentDTO';
import IFindCafDocumentsWithPaginationDTO from '../dtos/IFindCafDocumentsWithPaginationDTO';
import IFindCafDocumentsWithPaginationResponseDTO from '../dtos/IFindCafDocumentsWithPaginationResponseDTO';
import CafDocument from '../infra/typeorm/entities/CafDocument';

export default interface ICafCustomersDocumentsRepository {
  create(data: ICreateCafDocumentDTO): Promise<CafDocument>;
  save(document: CafDocument): Promise<CafDocument>;
  findNotDelivered(): Promise<CafDocument[]>;
  findNotFinished(): Promise<CafDocument[]>;
  findNotReproved(customer_id: string): Promise<CafDocument | undefined>;
  findApproved(customer_id: string): Promise<CafDocument | undefined>;
  findAllPendingAnalysisCafDocumentsWithPagination(
    data: IFindCafDocumentsWithPaginationDTO,
  ): Promise<IFindCafDocumentsWithPaginationResponseDTO>;
  findAllPreProcessedCafDocumentsWithPagination(
    data: IFindCafDocumentsWithPaginationDTO,
  ): Promise<IFindCafDocumentsWithPaginationResponseDTO>;
  findPendingAnalysis(customer_id: string): Promise<CafDocument | undefined>;
}
