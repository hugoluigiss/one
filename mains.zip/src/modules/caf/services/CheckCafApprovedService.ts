import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import CafDocument from '../infra/typeorm/entities/CafDocument';
import ICafCustomersDocumentsRepository from '../repositories/ICafCustomersDocumentsRepository';

interface IParams {
  customer_id: string;
}

@injectable()
class CheckCafApprovedService {
  constructor(
    @inject('CafCustomersDocumentsRepository')
    private cafCustomersDocumentsRepository: ICafCustomersDocumentsRepository,
  ) {}

  public async execute({
    customer_id,
  }: IParams): Promise<CafDocument | undefined> {
    const document = await this.cafCustomersDocumentsRepository.findApproved(
      customer_id,
    );
    if (!document)
      throw new ApolloError('Operacao permitida apos aprovacao dos documentos');
    return document;
  }
}
export default CheckCafApprovedService;
