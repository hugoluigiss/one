import { inject, injectable } from 'tsyringe';
import IStorageProvider from '../../../shared/container/providers/StorageProvider/models/IStorageProvider';
import CafDocument from '../infra/typeorm/entities/CafDocument';
import ICafCustomersDocumentsRepository from '../repositories/ICafCustomersDocumentsRepository';

interface IParams {
  customer_id: string;
  front: string;
  back: string;
  selfie: string;
  type: 'cnh' | 'rne' | 'rg';
  cpf?: string;
}

@injectable()
class CreateCustomerCfaDocumentService {
  constructor(
    @inject('CafCustomersDocumentsRepository')
    private cafCustomersDocumentsRepository: ICafCustomersDocumentsRepository,

    @inject('StorageProvider')
    private storageProvider: IStorageProvider,
  ) {}

  public async execute({
    back,
    customer_id,
    front,
    selfie,
    type,
    cpf,
  }: IParams): Promise<CafDocument> {
    await this.storageProvider.saveFile(back);
    await this.storageProvider.saveFile(front);
    await this.storageProvider.saveFile(selfie);
    const document = await this.cafCustomersDocumentsRepository.create({
      back,
      customer_id,
      front,
      selfie,
      type,
      cpf,
    });
    return document;
  }
}
export default CreateCustomerCfaDocumentService;
