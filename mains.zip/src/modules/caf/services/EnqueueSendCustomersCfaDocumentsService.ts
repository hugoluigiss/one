import { inject, injectable } from 'tsyringe';
import IQueue from '../../../shared/container/providers/QueueProvider/models/IQueue';

@injectable()
class EnqueueSendCustomersCfaDocumentsService {
  constructor(
    @inject('SendCustomersCfaDocumentsQueue')
    private sendCustomersCfaDocumentsQueue: IQueue,
  ) {}

  public async execute(): Promise<string> {
    return this.sendCustomersCfaDocumentsQueue.add(undefined);
  }
}
export default EnqueueSendCustomersCfaDocumentsService;
