import { inject, injectable } from 'tsyringe';
import CafDocument from '../infra/typeorm/entities/CafDocument';
import ICafCustomersDocumentsRepository from '../repositories/ICafCustomersDocumentsRepository';

interface IParams {
  customer_id: string;
}

@injectable()
class GetCustomerNotReprovedCfaService {
  constructor(
    @inject('CafCustomersDocumentsRepository')
    private cafCustomersDocumentsRepository: ICafCustomersDocumentsRepository,
  ) {}

  public async execute({
    customer_id,
  }: IParams): Promise<CafDocument | undefined> {
    const document = await this.cafCustomersDocumentsRepository.findNotReproved(
      customer_id,
    );
    return document;
  }
}
export default GetCustomerNotReprovedCfaService;
