import { inject, injectable } from 'tsyringe';
import IFindCafDocumentsWithPaginationDTO from '../dtos/IFindCafDocumentsWithPaginationDTO';
import IFindCafDocumentsWithPaginationResponseDTO from '../dtos/IFindCafDocumentsWithPaginationResponseDTO';
import ICafCustomersDocumentsRepository from '../repositories/ICafCustomersDocumentsRepository';

@injectable()
class GetCustomerNotReprovedCfaService {
  constructor(
    @inject('CafCustomersDocumentsRepository')
    private cafCustomersDocumentsRepository: ICafCustomersDocumentsRepository,
  ) {}

  public async execute({
    limit,
    offset,
    order,
  }: IFindCafDocumentsWithPaginationDTO): Promise<IFindCafDocumentsWithPaginationResponseDTO> {
    const { cafDocuments, count } =
      await this.cafCustomersDocumentsRepository.findAllPreProcessedCafDocumentsWithPagination(
        {
          limit,
          offset,
          order,
        },
      );
    return { cafDocuments, count };
  }
}
export default GetCustomerNotReprovedCfaService;
