import { inject, injectable } from 'tsyringe';
import ICafProvider from '../../../shared/container/providers/Caf/models/ICafProvider';
import ICafCustomersDocumentsRepository from '../repositories/ICafCustomersDocumentsRepository';

@injectable()
class GetCustomersCfaDocumentsStatusService {
  constructor(
    @inject('CafCustomersDocumentsRepository')
    private cafCustomersDocumentsRepository: ICafCustomersDocumentsRepository,

    @inject('CafProvider')
    private cafProvider: ICafProvider,
  ) {}

  public async execute(): Promise<void> {
    const notFinished =
      await this.cafCustomersDocumentsRepository.findNotFinished();

    let index = -1;
    const serialize = async (): Promise<string> => {
      index += 1;
      if (index === notFinished.length) return 'done';
      if (!notFinished[index].execution || !notFinished[index].report)
        return serialize();
      const result = await this.cafProvider.getDocumentStatus(
        notFinished[index],
      );
      if (!result) return serialize();

      if (result.status !== 'APROVADO' && result.status !== 'REPROVADO')
        return serialize();

      notFinished[index].status = result.status;
      notFinished[index].name = result.data.name;
      notFinished[index].cpf = result.data.cpf;
      notFinished[index].fraud = result.fraud;
      notFinished[index].birth_date = result.data.birthDate;

      await this.cafCustomersDocumentsRepository.save(notFinished[index]);

      return serialize();
    };

    await serialize();
  }
}
export default GetCustomersCfaDocumentsStatusService;
