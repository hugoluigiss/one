import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import ICafCustomersDocumentsRepository from '../repositories/ICafCustomersDocumentsRepository';

@injectable()
class ReproveCustomerCfaDocumentsService {
  constructor(
    @inject('CafCustomersDocumentsRepository')
    private cafCustomersDocumentsRepository: ICafCustomersDocumentsRepository,
  ) {}

  public async execute(customer_id: string): Promise<void> {
    const pendingAnalysis =
      await this.cafCustomersDocumentsRepository.findPendingAnalysis(
        customer_id,
      );

    if (!pendingAnalysis) throw new ApolloError('Documento não encontrado');

    pendingAnalysis.status = 'REPROVADO';

    await this.cafCustomersDocumentsRepository.save(pendingAnalysis);
  }
}
export default ReproveCustomerCfaDocumentsService;
