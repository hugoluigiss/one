import { inject, injectable } from 'tsyringe';
import ICafProvider from '../../../shared/container/providers/Caf/models/ICafProvider';
import ICafCustomersDocumentsRepository from '../repositories/ICafCustomersDocumentsRepository';

@injectable()
class SendCustomersCfaDocumentsService {
  constructor(
    @inject('CafCustomersDocumentsRepository')
    private cafCustomersDocumentsRepository: ICafCustomersDocumentsRepository,

    @inject('CafProvider')
    private cafProvider: ICafProvider,
  ) {}

  public async execute(): Promise<void> {
    const notDelivered =
      await this.cafCustomersDocumentsRepository.findNotDelivered();

    let index = -1;
    const serialize = async (): Promise<string> => {
      index += 1;
      if (index === notDelivered.length) return 'done';
      const result = await this.cafProvider.sendDocument(notDelivered[index]);
      if (!result) return serialize();

      const { execution, report } = result;

      notDelivered[index].report = report;
      notDelivered[index].execution = execution;

      await this.cafCustomersDocumentsRepository.save(notDelivered[index]);

      return serialize();
    };

    await serialize();
  }
}
export default SendCustomersCfaDocumentsService;
