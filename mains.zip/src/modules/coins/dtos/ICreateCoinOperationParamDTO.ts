export default interface ICreateCoinOperationParamDTO {
  operation: 'buy' | 'sell' | 'deposit' | 'withdrawal' | 'brl_transfer';
  has_complience: boolean;
  customer_type: 'PF' | 'PJ';
  coin_id: string;
  fixed_fee_brl_value: string;
  percentage_fee_value: string;
  min_brl_value?: string;
  max_brl_value?: string;
  validity_period_days?: number;
}
