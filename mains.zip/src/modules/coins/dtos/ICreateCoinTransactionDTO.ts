export default interface ICreateCoinTransactionDTO {
  customer_id: string;
  coin_id: string;
  net_value: string;
  fee_value: string;
  total_value: string;
  status: 'pending' | 'confirmed' | 'refused' | 'canceled';
  type: 'input' | 'output';
  description: string;
  operation: 'buy' | 'sell' | 'deposit' | 'withdrawal' | 'brl_transfer';
}
