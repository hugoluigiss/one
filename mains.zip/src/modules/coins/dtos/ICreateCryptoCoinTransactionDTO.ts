export default interface ICreateCryptoCoinTransactionDTO {
  transaction_id: string;
  txid?: string;
  address_to: string;
  dest_flag?: string;
  fee_network?: string;
  type: 'deposit' | 'withdrawal';
  blockhash?: string;
  confirmations?: number;
  block_height?: number;
}
