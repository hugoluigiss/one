export default interface ICreateCustomerCoinWalletDTO {
  customer_id: string;
  coin_id: string;
}
