export default interface IFindAllCoinTransactionDTO {
  filter?: {
    customer_id?: string;
    coin_id?: string;
  };
}
