export default interface IFindAllCoinsOperationParamsWithFilterDTO {
  operation?: 'buy' | 'sell' | 'deposit' | 'withdrawal' | 'brl_transfer';
  customer_type?: 'PF' | 'PJ';
  has_complience?: boolean;
}
