import { CoinsType } from '../infra/typeorm/entities/Coin';

export default interface IFindAndPaginateCoinsTransactionsDTO {
  start_date?: Date;
  final_date?: Date;
  coin_symbol?: CoinsType;
  customer_id?: string;
  limit?: number;
  offset?: number;
  status?: string;
  operation?: 'deposit' | 'buy' | 'withdrawal' | 'all';
}
