import CoinTransaction from '../infra/typeorm/entities/CoinTransaction';

export default interface IFindAndPaginateCoinsTransactionsResponseDTO {
  count: number;
  transactions: CoinTransaction[];
}
