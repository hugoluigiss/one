export default interface IFindCoinOperationParamsDTO {
  coin_id: string;
  has_complience: boolean;
  operation: 'buy' | 'sell' | 'deposit' | 'withdrawal' | 'brl_transfer';
  customer_type: 'PF' | 'PJ';
}
