export default interface IFindCryptoTransactionDTO {
  txid: string;
  address_to: string;
  type: 'deposit' | 'withdrawal';
}
