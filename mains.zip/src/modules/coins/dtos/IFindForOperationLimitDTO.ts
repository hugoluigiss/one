export default interface IFindForOperationLimitDTO {
  customer_id: string;
  start_date: Date;
  description: string;
  coin_id: string;
}
