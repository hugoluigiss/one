export default interface IFindUnconfirmedCryptoCoinsTransactionsDTO {
  coin_id: string;
}
