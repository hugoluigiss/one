import { Field, ObjectType } from 'type-graphql';
import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  OneToMany,
} from 'typeorm';
import CoinTransaction from './CoinTransaction';
import CoinOperationParam from './CoinOperationParam';

export type CoinsType = 'BTC' | 'ETH' | 'BRL' | 'BNB' | 'USDT';

@ObjectType()
@Entity('coins')
class Coin {
  @Field()
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Field()
  @Column()
  name: string;

  @OneToMany(() => CoinTransaction, transaction => transaction.coin)
  transactions: CoinTransaction[];

  @OneToMany(
    () => CoinOperationParam,
    coinOperationParam => coinOperationParam.coin,
  )
  params: CoinOperationParam[];

  @Field()
  @Column()
  type: 'fiat' | 'spot';

  @Field()
  @Column()
  symbol: CoinsType;

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;
}
export default Coin;
