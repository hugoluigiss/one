import BigNumber from 'bignumber.js';
import { container } from 'tsyringe';
import { Field, ObjectType } from 'type-graphql';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import GetNetworkFeeService from '../../../../fees/services/GetNetworkFeeService';
import Coin from './Coin';

const { format: FormatBrl } = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL',
});
@ObjectType()
@Entity('coins_operations_params')
class CoinOperationParam {
  @Field()
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  coin_id: string;

  @Field(() => Coin)
  @ManyToOne(() => Coin, coin => coin.params, { eager: true })
  @JoinColumn({ name: 'coin_id' })
  coin: Coin;

  @Field()
  @Column()
  operation: 'buy' | 'sell' | 'deposit' | 'withdrawal' | 'brl_transfer';

  @Field(() => String)
  get name(): string {
    switch (this.operation) {
      case 'buy':
        return 'Compra';

      case 'sell':
        return 'Venda';

      case 'deposit':
        return 'Depósito';

      case 'withdrawal':
        return 'Saque';

      case 'brl_transfer':
        return 'Transferência';

      default:
        return '';
    }
  }

  get transaction_description(): string {
    switch (this.operation) {
      case 'buy':
        return `Compra de ${this.coin.symbol}`;

      case 'sell':
        return `Venda de ${this.coin.symbol}`;

      case 'deposit':
        return `Depósito de ${this.coin.symbol}`;

      case 'withdrawal':
        return `Saque de ${this.coin.symbol}`;

      case 'brl_transfer':
        return `Transferência de ${this.coin.symbol}`;

      default:
        return '';
    }
  }

  @Field()
  @Column()
  fixed_fee_brl_value: string;

  @Field(() => String)
  get fixed_fee_brl_value_formatted(): string {
    return FormatBrl(new BigNumber(this.fixed_fee_brl_value).toNumber());
  }

  @Field()
  @Column()
  min_brl_value: string;

  @Field(() => String)
  get min_brl_value_formatted(): string {
    return FormatBrl(new BigNumber(this.min_brl_value).toNumber());
  }

  @Field()
  @Column()
  max_brl_value: string;

  @Field(() => String)
  get max_brl_value_formatted(): string {
    return FormatBrl(new BigNumber(this.max_brl_value).toNumber());
  }

  @Field()
  @Column()
  validity_period_days: number;

  @Field(() => String)
  get network_fee(): Promise<string> {
    const getNetworkFeeService = container.resolve(GetNetworkFeeService);
    return getNetworkFeeService.execute({ coin_symbol: this.coin.symbol });
  }

  @Field()
  @Column()
  percentage_fee_value: string;

  @Field(() => String)
  get percentage_fee_value_formatted(): string {
    return `${(Number(this.percentage_fee_value) * 100).toFixed(2)}%`;
  }

  @Field()
  @Column()
  customer_type: 'PF' | 'PJ';

  @Field()
  @Column()
  has_complience: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
export default CoinOperationParam;
