// import Customer from '@modules/customers/infra/typeorm/entities/Customer';
import BigNumber from 'bignumber.js';
import { Field, ObjectType } from 'type-graphql';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import BrlWithdrawal from '../../../../withdrawals/infra/typeorm/entities/BrlWaithdrawal';
import BrlDeposit from '../../../../deposits/infra/typeorm/entities/BrlDeposit';
import Customer from '../../../../customers/infra/typeorm/entities/Customer';
import Coin from './Coin';

const { format: FormatBrl } = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL',
});

@ObjectType()
@Entity('coins_transactions')
class CoinTransaction {
  @Field()
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Field()
  @Column()
  operation: 'buy' | 'sell' | 'deposit' | 'withdrawal' | 'brl_transfer';

  @Column()
  customer_id: string;

  @Field(() => BrlDeposit, { nullable: true })
  @OneToOne(() => BrlDeposit, brl_deposit => brl_deposit.transaction)
  brl_deposit?: BrlDeposit;

  @Field(() => BrlWithdrawal, { nullable: true })
  @OneToOne(() => BrlWithdrawal, brl_withdrawal => brl_withdrawal.transaction)
  brl_withdrawal?: BrlWithdrawal;

  @Column()
  coin_id: string;

  @Field(() => Coin)
  @ManyToOne(() => Coin, coin => coin.transactions, { eager: true })
  @JoinColumn({ name: 'coin_id' })
  coin: Coin;

  @Field(() => Customer)
  @ManyToOne(() => Customer, customer => customer.transactions, { eager: true })
  @JoinColumn({ name: 'customer_id' })
  customer: Customer;

  @Column()
  net_value: string;

  @Column()
  fee_value: string;

  @Column()
  total_value: string;

  @Field()
  @Column()
  status: 'pending' | 'confirmed' | 'refused' | 'canceled';

  @Field()
  @Column()
  type: 'input' | 'output';

  @Field()
  @Column()
  description: string;

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;

  @Field(() => String)
  get formatted_net_value(): string {
    switch (this.coin.symbol) {
      case 'BRL':
        return FormatBrl(
          new BigNumber(this.net_value)
            .times(this.type === 'input' ? '1' : '-1')
            .toNumber(),
        );

      case 'ETH':
        return `${new BigNumber(this.net_value)
          .times(this.type === 'input' ? '1' : '-1')
          .toFixed()} ETH`;

      case 'BNB':
        return `${new BigNumber(this.net_value)
          .times(this.type === 'input' ? '1' : '-1')
          .toFixed()} BNB`;

      case 'USDT':
        return `${new BigNumber(this.net_value)
          .times(this.type === 'input' ? '1' : '-1')
          .toFixed()} USDT`;

      default:
        return this.net_value;
    }
  }

  @Field(() => String)
  get formatted_fee_value(): string {
    switch (this.coin.symbol) {
      case 'BRL':
        return FormatBrl(
          new BigNumber(this.fee_value)
            // .times(this.type === 'input' ? '1' : '-1')
            .toNumber(),
        );

      case 'ETH':
        return `${new BigNumber(this.fee_value)
          // .times(this.type === 'input' ? '1' : '-1')
          .toFixed()} ETH`;

      case 'BNB':
        return `${new BigNumber(this.fee_value)
          // .times(this.type === 'input' ? '1' : '-1')
          .toFixed()} BNB`;

      case 'USDT':
        return `${new BigNumber(this.fee_value)
          // .times(this.type === 'input' ? '1' : '-1')
          .toFixed()} USDT`;

      default:
        return this.fee_value;
    }
  }

  @Field(() => String)
  get formatted_total_value(): string {
    switch (this.coin.symbol) {
      case 'BRL':
        return FormatBrl(
          new BigNumber(this.total_value)
            .times(this.type === 'input' ? '1' : '-1')
            .toNumber(),
        );

      case 'ETH':
        return `${new BigNumber(this.total_value)
          .times(this.type === 'input' ? '1' : '-1')
          .toFixed()} ETH`;

      case 'BNB':
        return `${new BigNumber(this.total_value)
          .times(this.type === 'input' ? '1' : '-1')
          .toFixed()} BNB`;

      case 'USDT':
        return `${new BigNumber(this.total_value)
          .times(this.type === 'input' ? '1' : '-1')
          .toFixed()} USDT`;

      default:
        return this.total_value;
    }
  }
}
export default CoinTransaction;
