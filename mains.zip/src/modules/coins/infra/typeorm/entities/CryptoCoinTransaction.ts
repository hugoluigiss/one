import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import CoinTransaction from './CoinTransaction';

@Entity('crypto_coins_transactions')
class CryptoCoinTransaction {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @OneToOne(() => CoinTransaction)
  @JoinColumn({ name: 'transaction_id' })
  transaction: CoinTransaction;

  @Column()
  transaction_id: string;

  @Column()
  txid?: string;

  @Column()
  blockhash?: string;

  @Column()
  block_height?: number;

  @Column()
  confirmations?: number;

  @Column()
  address_to: string;

  @Column()
  dest_flag?: string;

  @Column()
  fee_network?: string;

  @Column()
  type: 'deposit' | 'withdrawal';

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
export default CryptoCoinTransaction;
