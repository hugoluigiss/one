import BigNumber from 'bignumber.js';
import { container } from 'tsyringe';
import { Field, ObjectType } from 'type-graphql';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import GetCoinValueConversionService from '../../../services/GetCoinValueConversionService';
import Coin from './Coin';

const { format: FormatBrl } = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL',
});

@ObjectType()
@Entity('customers_coins_wallets')
class CustomerCoinWallet {
  @PrimaryGeneratedColumn('increment')
  index: number;

  @Field()
  @Column()
  customer_id: string;

  @Field()
  @Column()
  coin_id: string;

  @Field(() => Coin)
  @ManyToOne(() => Coin, { eager: true })
  @JoinColumn({ name: 'coin_id' })
  coin: Coin;

  @Field({ nullable: true })
  @Column()
  address: string;

  @Field(() => String)
  balance: string;

  @Field(() => String)
  get network(): string {
    switch (this.coin.symbol) {
      case 'BRL':
        return '';
      case 'BTC':
        return 'BTC Bitcoin';
      case 'ETH':
        return 'ETH Ethereum (ERC20)';
      case 'BNB':
        return 'BSC SCAN (BSC20)';
      case 'USDT':
        return 'BSC SCAN (BSC20)';
      // case 'XRP':
      //   return 'XRP Ripple';

      default:
        return '';
    }
  }

  @Field(() => String)
  get memo(): string {
    return `${this.index}`;
  }

  @Field(() => String)
  get formatted_balance(): string {
    switch (this.coin.symbol) {
      case 'BRL':
        return FormatBrl(new BigNumber(this.balance).toNumber());
      case 'BTC':
        return new BigNumber(this.balance).toFixed(8);

      case 'ETH':
        return new BigNumber(this.balance).toFixed(8);

      case 'BNB':
        return new BigNumber(this.balance).toFixed(8);

      case 'USDT':
        return new BigNumber(this.balance).toFixed(6);

      default:
        return this.balance;
    }
  }

  @Field(() => String)
  get formatted_brl_balance(): Promise<string> {
    return this.brl_balance.then(b => FormatBrl(new BigNumber(b).toNumber()));
  }

  @Field(() => String)
  get brl_balance(): Promise<string> {
    const getCoinValueConversionService = container.resolve(
      GetCoinValueConversionService,
    );
    return getCoinValueConversionService.execute({
      from: this.coin.symbol,
      to: 'BRL',
      value: this.balance,
    });
  }

  @Field(() => String)
  get brl_price(): Promise<string> {
    const getCoinValueConversionService = container.resolve(
      GetCoinValueConversionService,
    );
    return getCoinValueConversionService.execute({
      from: this.coin.symbol,
      to: 'BRL',
      value: '1',
    });
  }

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;
}
export default CustomerCoinWallet;
