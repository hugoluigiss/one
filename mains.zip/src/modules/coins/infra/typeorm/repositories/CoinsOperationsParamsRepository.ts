import ICreateCoinOperationParamDTO from 'src/modules/coins/dtos/ICreateCoinOperationParamDTO';
import IFindAllCoinsOperationParamsWithFilterDTO from 'src/modules/coins/dtos/IFindAllCoinsOperationParamsWithFilterDTO';
import IFindCoinOperationParamsDTO from 'src/modules/coins/dtos/IFindCoinOperationParamsDTO';
import ICoinsOperationsParamsRepository from 'src/modules/coins/repositories/ICoinsOperationsParamsRepository';
import { getRepository, Repository } from 'typeorm';
import CoinOperationParam from '../entities/CoinOperationParam';

class CoinsOperationsParamsRepository
  implements ICoinsOperationsParamsRepository
{
  private ormRepository: Repository<CoinOperationParam>;

  constructor() {
    this.ormRepository = getRepository(CoinOperationParam);
  }

  public async findById(id: string): Promise<CoinOperationParam | undefined> {
    return this.ormRepository.findOne(id);
  }

  public async findAllWithFilter({
    customer_type,
    has_complience,
    operation,
  }: IFindAllCoinsOperationParamsWithFilterDTO): Promise<CoinOperationParam[]> {
    const query = this.ormRepository.createQueryBuilder(
      'coins_operations_params',
    );

    query.leftJoinAndSelect('coins_operations_params.coin', 'coin');
    if (customer_type)
      query.andWhere(`customer_type =:customer_type`, { customer_type });

    if (has_complience)
      query.andWhere(`has_complience =:has_complience`, { has_complience });

    if (operation) query.andWhere(`operation =:operation`, { operation });

    return query.getMany();
  }

  public async findAllByCustomer(
    customer_type: 'PF' | 'PJ',
    has_complience: boolean,
  ): Promise<CoinOperationParam[]> {
    return this.ormRepository.find({
      where: {
        customer_type,
        has_complience,
      },
      order: { operation: 'ASC' },
    });
  }

  public async findOne({
    coin_id,
    has_complience,
    customer_type,
    operation,
  }: IFindCoinOperationParamsDTO): Promise<CoinOperationParam | undefined> {
    return this.ormRepository.findOne({
      where: {
        coin_id,
        has_complience,
        operation,
        customer_type,
      },
    });
  }

  public async create({
    operation,
    coin_id,
    customer_type,
    fixed_fee_brl_value,
    has_complience,
    percentage_fee_value,
    max_brl_value,
    min_brl_value,
    validity_period_days,
  }: ICreateCoinOperationParamDTO): Promise<CoinOperationParam> {
    const param = this.ormRepository.create({
      operation,
      coin_id,
      customer_type,
      fixed_fee_brl_value,
      has_complience,
      percentage_fee_value,
      max_brl_value,
      min_brl_value,
      validity_period_days,
    });

    await this.ormRepository.save(param);

    return param;
  }

  public async save(param: CoinOperationParam): Promise<CoinOperationParam> {
    return this.ormRepository.save(param);
  }
}
export default CoinsOperationsParamsRepository;
