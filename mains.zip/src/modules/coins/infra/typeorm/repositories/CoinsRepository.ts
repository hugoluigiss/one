import { getRepository, Repository } from 'typeorm';
import ICoinsRepository from '../../../repositories/ICoinsRepository';
import Coin, { CoinsType } from '../entities/Coin';

class CoinsRepository implements ICoinsRepository {
  private ormRepository: Repository<Coin>;

  constructor() {
    this.ormRepository = getRepository(Coin);
  }

  public async findAll(): Promise<Coin[]> {
    return this.ormRepository.find({ order: { symbol: 'ASC' } });
  }

  public async findBySymbol(symbol: CoinsType): Promise<Coin | undefined> {
    return this.ormRepository.findOne({ where: { symbol } });
  }
}

export default CoinsRepository;
