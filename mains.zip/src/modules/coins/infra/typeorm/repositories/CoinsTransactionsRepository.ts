import IFindAndPaginateCoinsTransactionsDTO from 'src/modules/coins/dtos/IFindAndPaginateCoinsTransactionsDTO';
import IFindAndPaginateCoinsTransactionsResponseDTO from 'src/modules/coins/dtos/IFindAndPaginateCoinsTransactionsResponseDTO';
import IFindForOperationLimitDTO from 'src/modules/coins/dtos/IFindForOperationLimitDTO';
import { getRepository, Repository } from 'typeorm';
import ICreateCoinTransactionDTO from '../../../dtos/ICreateCoinTransactionDTO';
import IFindAllCoinTransactionDTO from '../../../dtos/IFindAllCoinTransactionDTO';
import ICoinsTransactionsRepository from '../../../repositories/ICoinsTransactionsRepository';
import CoinTransaction from '../entities/CoinTransaction';

class CoinsTransactionsRepository implements ICoinsTransactionsRepository {
  private ormRepository: Repository<CoinTransaction>;

  constructor() {
    this.ormRepository = getRepository(CoinTransaction);
  }

  public async findForOperationLimit({
    customer_id,
    coin_id,
    description,
    start_date,
  }: IFindForOperationLimitDTO): Promise<CoinTransaction[]> {
    const query = this.ormRepository.createQueryBuilder('coins_transactions');
    query.where('customer_id = :customer_id', { customer_id });
    query.andWhere('description = :description', { description });
    query.andWhere('coin_id = :coin_id', { coin_id });
    query.andWhere('created_at > :start_date ', { start_date });

    return query.getMany();
  }

  public async findAndPaginate({
    customer_id,
    coin_symbol,
    final_date,
    limit,
    offset,
    start_date,
    status,
    operation,
  }: IFindAndPaginateCoinsTransactionsDTO): Promise<IFindAndPaginateCoinsTransactionsResponseDTO> {
    const query = this.ormRepository.createQueryBuilder('coins_transactions');
    if (customer_id)
      query.andWhere('coins_transactions.customer_id = :customer_id', {
        customer_id,
      });
    query.orderBy('coins_transactions.created_at', 'DESC');

    if (status)
      query.andWhere('coins_transactions.status = :status', { status });

    query.leftJoinAndSelect('coins_transactions.coin', 'coin');

    query.leftJoinAndSelect('coins_transactions.customer', 'customer');

    if (start_date && final_date)
      query.andWhere(
        'coins_transactions.created_at <= :final_date and coins_transactions.created_at >= :start_date',
        {
          start_date,
          final_date,
        },
      );

    if (operation === 'deposit' || operation === 'withdrawal')
      query.andWhere('coins_transactions.operation = :operation', {
        operation,
      });

    if (operation === 'buy')
      query.andWhere('operation = :sell or  operation = :buy', {
        buy: 'buy',
        sell: 'sell',
      });

    if (coin_symbol)
      query.andWhere('coin.symbol = :symbol', {
        symbol: coin_symbol,
      });

    if (coin_symbol === 'BRL') {
      if (operation === 'deposit') {
        query.innerJoinAndSelect(
          'coins_transactions.brl_deposit',
          'brl_deposit',
        );
      }
      if (operation === 'withdrawal') {
        query.innerJoinAndSelect(
          'coins_transactions.brl_withdrawal',
          'brl_withdrawal',
        );
      }
    }

    const count = await query.getCount();

    if (limit) {
      query.limit(limit);
      if (offset) query.offset(limit * offset);
    }

    const transactions = await query.getMany();

    return { count, transactions };
  }

  public async findById(id: string): Promise<CoinTransaction | undefined> {
    return this.ormRepository.findOne(id);
  }

  public async findAll({
    filter,
  }: IFindAllCoinTransactionDTO): Promise<CoinTransaction[]> {
    const builder = this.ormRepository.createQueryBuilder('coins_transactions');

    if (filter) {
      if (filter.customer_id)
        builder.where('customer_id = :customer_id', {
          customer_id: filter.customer_id,
        });
      if (filter.coin_id)
        builder.andWhere('coin_id = :coin_id', {
          coin_id: filter.coin_id,
        });
    }

    return builder.getMany();
  }

  public async create({
    customer_id,
    coin_id,
    fee_value,
    net_value,
    status,
    total_value,
    type,
    description,
    operation,
  }: ICreateCoinTransactionDTO): Promise<CoinTransaction> {
    const transaction = this.ormRepository.create({
      customer_id,
      coin_id,
      fee_value,
      net_value,
      status,
      total_value,
      type,
      description,
      operation,
    });

    await this.ormRepository.save(transaction);

    return transaction;
  }

  public async save(transaction: CoinTransaction): Promise<CoinTransaction> {
    return this.ormRepository.save(transaction);
  }
}

export default CoinsTransactionsRepository;
