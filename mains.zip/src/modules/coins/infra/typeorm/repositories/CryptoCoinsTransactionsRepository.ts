import { getRepository, Repository } from 'typeorm';
import IFindCryptoTransactionDTO from 'src/modules/coins/dtos/IFindCryptoTransactionDTO';
import IFindUnconfirmedCryptoCoinsTransactionsDTO from 'src/modules/coins/dtos/IFindUnconfirmedCryptoCoinsTransactionsDTO';
import ICreateCryptoCoinTransactionDTO from '../../../dtos/ICreateCryptoCoinTransactionDTO';
import ICryptoCoinsTransactionsRepository from '../../../repositories/ICryptoCoinsTransactionsRepository';
import CryptoCoinTransaction from '../entities/CryptoCoinTransaction';

class CryptoCoinsTransactionsRepository
  implements ICryptoCoinsTransactionsRepository
{
  private ormRepository: Repository<CryptoCoinTransaction>;

  constructor() {
    this.ormRepository = getRepository(CryptoCoinTransaction);
  }

  public async findUnconfirmedTransactions({
    coin_id,
  }: IFindUnconfirmedCryptoCoinsTransactionsDTO): Promise<
    CryptoCoinTransaction[]
  > {
    const query = this.ormRepository
      .createQueryBuilder('crypto_coins_transactions')
      .leftJoinAndSelect('crypto_coins_transactions.transaction', 'transaction')
      .leftJoinAndSelect('transaction.coin', 'coin')
      .where('coin.id = :id', { id: coin_id })
      .andWhere('transaction.status = :status', { status: 'pending' });

    return query.getMany();
  }

  public async findCryptoTransaction({
    type,
    address_to,
    txid,
  }: IFindCryptoTransactionDTO): Promise<CryptoCoinTransaction | undefined> {
    return this.ormRepository.findOne({
      where: {
        txid,
        address_to,
        type,
      },
    });
  }

  public async findPendingWithdrawalsByCoinSymbol(
    symbol: 'BTC' | 'ETH' | 'BNB',
  ): Promise<CryptoCoinTransaction[]> {
    const query = this.ormRepository
      .createQueryBuilder('crypto_coins_transactions')
      .leftJoinAndSelect('crypto_coins_transactions.transaction', 'transaction')
      .leftJoinAndSelect('transaction.coin', 'coin')
      .where('crypto_coins_transactions.type = :type', { type: 'withdrawal' })
      .andWhere('transaction.status = :status', { status: 'pending' })
      .andWhere('coin.symbol = :symbol', { symbol })
      .orderBy('crypto_coins_transactions.created_at', 'ASC');

    return query.getMany();
  }

  public async create({
    address_to,
    fee_network,
    transaction_id,
    type,
    txid,
    blockhash,
    confirmations,
    block_height,
    dest_flag,
  }: ICreateCryptoCoinTransactionDTO): Promise<CryptoCoinTransaction> {
    const cryptoTransaction = this.ormRepository.create({
      address_to,
      fee_network,
      transaction_id,
      type,
      txid,
      blockhash,
      confirmations,
      block_height,
      dest_flag,
    });
    await this.ormRepository.save(cryptoTransaction);
    return cryptoTransaction;
  }

  public async save(
    cryptoTransaction: CryptoCoinTransaction,
  ): Promise<CryptoCoinTransaction> {
    return this.ormRepository.save(cryptoTransaction);
  }
}

export default CryptoCoinsTransactionsRepository;
