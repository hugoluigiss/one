import { getRepository, Repository } from 'typeorm';
import ICreateCustomerCoinWalletDTO from '../../../dtos/ICreateCustomerCoinWalletDTO';
import ICustomersCoinsWalletsRepository from '../../../repositories/ICustomersCoinsWalletsRepository';
import CustomerCoinWallet from '../entities/CustomerCoinWallet';

class CustomersCoinsWalletsRepository
  implements ICustomersCoinsWalletsRepository
{
  private ormRepository: Repository<CustomerCoinWallet>;

  constructor() {
    this.ormRepository = getRepository(CustomerCoinWallet);
  }

  public async findByIndex(
    index: number,
  ): Promise<CustomerCoinWallet | undefined> {
    return this.ormRepository.findOne({ where: { index } });
  }

  public async findByAddress(
    address: string,
  ): Promise<CustomerCoinWallet | undefined> {
    return this.ormRepository.findOne({ where: { address } });
  }

  public async create({
    customer_id,
    coin_id,
  }: ICreateCustomerCoinWalletDTO): Promise<CustomerCoinWallet> {
    const userWallet = this.ormRepository.create({ coin_id, customer_id });
    await this.ormRepository.save(userWallet);
    return userWallet;
  }

  public async save(
    userWallet: CustomerCoinWallet,
  ): Promise<CustomerCoinWallet> {
    return this.ormRepository.save(userWallet);
  }

  public async findByCustomerId(
    customer_id: string,
  ): Promise<CustomerCoinWallet[]> {
    return this.ormRepository.find({ where: { customer_id } });
  }
}
export default CustomersCoinsWalletsRepository;
