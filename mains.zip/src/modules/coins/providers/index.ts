import { container } from 'tsyringe';
import CoinsOperationsParamsRepository from '../infra/typeorm/repositories/CoinsOperationsParamsRepository';
import CoinsRepository from '../infra/typeorm/repositories/CoinsRepository';
import CoinsTransactionsRepository from '../infra/typeorm/repositories/CoinsTransactionsRepository';
import CryptoCoinsTransactionsRepository from '../infra/typeorm/repositories/CryptoCoinsTransactionsRepository';
import CustomersCoinsWalletsRepository from '../infra/typeorm/repositories/CustomersCoinsWalletsRepository';
import ICoinsOperationsParamsRepository from '../repositories/ICoinsOperationsParamsRepository';
import ICoinsRepository from '../repositories/ICoinsRepository';
import ICoinsTransactionsRepository from '../repositories/ICoinsTransactionsRepository';
import ICryptoCoinsTransactionsRepository from '../repositories/ICryptoCoinsTransactionsRepository';
import ICustomersCoinsWalletsRepository from '../repositories/ICustomersCoinsWalletsRepository';

container.registerSingleton<ICoinsRepository>(
  'CoinsRepository',
  CoinsRepository,
);

container.registerSingleton<ICustomersCoinsWalletsRepository>(
  'CustomersCoinsWalletsRepository',
  CustomersCoinsWalletsRepository,
);

container.registerSingleton<ICoinsTransactionsRepository>(
  'CoinsTransactionsRepository',
  CoinsTransactionsRepository,
);

container.registerSingleton<ICryptoCoinsTransactionsRepository>(
  'CryptoCoinsTransactionsRepository',
  CryptoCoinsTransactionsRepository,
);

container.registerSingleton<ICoinsOperationsParamsRepository>(
  'CoinsOperationsParamsRepository',
  CoinsOperationsParamsRepository,
);
