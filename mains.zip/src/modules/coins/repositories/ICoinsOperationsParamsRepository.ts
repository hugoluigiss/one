import ICreateCoinOperationParamDTO from '../dtos/ICreateCoinOperationParamDTO';
import IFindAllCoinsOperationParamsWithFilterDTO from '../dtos/IFindAllCoinsOperationParamsWithFilterDTO';
import IFindCoinOperationParamsDTO from '../dtos/IFindCoinOperationParamsDTO';
import CoinOperationParam from '../infra/typeorm/entities/CoinOperationParam';

export default interface ICoinsOperationsParamsRepository {
  create(data: ICreateCoinOperationParamDTO): Promise<CoinOperationParam>;
  save(param: CoinOperationParam): Promise<CoinOperationParam>;
  findById(id: string): Promise<CoinOperationParam | undefined>;
  findOne(
    data: IFindCoinOperationParamsDTO,
  ): Promise<CoinOperationParam | undefined>;
  findAllByCustomer(
    customer_type: 'PF' | 'PJ',
    has_complience: boolean,
  ): Promise<CoinOperationParam[]>;
  findAllWithFilter(
    data: IFindAllCoinsOperationParamsWithFilterDTO,
  ): Promise<CoinOperationParam[]>;
}
