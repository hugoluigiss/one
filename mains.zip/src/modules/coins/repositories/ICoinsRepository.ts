import Coin, { CoinsType } from '../infra/typeorm/entities/Coin';

export default interface ICoinsRepository {
  findBySymbol(symbol: CoinsType): Promise<Coin | undefined>;
  findAll(): Promise<Coin[]>;
}
