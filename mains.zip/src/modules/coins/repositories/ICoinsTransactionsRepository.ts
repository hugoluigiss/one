import ICreateCoinTransactionDTO from '../dtos/ICreateCoinTransactionDTO';
import IFindAllCoinTransactionDTO from '../dtos/IFindAllCoinTransactionDTO';
import IFindAndPaginateCoinsTransactionsDTO from '../dtos/IFindAndPaginateCoinsTransactionsDTO';
import IFindAndPaginateCoinsTransactionsResponseDTO from '../dtos/IFindAndPaginateCoinsTransactionsResponseDTO';
import IFindForOperationLimitDTO from '../dtos/IFindForOperationLimitDTO';
import CoinTransaction from '../infra/typeorm/entities/CoinTransaction';

export default interface ICoinsTransactionsRepository {
  create(data: ICreateCoinTransactionDTO): Promise<CoinTransaction>;
  save(transaction: CoinTransaction): Promise<CoinTransaction>;
  findAll(data: IFindAllCoinTransactionDTO): Promise<CoinTransaction[]>;
  findById(id: string): Promise<CoinTransaction | undefined>;
  findAndPaginate(
    data: IFindAndPaginateCoinsTransactionsDTO,
  ): Promise<IFindAndPaginateCoinsTransactionsResponseDTO>;
  findForOperationLimit(
    data: IFindForOperationLimitDTO,
  ): Promise<CoinTransaction[]>;
}
