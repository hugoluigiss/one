import ICreateCryptoCoinTransactionDTO from '../dtos/ICreateCryptoCoinTransactionDTO';
import IFindCryptoTransactionDTO from '../dtos/IFindCryptoTransactionDTO';
import IFindUnconfirmedCryptoCoinsTransactionsDTO from '../dtos/IFindUnconfirmedCryptoCoinsTransactionsDTO';
import CryptoCoinTransaction from '../infra/typeorm/entities/CryptoCoinTransaction';

export default interface ICryptoCoinsTransactionsRepository {
  create(data: ICreateCryptoCoinTransactionDTO): Promise<CryptoCoinTransaction>;
  save(
    cryptoTransaction: CryptoCoinTransaction,
  ): Promise<CryptoCoinTransaction>;

  findPendingWithdrawalsByCoinSymbol(
    symbol: 'BTC' | 'ETH' | 'BNB' | 'USDT',
  ): Promise<CryptoCoinTransaction[]>;

  findCryptoTransaction(
    data: IFindCryptoTransactionDTO,
  ): Promise<CryptoCoinTransaction | undefined>;

  findUnconfirmedTransactions(
    data: IFindUnconfirmedCryptoCoinsTransactionsDTO,
  ): Promise<CryptoCoinTransaction[]>;
}
