import ICreateCustomerCoinWalletDTO from '../dtos/ICreateCustomerCoinWalletDTO';
import CustomerCoinWallet from '../infra/typeorm/entities/CustomerCoinWallet';

export default interface ICustomersCoinsWalletsRepository {
  create(data: ICreateCustomerCoinWalletDTO): Promise<CustomerCoinWallet>;
  save(userCoinWallet: CustomerCoinWallet): Promise<CustomerCoinWallet>;
  findByCustomerId(customer_id: string): Promise<CustomerCoinWallet[]>;
  findByAddress(address: string): Promise<CustomerCoinWallet | undefined>;
  findByIndex(index: number): Promise<CustomerCoinWallet | undefined>;
}
