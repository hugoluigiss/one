import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import ICryptoUtilsProvider from '../../../shared/container/providers/CryptoUtilsProvider/models/ICryptoUtilsProvider';

interface IParams {
  coin_symbol: 'BTC' | 'ETH' | 'BNB' | 'USDT';
  address: string;
}

@injectable()
class CheckCoinAddressService {
  constructor(
    @inject('CryptoUtilsProvider')
    private cryptoUtilsProvider: ICryptoUtilsProvider,
  ) {}

  public async execute({ address, coin_symbol }: IParams): Promise<boolean> {
    const isValid = await this.cryptoUtilsProvider.checkValidAddress({
      address,
      coin_symbol,
    });

    if (!isValid) throw new ApolloError('Endereço inválido');

    return isValid;
  }
}
export default CheckCoinAddressService;
