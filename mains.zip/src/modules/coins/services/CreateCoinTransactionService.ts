import { ApolloError } from 'apollo-server-express';
import BigNumber from 'bignumber.js';
import { inject, injectable } from 'tsyringe';
import { CoinsType } from '../infra/typeorm/entities/Coin';
import CoinTransaction from '../infra/typeorm/entities/CoinTransaction';
import ICoinsRepository from '../repositories/ICoinsRepository';
import ICoinsTransactionsRepository from '../repositories/ICoinsTransactionsRepository';

interface IParams {
  coin_symbol: CoinsType;
  customer_id: string;
  total_value: string;
  status: 'pending' | 'confirmed' | 'refused' | 'canceled';
  fee_value: string;
  type: 'input' | 'output';
  description: string;
  operation: 'buy' | 'sell' | 'deposit' | 'withdrawal' | 'brl_transfer';
}

@injectable()
class CreateCoinTransactionService {
  constructor(
    @inject('CoinsRepository')
    private coinsRepository: ICoinsRepository,

    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,
  ) {}

  public async execute({
    coin_symbol,
    customer_id,
    fee_value,
    status,
    total_value,
    type,
    description,
    operation,
  }: IParams): Promise<CoinTransaction> {
    const coin = await this.coinsRepository.findBySymbol(coin_symbol);
    if (!coin) throw new ApolloError('Moeda não encontrada');

    const net_value = new BigNumber(total_value).minus(
      new BigNumber(fee_value),
    );

    const isGreaterThanZero = net_value.isGreaterThan('0');
    if (!isGreaterThanZero)
      throw new ApolloError(
        'Valor Líquido da transação deve ser superior a zero',
      );

    const transaction = await this.coinsTransactionsRepository.create({
      total_value,
      status,
      net_value: net_value.toFixed(8),
      fee_value,
      coin_id: coin.id,
      customer_id,
      type,
      description,
      operation,
    });

    return transaction;
  }
}
export default CreateCoinTransactionService;
