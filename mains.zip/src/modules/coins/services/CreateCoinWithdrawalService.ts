import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import IQueue from '../../../shared/container/providers/QueueProvider/models/IQueue';
import CoinTransaction from '../infra/typeorm/entities/CoinTransaction';
import ICoinsTransactionsRepository from '../repositories/ICoinsTransactionsRepository';
import { ICreateCoinWithdrawalQueueParams } from '../../../shared/container/providers/QueueProvider/implementations/CreateCoinWithdrawalQueue';

@injectable()
class CreateCoinWithdrawalService {
  constructor(
    @inject('CreateCoinWithdrawalQueue')
    private createCoinWithdrawalQueue: IQueue,

    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,
  ) {}

  public async execute({
    coin_amount,
    coin_symbol,
    customer_id,
    description,
    fee_value,
    status,
    operation,
  }: ICreateCoinWithdrawalQueueParams): Promise<CoinTransaction> {
    const withdrawal_id = await this.createCoinWithdrawalQueue.add<
      string | undefined
    >({
      coin_amount,
      coin_symbol,
      customer_id,
      description,
      fee_value,
      status,
      operation,
    });

    if (!withdrawal_id) throw new ApolloError('Erro na criação do saque');

    const withdrawal = await this.coinsTransactionsRepository.findById(
      withdrawal_id,
    );
    if (!withdrawal) throw new ApolloError('Erro na criação do saque');

    return withdrawal;
  }
}
export default CreateCoinWithdrawalService;
