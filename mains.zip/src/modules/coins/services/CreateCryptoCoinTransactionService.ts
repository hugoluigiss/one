import { inject, injectable } from 'tsyringe';
import CryptoCoinTransaction from '../infra/typeorm/entities/CryptoCoinTransaction';
import ICryptoCoinsTransactionsRepository from '../repositories/ICryptoCoinsTransactionsRepository';

interface IParams {
  transaction_id: string;
  txid?: string;
  address_to: string;
  dest_flag?: string;
  fee_network?: string;
  type: 'deposit' | 'withdrawal';
}

@injectable()
class CreateCryptoCoinTransactionService {
  constructor(
    @inject('CryptoCoinsTransactionsRepository')
    private cryptoCoinsTransactionsRepository: ICryptoCoinsTransactionsRepository,
  ) {}

  public async execute({
    txid,
    type,
    transaction_id,
    fee_network,
    address_to,
    dest_flag,
  }: IParams): Promise<CryptoCoinTransaction> {
    const cryptoTransaction =
      await this.cryptoCoinsTransactionsRepository.create({
        txid,
        type,
        transaction_id,
        fee_network,
        address_to,
        dest_flag,
      });

    return cryptoTransaction;
  }
}
export default CreateCryptoCoinTransactionService;
