// import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import ICafCustomersDocumentsRepository from '../../caf/repositories/ICafCustomersDocumentsRepository';
import ICustomersDocumentsRepository from '../../customers/repositories/ICustomersDocumentsRepository';
import CoinOperationParam from '../infra/typeorm/entities/CoinOperationParam';
import ICoinsOperationsParamsRepository from '../repositories/ICoinsOperationsParamsRepository';

interface IParams {
  customer_id: string;
}

@injectable()
class GetAllCoinsOperationsParamsService {
  constructor(
    @inject('CoinsOperationsParamsRepository')
    private coinsOperationsParamsRepository: ICoinsOperationsParamsRepository,

    @inject('CustomersDocumentsRepository')
    private customersDocumentsRepository: ICustomersDocumentsRepository,

    @inject('CafCustomersDocumentsRepository')
    private cafCustomersDocumentsRepository: ICafCustomersDocumentsRepository,
  ) {}

  public async execute({
    customer_id,
  }: IParams): Promise<CoinOperationParam[]> {
    const customerDocument =
      await this.customersDocumentsRepository.findByCustomerId(customer_id);
    // if (!customerDocument) throw new ApolloError('Cliente não encontrado');

    const customer_type = customerDocument?.type === 'CNPJ' ? 'PJ' : 'PF';
    // const { has_complience } = customerDocument;

    const hasCaf = await this.cafCustomersDocumentsRepository.findApproved(
      customer_id,
    );

    const has_complience = !!hasCaf;

    const params = await this.coinsOperationsParamsRepository.findAllByCustomer(
      customer_type,
      has_complience,
    );

    return params;
  }
}
export default GetAllCoinsOperationsParamsService;
