import { inject, injectable } from 'tsyringe';
import CoinOperationParam from '../infra/typeorm/entities/CoinOperationParam';
import ICoinsOperationsParamsRepository from '../repositories/ICoinsOperationsParamsRepository';

interface IParams {
  operation?: 'buy' | 'sell' | 'deposit' | 'withdrawal' | 'brl_transfer';
  customer_type?: 'PF' | 'PJ';
  has_complience?: boolean;
}

@injectable()
class GetAllCoinsOperationsParamsWithFilterService {
  constructor(
    @inject('CoinsOperationsParamsRepository')
    private coinsOperationsParamsRepository: ICoinsOperationsParamsRepository,
  ) {}

  public async execute({
    operation,
    has_complience,
    customer_type,
  }: IParams): Promise<CoinOperationParam[]> {
    const params = await this.coinsOperationsParamsRepository.findAllWithFilter(
      { operation, has_complience, customer_type },
    );

    return params;
  }
}
export default GetAllCoinsOperationsParamsWithFilterService;
