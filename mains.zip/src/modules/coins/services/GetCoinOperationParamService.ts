import { ApolloError } from 'apollo-server-express';
// import ICustomersDocumentsRepository from 'src/modules/customers/repositories/ICustomersDocumentsRepository';
import { inject, injectable } from 'tsyringe';
import CoinOperationParam from '../infra/typeorm/entities/CoinOperationParam';
import ICoinsOperationsParamsRepository from '../repositories/ICoinsOperationsParamsRepository';
import ICoinsRepository from '../repositories/ICoinsRepository';
import ICafCustomersDocumentsRepository from '../../caf/repositories/ICafCustomersDocumentsRepository';
import { CoinsType } from '../infra/typeorm/entities/Coin';

interface IParams {
  customer_id: string;
  coin_symbol: CoinsType;
  operation: 'buy' | 'sell' | 'deposit' | 'withdrawal' | 'brl_transfer';
}

@injectable()
class GetCoinOperationParamService {
  constructor(
    @inject('CoinsRepository')
    private coinsRepository: ICoinsRepository,

    @inject('CoinsOperationsParamsRepository')
    private coinsOperationsParamsRepository: ICoinsOperationsParamsRepository,

    // @inject('CustomersDocumentsRepository')
    // private customersDocumentsRepository: ICustomersDocumentsRepository,

    @inject('CafCustomersDocumentsRepository')
    private cafCustomersDocumentsRepository: ICafCustomersDocumentsRepository,
  ) {}

  public async execute({
    coin_symbol,
    customer_id,
    operation,
  }: IParams): Promise<CoinOperationParam> {
    const coin = await this.coinsRepository.findBySymbol(coin_symbol);
    if (!coin) throw new ApolloError('Moeda não encontrada');

    // const customerDocument =
    //   await this.customersDocumentsRepository.findByCustomerId(customer_id);
    // if (!customerDocument) throw new ApolloError('Cliente não encontrado');

    // const customer_type = customerDocument.type === 'CNPJ' ? 'PJ' : 'PF';

    const hasCaf = await this.cafCustomersDocumentsRepository.findApproved(
      customer_id,
    );

    const has_complience = !!hasCaf;

    let param = await this.coinsOperationsParamsRepository.findOne({
      operation,
      customer_type: 'PF',
      has_complience,
      coin_id: coin.id,
    });

    if (!param)
      param = await this.coinsOperationsParamsRepository.create({
        operation,
        coin_id: coin.id,
        has_complience,
        customer_type: 'PF',
        validity_period_days: 7,
        fixed_fee_brl_value: '2',
        percentage_fee_value: '0.01',
        max_brl_value: '50000',
        min_brl_value: '10',
      });

    param.coin = coin;
    return param;
  }
}
export default GetCoinOperationParamService;
