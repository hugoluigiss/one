import BigNumber from 'bignumber.js';
import { inject, injectable } from 'tsyringe';
import ICacheProvider from '../../../shared/container/providers/CacheProvider/models/ICacheProvider';
import ICryptoUtilsProvider from '../../../shared/container/providers/CryptoUtilsProvider/models/ICryptoUtilsProvider';
import { CoinsType } from '../infra/typeorm/entities/Coin';

interface IParams {
  from: CoinsType;
  to: CoinsType;
  value: string;
}

@injectable()
class GetCoinValueConversionService {
  constructor(
    @inject('CryptoUtilsProvider')
    private cryptoUtilsProvider: ICryptoUtilsProvider,

    @inject('CacheProvider')
    private cacheProvider: ICacheProvider,
  ) {}

  public async execute({ from, to, value }: IParams): Promise<string> {
    const key = `coin-pair-conversion:${from}/${to}`;
    const cachedValue = await this.cacheProvider.recover<string>(key);

    if (!cachedValue) {
      const conversion = await this.cryptoUtilsProvider.getCoinParValue({
        from,
        to,
      });

      await this.cacheProvider.save(key, conversion, 1);
      return new BigNumber(conversion).multipliedBy(value).toFixed();
    }

    return new BigNumber(cachedValue).multipliedBy(value).toFixed();
  }
}
export default GetCoinValueConversionService;
