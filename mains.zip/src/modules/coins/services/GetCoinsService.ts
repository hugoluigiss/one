import { inject, injectable } from 'tsyringe';
import Coin from '../infra/typeorm/entities/Coin';
import ICoinsRepository from '../repositories/ICoinsRepository';

@injectable()
class GetCoinsService {
  constructor(
    @inject('CoinsRepository')
    private coinsRepository: ICoinsRepository,
  ) {}

  public async execute(): Promise<Coin[]> {
    const coins = await this.coinsRepository.findAll();
    return coins;
  }
}
export default GetCoinsService;
