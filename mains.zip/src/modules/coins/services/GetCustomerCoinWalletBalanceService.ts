import { ApolloError } from 'apollo-server-express';
import BigNumber from 'bignumber.js';
import { inject, injectable } from 'tsyringe';
import { CoinsType } from '../infra/typeorm/entities/Coin';
import ICoinsRepository from '../repositories/ICoinsRepository';
import ICoinsTransactionsRepository from '../repositories/ICoinsTransactionsRepository';

interface IParams {
  customer_id: string;
  coin_symbol: CoinsType;
}

@injectable()
class GetCustomerCoinWalletBalanceService {
  constructor(
    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,

    @inject('CoinsRepository')
    private coinsRepository: ICoinsRepository,
  ) {}

  public async execute({ customer_id, coin_symbol }: IParams): Promise<string> {
    const coin = await this.coinsRepository.findBySymbol(coin_symbol);
    if (!coin) throw new ApolloError('Moeda não encontrada');

    const transactions = await this.coinsTransactionsRepository.findAll({
      filter: {
        customer_id,
        coin_id: coin.id,
      },
    });

    const sum = transactions.reduce(
      (acc, curr) => {
        acc.input =
          curr.type === 'input' && curr.status === 'confirmed'
            ? new BigNumber(curr.net_value).plus(acc.input).toFixed()
            : acc.input;

        acc.output =
          curr.type === 'output' && curr.status !== 'refused'
            ? new BigNumber(curr.total_value).plus(acc.output).toFixed()
            : acc.output;

        return acc;
      },
      {
        input: '0',
        output: '0',
      },
    );

    return new BigNumber(sum.input).minus(sum.output).toFixed();
  }
}
export default GetCustomerCoinWalletBalanceService;
