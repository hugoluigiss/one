import { inject, injectable } from 'tsyringe';
import ICryptoProvider from '../../../shared/container/providers/CryptoProvider/models/ICryptoProvider';
import CustomerCoinWallet from '../infra/typeorm/entities/CustomerCoinWallet';
import ICoinsRepository from '../repositories/ICoinsRepository';
import ICustomersCoinsWalletsRepository from '../repositories/ICustomersCoinsWalletsRepository';

interface IParams {
  customer_id: string;
}

@injectable()
class GetCustomerCoinsWalletsService {
  constructor(
    @inject('CustomersCoinsWalletsRepository')
    private customersCoinsWalletsRepository: ICustomersCoinsWalletsRepository,

    @inject('CoinsRepository')
    private coinsRepository: ICoinsRepository,

    @inject('BitcoinProvider')
    private bitcoinProvider: ICryptoProvider,

    @inject('EthereumProvider')
    private ethereumProvider: ICryptoProvider, // @inject('RippleProvider') // private rippleProvider: ICryptoProvider,
  ) {}

  public async execute({
    customer_id,
  }: IParams): Promise<CustomerCoinWallet[]> {
    const userWallets =
      await this.customersCoinsWalletsRepository.findByCustomerId(customer_id);

    let btcWallet = userWallets.find(wallet => wallet.coin?.symbol === 'BTC');
    if (!btcWallet) {
      const btc = await this.coinsRepository.findBySymbol('BTC');
      if (!btc) throw new Error('btc não encontrado');
      btcWallet = await this.customersCoinsWalletsRepository.create({
        coin_id: btc.id,
        customer_id,
      });
      btcWallet.address = await this.bitcoinProvider.createNewAddress();

      await this.customersCoinsWalletsRepository.save(btcWallet);
      btcWallet.coin = btc;
    }

    let ethWallet = userWallets.find(wallet => wallet.coin?.symbol === 'ETH');
    if (!ethWallet) {
      const eth = await this.coinsRepository.findBySymbol('ETH');
      if (!eth) throw new Error('eth não encontrado');
      ethWallet = await this.customersCoinsWalletsRepository.create({
        coin_id: eth.id,
        customer_id,
      });
      ethWallet.address = await this.ethereumProvider.createNewAddress(
        ethWallet.index,
      );
      await this.customersCoinsWalletsRepository.save(ethWallet);
      ethWallet.coin = eth;
    }

    let bnbWallet = userWallets.find(wallet => wallet.coin?.symbol === 'BNB');
    if (!bnbWallet) {
      const bnb = await this.coinsRepository.findBySymbol('BNB');
      if (!bnb) throw new Error('bnb não encontrado');
      bnbWallet = await this.customersCoinsWalletsRepository.create({
        coin_id: bnb.id,
        customer_id,
      });
      bnbWallet.address = await this.ethereumProvider.createNewAddress(
        ethWallet.index,
      );
      await this.customersCoinsWalletsRepository.save(bnbWallet);
      bnbWallet.coin = bnb;
    }

    let usdtWallet = userWallets.find(wallet => wallet.coin?.symbol === 'USDT');
    if (!usdtWallet) {
      const usdt = await this.coinsRepository.findBySymbol('USDT');
      if (!usdt) throw new Error('usdt não encontrado');
      usdtWallet = await this.customersCoinsWalletsRepository.create({
        coin_id: usdt.id,
        customer_id,
      });
      usdtWallet.address = await this.ethereumProvider.createNewAddress(
        ethWallet.index,
      );
      await this.customersCoinsWalletsRepository.save(usdtWallet);
      usdtWallet.coin = usdt;
    }

    let brlWallet = userWallets.find(wallet => wallet.coin?.symbol === 'BRL');
    if (!brlWallet) {
      const brl = await this.coinsRepository.findBySymbol('BRL');
      if (!brl) throw new Error('brl não encontrado');
      brlWallet = await this.customersCoinsWalletsRepository.create({
        coin_id: brl.id,
        customer_id,
      });
      brlWallet.coin = brl;
    }

    // let xrpWallet = userWallets.find(wallet => wallet.coin?.symbol === 'XRP');
    // if (!xrpWallet) {
    //   const xrp = await this.coinsRepository.findBySymbol('XRP');
    //   if (!xrp) throw new Error('xrp não encontrado');
    //   xrpWallet = await this.customersCoinsWalletsRepository.create({
    //     coin_id: xrp.id,
    //     customer_id,
    //   });
    //   xrpWallet.address = await this.rippleProvider.createNewAddress(
    //     xrpWallet.index,
    //   );
    //   await this.customersCoinsWalletsRepository.save(xrpWallet);
    //   xrpWallet.coin = xrp;
    // }

    return [
      btcWallet,
      ethWallet,
      brlWallet, // xrpWalle
      bnbWallet,
      usdtWallet,
    ];
  }
}
export default GetCustomerCoinsWalletsService;
