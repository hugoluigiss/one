import { inject, injectable } from 'tsyringe';
import IFindAndPaginateCoinsTransactionsDTO from '../dtos/IFindAndPaginateCoinsTransactionsDTO';
import IFindAndPaginateCoinsTransactionsResponseDTO from '../dtos/IFindAndPaginateCoinsTransactionsResponseDTO';
import ICoinsTransactionsRepository from '../repositories/ICoinsTransactionsRepository';

@injectable()
class GetCustomerStatmentService {
  constructor(
    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,
  ) {}

  public async execute({
    start_date,
    final_date,
    coin_symbol,
    customer_id,
    limit,
    offset,
    status,
    operation,
  }: IFindAndPaginateCoinsTransactionsDTO): Promise<IFindAndPaginateCoinsTransactionsResponseDTO> {
    const { count, transactions } =
      await this.coinsTransactionsRepository.findAndPaginate({
        customer_id,
        coin_symbol,
        final_date,
        start_date,
        limit,
        offset,
        status,
        operation,
      });

    return { count, transactions };
  }
}
export default GetCustomerStatmentService;
