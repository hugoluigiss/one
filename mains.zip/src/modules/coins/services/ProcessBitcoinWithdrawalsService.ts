import BigNumber from 'bignumber.js';
import { inject, injectable } from 'tsyringe';
import ICryptoProvider from '../../../shared/container/providers/CryptoProvider/models/ICryptoProvider';
import ICoinsTransactionsRepository from '../repositories/ICoinsTransactionsRepository';
import ICryptoCoinsTransactionsRepository from '../repositories/ICryptoCoinsTransactionsRepository';

interface IMap {
  amounts: {
    [key: string]: string;
  };
  subtractFeeFrom: string[];
}

@injectable()
class ProcessBitcoinWithdrawalsService {
  constructor(
    @inject('BitcoinProvider')
    private bitcoinProvider: ICryptoProvider,

    @inject('CryptoCoinsTransactionsRepository')
    private cryptoCoinsTransactionsRepository: ICryptoCoinsTransactionsRepository,

    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,
  ) {}

  public async execute(): Promise<void> {
    const withdrawals =
      await this.cryptoCoinsTransactionsRepository.findPendingWithdrawalsByCoinSymbol(
        'BTC',
      );

    if (withdrawals.length === 0) return;

    const mapped: IMap = withdrawals.reduce(
      (acc, curr) => {
        if (!acc.amounts[curr.address_to]) acc.amounts[curr.address_to] = '0';
        acc.amounts[curr.address_to] = new BigNumber(
          acc.amounts[curr.address_to],
        )
          .plus(curr.transaction.net_value)
          .toFixed(8);

        if (!acc.subtractFeeFrom.find(addr => addr === curr.address_to))
          acc.subtractFeeFrom.push(curr.address_to);
        return acc;
      },
      {
        amounts: {},
        subtractFeeFrom: [],
      } as IMap,
    );

    try {
      const txid = await this.bitcoinProvider.sendMany({ ...mapped });
      await Promise.all(
        withdrawals.map(async withdrawal => {
          await this.cryptoCoinsTransactionsRepository.save({
            ...withdrawal,
            txid,
          });
          const { transaction } = withdrawal;
          transaction.status = 'confirmed';
          await this.coinsTransactionsRepository.save(transaction);
        }),
      );
    } catch (err) {
      console.log(err);
    }
  }
}
export default ProcessBitcoinWithdrawalsService;
