import { inject, injectable } from 'tsyringe';
import ICryptoProvider from '../../../shared/container/providers/CryptoProvider/models/ICryptoProvider';
import ICoinsTransactionsRepository from '../repositories/ICoinsTransactionsRepository';
import ICryptoCoinsTransactionsRepository from '../repositories/ICryptoCoinsTransactionsRepository';

@injectable()
class ProcessEthereumWithdrawalsService {
  constructor(
    @inject('EthereumProvider')
    private ethereumProvider: ICryptoProvider,

    @inject('BnbProvider')
    private bnbProvider: ICryptoProvider,

    @inject('CryptoCoinsTransactionsRepository')
    private cryptoCoinsTransactionsRepository: ICryptoCoinsTransactionsRepository,

    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,
  ) {}

  public async execute(): Promise<void> {
    let withdrawals =
      await this.cryptoCoinsTransactionsRepository.findPendingWithdrawalsByCoinSymbol(
        'ETH',
      );

    if (withdrawals.length === 0) return;

    let index = 0;
    const process = async (): Promise<string> => {
      try {
        const txid = await this.ethereumProvider.sendToAddress({
          amount: withdrawals[index].transaction.net_value,
          address: withdrawals[index].address_to,
          subtract_fee_from_amount: true,
        });
        await this.cryptoCoinsTransactionsRepository.save({
          ...withdrawals[index],
          txid,
        });
        withdrawals[index].transaction.status = 'confirmed';
        await this.coinsTransactionsRepository.save(
          withdrawals[index].transaction,
        );
      } catch (err) {
        // eslint-disable-next-line no-console
        console.log(err);
      }
      index += 1;
      return index === withdrawals.length ? 'finished' : process();
    };

    await process();

    withdrawals =
      await this.cryptoCoinsTransactionsRepository.findPendingWithdrawalsByCoinSymbol(
        'BNB',
      );

    if (withdrawals.length === 0) return;
    index = 0;
    const processBnb = async (): Promise<string> => {
      try {
        const txid = await this.bnbProvider.sendToAddress({
          amount: withdrawals[index].transaction.net_value,
          address: withdrawals[index].address_to,
          subtract_fee_from_amount: true,
        });
        await this.cryptoCoinsTransactionsRepository.save({
          ...withdrawals[index],
          txid,
        });
        withdrawals[index].transaction.status = 'confirmed';
        await this.coinsTransactionsRepository.save(
          withdrawals[index].transaction,
        );
      } catch (err) {
        // eslint-disable-next-line no-console
        console.log(err);
      }
      index += 1;
      return index === withdrawals.length ? 'finished' : process();
    };
    await processBnb();
  }
}
export default ProcessEthereumWithdrawalsService;
