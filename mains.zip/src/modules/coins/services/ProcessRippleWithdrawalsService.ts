import { injectable } from 'tsyringe';
// import ICryptoProvider from '../../../shared/container/providers/CryptoProvider/models/ICryptoProvider';
// import ICoinsTransactionsRepository from '../repositories/ICoinsTransactionsRepository';
// import ICryptoCoinsTransactionsRepository from '../repositories/ICryptoCoinsTransactionsRepository';

@injectable()
class ProcessRippleWithdrawalsService {
  // constructor() {} // private coinsTransactionsRepository: ICoinsTransactionsRepository, // @inject('CoinsTransactionsRepository') // private cryptoCoinsTransactionsRepository: ICryptoCoinsTransactionsRepository, // @inject('CryptoCoinsTransactionsRepository') // private rippleProvider: ICryptoProvider, // @inject('RippleProvider')

  public async execute(): Promise<void> {
    // const withdrawals =
    //   await this.cryptoCoinsTransactionsRepository.findPendingWithdrawalsByCoinSymbol(
    //     'XRP',
    //   );
    // if (withdrawals.length === 0) return;
    // let index = 0;
    // const process = async (): Promise<string> => {
    //   try {
    //     const txid = await this.rippleProvider.sendToAddress({
    //       amount: withdrawals[index].transaction.net_value,
    //       address: withdrawals[index].address_to,
    //       subtract_fee_from_amount: true,
    //       dest_flag: withdrawals[index].dest_flag,
    //     });
    //     await this.cryptoCoinsTransactionsRepository.save({
    //       ...withdrawals[index],
    //       txid,
    //     });
    //     withdrawals[index].transaction.status = 'confirmed';
    //     await this.coinsTransactionsRepository.save(
    //       withdrawals[index].transaction,
    //     );
    //   } catch (err) {
    //     // eslint-disable-next-line no-console
    //     console.log(err);
    //   }
    //   index += 1;
    //   return index === withdrawals.length ? 'finished' : process();
    // };
    // await process();
  }
}
export default ProcessRippleWithdrawalsService;
