import { ApolloError } from 'apollo-server-express';
import BigNumber from 'bignumber.js';
import { inject, injectable } from 'tsyringe';
import CoinOperationParam from '../infra/typeorm/entities/CoinOperationParam';
import ICoinsOperationsParamsRepository from '../repositories/ICoinsOperationsParamsRepository';

interface IParams {
  id: string;
  fixed_fee_brl_value?: string;
  max_brl_value?: string;
  min_brl_value?: string;
  percentage_fee_value?: string;
  validity_period_days?: number;
}

@injectable()
class UpdateCoinOperationParamService {
  constructor(
    @inject('CoinsOperationsParamsRepository')
    private coinsOperationsParamsRepository: ICoinsOperationsParamsRepository,
  ) {}

  public async execute({
    id,
    fixed_fee_brl_value,
    max_brl_value,
    min_brl_value,
    percentage_fee_value,
    validity_period_days,
  }: IParams): Promise<CoinOperationParam> {
    const param = await this.coinsOperationsParamsRepository.findById(id);
    if (!param) throw new ApolloError(`Parametro nao encontrado`);

    if (fixed_fee_brl_value)
      param.fixed_fee_brl_value = new BigNumber(fixed_fee_brl_value).toFixed();
    if (max_brl_value)
      param.max_brl_value = new BigNumber(max_brl_value).toFixed();
    if (min_brl_value)
      param.min_brl_value = new BigNumber(min_brl_value).toFixed();
    if (percentage_fee_value)
      param.percentage_fee_value = new BigNumber(
        percentage_fee_value,
      ).toFixed();
    if (percentage_fee_value)
      param.percentage_fee_value = new BigNumber(
        percentage_fee_value,
      ).toFixed();
    if (validity_period_days) param.validity_period_days = validity_period_days;

    return this.coinsOperationsParamsRepository.save(param);
  }
}
export default UpdateCoinOperationParamService;
