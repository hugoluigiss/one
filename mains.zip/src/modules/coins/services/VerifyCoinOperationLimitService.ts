import { inject, injectable } from 'tsyringe';
import { subDays } from 'date-fns';
import { ApolloError } from 'apollo-server-express';
import BigNumber from 'bignumber.js';
import CoinOperationParam from '../infra/typeorm/entities/CoinOperationParam';
import ICoinsTransactionsRepository from '../repositories/ICoinsTransactionsRepository';
import ICoinsRepository from '../repositories/ICoinsRepository';

const { format: FormatBrl } = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL',
});

interface IParams {
  param: CoinOperationParam;
  customer_id: string;
  value_brl: string;
}

@injectable()
class VerifyCoinOperationLimitService {
  constructor(
    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,

    @inject('CoinsRepository')
    private coinsRepository: ICoinsRepository,
  ) {}

  public async execute({
    customer_id,
    param,
    value_brl,
  }: IParams): Promise<string> {
    const brl = await this.coinsRepository.findBySymbol('BRL');
    if (!brl) throw new ApolloError('moeda BRL não encontrada');

    const start_date = subDays(new Date(), param.validity_period_days);

    const transactions =
      await this.coinsTransactionsRepository.findForOperationLimit({
        customer_id,
        description: param.transaction_description,
        start_date,
        coin_id: brl.id,
      });

    const sum = transactions.reduce(
      (acc, curr) => acc.plus(curr.total_value),
      new BigNumber('0'),
    );

    const allowedValue = new BigNumber(param.max_brl_value).minus(sum);

    if (new BigNumber(value_brl).isGreaterThan(allowedValue)) {
      throw new ApolloError(
        `Seu limite máximo para esta operação é de ${FormatBrl(
          allowedValue.toNumber(),
        )}`,
      );
    }

    return 'ok';
  }
}
export default VerifyCoinOperationLimitService;
