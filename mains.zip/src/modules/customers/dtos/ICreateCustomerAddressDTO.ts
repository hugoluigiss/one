export default interface ICreateCustomerAddressDTO {
  customer_id: string;
  zip_code: string;
  country: string;
  state: string;
  city: string;
  district: string;
  street: string;
  number: string;
  complement: string;
}
