export default interface ICreateCustomerAssociationDTO {
  customer_pf_id: string;
  customer_pj_id: string;
}
