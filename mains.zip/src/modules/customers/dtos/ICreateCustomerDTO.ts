export default interface ICreateCustomerDTO {
  email: string;

  full_name: string;

  birth_date: Date;

  password_hash: string;

  type: 'PF' | 'PJ';

  fantasy_name?: string;
}
