export default interface ICreateCustomerDocumentCopyDTO {
  customer_id: string;
  name: string;
  description: string;
  type: 'cnpj' | 'social_contract' | 'cpf' | 'passport' | 'selfie';
}
