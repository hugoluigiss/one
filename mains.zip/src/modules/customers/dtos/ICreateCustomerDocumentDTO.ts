export default interface ICreateCustomerDocumentDTO {
  customer_id: string;

  type: 'CPF' | 'PASSPORT' | 'CNPJ';

  nationality: string;

  document_value: string;
}
