export default interface ICreateCustomerTwoFaDTO {
  customer_id: string;
  secret: string;
}
