export default interface IFindAllDocumentsCopiesParamsDTO {
  filter?: {
    customer_id?: string;
    has_complience?: boolean;
  };
  pagination?: {
    offset?: number;
    limit?: number;
  };
  order: {
    field: 'created_at';
    order: 'ASC' | 'DESC';
  };
}
