import CustomerDocument from '../infra/typeorm/entities/CustomerDocument';

export default interface IFindAllDocumentsCopiesResponseDTO {
  documents: CustomerDocument[];
  count: number;
}
