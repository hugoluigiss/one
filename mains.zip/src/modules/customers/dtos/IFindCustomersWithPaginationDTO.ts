export default interface IFindCustomersWithPaginationDTO {
  limit?: number;
  offset?: number;
  order?: 'ASC' | 'DESC';
}
