import Customer from '../infra/typeorm/entities/Customer';

export default interface IFindCustomersWithPaginationResponseDTO {
  customers: Customer[];
  count: number;
}
