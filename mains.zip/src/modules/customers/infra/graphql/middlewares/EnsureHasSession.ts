import { AuthenticationError } from 'apollo-server-express';
import { container } from 'tsyringe';
import { MiddlewareInterface, NextFn, ResolverData } from 'type-graphql';
import CheckCustomerSessionService from '../../../services/CheckCustomerSessionService';

import { MyContext } from '../../../../../shared/infra/graphql/Context';

export default class EnsureHasSession
  implements MiddlewareInterface<MyContext>
{
  async use(
    { context }: ResolverData<MyContext>,
    next: NextFn,
  ): Promise<NextFn> {
    const { client_id } = context;
    if (!client_id) throw new AuthenticationError('Não autorizado');

    const checkCustomerSessionService = container.resolve(
      CheckCustomerSessionService,
    );

    await checkCustomerSessionService.execute(client_id);

    return next();
  }
}
