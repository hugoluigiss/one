import { AuthenticationError } from 'apollo-server-express';
import { MiddlewareInterface, NextFn, ResolverData } from 'type-graphql';

import { MyContext } from '../../../../../shared/infra/graphql/Context';
import CustomersRepository from '../../typeorm/repositories/CustomersRepository';

export default class EnsureIsCustomer
  implements MiddlewareInterface<MyContext>
{
  async use(
    { context }: ResolverData<MyContext>,
    next: NextFn,
  ): Promise<NextFn> {
    const { client_id } = context;
    if (!client_id) throw new AuthenticationError('Não autorizado');

    const customerRepository = new CustomersRepository();

    const isCustomer = await customerRepository.findById(client_id);
    if (!isCustomer) throw new AuthenticationError('Não autorizado');

    context.customer_id = client_id;
    return next();
  }
}
