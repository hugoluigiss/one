import {
  Resolver,
  Mutation,
  Arg,
  UseMiddleware,
  Ctx,
  Query,
} from 'type-graphql';
import speakeasy from 'speakeasy';
import { container } from 'tsyringe';
import CreateTwoFaService from '../../../services/CreateTwoFaService';
import CheckCustomerTwoFaExistsService from '../../../services/CheckCustomerTwoFaExistsService';
import DestroyTwoFaService from '../../../services/DestroyTwoFaService';
import TwoFaData from '../types/2FaData';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';

@Resolver()
export default class TwoFA {
  @Query(() => TwoFaData)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetTwoFaData(): Promise<TwoFaData> {
    const secretCode = speakeasy.generateSecret({ name: 'OneExchange' });

    return {
      otpauth_url: secretCode.otpauth_url,
      base32: secretCode.base32,
    };
  }

  @Query(() => Boolean)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CheckMyTwoFaExists(
    @Ctx('customer_id') customer_id: string,
  ): Promise<boolean> {
    const checkCustomerTwoFaExistsService = container.resolve(
      CheckCustomerTwoFaExistsService,
    );
    return checkCustomerTwoFaExistsService.execute({ customer_id });
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CreateMyTwoFa(
    @Arg('secret') secret: string,
    @Arg('token') token: string,
    @Ctx('customer_id') customer_id: string,
  ): Promise<string> {
    const createTwoFaService = container.resolve(CreateTwoFaService);
    await createTwoFaService.execute({ token, customer_id, secret });
    return 'success';
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async DeleteTwoFa(@Ctx('customer_id') customer_id: string): Promise<string> {
    const destroyTwoFaService = container.resolve(DestroyTwoFaService);
    await destroyTwoFaService.execute({ customer_id });
    return 'success';
  }
}
