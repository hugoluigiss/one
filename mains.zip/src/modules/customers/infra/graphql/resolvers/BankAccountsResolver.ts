import { container } from 'tsyringe';
import {
  Resolver,
  Arg,
  Mutation,
  Ctx,
  UseMiddleware,
  Query,
} from 'type-graphql';

import UpdateCustomerBankAccountService from '../../../../banks/services/UpdateCustomerBankAccountService';
import CreateCustomerBankAccountService from '../../../../banks/services/CreateCustomerBankAccountService';
import CustomerBankAccount from '../../../../banks/infra/typeorm/entities/CustomerBankAccount';
import ListCustomerBankAccountsService from '../../../../banks/services/ListCustomerBankAccountsService';
import CheckCafApprovedService from '../../../../caf/services/CheckCafApprovedService';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';

@Resolver()
export default class CustomerCoinsResolver {
  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CreateMyBankAccount(
    @Arg('agency') agency: string,
    @Arg('account') account: string,
    @Arg('pix', { nullable: true }) pix: string,
    @Arg('bank_id') bank_id: string,
    @Ctx('customer_id') customer_id: string,
  ): Promise<string> {
    await container.resolve(CheckCafApprovedService).execute({ customer_id });
    const createCustomerBankAccountService = container.resolve(
      CreateCustomerBankAccountService,
    );
    await createCustomerBankAccountService.execute({
      pix,
      account,
      agency,
      bank_id,
      customer_id,
    });

    return 'success';
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async UpdateMyBankAccount(
    @Arg('agency') agency: string,
    @Arg('account') account: string,
    @Arg('pix', { nullable: true }) pix: string,
    @Arg('bank_id') bank_id: string,
    @Ctx('customer_id') customer_id: string,
  ): Promise<string> {
    await container.resolve(CheckCafApprovedService).execute({ customer_id });
    const updateCustomerBankAccountService = container.resolve(
      UpdateCustomerBankAccountService,
    );
    await updateCustomerBankAccountService.execute({
      pix,
      account,
      agency,
      bank_id,
      customer_id,
    });

    return 'success';
  }

  @Query(() => [CustomerBankAccount])
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetMyBankAccounts(
    @Ctx('customer_id') customer_id: string,
  ): Promise<CustomerBankAccount[]> {
    const listCustomerBankAccountsService = container.resolve(
      ListCustomerBankAccountsService,
    );
    return listCustomerBankAccountsService.execute(customer_id);
  }
}
