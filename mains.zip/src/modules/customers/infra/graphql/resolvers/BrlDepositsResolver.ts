import {
  Resolver,
  Query,
  UseMiddleware,
  Mutation,
  Ctx,
  Arg,
} from 'type-graphql';
import { container } from 'tsyringe';
import { FileUpload, GraphQLUpload } from 'graphql-upload';
import DepositAccount from '../../../../deposits/infra/typeorm/entities/DepositAccount';
import ListAllBanksService from '../../../../banks/services/ListAllBanksService';

import SaveFileToTmpFolder from '../../../../../shared/container/providers/StorageProvider/middlewares/SaveFileTmpFolder';
import CreateBrlDepositService from '../../../../deposits/services/CreateBrlDepositService';
import CreateCoinTransactionService from '../../../../coins/services/CreateCoinTransactionService';
import ListAllCustomerBrlDepositsService from '../../../../deposits/services/ListAllCustomersBrlDepositsService';
import PaginationType from '../../../../../shared/infra/graphql/types/PaginationType';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';

@Resolver()
export default class DepositsResolver {
  @Query(() => DepositAccount)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetDepositAccount(): Promise<DepositAccount> {
    const listAllBanksService = container.resolve(ListAllBanksService);
    const banks = await listAllBanksService.execute();
    const bank = banks.find(b => Number(b.code) === 33);
    const depositAccount = new DepositAccount();
    Object.assign(depositAccount, {
      agency: '4543',
      account: '13007086-3',
      pix: '04.940.467/0001-72',
      owner: 'JW ANOMINONDAS JR',
      bank,
    });
    return depositAccount;
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CreateBrlDeposit(
    @Arg('file', () => GraphQLUpload) file: FileUpload,
    @Arg('value_brl') value_brl: string,
    @Ctx('customer_id') customer_id: string,
  ): Promise<string> {
    const saveFileToTmpFolder = new SaveFileToTmpFolder();
    const file_name = await saveFileToTmpFolder.execute(file);

    const createCoinTransactionService = container.resolve(
      CreateCoinTransactionService,
    );
    const transaction = await createCoinTransactionService.execute({
      total_value: value_brl,
      coin_symbol: 'BRL',
      customer_id,
      fee_value: '0',
      status: 'pending',
      type: 'input',
      description: 'Depósito bancário',
      operation: 'deposit',
    });

    const createBrlDepositService = container.resolve(CreateBrlDepositService);
    await createBrlDepositService.execute({
      file_name,
      transaction_id: transaction.id,
    });
    return 'success';
  }

  @Query(() => PaginationType)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetMyBrlDeposits(
    @Ctx('customer_id') customer_id: string,
    @Arg('limit', { nullable: true }) limit: number,
    @Arg('offset', { nullable: true }) offset: number,
    @Arg('status', { nullable: true }) status: string,
  ): Promise<PaginationType> {
    const listAllCustomerBrlDepositsService = container.resolve(
      ListAllCustomerBrlDepositsService,
    );
    const { count, deposits } = await listAllCustomerBrlDepositsService.execute(
      {
        limit,
        offset,
        customer_id,
        status,
      },
    );

    return {
      edges: { brl_deposits: deposits },
      totalCount: count,
      pageInfo: {
        hasNextPage: limit ? count > limit + limit * (offset || 0) : false,
        hasPrevPage: offset > 0,
      },
    };
  }
}
