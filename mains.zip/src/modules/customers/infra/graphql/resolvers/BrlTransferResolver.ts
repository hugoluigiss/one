import { container } from 'tsyringe';
import { Arg, Ctx, Mutation, Resolver, UseMiddleware } from 'type-graphql';
import BigNumber from 'bignumber.js';
import CheckCustomerTwoFaService from '../../../services/CheckCustomerTwoFaService';
import GetCoinOperationParamService from '../../../../coins/services/GetCoinOperationParamService';
import VerifyCoinOperationLimitService from '../../../../coins/services/VerifyCoinOperationLimitService';

import CreateCoinWithdrawalService from '../../../../coins/services/CreateCoinWithdrawalService';
import GetCustomerReceiverService from '../../../../transfers/services/GetCustomerReceiverService';
import CreateCoinTransactionService from '../../../../coins/services/CreateCoinTransactionService';
import CreateBrlTransferService from '../../../../transfers/services/CreateBrlTransferService';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';
import CheckCafApprovedService from '../../../../caf/services/CheckCafApprovedService';
import CheckOneTimeCodeService from '../../../services/CheckOneTimeCodeService';

@Resolver()
export default class BrlTransferResolver {
  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CreateBrlTransfer(
    @Arg('two_fa') two_fa: string,
    @Arg('value_brl') value_brl: string,
    @Arg('email_to') email_to: string,
    @Ctx('customer_id') customer_id: string,
  ): Promise<string> {
    await container.resolve(CheckCafApprovedService).execute({ customer_id });
    /**
     * verifica 2fa
     */

    await container
      .resolve(CheckOneTimeCodeService)
      .execute({ customer_id, code: two_fa });

    const checkCustomerTwoFaService = container.resolve(
      CheckCustomerTwoFaService,
    );
    await checkCustomerTwoFaService.execute({ token: two_fa, customer_id });

    /**
     * verifica recebedor
     */
    const getCustomerReceiverService = container.resolve(
      GetCustomerReceiverService,
    );
    const { receiver, sender } = await getCustomerReceiverService.execute({
      email_to,
      customer_id,
    });

    /**
     * cria saída
     */

    const getCoinOperationParamService = container.resolve(
      GetCoinOperationParamService,
    );
    const param = await getCoinOperationParamService.execute({
      coin_symbol: 'BRL',
      customer_id,
      operation: 'brl_transfer',
    });

    const verifyCoinOperationLimitService = container.resolve(
      VerifyCoinOperationLimitService,
    );
    await verifyCoinOperationLimitService.execute({
      customer_id,
      param,
      value_brl,
    });

    const description = param.transaction_description;

    const createCoinWithdrawalService = container.resolve(
      CreateCoinWithdrawalService,
    );
    const withdrawal = await createCoinWithdrawalService.execute({
      coin_amount: value_brl,
      coin_symbol: 'BRL',
      customer_id,
      description,
      fee_value: new BigNumber(param.percentage_fee_value)
        .multipliedBy(value_brl)
        .plus(param.fixed_fee_brl_value)
        .toFixed(),
      status: 'confirmed',
      operation: 'brl_transfer',
    });

    /**
     * cria entrada
     */
    const createCoinTransactionService = container.resolve(
      CreateCoinTransactionService,
    );
    const deposit = await createCoinTransactionService.execute({
      customer_id: receiver.id,
      total_value: withdrawal.net_value,
      type: 'input',
      coin_symbol: 'BRL',
      description: `Transferência de ${sender.email}`,
      fee_value: '0',
      status: 'confirmed',
      operation: 'brl_transfer',
    });

    const createBrlTransferService = container.resolve(
      CreateBrlTransferService,
    );
    await createBrlTransferService.execute({
      receiver_transaction_id: deposit.id,
      sender_transaction_id: withdrawal.id,
    });
    return 'success';
  }
}
