import { container } from 'tsyringe';
import {
  Arg,
  Ctx,
  Mutation,
  Query,
  Resolver,
  UseMiddleware,
} from 'type-graphql';
import BigNumber from 'bignumber.js';
import CheckCustomerTwoFaService from '../../../services/CheckCustomerTwoFaService';
import GetCoinOperationParamService from '../../../../coins/services/GetCoinOperationParamService';
import VerifyCoinOperationLimitService from '../../../../coins/services/VerifyCoinOperationLimitService';

import CreateBrlWithdrawalService from '../../../../withdrawals/services/CreateBrlWithdrawalService';
import PaginationType from '../../../../../shared/infra/graphql/types/PaginationType';
import ListAllCustomersBrlWithdrawalsService from '../../../../withdrawals/services/ListAllCustomersBrlWithdrawalsService';
import CreateCoinWithdrawalService from '../../../../coins/services/CreateCoinWithdrawalService';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';
import CheckCafApprovedService from '../../../../caf/services/CheckCafApprovedService';
import CheckOneTimeCodeService from '../../../services/CheckOneTimeCodeService';

@Resolver()
export default class BrlWithdrawalResolver {
  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CreateBrlWithdrawal(
    @Arg('two_fa') two_fa: string,
    @Arg('value_brl') value_brl: string,
    @Arg('bank_account_id') bank_account_id: string,
    @Ctx('customer_id') customer_id: string,
  ): Promise<string> {
    await container.resolve(CheckCafApprovedService).execute({ customer_id });

    await container
      .resolve(CheckOneTimeCodeService)
      .execute({ customer_id, code: two_fa });

    const checkCustomerTwoFaService = container.resolve(
      CheckCustomerTwoFaService,
    );
    await checkCustomerTwoFaService.execute({ token: two_fa, customer_id });

    const createCoinWithdrawalService = container.resolve(
      CreateCoinWithdrawalService,
    );

    const getCoinOperationParamService = container.resolve(
      GetCoinOperationParamService,
    );
    const param = await getCoinOperationParamService.execute({
      coin_symbol: 'BRL',
      customer_id,
      operation: 'withdrawal',
    });

    const verifyCoinOperationLimitService = container.resolve(
      VerifyCoinOperationLimitService,
    );
    await verifyCoinOperationLimitService.execute({
      customer_id,
      param,
      value_brl,
    });

    const description = param.transaction_description;

    const withdrawal = await createCoinWithdrawalService.execute({
      coin_amount: value_brl,
      coin_symbol: 'BRL',
      customer_id,
      description,
      fee_value: new BigNumber(param.percentage_fee_value)
        .multipliedBy(value_brl)
        .plus(param.fixed_fee_brl_value)
        .toFixed(),
      status: 'pending',
      operation: 'withdrawal',
    });

    const createBrlWithdrawalService = container.resolve(
      CreateBrlWithdrawalService,
    );
    await createBrlWithdrawalService.execute({
      transaction_id: withdrawal.id,
      bank_account_id,
    });
    return 'success';
  }

  @Query(() => PaginationType)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetMyBrlWithdrawals(
    @Ctx('customer_id') customer_id: string,
    @Arg('limit', { nullable: true }) limit: number,
    @Arg('offset', { nullable: true }) offset: number,
    @Arg('status', { nullable: true }) status: string,
  ): Promise<PaginationType> {
    const listAllCustomersBrlWithdrawalsService = container.resolve(
      ListAllCustomersBrlWithdrawalsService,
    );
    const { count, deposits } =
      await listAllCustomersBrlWithdrawalsService.execute({
        limit,
        offset,
        customer_id,
        status,
      });

    return {
      edges: { brl_withdrawals: deposits },
      totalCount: count,
      pageInfo: {
        hasNextPage: limit ? count > limit + limit * (offset || 0) : false,
        hasPrevPage: offset > 0,
      },
    };
  }
}
