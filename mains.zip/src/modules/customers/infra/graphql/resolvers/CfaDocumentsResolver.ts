import { container } from 'tsyringe';

import {
  Resolver,
  Ctx,
  UseMiddleware,
  Mutation,
  Arg,
  Query,
} from 'type-graphql';
import { FileUpload, GraphQLUpload } from 'graphql-upload';
import CafDocument from '../../../../caf/infra/typeorm/entities/CafDocument';
// import EnqueueSendCustomersCfaDocumentsService from '../../../../caf/services/EnqueueSendCustomersCfaDocumentsService';
import SaveFileToTmpFolder from '../../../../../shared/container/providers/StorageProvider/middlewares/SaveFileTmpFolder';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';

import CreateCustomerCfaDocumentService from '../../../../caf/services/CreateCustomerCfaDocumentService';
import GetCustomerNotReprovedCfaService from '../../../../caf/services/GetCustomerNotReprovedCfaService';

@Resolver()
export default class CfaDocumentsResolver {
  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async createCfaDocument(
    @Ctx('customer_id') customer_id: string,
    @Arg('front', () => GraphQLUpload) front: FileUpload,
    @Arg('back', () => GraphQLUpload) back: FileUpload,
    @Arg('selfie', () => GraphQLUpload) selfie: FileUpload,
    @Arg('type') type: 'cnh' | 'rne' | 'rg',
    @Arg('cpf', { nullable: true }) cpf?: string,
  ): Promise<string> {
    const saveFileToTmpFolder = new SaveFileToTmpFolder();
    const [front_file_name, back_file_name, selfie_file_name] =
      await Promise.all([
        saveFileToTmpFolder.execute(front),
        saveFileToTmpFolder.execute(back),
        saveFileToTmpFolder.execute(selfie),
      ]);

    const createCustomerCfaDocumentService = container.resolve(
      CreateCustomerCfaDocumentService,
    );
    await createCustomerCfaDocumentService.execute({
      cpf,
      back: back_file_name,
      customer_id,
      front: front_file_name,
      selfie: selfie_file_name,
      type,
    });

    // const enqueueSendCustomersCfaDocumentsService = container.resolve(
    //   EnqueueSendCustomersCfaDocumentsService,
    // );
    // await enqueueSendCustomersCfaDocumentsService.execute();

    return 'Documentos enviados com sucesso';
  }

  @Query(() => CafDocument, { nullable: true })
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async getCustomerNotReprovedCaf(
    @Ctx('customer_id') customer_id: string,
  ): Promise<CafDocument | undefined> {
    const getCustomerNotReprovedCfaService = container.resolve(
      GetCustomerNotReprovedCfaService,
    );
    return getCustomerNotReprovedCfaService.execute({ customer_id });
  }
}
