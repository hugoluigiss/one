import { container } from 'tsyringe';
import { Resolver, Query, UseMiddleware, Arg } from 'type-graphql';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';
import GetOscilationChartDataService from '../../../services/GetOscilationChartDataService';

@Resolver()
export default class ChartResolver {
  @Query(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetOscilationChartData(
    @Arg('value') value: number,
    @Arg('coin_symbol') coin_symbol: 'BTC' | 'ETH' | 'BNB' | 'USDT',
    @Arg('interval') interval: 'hour' | 'day',
  ): Promise<string> {
    const getCustomerProfileService = container.resolve(
      GetOscilationChartDataService,
    );
    return getCustomerProfileService.execute({ value, coin_symbol, interval });
  }
}
