import { container } from 'tsyringe';
import { Arg, Ctx, Query, Resolver, UseMiddleware } from 'type-graphql';
import { CoinsType } from 'src/modules/coins/infra/typeorm/entities/Coin';
import GetAllCoinsOperationsParamsService from '../../../../coins/services/GetAllCoinsOperationsParamsService';
import CoinOperationParam from '../../../../coins/infra/typeorm/entities/CoinOperationParam';
import GetCoinOperationParamService from '../../../../coins/services/GetCoinOperationParamService';
// import Fee from '../../../../fees/infra/typeorm/entities/Fee';
// import FindFeeService from '../../../../fees/services/FindFeeService';

import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';

@Resolver()
export default class CoinsOperationParamsResolver {
  @Query(() => CoinOperationParam)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetCoinOperationParam(
    @Ctx('customer_id') customer_id: string,
    @Arg('coin_symbol') coin_symbol: CoinsType,
    @Arg('operation')
    operation: 'buy' | 'sell' | 'deposit' | 'withdrawal' | 'brl_transfer',
  ): Promise<CoinOperationParam> {
    const getCoinOperationParamService = container.resolve(
      GetCoinOperationParamService,
    );
    const param = await getCoinOperationParamService.execute({
      coin_symbol,
      operation,
      customer_id,
    });

    return param;
  }

  @Query(() => [CoinOperationParam])
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetAllCoinsOperationParams(
    @Ctx('customer_id') customer_id: string,
  ): Promise<CoinOperationParam[]> {
    const getAllCoinsOperationsParamsService = container.resolve(
      GetAllCoinsOperationsParamsService,
    );
    const param = await getAllCoinsOperationsParamsService.execute({
      customer_id,
    });

    return param;
  }
}
