import { container } from 'tsyringe';
import { Resolver, Arg, Query, Ctx, UseMiddleware } from 'type-graphql';
import { ApolloError } from 'apollo-server-express';
import GetCustomerCoinsWalletsService from '../../../../coins/services/GetCustomerCoinsWalletsService';
import CustomerCoinWallet from '../../../../coins/infra/typeorm/entities/CustomerCoinWallet';
import GetCustomerCoinWalletBalanceService from '../../../../coins/services/GetCustomerCoinWalletBalanceService';
import Coin, { CoinsType } from '../../../../coins/infra/typeorm/entities/Coin';
import GetCoinsService from '../../../../coins/services/GetCoinsService';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';

@Resolver()
export default class CustomerCoinsResolver {
  @Query(() => CustomerCoinWallet)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetMyCoinWalletBySymbol(
    @Arg('symbol') symbol: CoinsType,
    @Ctx('customer_id') customer_id: string,
  ): Promise<CustomerCoinWallet> {
    const getCustomerCoinsWalletsService = container.resolve(
      GetCustomerCoinsWalletsService,
    );

    const wallets = await getCustomerCoinsWalletsService.execute({
      customer_id,
    });

    const wallet = wallets.find(w => w.coin?.symbol === symbol);

    if (!wallet)
      throw new ApolloError(`Não encontrada carteira para símbolo "${symbol}"`);

    const getCustomerCoinWalletBalanceService = container.resolve(
      GetCustomerCoinWalletBalanceService,
    );
    wallet.balance = await getCustomerCoinWalletBalanceService.execute({
      coin_symbol: symbol,
      customer_id,
    });
    return wallet;
  }

  @Query(() => [CustomerCoinWallet])
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetMyCoinWallets(
    @Ctx('customer_id') customer_id: string,
  ): Promise<CustomerCoinWallet[]> {
    const getCustomerCoinsWalletsService = container.resolve(
      GetCustomerCoinsWalletsService,
    );

    const wallets = await getCustomerCoinsWalletsService.execute({
      customer_id,
    });

    const getCustomerCoinWalletBalanceService = container.resolve(
      GetCustomerCoinWalletBalanceService,
    );

    const walletsWithBalance = await Promise.all(
      wallets.map(async w => ({
        ...w,
        balance: await getCustomerCoinWalletBalanceService.execute({
          coin_symbol: w.coin.symbol,
          customer_id,
        }),
      })),
    );

    return walletsWithBalance as CustomerCoinWallet[];
  }

  @Query(() => [Coin])
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetCoins(): Promise<Coin[]> {
    const getCoinsService = container.resolve(GetCoinsService);
    return getCoinsService.execute();
  }
}
