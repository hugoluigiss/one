import { container } from 'tsyringe';
import { Arg, Ctx, Mutation, Resolver, UseMiddleware } from 'type-graphql';
import BigNumber from 'bignumber.js';
import CheckOneTimeCodeService from '../../../services/CheckOneTimeCodeService';
import VerifyCoinOperationLimitService from '../../../../coins/services/VerifyCoinOperationLimitService';
import GetCoinOperationParamService from '../../../../coins/services/GetCoinOperationParamService';
import CheckCustomerTwoFaService from '../../../services/CheckCustomerTwoFaService';

import CreateCoinWithdrawalService from '../../../../coins/services/CreateCoinWithdrawalService';
import CreateCoinTransactionService from '../../../../coins/services/CreateCoinTransactionService';
import GetCoinValueConversionService from '../../../../coins/services/GetCoinValueConversionService';
import CreateCryptoCoinTransactionService from '../../../../coins/services/CreateCryptoCoinTransactionService';
import CheckCoinAddressService from '../../../../coins/services/CheckCoinAddressService';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';
import CheckCafApprovedService from '../../../../caf/services/CheckCafApprovedService';

@Resolver()
export default class CryptoResolver {
  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CreateCryptoBuy(
    @Arg('two_fa') two_fa: string,
    @Arg('value_brl') value_brl: string,
    @Arg('coin_symbol') coin_symbol: 'BTC' | 'ETH' | 'BNB',
    @Ctx('customer_id') customer_id: string,
  ): Promise<string> {
    await container.resolve(CheckCafApprovedService).execute({ customer_id });
    /**
     * verifica 2fa
     */
    await container
      .resolve(CheckOneTimeCodeService)
      .execute({ customer_id, code: two_fa });

    const checkCustomerTwoFaService = container.resolve(
      CheckCustomerTwoFaService,
    );
    await checkCustomerTwoFaService.execute({ token: two_fa, customer_id });

    const getCoinOperationParamService = container.resolve(
      GetCoinOperationParamService,
    );
    const param = await getCoinOperationParamService.execute({
      coin_symbol,
      customer_id,
      operation: 'buy',
    });

    const verifyCoinOperationLimitService = container.resolve(
      VerifyCoinOperationLimitService,
    );
    await verifyCoinOperationLimitService.execute({
      customer_id,
      param,
      value_brl,
    });

    const description = param.transaction_description;

    const createCoinWithdrawalService = container.resolve(
      CreateCoinWithdrawalService,
    );
    const withdrawal = await createCoinWithdrawalService.execute({
      coin_amount: value_brl,
      coin_symbol: 'BRL',
      customer_id,
      description,
      fee_value: new BigNumber(param.percentage_fee_value)
        .multipliedBy(value_brl)
        .plus(param.fixed_fee_brl_value)
        .toFixed(),
      status: 'confirmed',
      operation: 'sell',
    });

    const getCoinValueConversionService = container.resolve(
      GetCoinValueConversionService,
    );
    const convertedValue = await getCoinValueConversionService.execute({
      from: 'BRL',
      to: coin_symbol,
      value: withdrawal.net_value,
    });

    /**
     * cria entrada
     */
    const createCoinTransactionService = container.resolve(
      CreateCoinTransactionService,
    );
    await createCoinTransactionService.execute({
      customer_id,
      total_value: convertedValue,
      type: 'input',
      coin_symbol,
      description,
      fee_value: '0',
      status: 'confirmed',
      operation: 'buy',
    });

    return 'success';
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CreateCryptoSell(
    @Arg('two_fa') two_fa: string,
    @Arg('coin_amount') coin_amount: string,
    @Arg('coin_symbol') coin_symbol: 'BTC' | 'ETH',
    @Ctx('customer_id') customer_id: string,
  ): Promise<string> {
    await container.resolve(CheckCafApprovedService).execute({ customer_id });
    /**
     * verifica 2fa
     */
    await container
      .resolve(CheckOneTimeCodeService)
      .execute({ customer_id, code: two_fa });
    const checkCustomerTwoFaService = container.resolve(
      CheckCustomerTwoFaService,
    );
    await checkCustomerTwoFaService.execute({ token: two_fa, customer_id });

    const getCoinOperationParamService = container.resolve(
      GetCoinOperationParamService,
    );
    const param = await getCoinOperationParamService.execute({
      coin_symbol,
      customer_id,
      operation: 'sell',
    });

    const verifyCoinOperationLimitService = container.resolve(
      VerifyCoinOperationLimitService,
    );
    const getCoinValueConversionService = container.resolve(
      GetCoinValueConversionService,
    );

    const fixedFeeCoin = await getCoinValueConversionService.execute({
      from: 'BRL',
      to: coin_symbol,
      value: param.fixed_fee_brl_value,
    });

    const fee_value = new BigNumber(param.percentage_fee_value)
      .multipliedBy(coin_amount)
      .plus(fixedFeeCoin)
      .toFixed();

    const value_brl = await getCoinValueConversionService.execute({
      to: 'BRL',
      from: coin_symbol,
      value: new BigNumber(coin_amount).minus(fee_value).toFixed(),
    });
    await verifyCoinOperationLimitService.execute({
      customer_id,
      param,
      value_brl,
    });

    const createCoinWithdrawalService = container.resolve(
      CreateCoinWithdrawalService,
    );

    const description = param.transaction_description;

    const withdrawal = await createCoinWithdrawalService.execute({
      coin_amount,
      coin_symbol,
      customer_id,
      description,
      fee_value,
      status: 'confirmed',
      operation: 'sell',
    });

    const convertedValue = await getCoinValueConversionService.execute({
      to: 'BRL',
      from: coin_symbol,
      value: withdrawal.net_value,
    });

    /**
     * cria entrada
     */
    const createCoinTransactionService = container.resolve(
      CreateCoinTransactionService,
    );
    await createCoinTransactionService.execute({
      customer_id,
      total_value: convertedValue,
      type: 'input',
      coin_symbol: 'BRL',
      description,
      fee_value: '0',
      status: 'confirmed',
      operation: 'buy',
    });

    return 'success';
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CreateCryptoWithdrawal(
    @Arg('two_fa') two_fa: string,
    @Arg('coin_amount') coin_amount: string,
    @Arg('coin_symbol') coin_symbol: 'BTC' | 'ETH' | 'BNB',
    @Arg('address_to') address_to: string,
    @Ctx('customer_id') customer_id: string,
    @Arg('dest_flag', { nullable: true }) dest_flag?: string,
  ): Promise<string> {
    await container.resolve(CheckCafApprovedService).execute({ customer_id });

    await container
      .resolve(CheckOneTimeCodeService)
      .execute({ customer_id, code: two_fa });

    const checkCustomerTwoFaService = container.resolve(
      CheckCustomerTwoFaService,
    );
    await checkCustomerTwoFaService.execute({ token: two_fa, customer_id });

    const checkCoinAddressService = container.resolve(CheckCoinAddressService);
    await checkCoinAddressService.execute({ address: address_to, coin_symbol });

    const getCoinOperationParamService = container.resolve(
      GetCoinOperationParamService,
    );
    const param = await getCoinOperationParamService.execute({
      coin_symbol,
      customer_id,
      operation: 'withdrawal',
    });

    const description = param.transaction_description;

    const verifyCoinOperationLimitService = container.resolve(
      VerifyCoinOperationLimitService,
    );
    const getCoinValueConversionService = container.resolve(
      GetCoinValueConversionService,
    );
    const fixedFeeCoin = await getCoinValueConversionService.execute({
      from: 'BRL',
      to: coin_symbol,
      value: param.fixed_fee_brl_value,
    });

    const fee_value = new BigNumber(param.percentage_fee_value)
      .multipliedBy(coin_amount)
      .plus(fixedFeeCoin)
      .toFixed();

    const value_brl = await getCoinValueConversionService.execute({
      to: 'BRL',
      from: coin_symbol,
      value: new BigNumber(coin_amount).minus(fee_value).toFixed(),
    });

    await verifyCoinOperationLimitService.execute({
      customer_id,
      param,
      value_brl,
    });

    const createCoinWithdrawalService = container.resolve(
      CreateCoinWithdrawalService,
    );

    const withdrawal = await createCoinWithdrawalService.execute({
      coin_amount,
      coin_symbol,
      customer_id,
      description,
      fee_value,
      status: 'pending',
      operation: 'withdrawal',
    });

    const createCryptoCoinTransactionService = container.resolve(
      CreateCryptoCoinTransactionService,
    );
    await createCryptoCoinTransactionService.execute({
      address_to,
      transaction_id: withdrawal.id,
      type: 'withdrawal',
      dest_flag,
    });

    return 'success';
  }
}
