import { container } from 'tsyringe';

import {
  Resolver,
  Query,
  Ctx,
  UseMiddleware,
  Mutation,
  Arg,
} from 'type-graphql';
import { FileUpload, GraphQLUpload } from 'graphql-upload';
import GetCustomerDocumentsCopiesService from '../../../services/GetCustomerDocumentsCopiesService';
import SaveFileToTmpFolder from '../../../../../shared/container/providers/StorageProvider/middlewares/SaveFileTmpFolder';
import UpLoadCustomerDocumentCopyService from '../../../services/UpLoadCustomerDocumentCopyService';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';

import CustomerDocumentCopy from '../../typeorm/entities/CustomerDocumentCopy';

@Resolver()
export default class ProfileResolver {
  @Query(() => [CustomerDocumentCopy])
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetMyDocuments(
    @Ctx('customer_id') customer_id: string,
  ): Promise<CustomerDocumentCopy[]> {
    const getCustomerDocumentsCopiesService = container.resolve(
      GetCustomerDocumentsCopiesService,
    );
    return getCustomerDocumentsCopiesService.execute({ customer_id });
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async SendMyDocumentFile(
    @Arg('file', () => GraphQLUpload) file: FileUpload,
    @Arg('document_id') document_id: string,
    @Ctx('customer_id') customer_id: string,
  ): Promise<string> {
    const saveFileToTmpFolder = new SaveFileToTmpFolder();
    const file_name = await saveFileToTmpFolder.execute(file);

    const upLoadCustomerDocumentCopyService = container.resolve(
      UpLoadCustomerDocumentCopyService,
    );
    await upLoadCustomerDocumentCopyService.execute({
      customer_id,
      document_copy_id: document_id,
      file_name,
    });

    return file_name;
  }
}
