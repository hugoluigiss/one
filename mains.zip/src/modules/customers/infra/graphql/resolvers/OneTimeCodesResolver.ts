import { Resolver, Mutation, UseMiddleware, Ctx } from 'type-graphql';
import { container } from 'tsyringe';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';
import CreateCustomerOneTimeCodeService from '../../../services/CreateCustomerOneTimeCodeService';

@Resolver()
export default class OneTimeCodesResolver {
  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CreateMyOneTimeCode(
    @Ctx('customer_id') customer_id: string,
  ): Promise<string> {
    container.resolve(CreateCustomerOneTimeCodeService).execute(customer_id);
    return 'Codigo enviado com sucesso, acesse seu e-mail';
  }
}
