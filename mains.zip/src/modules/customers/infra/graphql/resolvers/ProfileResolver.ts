import { container } from 'tsyringe';
import {
  Resolver,
  Query,
  Ctx,
  UseMiddleware,
  Mutation,
  Arg,
} from 'type-graphql';
import { v4 } from 'uuid';
import GetCustomerProfileService from '../../../services/GetCustomerProfileService';
import UpdateCustomerPasswordService from '../../../services/UpdateCustomerPasswordService';
import CreateCustomerService from '../../../services/CreateCustomerService';
import CreateCustomerDocumentService from '../../../services/CreateCustomerDocumentService';
import CreateCustomerAddressService from '../../../services/CreateCustomerAddressService';
import CreateCustomerAssociationService from '../../../services/CreateCustomerAssociationService';
import GetCustomerAssociatedAccountsService from '../../../services/GetCustomerAssociatedAccountsService';
import CreateSwitchAccountService from '../../../services/CreateSwitchAccountService';
import Customer from '../../typeorm/entities/Customer';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';
import CheckCafApprovedService from '../../../../caf/services/CheckCafApprovedService';
import CustomerSession from '../types/CustomerSession';

@Resolver()
export default class ProfileResolver {
  @Query(() => Customer)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetMyProfile(
    @Ctx('customer_id') customer_id: string,
  ): Promise<Customer> {
    const getCustomerProfileService = container.resolve(
      GetCustomerProfileService,
    );
    return getCustomerProfileService.execute({ customer_id });
  }

  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async UpdateMyPassword(
    @Arg('current_password') current_password: string,
    @Arg('new_password') new_password: string,
    @Ctx('customer_id') customer_id: string,
  ): Promise<string> {
    const updateCustomerPasswordService = container.resolve(
      UpdateCustomerPasswordService,
    );
    await updateCustomerPasswordService.execute({
      current_password,
      customer_id,
      new_password,
    });
    return 'success';
  }

  @Mutation(() => Customer)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CreateCustomerPJ(
    @Arg('full_name') full_name: string,
    @Arg('birth_date') birth_date: Date,

    @Arg('fantasy_name') fantasy_name: string,
    @Arg('cnpj') cnpj: string,

    @Arg('zipcode') zipcode: string,
    @Arg('country') country: string,
    @Arg('state') state: string,
    @Arg('city') city: string,
    @Arg('district') district: string,
    @Arg('street') street: string,
    @Arg('number') number: string,
    @Arg('complement') complement: string,

    @Ctx('customer_id') customer_id: string,
  ): Promise<Customer> {
    await container.resolve(CheckCafApprovedService).execute({ customer_id });
    const createCustomerService = container.resolve(CreateCustomerService);

    const customer = await createCustomerService.execute({
      birth_date,
      full_name,
      type: 'PJ',
      document_value: cnpj,
      email: v4(),
      nationality: 'BR',
      password: v4(),
      fantasy_name,
    });
    const createCustomerDocumentService = container.resolve(
      CreateCustomerDocumentService,
    );
    await createCustomerDocumentService.execute({
      customer_id: customer.id,
      nationality: 'BR',
      document_value: cnpj,
      type: 'CNPJ',
    });
    const createCustomerAddressService = container.resolve(
      CreateCustomerAddressService,
    );
    await createCustomerAddressService.execute({
      customer_id: customer.id,
      complement,
      number,
      street,
      district,
      city,
      state,
      country,
      zip_code: zipcode,
    });

    const createCustomerAssociationService = container.resolve(
      CreateCustomerAssociationService,
    );
    await createCustomerAssociationService.execute({
      customer_pf_id: customer_id,
      customer_pj_id: customer.id,
    });
    return customer;
  }

  @Query(() => [Customer])
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetMyAssociatedAccounts(
    @Ctx('customer_id') customer_id: string,
    @Ctx('customer_pf_id') customer_pf_id: string,
  ): Promise<Customer[]> {
    const getCustomerAssociatedAccountsService = container.resolve(
      GetCustomerAssociatedAccountsService,
    );

    return getCustomerAssociatedAccountsService.execute(
      customer_id,
      customer_pf_id,
    );
  }

  @Mutation(() => CustomerSession)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CreateSwitchAccount(
    @Arg('to_customer_id') to_customer_id: string,
    @Ctx('customer_id') customer_id: string,
    @Ctx('customer_pf_id') customer_pf_id: string,
  ): Promise<CustomerSession> {
    const createSwitchAccountService = container.resolve(
      CreateSwitchAccountService,
    );

    const { customer, token } = await createSwitchAccountService.execute({
      customer_id,
      to_customer_id,
      customer_pf_id,
    });
    return { customer, token };
  }
}
