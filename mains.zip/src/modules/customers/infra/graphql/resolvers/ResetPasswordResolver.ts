import { container } from 'tsyringe';
import { Resolver, Mutation, Arg } from 'type-graphql';
import CreateNewCustomerPasswordService from '../../../services/CreateNewCustomerPasswordService';
import SendForgotPasswordEmailService from '../../../services/SendForgotPasswordEmailService';

@Resolver()
export default class ResetPasswordResolver {
  @Mutation(() => String)
  async SendForgotPasswordEmail(@Arg('email') email: string): Promise<string> {
    const sendForgotPasswordEmailService = container.resolve(
      SendForgotPasswordEmailService,
    );

    await sendForgotPasswordEmailService.execute({ email });
    return 'success';
  }

  @Mutation(() => String)
  async CreateNewCustomerPassword(
    @Arg('token') token: string,
    @Arg('new_password') new_password: string,
  ): Promise<string> {
    const createNewCustomerPasswordService = container.resolve(
      CreateNewCustomerPasswordService,
    );

    await createNewCustomerPasswordService.execute({ token, new_password });

    return 'success';
  }
}
