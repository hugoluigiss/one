import { container } from 'tsyringe';
import { Resolver, Mutation, Arg } from 'type-graphql';
import CreateCustomerSessionService from '../../../services/CreateCustomerSessionService';
import CustomerSession from '../types/CustomerSession';

@Resolver()
export default class SignInResolver {
  @Mutation(() => CustomerSession)
  async CreateCustomerSession(
    @Arg('email') email: string,
    @Arg('password') password: string,
  ): Promise<CustomerSession> {
    const createCustomerSessionService = container.resolve(
      CreateCustomerSessionService,
    );
    const { token, user } = await createCustomerSessionService.execute({
      email,
      password,
    });

    return { customer: user, token };
  }
}
