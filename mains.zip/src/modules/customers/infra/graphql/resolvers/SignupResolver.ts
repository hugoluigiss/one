import { container } from 'tsyringe';
import { Resolver, Mutation, Arg } from 'type-graphql';
import CheckEmailConfirmationTokenSevice from '../../../services/CheckEmailConfirmationTokenService';
import CreateCustomerAddressService from '../../../services/CreateCustomerAddressService';
// import CreateCustomerDocumentService from '../../../services/CreateCustomerDocumentService';
import CreateCustomerService from '../../../services/CreateCustomerService';
import SendEmailConfirmationTokenService from '../../../services/SendEmailConfirmationTokenService';
import Customer from '../../typeorm/entities/Customer';

@Resolver()
export default class SignUpResolver {
  @Mutation(() => String)
  async SendEmailConfirmationToken(
    @Arg('email') email: string,
  ): Promise<string> {
    const sendEmailConfirmationTokenService = container.resolve(
      SendEmailConfirmationTokenService,
    );
    sendEmailConfirmationTokenService.execute({ email });
    return 'success';
  }

  @Mutation(() => String)
  async ConfirmEmailToken(
    @Arg('email') email: string,
    @Arg('token') token: string,
  ): Promise<string> {
    const checkEmailConfirmationTokenSevice = container.resolve(
      CheckEmailConfirmationTokenSevice,
    );

    await checkEmailConfirmationTokenSevice.execute({ email, token });

    return 'success';
  }

  @Mutation(() => Customer)
  async CreateCustomerPF(
    @Arg('email') email: string,
    @Arg('full_name') full_name: string,
    @Arg('birth_date') birth_date: Date,
    @Arg('password') password: string,

    @Arg('nationality') nationality: string,
    @Arg('document') document: string,

    @Arg('zipcode') zipcode: string,
    @Arg('country') country: string,
    @Arg('state') state: string,
    @Arg('city') city: string,
    @Arg('district') district: string,
    @Arg('street') street: string,
    @Arg('number') number: string,
    @Arg('complement') complement: string,
  ): Promise<Customer> {
    const createCustomerService = container.resolve(CreateCustomerService);

    const customer = await createCustomerService.execute({
      birth_date,
      full_name,
      type: 'PF',
      document_value: document,
      email,
      nationality,
      password,
    });

    // const createCustomerDocumentService = container.resolve(
    //   CreateCustomerDocumentService,
    // );
    // await createCustomerDocumentService.execute({
    //   customer_id: customer.id,
    //   nationality,
    //   document_value: document,
    //   type: nationality === 'brazilian' ? 'CPF' : 'PASSPORT',
    // });

    const createCustomerAddressService = container.resolve(
      CreateCustomerAddressService,
    );
    await createCustomerAddressService.execute({
      customer_id: customer.id,
      complement,
      number,
      street,
      district,
      city,
      state,
      country,
      zip_code: zipcode,
    });

    return customer;
  }
}
