import { container } from 'tsyringe';
import { Arg, Ctx, Query, Resolver, UseMiddleware } from 'type-graphql';
import { CoinsType } from 'src/modules/coins/infra/typeorm/entities/Coin';
import GetCustomerStatmentService from '../../../../coins/services/GetCustomerStatmentService';
import PaginationType from '../../../../../shared/infra/graphql/types/PaginationType';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';

@Resolver()
export default class StatmentResolver {
  @Query(() => PaginationType)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetMyStatment(
    @Ctx('customer_id') customer_id: string,
    @Arg('start_date', { nullable: true }) start_date?: Date,
    @Arg('final_date', { nullable: true }) final_date?: Date,
    @Arg('coin_symbol', { nullable: true }) coin_symbol?: CoinsType,
    @Arg('limit', { nullable: true }) limit?: number,
    @Arg('offset', { nullable: true }) offset?: number,
    @Arg('status', { nullable: true }) status?: string,
    @Arg('operation', { nullable: true })
    operation?: 'buy' | 'deposit' | 'withdrawal',
  ): Promise<PaginationType> {
    const getCustomerStatmentService = container.resolve(
      GetCustomerStatmentService,
    );
    const { count, transactions } = await getCustomerStatmentService.execute({
      customer_id,
      coin_symbol,
      final_date: final_date || new Date(),
      start_date: start_date || new Date(2020),
      limit: limit || 10,
      offset,
      status,
      operation,
    });
    return {
      edges: {
        transactions,
      },
      pageInfo: {
        hasNextPage: limit ? count > limit + limit * (offset || 0) : false,
        hasPrevPage: (offset || 0) > 0,
      },
      totalCount: count,
    };
  }
}
