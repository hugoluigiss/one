import { container } from 'tsyringe';
import {
  Arg,
  Ctx,
  Mutation,
  Query,
  Resolver,
  UseMiddleware,
} from 'type-graphql';
import { FileUpload, GraphQLUpload } from 'graphql-upload';
import GetCustomerTicketsService from '../../../../tickets/services/GetCustomerTicketsService';
import PaginationType from '../../../../../shared/infra/graphql/types/PaginationType';
import CreateTicketService from '../../../../tickets/services/CreateTicketService';
import EnsureIsCustomer from '../middlewares/EnsureIsCustomer';
import EnsureHasSession from '../middlewares/EnsureHasSession';

import SaveFileToTmpFolder from '../../../../../shared/container/providers/StorageProvider/middlewares/SaveFileTmpFolder';
import TicketCategory from '../types/TicketCategories';

@Resolver()
export default class TicketResolver {
  @Mutation(() => String)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async CreateTicket(
    @Ctx('customer_id') customer_id: string,
    @Arg('message') message: string,
    @Arg('subject') subject: string,
    @Arg('category_value') category: 'financial' | 'support' | 'marketing',
    @Arg('file', () => GraphQLUpload, { nullable: true }) file?: FileUpload,
  ): Promise<string> {
    let file_name;
    if (file) {
      const saveFileToTmpFolder = new SaveFileToTmpFolder();
      file_name = await saveFileToTmpFolder.execute(file);
    }

    const createTicketService = container.resolve(CreateTicketService);

    await createTicketService.execute({
      category,
      customer_id,
      file_name,
      subject,
      message,
    });

    return 'sucess';
  }

  @Query(() => [TicketCategory])
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetTicketCategories(): Promise<TicketCategory[]> {
    const categories: TicketCategory[] = [
      { name: 'Setor financeiro', value: 'financial' },
      { value: 'marketing', name: 'Setor de marketing' },
      { value: 'support', name: 'Setor de suporte' },
    ];

    return categories;
  }

  @Query(() => PaginationType)
  @UseMiddleware(EnsureIsCustomer)
  @UseMiddleware(EnsureHasSession)
  async GetMyTickets(
    @Ctx('customer_id') customer_id: string,
    @Arg('limit', { nullable: true }) limit?: number,
    @Arg('offset', { nullable: true }) offset?: number,
    @Arg('status', { nullable: true }) status?: 'open' | 'closed',
    @Arg('category_value', { nullable: true })
    category?: 'financial' | 'support' | 'marketing',
  ): Promise<PaginationType> {
    const getCustomerTicketsService = container.resolve(
      GetCustomerTicketsService,
    );
    const { count, tickets } = await getCustomerTicketsService.execute({
      category,
      customer_id,
      limit,
      offset,
      status,
    });

    return {
      totalCount: count,
      edges: { tickets },
      pageInfo: {
        hasNextPage: limit ? count > limit + limit * (offset || 0) : false,
        hasPrevPage: (offset || 0) > 0,
      },
    };
  }
}
