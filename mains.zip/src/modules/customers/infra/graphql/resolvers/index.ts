import SignupResolver from './SignupResolver';
import SignInResolver from './SignInResolver';
import ResetPasswordResolver from './ResetPasswordResolver';
import FaAuthentication from './2FaAuthentication';
import CoinsWalletsResolver from './CoinsWalletsResolver';
import ProfileResolver from './ProfileResolver';
import BankAccountsResolver from './BankAccountsResolver';
import DocumentsResolver from './DocumentsResolver';
import BrlDepositsResolver from './BrlDepositsResolver';
import BrlWithdrawalResolver from './BrlWithdrawalResolver';
import BrlTransferResolver from './BrlTransferResolver';
import CryptoResolver from './CryptoResolver';
import StatmentResolver from './StatmentResolver';
import CoinsOperationParamsResolver from './CoinsOperationParamsResolver';
import TicketsResolver from './TicketsResolver';
import CfaDocumentsResolver from './CfaDocumentsResolver';
import OneTimeCodesResolver from './OneTimeCodesResolver';
import ChartResolver from './ChartResolver';

export default [
  ChartResolver,
  OneTimeCodesResolver,
  CfaDocumentsResolver,
  CoinsOperationParamsResolver,
  StatmentResolver,
  CryptoResolver,
  TicketsResolver,
  BrlTransferResolver,
  SignupResolver,
  SignInResolver,
  ResetPasswordResolver,
  FaAuthentication,
  CoinsWalletsResolver,
  ProfileResolver,
  BankAccountsResolver,
  DocumentsResolver,
  BrlDepositsResolver,
  BrlWithdrawalResolver,
];
