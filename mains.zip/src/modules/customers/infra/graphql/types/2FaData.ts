import { ObjectType, Field } from 'type-graphql';

@ObjectType()
class TwoFaData {
  @Field()
  base32: string;

  @Field(() => String || undefined, { nullable: true })
  otpauth_url?: string | undefined;
}

export default TwoFaData;
