/* eslint-disable max-classes-per-file */
import { ObjectType, Field } from 'type-graphql';
import Customer from '../../typeorm/entities/Customer';

@ObjectType()
class CustomerSession {
  @Field()
  token: string;

  @Field(() => Customer)
  customer: Customer;
}

export default CustomerSession;
