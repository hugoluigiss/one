import { Field, ObjectType } from 'type-graphql';

@ObjectType()
class TicketCategory {
  @Field()
  name: string;

  @Field(() => String)
  value: 'financial' | 'support' | 'marketing';
}

export default TicketCategory;
