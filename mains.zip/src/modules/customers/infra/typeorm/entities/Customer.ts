import { Field, ObjectType } from 'type-graphql';
import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToOne,
  JoinColumn,
  OneToMany,
} from 'typeorm';
import CoinTransaction from '../../../../coins/infra/typeorm/entities/CoinTransaction';
import CustomerDocument from './CustomerDocument';
import CustomerAddress from './CustomerAddress';
import CustomerTwoFa from './CustomerTwoFa';
// import CafDocument from '../../../../caf/infra/typeorm/entities/CafDocument';

@ObjectType()
@Entity('customers')
class Customer {
  @Field()
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Field()
  @Column()
  email: string;

  @Field()
  @Column()
  full_name: string;

  @Field(() => CustomerTwoFa, { nullable: true })
  @OneToOne(() => CustomerTwoFa)
  @JoinColumn({ name: 'id' })
  two_fa?: CustomerTwoFa;

  @Field()
  @Column()
  birth_date: Date;

  @OneToMany(() => CoinTransaction, transaction => transaction.coin)
  transactions: CoinTransaction[];

  @Field(() => CustomerDocument, { nullable: true })
  @OneToOne(() => CustomerDocument, { eager: true })
  @JoinColumn({ name: 'id' })
  document: CustomerDocument;

  @Field(() => CustomerAddress, { nullable: true })
  @OneToOne(() => CustomerAddress, { eager: true })
  @JoinColumn({ name: 'id' })
  address: CustomerAddress;

  @Column()
  password_hash: string;

  @Field({ nullable: true })
  @Column()
  fantasy_name?: string;

  @Field()
  @Column()
  type: 'PF' | 'PJ';

  @Field(() => String)
  get avatar_url(): string {
    return `https://ui-avatars.com/api/?size=512&bold=true&color=a17725&background=efefef&name=${this.full_name}`;
  }

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;
}
export default Customer;
