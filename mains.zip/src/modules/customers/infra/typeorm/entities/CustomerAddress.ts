import { Field, ObjectType } from 'type-graphql';
import {
  Entity,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  PrimaryColumn,
} from 'typeorm';

@ObjectType()
@Entity('customers_addresses')
class CustomerAddress {
  @PrimaryColumn()
  customer_id: string;

  @Field()
  @Column()
  zip_code: string;

  @Field()
  @Column()
  country: string;

  @Field()
  @Column()
  state: string;

  @Field()
  @Column()
  city: string;

  @Field()
  @Column()
  district: string;

  @Field()
  @Column()
  street: string;

  @Field()
  @Column()
  number: string;

  @Field()
  @Column()
  complement: string;

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;
}
export default CustomerAddress;
