import { Field, ObjectType } from 'type-graphql';
import {
  Entity,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  PrimaryGeneratedColumn,
  JoinColumn,
  OneToOne,
} from 'typeorm';
import Customer from './Customer';

@ObjectType()
@Entity('customers_associations')
class CustomerAssociation {
  @Field()
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Field()
  @Column()
  customer_pf_id: string;

  @Field()
  @Column()
  customer_pj_id: string;

  @Field(() => Customer)
  @OneToOne(() => Customer)
  @JoinColumn({ name: 'customer_pj_id' })
  customer_pj: Customer;

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;
}

export default CustomerAssociation;
