import { Field, ObjectType } from 'type-graphql';
import {
  Entity,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  PrimaryColumn,
  OneToOne,
  JoinColumn,
  OneToMany,
} from 'typeorm';
import Customer from './Customer';
import CustomerDocumentCopy from './CustomerDocumentCopy';

@ObjectType()
@Entity('customers_documents')
class CustomerDocument {
  @PrimaryColumn()
  customer_id: string;

  @Field(() => Customer)
  @OneToOne(() => Customer)
  @JoinColumn({ name: 'customer_id' })
  customer: Customer;

  @Field(() => [CustomerDocumentCopy], { nullable: true })
  @OneToMany(() => CustomerDocumentCopy, copy => copy.document)
  copies: CustomerDocumentCopy[];

  @Field()
  @Column()
  type: 'CPF' | 'PASSPORT' | 'CNPJ';

  @Field()
  @Column()
  nationality: string;

  @Field(() => Boolean, { nullable: true })
  @Column()
  has_complience: boolean;

  @Field()
  @Column()
  document_value: string;

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;
}

export default CustomerDocument;
