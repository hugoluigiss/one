import { Field, ObjectType } from 'type-graphql';
import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';

import upload from '../../../../../config/upload';
import app from '../../../../../config/app';
import CustomerDocument from './CustomerDocument';

@ObjectType()
@Entity('customers_documents_copies')
class CustomerDocumentCopy {
  @Field()
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  customer_id: string;

  @Field()
  @Column()
  name: string;

  @Field(() => CustomerDocument)
  @ManyToOne(() => CustomerDocument, document => document.copies, {
    eager: true,
  })
  @JoinColumn({ name: 'customer_id' })
  document: CustomerDocument;

  @Field()
  @Column()
  status: 'pending' | 'approved' | 'rejected';

  @Field({ nullable: true })
  @Column()
  admin_answear?: string;

  @Field()
  @Column()
  type: 'cnpj' | 'social_contract' | 'cpf' | 'passport' | 'selfie';

  @Field()
  @Column()
  description: string;

  @Column({ nullable: true })
  file_name: string;

  @Field(() => String, { nullable: true })
  get file_url(): string {
    if (this.file_name)
      return upload.driver === 's3'
        ? `https://${upload.config.aws.bucket}.s3.${upload.config.aws.region}.amazonaws.com/${this.file_name}`
        : `${app.backend.host}/files/${this.file_name}`;

    return this.file_name;
  }

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;
}
export default CustomerDocumentCopy;
