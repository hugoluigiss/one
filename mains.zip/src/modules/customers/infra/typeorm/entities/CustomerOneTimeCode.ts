import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity('customers_one_time_codes')
class CustomerOneTimeCode {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  customer_id: string;

  @Column()
  code: string;

  @Column()
  valid: boolean;

  @CreateDateColumn()
  created_at: Date;
}
export default CustomerOneTimeCode;
