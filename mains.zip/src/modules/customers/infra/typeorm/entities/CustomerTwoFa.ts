import { Field, ObjectType } from 'type-graphql';
import {
  Entity,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  PrimaryColumn,
} from 'typeorm';

@ObjectType()
@Entity('customers_twofa')
class CustomerTwoFa {
  @PrimaryColumn()
  customer_id: string;

  @Field()
  @Column()
  secret: string;

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;
}

export default CustomerTwoFa;
