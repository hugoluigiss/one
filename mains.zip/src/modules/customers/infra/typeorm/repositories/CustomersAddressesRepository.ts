import ICreateCustomerAddressDTO from '../../../dtos/ICreateCustomerAddressDTO';
import ICustomersAddressesRepository from '../../../repositories/ICustomersAddressesRepository';
import { getRepository, Repository } from 'typeorm';
import CustomerAddress from '../entities/CustomerAddress';

class CustomersAddressesRepository implements ICustomersAddressesRepository {
  private ormRepository: Repository<CustomerAddress>;

  constructor() {
    this.ormRepository = getRepository(CustomerAddress);
  }

  public async create({
    city,
    complement,
    country,
    customer_id,
    district,
    number,
    state,
    street,
    zip_code,
  }: ICreateCustomerAddressDTO): Promise<CustomerAddress> {
    const address = this.ormRepository.create({
      city,
      complement,
      country,
      customer_id,
      district,
      number,
      state,
      street,
      zip_code,
    });
    await this.ormRepository.save(address);
    return address;
  }

  public async save(address: CustomerAddress): Promise<CustomerAddress> {
    return this.ormRepository.save(address);
  }
}
export default CustomersAddressesRepository;
