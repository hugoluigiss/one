import ICreateCustomerAssociationDTO from '../../../dtos/ICreateCustomerAssociationDTO';
import ICustomersAssociationsRepository from '../../../repositories/ICustomersAssociationsRepository';
import { getRepository, Repository } from 'typeorm';
import CustomerAssociation from '../entities/CustomerAssociation';

class CustomersAssociationsRepository
  implements ICustomersAssociationsRepository
{
  private ormRepository: Repository<CustomerAssociation>;

  constructor() {
    this.ormRepository = getRepository(CustomerAssociation);
  }

  public async create({
    customer_pf_id,
    customer_pj_id,
  }: ICreateCustomerAssociationDTO): Promise<CustomerAssociation> {
    const association = this.ormRepository.create({
      customer_pf_id,
      customer_pj_id,
    });
    await this.ormRepository.save(association);
    return association;
  }

  public async save(
    association: CustomerAssociation,
  ): Promise<CustomerAssociation> {
    return this.ormRepository.save(association);
  }

  public async findAssociationsByCustomerPfId(
    customer_pf_id: string,
  ): Promise<CustomerAssociation[]> {
    return this.ormRepository.find({
      where: { customer_pf_id },
      relations: ['customer_pj'],
    });
  }
}
export default CustomersAssociationsRepository;
