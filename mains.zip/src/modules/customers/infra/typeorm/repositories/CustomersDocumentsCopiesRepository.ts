import { getRepository, Repository } from 'typeorm';
import ICreateCustomerDocumentCopyDTO from '../../../dtos/ICreateCustomerDocumentCopyDTO';
import ICustomersDocumentsCopiesRepository from '../../../repositories/ICustomersDocumentsCopiesRepository';
import CustomerDocumentCopy from '../entities/CustomerDocumentCopy';

class CustomersDocumentsCopiesRepository
  implements ICustomersDocumentsCopiesRepository
{
  private ormRepository: Repository<CustomerDocumentCopy>;

  constructor() {
    this.ormRepository = getRepository(CustomerDocumentCopy);
  }

  public async findById(id: string): Promise<CustomerDocumentCopy | undefined> {
    return this.ormRepository.findOne(id);
  }

  public async create({
    customer_id,
    description,
    name,
    type,
  }: ICreateCustomerDocumentCopyDTO): Promise<CustomerDocumentCopy> {
    const copy = this.ormRepository.create({
      customer_id,
      description,
      name,
      type,
      status: 'pending',
    });

    await this.ormRepository.save(copy);
    return copy;
  }

  public async save(copy: CustomerDocumentCopy): Promise<CustomerDocumentCopy> {
    return this.ormRepository.save(copy);
  }

  public async findByCustomerId(
    customer_id: string,
  ): Promise<CustomerDocumentCopy[]> {
    return this.ormRepository.find({ where: { customer_id } });
  }
}
export default CustomersDocumentsCopiesRepository;
