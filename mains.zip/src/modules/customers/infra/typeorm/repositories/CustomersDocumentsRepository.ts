import ICreateCustomerDocumentDTO from '../../../dtos/ICreateCustomerDocumentDTO';
import IFindAllDocumentsCopiesParamsDTO from '../../../dtos/IFindAllDocumentsCopiesParamsDTO';
import IFindAllDocumentsCopiesResponseDTO from '../../../dtos/IFindAllDocumentsCopiesResponseDTO';
import ICustomersDocumentsRepository from '../../../repositories/ICustomersDocumentsRepository';
import { getRepository, Repository } from 'typeorm';
import CustomerDocument from '../entities/CustomerDocument';

class CustomersDocumentsRepository implements ICustomersDocumentsRepository {
  private ormRepository: Repository<CustomerDocument>;

  constructor() {
    this.ormRepository = getRepository(CustomerDocument);
  }

  public async create({
    customer_id,
    document_value,
    nationality,
    type,
  }: ICreateCustomerDocumentDTO): Promise<CustomerDocument> {
    const document = this.ormRepository.create({
      customer_id,
      document_value,
      nationality,
      type,
    });
    await this.ormRepository.save(document);
    return document;
  }

  public async save(document: CustomerDocument): Promise<CustomerDocument> {
    return this.ormRepository.save(document);
  }

  public async findByTypeAndValue(
    type: 'CPF' | 'PASSPORT' | 'CNPJ',
    value: string,
  ): Promise<CustomerDocument | undefined> {
    const finded = await this.ormRepository.findOne({
      where: { type, document_value: value },
    });
    return finded;
  }

  public async findByCustomerId(
    customer_id: string,
  ): Promise<CustomerDocument | undefined> {
    return this.ormRepository.findOne({ where: { customer_id } });
  }

  public async findAll({
    order,
    filter,
    pagination,
  }: IFindAllDocumentsCopiesParamsDTO): Promise<IFindAllDocumentsCopiesResponseDTO> {
    const builder = this.ormRepository.createQueryBuilder(
      'customers_documents',
    );

    builder.leftJoinAndSelect('customers_documents.customer', 'customer');

    builder.leftJoinAndSelect('customers_documents.copies', 'copies');

    builder.orderBy(`customers_documents.${order.field}`, order.order);

    if (filter) {
      if (filter.has_complience !== null && filter.has_complience !== undefined)
        builder.where('customers_documents.has_complience = :has_complience', {
          has_complience: filter.has_complience,
        });

      if (filter.customer_id)
        builder.andWhere('customers_documents.customer_id = :customer_id', {
          customer_id: filter.customer_id,
        });
    }

    const count = await builder.getCount();

    if (pagination && pagination.limit) {
      builder.limit(pagination.limit);
      builder.offset(pagination.limit * (pagination.offset || 0));
    }

    const documents = await builder.getMany();

    return { count, documents };
  }
}
export default CustomersDocumentsRepository;
