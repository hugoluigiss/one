import { getRepository } from 'typeorm';
import ICustomersOneTimeCodesRepository from '../../../repositories/ICustomersOneTimeCodesRepository';
import CustomerOneTimeCode from '../entities/CustomerOneTimeCode';

class CustomersOneTimeCodesRepository
  implements ICustomersOneTimeCodesRepository
{
  constructor(private ormRepository = getRepository(CustomerOneTimeCode)) {}

  public async save(
    customerOneTimeCode: CustomerOneTimeCode,
  ): Promise<CustomerOneTimeCode> {
    return this.ormRepository.save(customerOneTimeCode);
  }

  public async create(
    customer_id: string,
    code: string,
  ): Promise<CustomerOneTimeCode> {
    const customerCode = this.ormRepository.create({
      customer_id,
      code,
      valid: true,
    });
    await this.ormRepository.save(customerCode);
    return customerCode;
  }

  public async findCustomerValidCode(
    customer_id: string,
    code: string,
  ): Promise<CustomerOneTimeCode | undefined> {
    return this.ormRepository.findOne({
      where: { code, customer_id, valid: true },
    });
  }
}
export default CustomersOneTimeCodesRepository;
