import IFindCustomersWithPaginationDTO from 'src/modules/customers/dtos/IFindCustomersWithPaginationDTO';
import IFindCustomersWithPaginationResponseDTO from 'src/modules/customers/dtos/IFindCustomersWithPaginationResponseDTO';
import { getRepository, Repository } from 'typeorm';
import ICreateCustomerDTO from '../../../dtos/ICreateCustomerDTO';
import ICustomersRepository from '../../../repositories/ICustomersRepository';
import Customer from '../entities/Customer';

class CustomersRepository implements ICustomersRepository {
  private ormRepository: Repository<Customer>;

  constructor() {
    this.ormRepository = getRepository(Customer);
  }

  public async findAll(): Promise<Customer[]> {
    return this.ormRepository.find();
  }

  public async findWithPagination({
    order,
    limit,
    offset,
  }: IFindCustomersWithPaginationDTO): Promise<IFindCustomersWithPaginationResponseDTO> {
    const query = this.ormRepository.createQueryBuilder('customers');

    query.orderBy('customers.created_at', order || 'ASC');

    if (limit) {
      query.limit(limit);
      if (offset) query.offset(limit * offset);
    }

    query.leftJoinAndSelect('customers.two_fa', 'two_fa');
    query.leftJoinAndSelect('customers.document', 'document');
    query.leftJoinAndSelect('document.copies', 'copies');
    query.leftJoinAndSelect('customers.address', 'address');

    const customers = await query.getMany();
    const count = await query.getCount();

    return { customers, count };
  }

  public async create({
    type,
    email,
    full_name,
    birth_date,
    password_hash,
    fantasy_name,
  }: ICreateCustomerDTO): Promise<Customer> {
    const customer = this.ormRepository.create({
      type,
      email,
      full_name,
      birth_date,
      password_hash,
      fantasy_name,
    });

    await this.ormRepository.save(customer);
    return customer;
  }

  public async save(customer: Customer): Promise<Customer> {
    return this.ormRepository.save(customer);
  }

  public async findByEmail(email: string): Promise<Customer | undefined> {
    const finded = await this.ormRepository.findOne({ where: { email } });
    return finded;
  }

  public async findById(id: string): Promise<Customer | undefined> {
    const finded = await this.ormRepository.findOne(id);
    return finded;
  }
}
export default CustomersRepository;
