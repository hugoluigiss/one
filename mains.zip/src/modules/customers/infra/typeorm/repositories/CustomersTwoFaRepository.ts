import { getRepository, Repository } from 'typeorm';
import ICreateCustomerTwoFaDTO from '../../../dtos/ICreateCustomerTwoFaDTO';
import ICustomersTwoFaRepository from '../../../repositories/ICustomersTwoFaRepository';
import CustomerTwoFa from '../entities/CustomerTwoFa';

class CustomersTwoFaRepository implements ICustomersTwoFaRepository {
  private ormRepository: Repository<CustomerTwoFa>;

  constructor() {
    this.ormRepository = getRepository(CustomerTwoFa);
  }

  public async create({
    customer_id,
    secret,
  }: ICreateCustomerTwoFaDTO): Promise<CustomerTwoFa> {
    const twofa = this.ormRepository.create({
      customer_id,
      secret,
    });
    await this.ormRepository.save(twofa);
    return twofa;
  }

  public async save(twofa: CustomerTwoFa): Promise<CustomerTwoFa> {
    return this.ormRepository.save(twofa);
  }

  public async destroy(twofa: CustomerTwoFa): Promise<void> {
    this.ormRepository.delete(twofa.customer_id);
  }

  public async findByCustomerId(
    customer_id: string,
  ): Promise<CustomerTwoFa | undefined> {
    const finded = await this.ormRepository.findOne(customer_id);
    return finded;
  }
}
export default CustomersTwoFaRepository;
