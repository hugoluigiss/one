import { container } from 'tsyringe';
import CustomersAddressesRepository from '../infra/typeorm/repositories/CustomersAddressesRepository';
import CustomersAssociationsRepository from '../infra/typeorm/repositories/CustomersAssociationsRepository';
import CustomersDocumentsCopiesRepository from '../infra/typeorm/repositories/CustomersDocumentsCopiesRepository';
import CustomersDocumentsRepository from '../infra/typeorm/repositories/CustomersDocumentsRepository';
import CustomersOneTimeCodesRepository from '../infra/typeorm/repositories/CustomersOneTimeCodesRepository';
import CustomersRepository from '../infra/typeorm/repositories/CustomersRepository';
import CustomersTwoFaRepository from '../infra/typeorm/repositories/CustomersTwoFaRepository';
import ICustomersAddressesRepository from '../repositories/ICustomersAddressesRepository';
import ICustomersAssociationsRepository from '../repositories/ICustomersAssociationsRepository';
import ICustomersDocumentsCopiesRepository from '../repositories/ICustomersDocumentsCopiesRepository';
import ICustomersDocumentsRepository from '../repositories/ICustomersDocumentsRepository';
import ICustomersOneTimeCodesRepository from '../repositories/ICustomersOneTimeCodesRepository';
import ICustomersRepository from '../repositories/ICustomersRepository';
import ICustomersTwoFaRepository from '../repositories/ICustomersTwoFaRepository';

container.registerSingleton<ICustomersOneTimeCodesRepository>(
  'CustomersOneTimeCodesRepository',
  CustomersOneTimeCodesRepository,
);

container.registerSingleton<ICustomersRepository>(
  'CustomersRepository',
  CustomersRepository,
);

container.registerSingleton<ICustomersDocumentsRepository>(
  'CustomersDocumentsRepository',
  CustomersDocumentsRepository,
);

container.registerSingleton<ICustomersAddressesRepository>(
  'CustomersAddressesRepository',
  CustomersAddressesRepository,
);

container.registerSingleton<ICustomersTwoFaRepository>(
  'CustomersTwoFaRepository',
  CustomersTwoFaRepository,
);

container.registerSingleton<ICustomersDocumentsCopiesRepository>(
  'CustomersDocumentsCopiesRepository',
  CustomersDocumentsCopiesRepository,
);

container.registerSingleton<ICustomersAssociationsRepository>(
  'CustomersAssociationsRepository',
  CustomersAssociationsRepository,
);
