import ICreateCustomerAddressDTO from '../dtos/ICreateCustomerAddressDTO';
import CustomerAddress from '../infra/typeorm/entities/CustomerAddress';

export default interface ICustomersAddressesRepository {
  create(data: ICreateCustomerAddressDTO): Promise<CustomerAddress>;
  save(address: CustomerAddress): Promise<CustomerAddress>;
}
