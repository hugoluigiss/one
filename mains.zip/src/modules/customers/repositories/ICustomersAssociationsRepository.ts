import ICreateCustomerAssociationDTO from '../dtos/ICreateCustomerAssociationDTO';
import CustomerAssociation from '../infra/typeorm/entities/CustomerAssociation';

export default interface ICustomersAssociationsRepository {
  create(data: ICreateCustomerAssociationDTO): Promise<CustomerAssociation>;
  save(data: CustomerAssociation): Promise<CustomerAssociation>;
  findAssociationsByCustomerPfId(
    customer_pf_id: string,
  ): Promise<CustomerAssociation[]>;
}
