import ICreateCustomerDocumentCopyDTO from '../dtos/ICreateCustomerDocumentCopyDTO';
import CustomerDocumentCopy from '../infra/typeorm/entities/CustomerDocumentCopy';

export default interface ICustomersDocumentsCopiesRepository {
  create(data: ICreateCustomerDocumentCopyDTO): Promise<CustomerDocumentCopy>;
  save(copy: CustomerDocumentCopy): Promise<CustomerDocumentCopy>;
  findByCustomerId(customer_id: string): Promise<CustomerDocumentCopy[]>;
  findById(id: string): Promise<CustomerDocumentCopy | undefined>;
}
