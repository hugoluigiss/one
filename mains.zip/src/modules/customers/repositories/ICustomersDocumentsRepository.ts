import ICreateCustomerDocumentDTO from '../dtos/ICreateCustomerDocumentDTO';
import IFindAllDocumentsCopiesParamsDTO from '../dtos/IFindAllDocumentsCopiesParamsDTO';
import IFindAllDocumentsCopiesResponseDTO from '../dtos/IFindAllDocumentsCopiesResponseDTO';
import CustomerDocument from '../infra/typeorm/entities/CustomerDocument';

export default interface ICustomersDocumentsRepository {
  create(data: ICreateCustomerDocumentDTO): Promise<CustomerDocument>;
  save(document: CustomerDocument): Promise<CustomerDocument>;
  findByTypeAndValue(
    type: 'CPF' | 'PASSPORT' | 'CNPJ',
    value: string,
  ): Promise<CustomerDocument | undefined>;
  findByCustomerId(customer_id: string): Promise<CustomerDocument | undefined>;
  findAll(
    data: IFindAllDocumentsCopiesParamsDTO,
  ): Promise<IFindAllDocumentsCopiesResponseDTO>;
}
