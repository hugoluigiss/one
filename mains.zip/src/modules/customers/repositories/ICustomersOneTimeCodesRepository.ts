import CustomerOneTimeCode from '../infra/typeorm/entities/CustomerOneTimeCode';

export default interface ICustomersOneTimeCodesRepository {
  create(customer_id: string, code: string): Promise<CustomerOneTimeCode>;
  save(customerOneTimeCode: CustomerOneTimeCode): Promise<CustomerOneTimeCode>;
  findCustomerValidCode(
    customer_id: string,
    code: string,
  ): Promise<CustomerOneTimeCode | undefined>;
}
