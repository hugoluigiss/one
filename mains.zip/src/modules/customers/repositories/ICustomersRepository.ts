import ICreateCustomerDTO from '../dtos/ICreateCustomerDTO';
import IFindCustomersWithPaginationDTO from '../dtos/IFindCustomersWithPaginationDTO';
import IFindCustomersWithPaginationResponseDTO from '../dtos/IFindCustomersWithPaginationResponseDTO';
import Customer from '../infra/typeorm/entities/Customer';

export default interface ICustomersRepository {
  create(data: ICreateCustomerDTO): Promise<Customer>;
  save(customer: Customer): Promise<Customer>;
  findByEmail(email: string): Promise<Customer | undefined>;
  findById(id: string): Promise<Customer | undefined>;
  findAll(): Promise<Customer[]>;
  findWithPagination(
    data: IFindCustomersWithPaginationDTO,
  ): Promise<IFindCustomersWithPaginationResponseDTO>;
}
