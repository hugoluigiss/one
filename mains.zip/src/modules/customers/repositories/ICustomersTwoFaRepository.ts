import ICreateCustomerTwoFaDTO from '../dtos/ICreateCustomerTwoFaDTO';
import CustomerTwoFa from '../infra/typeorm/entities/CustomerTwoFa';

export default interface ICustomersTwoFaRepository {
  create(data: ICreateCustomerTwoFaDTO): Promise<CustomerTwoFa>;
  save(twoFa: CustomerTwoFa): Promise<CustomerTwoFa>;
  findByCustomerId(customer_id: string): Promise<CustomerTwoFa | undefined>;
  destroy(twoFa: CustomerTwoFa): Promise<void>;
}
