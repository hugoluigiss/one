import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import CustomerDocumentCopy from '../infra/typeorm/entities/CustomerDocumentCopy';
import ICustomersDocumentsCopiesRepository from '../repositories/ICustomersDocumentsCopiesRepository';
import ICustomersDocumentsRepository from '../repositories/ICustomersDocumentsRepository';

interface IParams {
  document_copy_id: string;
}

@injectable()
class ApproveCustomerDocumentCopyService {
  constructor(
    @inject('CustomersDocumentsCopiesRepository')
    private customersDocumentsCopiesRepository: ICustomersDocumentsCopiesRepository,

    @inject('CustomersDocumentsRepository')
    private customersDocumentsRepository: ICustomersDocumentsRepository,
  ) {}

  public async execute({
    document_copy_id,
  }: IParams): Promise<CustomerDocumentCopy> {
    const copy = await this.customersDocumentsCopiesRepository.findById(
      document_copy_id,
    );
    if (!copy) throw new ApolloError('Documento não encontrado');

    copy.status = 'approved';
    await this.customersDocumentsCopiesRepository.save(copy);

    const copies =
      await this.customersDocumentsCopiesRepository.findByCustomerId(
        copy.customer_id,
      );
    const hasNotApproved = copies.find(c => c.status !== 'approved');
    if (!hasNotApproved) {
      const document = await this.customersDocumentsRepository.findByCustomerId(
        copy.customer_id,
      );
      if (!document) throw new ApolloError('Documento não encontrado');
      document.has_complience = true;
      await this.customersDocumentsRepository.save(document);
    }

    return copy;
  }
}
export default ApproveCustomerDocumentCopyService;
