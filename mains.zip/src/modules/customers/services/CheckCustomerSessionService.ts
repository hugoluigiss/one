import { inject, injectable } from 'tsyringe';

import { ApolloError } from 'apollo-server-express';

import ICacheProvider from '../../../shared/container/providers/CacheProvider/models/ICacheProvider';

interface ICacheData {
  date: Date;
}

@injectable()
class CheckCustomerSessionService {
  constructor(
    @inject('CacheProvider')
    private cacheProvider: ICacheProvider,
  ) {}

  public async execute(user_id: string): Promise<void> {
    const key = `user_logged:${user_id}`;
    const value = await this.cacheProvider.recover<ICacheData>(key);
    if (!value) throw new ApolloError('session_expired');
    await this.cacheProvider.save(key, { date: new Date() }, 10);
  }
}

export default CheckCustomerSessionService;
