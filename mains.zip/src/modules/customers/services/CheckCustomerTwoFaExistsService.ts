import { inject, injectable } from 'tsyringe';
import ICustomersTwoFaRepository from '../repositories/ICustomersTwoFaRepository';

interface IParams {
  customer_id: string;
}

@injectable()
class CheckCustomerTwoFaExistsService {
  constructor(
    @inject('CustomersTwoFaRepository')
    private customersTwoFaRepository: ICustomersTwoFaRepository,
  ) {}

  public async execute({ customer_id }: IParams): Promise<boolean> {
    const alredyHas = await this.customersTwoFaRepository.findByCustomerId(
      customer_id,
    );
    return !!alredyHas;
  }
}
export default CheckCustomerTwoFaExistsService;
