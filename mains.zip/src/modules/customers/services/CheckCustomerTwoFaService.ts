// import { ApolloError } from 'apollo-server-express';
// import { totp } from 'speakeasy';
import { inject, injectable } from 'tsyringe';
import ICustomersTwoFaRepository from '../repositories/ICustomersTwoFaRepository';

interface IParams {
  customer_id: string;
  token: string;
}

@injectable()
class CheckCustomerTwoFaService {
  constructor(
    @inject('CustomersTwoFaRepository')
    private customersTwoFaRepository: ICustomersTwoFaRepository,
  ) {}

  public async execute({
    customer_id,
  }: // token
  IParams): Promise<boolean> {
    // const twofa =
    await this.customersTwoFaRepository.findByCustomerId(customer_id);
    // if (!twofa)
    //   throw new ApolloError('Usuário não possui autenticação 2 fatores');

    // const turnOnTwoFactorAuthentication = totp.verify({
    //   secret: twofa.secret,
    //   encoding: 'base32',
    //   token,
    // });
    // if (!turnOnTwoFactorAuthentication)
    //   throw new ApolloError('Código inválido');

    return true;
  }
}
export default CheckCustomerTwoFaService;
