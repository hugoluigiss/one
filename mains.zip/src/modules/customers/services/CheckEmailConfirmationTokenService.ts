import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import ICacheProvider from '../../../shared/container/providers/CacheProvider/models/ICacheProvider';

interface IParams {
  email: string;
  token: string;
}

@injectable()
class CheckEmailConfirmationTokenSevice {
  constructor(
    @inject('CacheProvider')
    private cacheProvider: ICacheProvider,
  ) {}

  public async execute({ email, token }: IParams): Promise<string> {
    const cachedToken = await this.cacheProvider.recover<string>(
      `confirmation_token:${email}`,
    );
    if (!cachedToken) throw new ApolloError('Token não encontrado ou expirado');

    if (cachedToken !== token) throw new ApolloError('Token incorreto');

    await this.cacheProvider.invalidate(`confirmation_token:${email}`);
    return 'success';
  }
}
export default CheckEmailConfirmationTokenSevice;
