import { ApolloError } from 'apollo-server-express';
import { addMinutes, isAfter } from 'date-fns';
import { inject, injectable } from 'tsyringe';
import ICustomersOneTimeCodesRepository from '../repositories/ICustomersOneTimeCodesRepository';

interface IParams {
  customer_id: string;
  code: string;
}

@injectable()
class CheckOneTimeCodeService {
  constructor(
    @inject('CustomersOneTimeCodesRepository')
    private customersOneTimeCodesRepository: ICustomersOneTimeCodesRepository,
  ) {}

  public async execute({ customer_id, code }: IParams): Promise<boolean> {
    const userCode =
      await this.customersOneTimeCodesRepository.findCustomerValidCode(
        customer_id,
        code,
      );
    if (!userCode) throw new ApolloError('Código inválido');

    const deadLine = addMinutes(userCode.created_at, 15);
    if (isAfter(new Date(), deadLine)) throw new ApolloError('Código expirado');

    userCode.valid = false;
    await this.customersOneTimeCodesRepository.save(userCode);

    return true;
  }
}
export default CheckOneTimeCodeService;
