import { inject, injectable } from 'tsyringe';
import CustomerAddress from '../infra/typeorm/entities/CustomerAddress';
import ICustomersAddressesRepository from '../repositories/ICustomersAddressesRepository';

interface IParams {
  customer_id: string;
  zip_code: string;
  country: string;
  state: string;
  city: string;
  district: string;
  street: string;
  number: string;
  complement: string;
}

@injectable()
class CreateCustomerAddressService {
  constructor(
    @inject('CustomersAddressesRepository')
    private customersAddressesRepository: ICustomersAddressesRepository,
  ) {}

  public async execute({
    customer_id,
    zip_code,
    country,
    state,
    city,
    district,
    street,
    number,
    complement,
  }: IParams): Promise<CustomerAddress> {
    const address = await this.customersAddressesRepository.create({
      customer_id,
      zip_code,
      country,
      state,
      city,
      district,
      street,
      number,
      complement,
    });
    return address;
  }
}
export default CreateCustomerAddressService;
