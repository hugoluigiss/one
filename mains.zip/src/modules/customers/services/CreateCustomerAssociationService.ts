import { inject, injectable } from 'tsyringe';
import CustomerAssociation from '../infra/typeorm/entities/CustomerAssociation';
import ICustomersAssociationsRepository from '../repositories/ICustomersAssociationsRepository';

interface IParams {
  customer_pf_id: string;
  customer_pj_id: string;
}

@injectable()
class CreateCustomerAssociationService {
  constructor(
    @inject('CustomersAssociationsRepository')
    private customersAssociationsRepository: ICustomersAssociationsRepository,
  ) {}

  public async execute({
    customer_pf_id,
    customer_pj_id,
  }: IParams): Promise<CustomerAssociation> {
    const association = await this.customersAssociationsRepository.create({
      customer_pj_id,
      customer_pf_id,
    });
    return association;
  }
}
export default CreateCustomerAssociationService;
