import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import CustomerDocument from '../infra/typeorm/entities/CustomerDocument';
import ICustomersDocumentsRepository from '../repositories/ICustomersDocumentsRepository';

interface IParams {
  customer_id: string;
  document_value: string;
  nationality: string;
  type: 'CPF' | 'CNPJ' | 'PASSPORT';
}

@injectable()
class CreateCustomerDocumentService {
  constructor(
    @inject('CustomersDocumentsRepository')
    private customerDocumentsRepository: ICustomersDocumentsRepository,
  ) {}

  public async execute({
    type,
    nationality,
    document_value,
    customer_id,
  }: IParams): Promise<CustomerDocument> {
    const alreadyExists =
      await this.customerDocumentsRepository.findByTypeAndValue(
        type,
        document_value,
      );

    if (alreadyExists) throw new ApolloError('Documento já existe');

    const document = await this.customerDocumentsRepository.create({
      customer_id,
      document_value,
      nationality,
      type,
    });
    return document;
  }
}
export default CreateCustomerDocumentService;
