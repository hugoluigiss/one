import { inject, injectable } from 'tsyringe';
import path from 'path';
import { ApolloError } from 'apollo-server-express';
import ICustomersOneTimeCodesRepository from '../repositories/ICustomersOneTimeCodesRepository';
import CustomerOneTimeCode from '../infra/typeorm/entities/CustomerOneTimeCode';
import IMailProvider from '../../../shared/container/providers/MailProvider/models/IMailProvider';
import mailConfig from '../../../config/mail';
import ICustomersRepository from '../repositories/ICustomersRepository';

@injectable()
class CreateCustomerOneTimeCodeService {
  constructor(
    @inject('CustomersOneTimeCodesRepository')
    private customersOneTimeCodesRepository: ICustomersOneTimeCodesRepository,

    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,

    @inject('MailProvider')
    private mailProvider: IMailProvider,
  ) {}

  public async execute(customer_id: string): Promise<CustomerOneTimeCode> {
    const customer = await this.customersRepository.findById(customer_id);
    if (!customer) throw new ApolloError('Usuario nao encontrado');
    const code = Math.floor(100000 + Math.random() * 900000);
    const template = path.resolve(
      mailConfig.templatesFolder,
      'one_time_code.hbs',
    );

    await this.mailProvider.sendMail({
      to: {
        name: 'no-reply',
        email: customer.email,
      },
      subject: '[exchange] Confirmacao de operacao financeira',
      templateData: {
        file: template,
        variables: {
          code: String(code),
        },
      },
    });

    return this.customersOneTimeCodesRepository.create(
      customer_id,
      String(code),
    );
  }
}
export default CreateCustomerOneTimeCodeService;
