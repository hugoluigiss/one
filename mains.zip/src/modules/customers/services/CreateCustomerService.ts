/* eslint-disable no-nested-ternary */
import { inject, injectable } from 'tsyringe';
import { ApolloError } from 'apollo-server-express';
import IHashProvider from 'src/shared/container/providers/HashProvider/models/IHashProvider';
import Customer from '../infra/typeorm/entities/Customer';
import ICustomersRepository from '../repositories/ICustomersRepository';
import ICustomersDocumentsRepository from '../repositories/ICustomersDocumentsRepository';

interface IParams {
  birth_date: Date;
  email: string;
  full_name: string;
  password: string;
  type: 'PF' | 'PJ';
  nationality: string;
  document_value: string;
  fantasy_name?: string;
}

@injectable()
class CreateCustomerService {
  constructor(
    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,

    @inject('HashProvider')
    private hashProvider: IHashProvider,

    @inject('CustomersDocumentsRepository')
    private customerDocumentsRepository: ICustomersDocumentsRepository,
  ) {}

  public async execute({
    full_name,
    email,
    birth_date,
    password,
    type,
    nationality,
    document_value,
    fantasy_name,
  }: IParams): Promise<Customer> {
    const emailExists = await this.customersRepository.findByEmail(email);
    if (emailExists) throw new ApolloError('Email já cadastrado');

    const documentType =
      type === 'PJ' ? 'CNPJ' : nationality === 'BR' ? 'CPF' : 'PASSPORT';

    const documentExists =
      await this.customerDocumentsRepository.findByTypeAndValue(
        documentType,
        document_value,
      );
    if (documentExists) throw new ApolloError('Documento ja cadastrado');

    const password_hash = await this.hashProvider.generateHash(password);
    const customer = await this.customersRepository.create({
      birth_date,
      email,
      full_name,
      password_hash,
      type,
      fantasy_name,
    });

    return customer;
  }
}
export default CreateCustomerService;
