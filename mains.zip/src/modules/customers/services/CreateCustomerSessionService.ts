import { sign } from 'jsonwebtoken';
import { inject, injectable } from 'tsyringe';

import { ApolloError } from 'apollo-server-express';
import authConfig from '../../../config/auth';

import IHashProvider from '../../../shared/container/providers/HashProvider/models/IHashProvider';
import ICustomersRepository from '../repositories/ICustomersRepository';
import Customer from '../infra/typeorm/entities/Customer';
import ICacheProvider from '../../../shared/container/providers/CacheProvider/models/ICacheProvider';

interface IRequest {
  email: string;
  password: string;
}

interface IResponse {
  user: Customer;
  token: string;
}

@injectable()
class CreateCustomerSessionService {
  constructor(
    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,

    @inject('HashProvider')
    private hashProvider: IHashProvider,

    @inject('CacheProvider')
    private cacheProvider: ICacheProvider,
  ) {}

  public async execute({ email, password }: IRequest): Promise<IResponse> {
    const user = await this.customersRepository.findByEmail(email);

    if (!user) {
      throw new ApolloError('E-mail ou senha incorretos');
    }

    const passwordMatched = await this.hashProvider.compareHash(
      password,
      user.password_hash,
    );

    if (!passwordMatched) {
      throw new ApolloError('E-mail ou senha incorretos');
    }

    const { secret, expiresIn } = authConfig.jwt;

    const token = sign({ subject: user.id }, secret, {
      expiresIn,
    });

    const key = `user_logged:${user.id}`;
    await this.cacheProvider.save(key, { date: new Date() }, 10);

    return { user, token };
  }
}

export default CreateCustomerSessionService;
