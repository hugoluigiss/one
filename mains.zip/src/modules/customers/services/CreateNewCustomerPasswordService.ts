import ICacheProvider from '../../../shared/container/providers/CacheProvider/models/ICacheProvider';
import { ApolloError } from 'apollo-server-express';
import { injectable, inject } from 'tsyringe';
import IHashProvider from '../../../shared/container/providers/HashProvider/models/IHashProvider';

import ICustomersRepository from '../repositories/ICustomersRepository';

interface IParams {
  token: string;
  new_password: string;
}
@injectable()
class CreateNewCustomerPasswordService {
  constructor(
    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,

    @inject('CacheProvider')
    private cacheProvider: ICacheProvider,

    @inject('HashProvider')
    private hashProvider: IHashProvider,
  ) {}

  public async execute({ token, new_password }: IParams): Promise<string> {
    const email = await this.cacheProvider.recover<string>(
      `forgot_password_token:${token}`,
    );
    if (!email) throw new ApolloError('Token inválido ou expirado');

    const user = await this.customersRepository.findByEmail(email);

    if (!user) throw new ApolloError('Usuário não encontrado');

    user.password_hash = await this.hashProvider.generateHash(new_password);

    await this.customersRepository.save(user);

    await this.cacheProvider.invalidate(`forgot_password_token:${token}`);

    return 'success';
  }
}
export default CreateNewCustomerPasswordService;
