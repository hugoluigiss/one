import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import { sign } from 'jsonwebtoken';
import authConfig from '../../../config/auth';
import ICustomersAssociationsRepository from '../repositories/ICustomersAssociationsRepository';
import Customer from '../infra/typeorm/entities/Customer';
import ICustomersRepository from '../repositories/ICustomersRepository';
import ICacheProvider from '../../../shared/container/providers/CacheProvider/models/ICacheProvider';

interface IParams {
  customer_id: string;
  to_customer_id: string;
  customer_pf_id?: string;
}

interface IResponse {
  customer: Customer;
  token: string;
}

@injectable()
class CreateSwitchAccountService {
  constructor(
    @inject('CustomersAssociationsRepository')
    private customersAssociationsRepository: ICustomersAssociationsRepository,

    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,

    @inject('CacheProvider')
    private cacheProvider: ICacheProvider,
  ) {}

  public async execute({
    customer_id,
    to_customer_id,
    customer_pf_id,
  }: IParams): Promise<IResponse> {
    const customer = await this.customersRepository.findById(customer_id);
    if (!customer) throw new ApolloError('Usuário não encontrado');

    const { secret, expiresIn } = authConfig.jwt;

    if (customer.type === 'PF') {
      const associations =
        await this.customersAssociationsRepository.findAssociationsByCustomerPfId(
          customer_id,
        );

      const customerAssociation = associations.find(
        a => a.customer_pj_id === to_customer_id,
      );
      if (!customerAssociation)
        throw new ApolloError('Usuário não tem acesso a conta');

      const { customer_pj } = customerAssociation;

      const token = sign(
        { subject: customer_pj.id, customer_pf_id: customer_id },
        secret,
        {
          expiresIn,
        },
      );

      const key = `user_logged:${customer_pj.id}`;
      await this.cacheProvider.save(key, { date: new Date() }, 1);

      return { customer: customer_pj, token };
    }

    if (to_customer_id !== customer_pf_id || !customer_pf_id)
      throw new ApolloError('Acesso negado');

    const customer_pf = await this.customersRepository.findById(customer_pf_id);
    if (!customer_pf) throw new ApolloError('Conta não encontrada');

    const token = sign({ subject: customer_pf.id }, secret, {
      expiresIn,
    });

    const key = `user_logged:${customer_pf.id}`;
    await this.cacheProvider.save(key, { date: new Date() }, 1);

    return { customer: customer_pf, token };
  }
}
export default CreateSwitchAccountService;
