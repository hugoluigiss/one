import { ApolloError } from 'apollo-server-express';
import { totp } from 'speakeasy';
import { inject, injectable } from 'tsyringe';
import CustomerTwoFa from '../infra/typeorm/entities/CustomerTwoFa';
import ICustomersTwoFaRepository from '../repositories/ICustomersTwoFaRepository';

interface IParams {
  customer_id: string;
  secret: string;
  token: string;
}

@injectable()
class CreateTwoFaService {
  constructor(
    @inject('CustomersTwoFaRepository')
    private customersTwoFaRepository: ICustomersTwoFaRepository,
  ) {}

  public async execute({
    customer_id,
    token,
    secret,
  }: IParams): Promise<CustomerTwoFa> {
    const turnOnTwoFactorAuthentication = totp.verify({
      secret,
      encoding: 'base32',
      token,
    });
    if (!turnOnTwoFactorAuthentication)
      throw new ApolloError('Código inválido');

    const alredyHas = await this.customersTwoFaRepository.findByCustomerId(
      customer_id,
    );
    if (alredyHas) {
      alredyHas.secret = secret;
      return this.customersTwoFaRepository.save(alredyHas);
    }

    const customerTwoFa = await this.customersTwoFaRepository.create({
      secret,
      customer_id,
    });

    return customerTwoFa;
  }
}
export default CreateTwoFaService;
