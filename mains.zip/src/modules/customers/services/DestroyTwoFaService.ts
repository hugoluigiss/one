import { inject, injectable } from 'tsyringe';
import ICustomersTwoFaRepository from '../repositories/ICustomersTwoFaRepository';

interface IParams {
  customer_id: string;
}

@injectable()
class DestroyTwoFaService {
  constructor(
    @inject('CustomersTwoFaRepository')
    private customersTwoFaRepository: ICustomersTwoFaRepository,
  ) {}

  public async execute({ customer_id }: IParams): Promise<void> {
    const alredyHas = await this.customersTwoFaRepository.findByCustomerId(
      customer_id,
    );
    if (alredyHas) await this.customersTwoFaRepository.destroy(alredyHas);
  }
}
export default DestroyTwoFaService;
