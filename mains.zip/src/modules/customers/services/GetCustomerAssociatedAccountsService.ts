import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import Customer from '../infra/typeorm/entities/Customer';
import ICustomersAssociationsRepository from '../repositories/ICustomersAssociationsRepository';
import ICustomersRepository from '../repositories/ICustomersRepository';

@injectable()
class GetCustomerAssociatedAccountsService {
  constructor(
    @inject('CustomersAssociationsRepository')
    private customersAssociationsRepository: ICustomersAssociationsRepository,

    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,
  ) {}

  public async execute(
    customer_id: string,
    customer_pf_id?: string,
  ): Promise<Customer[]> {
    if (customer_pf_id) {
      const customer = await this.customersRepository.findById(customer_pf_id);
      if (!customer) throw new ApolloError('Conta PF associada não encontrada');
      return [customer];
    }

    const associations =
      await this.customersAssociationsRepository.findAssociationsByCustomerPfId(
        customer_id,
      );

    if (associations.length === 0) return [];

    return associations.map(association => association.customer_pj);
  }
}
export default GetCustomerAssociatedAccountsService;
