import { inject, injectable } from 'tsyringe';
import CustomerDocumentCopy from '../infra/typeorm/entities/CustomerDocumentCopy';
import ICustomersDocumentsCopiesRepository from '../repositories/ICustomersDocumentsCopiesRepository';
import ICustomersDocumentsRepository from '../repositories/ICustomersDocumentsRepository';

interface IParams {
  customer_id: string;
}

@injectable()
class GetCustomerDocumentsCopiesService {
  constructor(
    @inject('CustomersDocumentsRepository')
    private customersDocumentsRepository: ICustomersDocumentsRepository,

    @inject('CustomersDocumentsCopiesRepository')
    private customersDocumentsCopiesRepository: ICustomersDocumentsCopiesRepository,
  ) {}

  public async execute({
    customer_id,
  }: IParams): Promise<CustomerDocumentCopy[]> {
    const document = await this.customersDocumentsRepository.findByCustomerId(
      customer_id,
    );

    if (!document) return [];

    const copies =
      await this.customersDocumentsCopiesRepository.findByCustomerId(
        customer_id,
      );

    const documentType = document.type;

    if (documentType === 'CNPJ') {
      let cnpjCopy = copies.find(copy => copy.type === 'cnpj');
      if (!cnpjCopy)
        cnpjCopy = await this.customersDocumentsCopiesRepository.create({
          name: 'Cópia do cartão CNPJ',
          description: 'Envie uma cópia do cartao CNPJ da empresa',
          customer_id,
          type: 'cnpj',
        });

      let contractCopy = copies.find(copy => copy.type === 'social_contract');
      if (!contractCopy)
        contractCopy = await this.customersDocumentsCopiesRepository.create({
          name: 'Cópia do Contrato social',
          description: 'Envie uma cópia do contrato social da empresa',
          customer_id,
          type: 'social_contract',
        });

      cnpjCopy.document = document;
      contractCopy.document = document;

      return [cnpjCopy, contractCopy];
    }

    if (documentType === 'CPF') {
      let cpfCopy = copies.find(copy => copy.type === 'cpf');
      if (!cpfCopy)
        cpfCopy = await this.customersDocumentsCopiesRepository.create({
          name: 'Documento de identificação com CPF',
          description: 'Envie uma imagem do documento de identificação com CPF',
          customer_id,
          type: 'cpf',
        });

      let selfieCopy = copies.find(copy => copy.type === 'selfie');
      if (!selfieCopy)
        selfieCopy = await this.customersDocumentsCopiesRepository.create({
          name: 'Selfie com documento de identificação',
          description:
            'Envie uma selfie segurando seu documento de identificação',
          customer_id,
          type: 'selfie',
        });

      cpfCopy.document = document;
      selfieCopy.document = document;

      return [cpfCopy, selfieCopy];
    }

    if (documentType === 'PASSPORT') {
      let passportCopy = copies.find(copy => copy.type === 'passport');
      if (!passportCopy)
        passportCopy = await this.customersDocumentsCopiesRepository.create({
          name: 'Passaporte',
          description: 'Envie uma imagem do do seu passaporte',
          customer_id,
          type: 'passport',
        });

      let selfieCopy = copies.find(copy => copy.type === 'selfie');
      if (!selfieCopy)
        selfieCopy = await this.customersDocumentsCopiesRepository.create({
          name: 'Selfie com documento de identificação',
          description: 'Envie uma selfie segurando seu passaporte',
          customer_id,
          type: 'selfie',
        });

      passportCopy.document = document;
      selfieCopy.document = document;

      return [passportCopy, selfieCopy];
    }

    return [];
  }
}
export default GetCustomerDocumentsCopiesService;
