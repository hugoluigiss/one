import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import Customer from '../infra/typeorm/entities/Customer';
import ICustomersRepository from '../repositories/ICustomersRepository';

interface IParams {
  customer_id: string;
}

@injectable()
class GetCustomerProfileService {
  constructor(
    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,
  ) {}

  public async execute({ customer_id }: IParams): Promise<Customer> {
    const customer = await this.customersRepository.findById(customer_id);
    if (!customer) throw new ApolloError('Usuário não encontrado');
    return customer;
  }
}
export default GetCustomerProfileService;
