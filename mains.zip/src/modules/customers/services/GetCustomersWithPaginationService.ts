import { inject, injectable } from 'tsyringe';
import IFindCustomersWithPaginationResponseDTO from '../dtos/IFindCustomersWithPaginationResponseDTO';
import ICustomersRepository from '../repositories/ICustomersRepository';

interface IParams {
  limit?: number;
  offset?: number;
  order?: 'ASC' | 'DESC';
}

@injectable()
class GetCustomersWithPaginationService {
  constructor(
    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,
  ) {}

  public async execute({
    limit,
    offset,
    order,
  }: IParams): Promise<IFindCustomersWithPaginationResponseDTO> {
    const { count, customers } =
      await this.customersRepository.findWithPagination({
        limit,
        offset,
        order,
      });

    return { customers, count };
  }
}
export default GetCustomersWithPaginationService;
