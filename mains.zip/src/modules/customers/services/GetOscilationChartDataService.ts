import { inject, injectable } from 'tsyringe';
import ICryptoUtilsProvider from '../../../shared/container/providers/CryptoUtilsProvider/models/ICryptoUtilsProvider';
import ICacheProvider from '../../../shared/container/providers/CacheProvider/models/ICacheProvider';

interface IParams {
  interval: 'hour' | 'day';
  value: number;
  coin_symbol: 'BTC' | 'ETH' | 'BNB' | 'USDT';
}

@injectable()
class GetOscilationChartDataService {
  constructor(
    @inject('CryptoUtilsProvider')
    private cryptoUtilsProvider: ICryptoUtilsProvider,

    @inject('CacheProvider')
    private cacheProvider: ICacheProvider,
  ) {}

  public async execute({
    coin_symbol,
    interval,
    value,
  }: IParams): Promise<string> {
    const key = `coins-oscilation:${coin_symbol}-${interval}-${value}`;

    const cachedData = await this.cacheProvider.recover<string>(key);

    if (cachedData) return cachedData;

    const data = await this.cryptoUtilsProvider.getOscilationChartData(
      interval,
      value,
      coin_symbol,
    );

    await this.cacheProvider.save(key, data, 30);
    return data;
  }
}
export default GetOscilationChartDataService;
