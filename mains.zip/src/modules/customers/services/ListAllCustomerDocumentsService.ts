import { inject, injectable } from 'tsyringe';
import IFindAllDocumentsCopiesResponseDTO from '../dtos/IFindAllDocumentsCopiesResponseDTO';
import ICustomersDocumentsRepository from '../repositories/ICustomersDocumentsRepository';

interface IParams {
  limit?: number;
  offset?: number;
  customer_id?: string;
  has_complience?: boolean;
}

@injectable()
class ListAllCustomerDocumentsService {
  constructor(
    @inject('CustomersDocumentsRepository')
    private customerDocumentsRepository: ICustomersDocumentsRepository,
  ) {}

  public async execute({
    offset,
    customer_id,
    limit,
    has_complience,
  }: IParams): Promise<IFindAllDocumentsCopiesResponseDTO> {
    const { count, documents } = await this.customerDocumentsRepository.findAll(
      {
        order: { field: 'created_at', order: 'ASC' },
        filter: { has_complience, customer_id },
        pagination: { limit, offset },
      },
    );
    return { count, documents };
  }
}
export default ListAllCustomerDocumentsService;
