import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import CustomerDocumentCopy from '../infra/typeorm/entities/CustomerDocumentCopy';
import ICustomersDocumentsCopiesRepository from '../repositories/ICustomersDocumentsCopiesRepository';
import ICustomersDocumentsRepository from '../repositories/ICustomersDocumentsRepository';

interface IParams {
  document_copy_id: string;
  admin_answear: string;
}

@injectable()
class ReproveCustomerDocumentCopyService {
  constructor(
    @inject('CustomersDocumentsCopiesRepository')
    private customersDocumentsCopiesRepository: ICustomersDocumentsCopiesRepository,

    @inject('CustomersDocumentsRepository')
    private customersDocumentsRepository: ICustomersDocumentsRepository,
  ) {}

  public async execute({
    document_copy_id,
    admin_answear,
  }: IParams): Promise<CustomerDocumentCopy> {
    const copy = await this.customersDocumentsCopiesRepository.findById(
      document_copy_id,
    );
    if (!copy) throw new ApolloError('Documento não encontrado');

    copy.status = 'rejected';
    copy.admin_answear = admin_answear;
    await this.customersDocumentsCopiesRepository.save(copy);

    const document = await this.customersDocumentsRepository.findByCustomerId(
      copy.customer_id,
    );
    if (!document) throw new ApolloError('Documento não encontrado');
    document.has_complience = false;
    await this.customersDocumentsRepository.save(document);

    return copy;
  }
}
export default ReproveCustomerDocumentCopyService;
