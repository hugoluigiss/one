import { ApolloError } from 'apollo-server-express';
import path from 'path';
import { injectable, inject } from 'tsyringe';
import { v4 } from 'uuid';
import mailConfig from '../../../config/mail';

import ICacheProvider from '../../../shared/container/providers/CacheProvider/models/ICacheProvider';
import IMailProvider from '../../../shared/container/providers/MailProvider/models/IMailProvider';
import ICustomersRepository from '../repositories/ICustomersRepository';

interface IParams {
  email: string;
}

@injectable()
class SendEmailConfirmationTokenService {
  constructor(
    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,

    @inject('CacheProvider')
    private cacheProvider: ICacheProvider,

    @inject('MailProvider')
    private mailProvider: IMailProvider,
  ) {}

  public async execute({ email }: IParams): Promise<void> {
    const emailAlreadyExists = await this.customersRepository.findByEmail(
      email,
    );
    if (emailAlreadyExists) throw new ApolloError('E-mail ja cadastrado');

    let token = await this.cacheProvider.recover<string>(
      `confirmation_token:${email}`,
    );
    if (!token) {
      token = v4();
      await this.cacheProvider.save(`confirmation_token:${email}`, token, 120);
    }

    const template = path.resolve(
      mailConfig.templatesFolder,
      'confirm_account.hbs',
    );

    await this.mailProvider.sendMail({
      to: {
        name: 'no-reply',
        email,
      },
      subject: '[exchange] Confirmação de e-mail',
      templateData: {
        file: template,
        variables: {
          token,
        },
      },
    });
  }
}
export default SendEmailConfirmationTokenService;
