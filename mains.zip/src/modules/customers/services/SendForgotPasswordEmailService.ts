import { ApolloError } from 'apollo-server-express';
import path from 'path';
import { injectable, inject } from 'tsyringe';
import { v4 } from 'uuid';
import authConfig from '../../../config/app';
import mailConfig from '../../../config/mail';

import ICacheProvider from '../../../shared/container/providers/CacheProvider/models/ICacheProvider'
import IMailProvider from '../../../shared/container/providers/MailProvider/models/IMailProvider';


import ICustomersRepository from '../repositories/ICustomersRepository';

interface IParams {
  email: string;
}

@injectable()
class SendForgotPasswordEmailService {
  constructor(
    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,

    @inject('CacheProvider')
    private cacheProvider: ICacheProvider,

    @inject('MailProvider')
    private mailProvider: IMailProvider,
  ) {}

  public async execute({ email }: IParams): Promise<void> {
    const customer = await this.customersRepository.findByEmail(email);
    if (!customer) throw new ApolloError('E-mail não encontrado');

    const token = v4();

    await this.cacheProvider.save(`forgot_password_token:${token}`, email, 120);

    const template = path.resolve(
      mailConfig.templatesFolder,
      'forgot_password.hbs',
    );

    await this.mailProvider.sendMail({
      to: {
        name: customer.full_name,
        email: customer.email,
      },
      subject: '[exchange] Recuperação de senha',
      templateData: {
        file: template,
        variables: {
          name: customer.full_name,
          link: `${authConfig.frontend.host}/reset-password/${token}`,
        },
      },
    });
  }
}
export default SendForgotPasswordEmailService;
