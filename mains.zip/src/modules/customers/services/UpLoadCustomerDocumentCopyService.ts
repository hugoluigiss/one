import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import IStorageProvider from '../../../shared/container/providers/StorageProvider/models/IStorageProvider';
import ICustomersDocumentsCopiesRepository from '../repositories/ICustomersDocumentsCopiesRepository';

interface IParams {
  customer_id: string;
  document_copy_id: string;
  file_name: string;
}

@injectable()
class UpLoadCustomerDocumentCopyService {
  constructor(
    @inject('CustomersDocumentsCopiesRepository')
    private customersDocumentsCopiesRepository: ICustomersDocumentsCopiesRepository,

    @inject('StorageProvider')
    private storageProvider: IStorageProvider,
  ) {}

  public async execute({
    document_copy_id,
    file_name,
    customer_id,
  }: IParams): Promise<void> {
    const documentCopy = await this.customersDocumentsCopiesRepository.findById(
      document_copy_id,
    );
    if (!documentCopy) throw new ApolloError('Documento não encontrado');

    if (documentCopy.status === 'approved')
      throw new ApolloError('Documento aprovado, não é possível alterar');

    if (documentCopy.customer_id !== customer_id)
      throw new ApolloError(
        'Não é possível alterar documento de outro cliente',
      );

    const filename = await this.storageProvider.saveFile(file_name);

    // console.log({ filename });

    if (documentCopy.file_name)
      this.storageProvider.deleteFile(documentCopy.file_name);

    documentCopy.file_name = filename;
    documentCopy.status = 'pending';

    await this.customersDocumentsCopiesRepository.save(documentCopy);
  }
}
export default UpLoadCustomerDocumentCopyService;
