import { ApolloError } from 'apollo-server-express';
import { injectable, inject } from 'tsyringe';
import IHashProvider from '../../../shared/container/providers/HashProvider/models/IHashProvider';

import ICustomersRepository from '../repositories/ICustomersRepository';

interface IParams {
  current_password: string;
  new_password: string;
  customer_id: string;
}
@injectable()
class UpdateCustomerPasswordService {
  constructor(
    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,

    @inject('HashProvider')
    private hashProvider: IHashProvider,
  ) {}

  public async execute({
    current_password,
    new_password,
    customer_id,
  }: IParams): Promise<string> {
    const customer = await this.customersRepository.findById(customer_id);

    if (!customer) throw new ApolloError('Usuário não encontrado');

    const passwordMatched = await this.hashProvider.compareHash(
      current_password,
      customer.password_hash,
    );

    if (!passwordMatched) {
      throw new ApolloError('Senha atual incorreta');
    }

    customer.password_hash = await this.hashProvider.generateHash(new_password);

    await this.customersRepository.save(customer);

    return 'success';
  }
}
export default UpdateCustomerPasswordService;
