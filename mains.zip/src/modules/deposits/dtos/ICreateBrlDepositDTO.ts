export default interface ICreateBrlDepositDTO {
  file_name: string;
  transaction_id: string;
}
