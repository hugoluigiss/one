export default interface IFindAllParamsDTO {
  filter?: {
    customer_id?: string;
    status?: string;
  };
  pagination?: {
    offset?: number;
    limit?: number;
  };
  order: {
    field: 'created_at';
    order: 'ASC' | 'DESC';
  };
}
