import BrlDeposit from '../infra/typeorm/entities/BrlDeposit';

export default interface IFindAllResponseDTO {
  deposits: BrlDeposit[];
  count: number;
}
