import { Field, ObjectType } from 'type-graphql';
import Bank from '../../../../banks/infra/typeorm/entities/Bank';

@ObjectType()
class DepositAccount {
  @Field(() => Bank)
  bank: Bank;

  @Field()
  agency: string;

  @Field()
  account: string;

  @Field()
  pix: string;

  @Field()
  owner: string;
}
export default DepositAccount;
