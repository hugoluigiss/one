import { getRepository, Repository } from 'typeorm';
import ICreateBrlDepositDTO from '../../../dtos/ICreateBrlDepositDTO';
import IFindAllParamsDTO from '../../../dtos/IFindAllParamsDTO';
import IFindAllResponseDTO from '../../../dtos/IFindAllResponseDTO';
import IBrlDepositsRepository from '../../../repositories/IBrlDepositsRepository';
import BrlDeposit from '../entities/BrlDeposit';

class BrlDepositsRepository implements IBrlDepositsRepository {
  private ormRepository: Repository<BrlDeposit>;

  constructor() {
    this.ormRepository = getRepository(BrlDeposit);
  }

  public findById(id: string): Promise<BrlDeposit | undefined> {
    return this.ormRepository.findOne(id);
  }

  public async findByTransactionId(
    transaction_id: string,
  ): Promise<BrlDeposit | undefined> {
    return this.ormRepository.findOne({ where: { transaction_id } });
  }

  public async create({
    file_name,
    transaction_id,
  }: ICreateBrlDepositDTO): Promise<BrlDeposit> {
    const deposit = this.ormRepository.create({ file_name, transaction_id });
    await this.ormRepository.save(deposit);
    return deposit;
  }

  public async save(deposit: BrlDeposit): Promise<BrlDeposit> {
    return this.ormRepository.save(deposit);
  }

  public async findAndCountAll({
    order,
    filter,
    pagination,
  }: IFindAllParamsDTO): Promise<IFindAllResponseDTO> {
    const builder = this.ormRepository
      .createQueryBuilder('brl_deposits')
      .leftJoinAndSelect('brl_deposits.transaction', 'transaction')
      .leftJoinAndSelect('transaction.coin', 'coin')
      .leftJoinAndSelect('transaction.customer', 'customer')
      .orderBy(`brl_deposits.${order.field}`, order.order);

    if (filter) {
      if (filter.customer_id)
        builder.where('transaction.customer_id = :customer_id', {
          customer_id: filter.customer_id,
        });

      if (filter.status)
        builder.andWhere('transaction.status = :status', {
          status: filter.status,
        });
    }

    const count = await builder.getCount();

    if (pagination && pagination.limit) {
      builder.limit(pagination.limit);
      builder.offset(pagination.limit * (pagination.offset || 0));
    }

    const deposits = await builder.getMany();

    return { count, deposits };
  }
}
export default BrlDepositsRepository;
