import { container } from 'tsyringe';
import BrlDepositsRepository from '../infra/typeorm/repositories/BrlDepositsRepository';
import IBrlDepositsRepository from '../repositories/IBrlDepositsRepository';

container.registerSingleton<IBrlDepositsRepository>(
  'BrlDepositsRepository',
  BrlDepositsRepository,
);
