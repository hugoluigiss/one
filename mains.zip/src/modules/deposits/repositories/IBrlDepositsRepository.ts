import ICreateBrlDepositDTO from '../dtos/ICreateBrlDepositDTO';
import IFindAllParamsDTO from '../dtos/IFindAllParamsDTO';
import IFindAllResponseDTO from '../dtos/IFindAllResponseDTO';
import BrlDeposit from '../infra/typeorm/entities/BrlDeposit';

export default interface IBrlDepositsRepository {
  create(data: ICreateBrlDepositDTO): Promise<BrlDeposit>;
  save(deposit: BrlDeposit): Promise<BrlDeposit>;
  findByTransactionId(transaction_id: string): Promise<BrlDeposit | undefined>;
  findAndCountAll(data: IFindAllParamsDTO): Promise<IFindAllResponseDTO>;
  findById(id: string): Promise<BrlDeposit | undefined>;
}
