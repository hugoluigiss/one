import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import ICoinsTransactionsRepository from '../../coins/repositories/ICoinsTransactionsRepository';
import BrlDeposit from '../infra/typeorm/entities/BrlDeposit';
import IBrlDepositsRepository from '../repositories/IBrlDepositsRepository';

interface IParams {
  deposit_id: string;
}

@injectable()
class ConfirmBrlDepositService {
  constructor(
    @inject('BrlDepositsRepository')
    private brlDepositsRepository: IBrlDepositsRepository,

    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,
  ) {}

  public async execute({ deposit_id }: IParams): Promise<BrlDeposit> {
    const deposit = await this.brlDepositsRepository.findById(deposit_id);

    if (!deposit) throw new ApolloError('Depósito não encontrado');

    deposit.transaction.status = 'confirmed';

    await this.coinsTransactionsRepository.save(deposit.transaction);

    return deposit;
  }
}
export default ConfirmBrlDepositService;
