import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import IStorageProvider from '../../../shared/container/providers/StorageProvider/models/IStorageProvider';
import BrlDeposit from '../infra/typeorm/entities/BrlDeposit';
import IBrlDepositsRepository from '../repositories/IBrlDepositsRepository';

interface IParams {
  file_name: string;
  transaction_id: string;
}

@injectable()
class CreateBrlDepositService {
  constructor(
    @inject('BrlDepositsRepository')
    private brlDepositsRepository: IBrlDepositsRepository,

    @inject('StorageProvider')
    private storageProvider: IStorageProvider,
  ) {}

  public async execute({
    transaction_id,
    file_name,
  }: IParams): Promise<BrlDeposit> {
    const alreadyExists = await this.brlDepositsRepository.findByTransactionId(
      transaction_id,
    );
    if (alreadyExists)
      throw new ApolloError('Ja existe um depósito associado a esta transação');

    const filename = await this.storageProvider.saveFile(file_name);

    const deposit = await this.brlDepositsRepository.create({
      file_name: filename,
      transaction_id,
    });
    return deposit;
  }
}
export default CreateBrlDepositService;
