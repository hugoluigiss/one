import { inject, injectable } from 'tsyringe';
import BrlDeposit from '../infra/typeorm/entities/BrlDeposit';
import IBrlDepositsRepository from '../repositories/IBrlDepositsRepository';

interface IParams {
  limit?: number;
  offset?: number;
  customer_id?: string;
  status?: string;
}

interface IResponse {
  deposits: BrlDeposit[];
  count: number;
}

@injectable()
class ListAllCustomerBrlDepositsService {
  constructor(
    @inject('BrlDepositsRepository')
    private brlDepositsRepository: IBrlDepositsRepository,
  ) {}

  public async execute({
    limit,
    offset,
    customer_id,
    status,
  }: IParams): Promise<IResponse> {
    const { count, deposits } =
      await this.brlDepositsRepository.findAndCountAll({
        order: { field: 'created_at', order: 'ASC' },
        filter: {
          customer_id,
          status,
        },
        pagination: {
          limit,
          offset,
        },
      });

    return { count, deposits };
  }
}
export default ListAllCustomerBrlDepositsService;
