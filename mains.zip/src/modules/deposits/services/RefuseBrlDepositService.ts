import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import ICoinsTransactionsRepository from '../../coins/repositories/ICoinsTransactionsRepository';
import BrlDeposit from '../infra/typeorm/entities/BrlDeposit';
import IBrlDepositsRepository from '../repositories/IBrlDepositsRepository';

interface IParams {
  deposit_id: string;
}

@injectable()
class RefuseBrlDepositService {
  constructor(
    @inject('BrlDepositsRepository')
    private brlDepositsRepository: IBrlDepositsRepository,

    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,
  ) {}

  public async execute({ deposit_id }: IParams): Promise<BrlDeposit> {
    const deposit = await this.brlDepositsRepository.findById(deposit_id);

    if (!deposit) throw new ApolloError('Depósito não encontrado');

    if (deposit.transaction.status !== 'pending')
      throw new ApolloError(
        'Não é possivel rejeitar um depósito que não esteja pendente',
      );

    deposit.transaction.status = 'refused';

    await this.coinsTransactionsRepository.save(deposit.transaction);

    return deposit;
  }
}
export default RefuseBrlDepositService;
