import { ApolloError } from 'apollo-server-express';
import { CoinsType } from 'src/modules/coins/infra/typeorm/entities/Coin';
import { inject, injectable } from 'tsyringe';
import ICacheProvider from '../../../shared/container/providers/CacheProvider/models/ICacheProvider';
import ICryptoProvider from '../../../shared/container/providers/CryptoProvider/models/ICryptoProvider';

interface IParams {
  coin_symbol: CoinsType;
}

@injectable()
class GetNetworkFeeService {
  constructor(
    @inject('BitcoinProvider')
    private bitcoinProvider: ICryptoProvider,

    @inject('EthereumProvider')
    private ethereumProvider: ICryptoProvider,

    @inject('BnbProvider')
    private bnbProvider: ICryptoProvider,

    @inject('CacheProvider')
    private cacheProvider: ICacheProvider,
  ) {}

  public async execute({ coin_symbol }: IParams): Promise<string> {
    const key = `network_fee:${coin_symbol}`;
    let network_fee = await this.cacheProvider.recover<string>(key);

    if (!network_fee) {
      switch (coin_symbol) {
        case 'BTC':
          network_fee = await this.bitcoinProvider.getNetworkFee();
          break;
        case 'ETH':
          network_fee = await this.ethereumProvider.getNetworkFee();
          break;

        case 'BNB':
          network_fee = await this.bnbProvider.getNetworkFee();
          break;

        case 'USDT':
          network_fee = await this.bnbProvider.getNetworkFee();
          break;
        case 'BRL':
          network_fee = '0';
          break;
        // case 'XRP':
        //   network_fee = await this.rippleProvider.getNetworkFee();

        //   break;
        default:
          throw new ApolloError(
            `Taxa de rede não encontrada para ${coin_symbol}`,
          );
      }
      await this.cacheProvider.save(key, network_fee, 1);
    }

    return network_fee;
  }
}
export default GetNetworkFeeService;
