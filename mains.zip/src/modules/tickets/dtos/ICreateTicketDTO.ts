export default interface ICreateTicketDTO {
  customer_id: string;
  message: string;
  subject: string;
  file_name?: string;
  category: 'financial' | 'support' | 'marketing';
}
