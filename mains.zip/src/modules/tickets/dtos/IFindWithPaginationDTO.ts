export default interface IFindWithPaginationDTO {
  limit?: number;
  offset?: number;
  customer_id?: string;
  status?: 'open' | 'closed';
  category?: 'financial' | 'support' | 'marketing';
}
