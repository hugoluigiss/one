import Ticket from '../infra/typeorm/entities/Ticket';

export default interface IFindWithPaginationResponseDTO {
  count: number;
  tickets: Ticket[];
}
