import { Field, ObjectType } from 'type-graphql';
import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import upload from '../../../../../config/upload';
import app from '../../../../../config/app';

@ObjectType()
@Entity('tickets')
class Ticket {
  @Field()
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  customer_id: string;

  @Field()
  @Column()
  category: 'financial' | 'support' | 'marketing';

  @Field()
  @Column()
  message: string;

  @Field()
  @Column()
  status: 'open' | 'closed';

  @Field({ nullable: true })
  @Column()
  admin_answear?: string;

  @Column({ nullable: true })
  file_name?: string;

  @Field(() => String, { nullable: true })
  get file_url(): string | undefined {
    if (this.file_name)
      return upload.driver === 's3'
        ? `https://${upload.config.aws.bucket}.s3.${upload.config.aws.region}.amazonaws.com/${this.file_name}`
        : `${app.backend.host}/files/${this.file_name}`;

    return this.file_name;
  }

  @Field()
  @Column()
  subject: string;

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;
}
export default Ticket;
