import ICreateTicketDTO from 'src/modules/tickets/dtos/ICreateTicketDTO';
import IFindWithPaginationDTO from 'src/modules/tickets/dtos/IFindWithPaginationDTO';
import IFindWithPaginationResponseDTO from 'src/modules/tickets/dtos/IFindWithPaginationResponseDTO';
import ITicketsRepository from 'src/modules/tickets/repositories/ITicketsRepository';
import { getRepository, Repository } from 'typeorm';
import Ticket from '../entities/Ticket';

class TicketsRepository implements ITicketsRepository {
  private ormRepository: Repository<Ticket>;

  constructor() {
    this.ormRepository = getRepository(Ticket);
  }

  public async findWithPagination({
    status,
    category,
    offset,
    limit,
    customer_id,
  }: IFindWithPaginationDTO): Promise<IFindWithPaginationResponseDTO> {
    const query = this.ormRepository.createQueryBuilder('tickets');
    if (status) query.andWhere('tickets.status = :status', { status });
    if (category) query.andWhere('tickets.category = :category', { category });
    if (customer_id)
      query.andWhere('tickets.customer_id = :customer_id', { customer_id });

    const count = await query.getCount();

    if (limit) {
      query.limit(limit);
      if (offset) query.offset(limit * offset);
    }
    const tickets = await query.getMany();

    return { count, tickets };
  }

  public async create({
    customer_id,
    category,
    message,
    subject,
    file_name,
  }: ICreateTicketDTO): Promise<Ticket> {
    const ticket = this.ormRepository.create({
      customer_id,
      category,
      message,
      subject,
      file_name,
      status: 'open',
    });
    await this.ormRepository.save(ticket);
    return ticket;
  }
}

export default TicketsRepository;
