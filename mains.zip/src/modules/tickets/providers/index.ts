import { container } from 'tsyringe';
import TicketsRepository from '../infra/typeorm/repositories/TicketsRepository';
import ITicketsRepository from '../repositories/ITicketsRepository';

container.registerSingleton<ITicketsRepository>(
  'TicketsRepository',
  TicketsRepository,
);
