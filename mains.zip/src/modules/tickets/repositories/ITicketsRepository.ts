import ICreateTicketDTO from '../dtos/ICreateTicketDTO';
import IFindWithPaginationDTO from '../dtos/IFindWithPaginationDTO';
import IFindWithPaginationResponseDTO from '../dtos/IFindWithPaginationResponseDTO';
import Ticket from '../infra/typeorm/entities/Ticket';

export default interface ITicketsRepository {
  create(data: ICreateTicketDTO): Promise<Ticket>;
  findWithPagination(
    data: IFindWithPaginationDTO,
  ): Promise<IFindWithPaginationResponseDTO>;
}
