import { inject, injectable } from 'tsyringe';
import Ticket from '../infra/typeorm/entities/Ticket';
import ITicketsRepository from '../repositories/ITicketsRepository';
import IStorageProvider from '../../../shared/container/providers/StorageProvider/models/IStorageProvider';

interface IParams {
  customer_id: string;
  message: string;
  subject: string;
  file_name?: string;
  category: 'financial' | 'support' | 'marketing';
}

@injectable()
class CreateTicketService {
  constructor(
    @inject('TicketsRepository')
    private ticketsRepository: ITicketsRepository,

    @inject('StorageProvider')
    private storageProvider: IStorageProvider,
  ) {}

  public async execute({
    message,
    subject,
    file_name,
    customer_id,
    category,
  }: IParams): Promise<Ticket> {
    if (file_name) await this.storageProvider.saveFile(file_name);

    const ticket = await this.ticketsRepository.create({
      category,
      customer_id,
      file_name,
      subject,
      message,
    });

    return ticket;
  }
}
export default CreateTicketService;
