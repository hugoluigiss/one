import { inject, injectable } from 'tsyringe';
import IFindWithPaginationResponseDTO from '../dtos/IFindWithPaginationResponseDTO';
import ITicketsRepository from '../repositories/ITicketsRepository';

interface IParams {
  limit?: number;
  offset?: number;
  customer_id?: string;
  status?: 'open' | 'closed';
  category?: 'financial' | 'support' | 'marketing';
}

@injectable()
class GetCustomerTicketsService {
  constructor(
    @inject('TicketsRepository')
    private ticketsRepository: ITicketsRepository,
  ) {}

  public async execute({
    customer_id,
    status,
    offset,
    limit,
    category,
  }: IParams): Promise<IFindWithPaginationResponseDTO> {
    const { count, tickets } = await this.ticketsRepository.findWithPagination({
      category,
      limit,
      offset,
      status,
      customer_id,
    });
    return { count, tickets };
  }
}
export default GetCustomerTicketsService;
