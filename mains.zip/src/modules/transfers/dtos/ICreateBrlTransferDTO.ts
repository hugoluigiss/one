export default interface ICreateBrlTransferDTO {
  sender_transaction_id: string;

  receiver_transaction_id: string;
}
