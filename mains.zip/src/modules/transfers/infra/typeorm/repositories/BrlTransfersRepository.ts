import { getRepository, Repository } from 'typeorm';
import ICreateBrlTransferDTO from '../../../dtos/ICreateBrlTransferDTO';
import IBrlTransfersRepository from '../../../repositories/IBrlTransfersRepository';
import BrlTransfer from '../entities/BrlTransfer';

class BrlTransfersRepository implements IBrlTransfersRepository {
  private ormRepository: Repository<BrlTransfer>;

  constructor() {
    this.ormRepository = getRepository(BrlTransfer);
  }

  public async create({
    receiver_transaction_id,
    sender_transaction_id,
  }: ICreateBrlTransferDTO): Promise<BrlTransfer> {
    const transfer = this.ormRepository.create({
      receiver_transaction_id,
      sender_transaction_id,
    });

    await this.ormRepository.save(transfer);

    return transfer;
  }

  save(transfer: BrlTransfer): Promise<BrlTransfer> {
    return this.ormRepository.save(transfer);
  }
}

export default BrlTransfersRepository;
