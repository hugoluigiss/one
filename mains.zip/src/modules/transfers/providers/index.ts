import { container } from 'tsyringe';
import BrlTransfersRepository from '../infra/typeorm/repositories/BrlTransfersRepository';
import IBrlTransfersRepository from '../repositories/IBrlTransfersRepository';

container.registerSingleton<IBrlTransfersRepository>(
  'BrlTransfersRepository',
  BrlTransfersRepository,
);
