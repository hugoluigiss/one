import ICreateBrlTransferDTO from '../dtos/ICreateBrlTransferDTO';
import BrlTransfer from '../infra/typeorm/entities/BrlTransfer';

export default interface IBrlTransfersRepository {
  create(data: ICreateBrlTransferDTO): Promise<BrlTransfer>;
  save(transfer: BrlTransfer): Promise<BrlTransfer>;
}
