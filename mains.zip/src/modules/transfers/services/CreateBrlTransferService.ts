import { inject, injectable } from 'tsyringe';
import BrlTransfer from '../infra/typeorm/entities/BrlTransfer';
import IBrlTransfersRepository from '../repositories/IBrlTransfersRepository';

interface IParams {
  sender_transaction_id: string;
  receiver_transaction_id: string;
}

@injectable()
class CreateBrlTransferService {
  constructor(
    @inject('BrlTransfersRepository')
    private brlTransfersRepository: IBrlTransfersRepository,
  ) {}

  public async execute({
    sender_transaction_id,
    receiver_transaction_id,
  }: IParams): Promise<BrlTransfer> {
    return this.brlTransfersRepository.create({
      sender_transaction_id,
      receiver_transaction_id,
    });
  }
}
export default CreateBrlTransferService;
