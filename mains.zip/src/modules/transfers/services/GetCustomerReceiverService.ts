import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import Customer from '../../customers/infra/typeorm/entities/Customer';
import ICustomersRepository from '../../customers/repositories/ICustomersRepository';

interface IParams {
  email_to: string;
  customer_id: string;
}

interface IResponse {
  receiver: Customer;
  sender: Customer;
}

@injectable()
class GetCustomerReceiverService {
  constructor(
    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,
  ) {}

  public async execute({ customer_id, email_to }: IParams): Promise<IResponse> {
    const receiver = await this.customersRepository.findByEmail(email_to);
    if (!receiver) throw new ApolloError('Email não encontrado');
    if (receiver.id === customer_id)
      throw new ApolloError('Não é possível fazer transferência para si mesmo');

    const sender = await this.customersRepository.findById(customer_id);
    if (!sender) throw new ApolloError('Remetente não encontrado');

    return { receiver, sender };
  }
}
export default GetCustomerReceiverService;
