export default interface ICreateBrlWithdrawalDTO {
  transaction_id: string;
  bank_account_id: string;
}
