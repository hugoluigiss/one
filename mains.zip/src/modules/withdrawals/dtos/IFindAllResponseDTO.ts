import BrlWithdrawal from '../infra/typeorm/entities/BrlWaithdrawal';

export default interface IFindAllResponseDTO {
  deposits: BrlWithdrawal[];
  count: number;
}
