import { Field, ObjectType } from 'type-graphql';
import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  OneToOne,
  JoinColumn,
} from 'typeorm';

import upload from '../../../../../config/upload';
import app from '../../../../../config/app';
import CoinTransaction from '../../../../coins/infra/typeorm/entities/CoinTransaction';
import CustomerBankAccount from '../../../../banks/infra/typeorm/entities/CustomerBankAccount';

@ObjectType()
@Entity('brl_withdrawals')
class BrlWithdrawal {
  @Field()
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  file_name?: string;

  @Column()
  bank_account_id: string;

  @Field(() => CustomerBankAccount)
  @OneToOne(() => CustomerBankAccount, { eager: true })
  @JoinColumn({ name: 'bank_account_id' })
  bank_account: CustomerBankAccount;

  @Column()
  transaction_id: string;

  @Field(() => CoinTransaction)
  @OneToOne(() => CoinTransaction, transaction => transaction.brl_withdrawal, {
    eager: true,
  })
  @JoinColumn({ name: 'transaction_id' })
  transaction: CoinTransaction;

  @Field(() => String, { nullable: true })
  get file_url(): string | undefined {
    if (this.file_name)
      return upload.driver === 's3'
        ? `https://${upload.config.aws.bucket}.s3.${upload.config.aws.region}.amazonaws.com/${this.file_name}`
        : `${app.backend.host}/files/${this.file_name}`;

    return this.file_name;
  }

  @Field({ nullable: true })
  @Column()
  admin_comment?: string;

  @Field()
  @CreateDateColumn()
  created_at: Date;

  @Field()
  @UpdateDateColumn()
  updated_at: Date;
}
export default BrlWithdrawal;
