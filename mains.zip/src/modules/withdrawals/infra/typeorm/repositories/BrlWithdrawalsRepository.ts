import { getRepository, Repository } from 'typeorm';
import ICreateBrlWithdrawalDTO from '../../../dtos/ICreateBrlWithdrawalDTO';
import IFindAllParamsDTO from '../../../dtos/IFindAllParamsDTO';
import IFindAllResponseDTO from '../../../dtos/IFindAllResponseDTO';
import IBrlWithdrawalsRepository from '../../../repositories/IBrlWithdrawalsRepository';
import BrlWithdrawal from '../entities/BrlWaithdrawal';

class BrlWithdrawalsRepository implements IBrlWithdrawalsRepository {
  private ormRepository: Repository<BrlWithdrawal>;

  constructor() {
    this.ormRepository = getRepository(BrlWithdrawal);
  }

  public async create({
    transaction_id,
    bank_account_id,
  }: ICreateBrlWithdrawalDTO): Promise<BrlWithdrawal> {
    const withdrawal = this.ormRepository.create({
      transaction_id,
      bank_account_id,
    });
    await this.ormRepository.save(withdrawal);
    return withdrawal;
  }

  public async save(withdrawal: BrlWithdrawal): Promise<BrlWithdrawal> {
    return this.ormRepository.save(withdrawal);
  }

  public async findAndCountAll({
    order,
    filter,
    pagination,
  }: IFindAllParamsDTO): Promise<IFindAllResponseDTO> {
    const builder = this.ormRepository
      .createQueryBuilder('brl_withdrawals')
      .leftJoinAndSelect('brl_withdrawals.transaction', 'transaction')
      .leftJoinAndSelect('brl_withdrawals.bank_account', 'bank_account')
      .leftJoinAndSelect('bank_account.bank', 'bank')
      .leftJoinAndSelect('transaction.coin', 'coin')
      .leftJoinAndSelect('transaction.customer', 'customer')
      .orderBy(`brl_withdrawals.${order.field}`, order.order);

    if (filter) {
      if (filter.customer_id)
        builder.where('transaction.customer_id = :customer_id', {
          customer_id: filter.customer_id,
        });

      if (filter.status)
        builder.andWhere('transaction.status = :status', {
          status: filter.status,
        });
    }

    const count = await builder.getCount();

    if (pagination && pagination.limit) {
      builder.limit(pagination.limit);
      builder.offset(pagination.limit * (pagination.offset || 0));
    }

    const deposits = await builder.getMany();

    return { count, deposits };
  }

  public async findById(id: string): Promise<BrlWithdrawal | undefined> {
    return this.ormRepository.findOne(id);
  }
}

export default BrlWithdrawalsRepository;
