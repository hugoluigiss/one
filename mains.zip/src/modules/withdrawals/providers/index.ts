import { container } from 'tsyringe';
import BrlWithdrawalsRepository from '../infra/typeorm/repositories/BrlWithdrawalsRepository';
import IBrlWithdrawalsRepository from '../repositories/IBrlWithdrawalsRepository';

container.registerSingleton<IBrlWithdrawalsRepository>(
  'BrlWithdrawalsRepository',
  BrlWithdrawalsRepository,
);
