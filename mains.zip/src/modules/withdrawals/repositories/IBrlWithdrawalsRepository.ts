import ICreateBrlWithdrawalDTO from '../dtos/ICreateBrlWithdrawalDTO';
import IFindAllResponseDTO from '../dtos/IFindAllResponseDTO';
import IFindAllParamsDTO from '../dtos/IFindAllParamsDTO';
import BrlWithdrawal from '../infra/typeorm/entities/BrlWaithdrawal';

export default interface IBrlWithdrawalsRepository {
  create(data: ICreateBrlWithdrawalDTO): Promise<BrlWithdrawal>;
  save(withdrawal: BrlWithdrawal): Promise<BrlWithdrawal>;
  findAndCountAll(data: IFindAllParamsDTO): Promise<IFindAllResponseDTO>;
  findById(id: string): Promise<BrlWithdrawal | undefined>;
}
