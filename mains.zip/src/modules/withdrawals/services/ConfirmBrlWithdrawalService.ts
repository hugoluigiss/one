import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import ICoinsTransactionsRepository from '../../coins/repositories/ICoinsTransactionsRepository';
import IStorageProvider from '../../../shared/container/providers/StorageProvider/models/IStorageProvider';
import BrlWithdrawal from '../infra/typeorm/entities/BrlWaithdrawal';
import IBrlWithdrawalsRepository from '../repositories/IBrlWithdrawalsRepository';

interface IParams {
  withdrawal_id: string;
  file_name?: string;
}

@injectable()
class ConfirmBrlWithdrawalService {
  constructor(
    @inject('BrlWithdrawalsRepository')
    private brlWithdrawalsRepository: IBrlWithdrawalsRepository,

    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,

    @inject('StorageProvider')
    private storageProvider: IStorageProvider,
  ) {}

  public async execute({
    withdrawal_id,
    file_name,
  }: IParams): Promise<BrlWithdrawal> {
    const withdrawal = await this.brlWithdrawalsRepository.findById(
      withdrawal_id,
    );
    if (!withdrawal) throw new ApolloError('Saque não encontrado');

    withdrawal.transaction.status = 'confirmed';
    await this.coinsTransactionsRepository.save(withdrawal.transaction);

    if (file_name) {
      await this.storageProvider.saveFile(file_name);
      withdrawal.file_name = file_name;
      await this.brlWithdrawalsRepository.save(withdrawal);
    }

    return withdrawal;
  }
}
export default ConfirmBrlWithdrawalService;
