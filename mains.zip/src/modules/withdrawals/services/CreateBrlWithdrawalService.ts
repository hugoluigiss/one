import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import ICustomersBanksAccountsRepository from '../../banks/repositories/ICustomersBanksAccountsRepository';
import BrlWithdrawal from '../infra/typeorm/entities/BrlWaithdrawal';
import IBrlWithdrawalsRepository from '../repositories/IBrlWithdrawalsRepository';

interface IParams {
  transaction_id: string;
  bank_account_id: string;
}

@injectable()
class CreateBrlWithdrawalService {
  constructor(
    @inject('BrlWithdrawalsRepository')
    private brlWithdrawalsRepository: IBrlWithdrawalsRepository,

    @inject('CustomersBanksAccountsRepository')
    private customersBanksAccountsRepository: ICustomersBanksAccountsRepository,
  ) {}

  public async execute({
    transaction_id,
    bank_account_id,
  }: IParams): Promise<BrlWithdrawal> {
    const bankAccount = await this.customersBanksAccountsRepository.findById(
      bank_account_id,
    );
    if (!bankAccount) throw new ApolloError('Conta bancária não encontrada');

    const withdrawal = await this.brlWithdrawalsRepository.create({
      transaction_id,
      bank_account_id,
    });

    return withdrawal;
  }
}
export default CreateBrlWithdrawalService;
