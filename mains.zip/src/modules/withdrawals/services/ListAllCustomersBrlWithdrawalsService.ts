import { inject, injectable } from 'tsyringe';
import BrlWithdrawal from '../infra/typeorm/entities/BrlWaithdrawal';
import IBrlWithdrawalsRepository from '../repositories/IBrlWithdrawalsRepository';

interface IParams {
  limit?: number;
  offset?: number;
  customer_id?: string;
  status?: string;
}

interface IResponse {
  deposits: BrlWithdrawal[];
  count: number;
}

@injectable()
class ListAllCustomersBrlWithdrawalsService {
  constructor(
    @inject('BrlWithdrawalsRepository')
    private brlWithdrawalsRepository: IBrlWithdrawalsRepository,
  ) {}

  public async execute({
    limit,
    offset,
    customer_id,
    status,
  }: IParams): Promise<IResponse> {
    const { count, deposits } =
      await this.brlWithdrawalsRepository.findAndCountAll({
        order: { field: 'created_at', order: 'ASC' },
        filter: {
          customer_id,
          status,
        },
        pagination: {
          limit,
          offset,
        },
      });

    return { count, deposits };
  }
}
export default ListAllCustomersBrlWithdrawalsService;
