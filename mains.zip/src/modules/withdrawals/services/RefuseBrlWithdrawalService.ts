import { ApolloError } from 'apollo-server-express';
import { inject, injectable } from 'tsyringe';
import ICoinsTransactionsRepository from '../../coins/repositories/ICoinsTransactionsRepository';
import BrlWithdrawal from '../infra/typeorm/entities/BrlWaithdrawal';
import IBrlWithdrawalsRepository from '../repositories/IBrlWithdrawalsRepository';

interface IParams {
  withdrawal_id: string;
  comment?: string;
}

@injectable()
class RefuseBrlWithdrawalService {
  constructor(
    @inject('BrlWithdrawalsRepository')
    private brlWithdrawalsRepository: IBrlWithdrawalsRepository,

    @inject('CoinsTransactionsRepository')
    private coinsTransactionsRepository: ICoinsTransactionsRepository,
  ) {}

  public async execute({
    withdrawal_id,
    comment,
  }: IParams): Promise<BrlWithdrawal> {
    const withdrawal = await this.brlWithdrawalsRepository.findById(
      withdrawal_id,
    );
    if (!withdrawal) throw new ApolloError('Saque não encontrado');

    if (withdrawal.transaction.status !== 'pending')
      throw new ApolloError(
        'não é possivel recusar um saque que não esta pendente',
      );

    withdrawal.transaction.status = 'refused';
    await this.coinsTransactionsRepository.save(withdrawal.transaction);

    if (comment) {
      withdrawal.admin_comment = comment;
      await this.brlWithdrawalsRepository.save(withdrawal);
    }

    return withdrawal;
  }
}
export default RefuseBrlWithdrawalService;
