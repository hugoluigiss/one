export default interface IPaymentNotification {
  engine_result?: string;
  transaction?: {
    Amount?: string;
    DestinationTag?: number;
    Destination?: string;
    TransactionType?: string;
    hash?: string;
  };
  validated: boolean;
}
