import { inject, injectable } from 'tsyringe';
import IQueue from '../../../shared/container/providers/QueueProvider/models/IQueue';
import { IRipllePaymentNotificationParams } from '../../../shared/container/providers/QueueProvider/implementations/RipplePaymentNotificationQueue';

@injectable()
class EnqueueXRPNotificationsService {
  constructor(
    @inject('RipplePaymentNotificationQueue')
    private ripplePaymentNotificationQueue: IQueue,
  ) {}

  public async execute(
    paymentNotification: IRipllePaymentNotificationParams,
  ): Promise<void> {
    await this.ripplePaymentNotificationQueue.add(paymentNotification);
  }
}
export default EnqueueXRPNotificationsService;
