import { inject, injectable } from 'tsyringe';
// import BigNumber from 'bignumber.js';
// import ICoinsTransactionsRepository from '../../coins/repositories/ICoinsTransactionsRepository';
import ICryptoCoinsTransactionsRepository from '../../coins/repositories/ICryptoCoinsTransactionsRepository';
import ICustomersCoinsWalletsRepository from '../../coins/repositories/ICustomersCoinsWalletsRepository';
// import ICoinsRepository from '../../coins/repositories/ICoinsRepository';
import xrpConfig from '../../../config/xrp';
import { IRipllePaymentNotificationParams } from '../../../shared/container/providers/QueueProvider/implementations/RipplePaymentNotificationQueue';

@injectable()
class ProcessXrpPaymentsService {
  constructor(
    @inject('CustomersCoinsWalletsRepository')
    private customersCoinsWalletsRepository: ICustomersCoinsWalletsRepository,

    @inject('CryptoCoinsTransactionsRepository')
    private cryptoCoinsTransactionsRepository: ICryptoCoinsTransactionsRepository, // @inject('CoinsTransactionsRepository') // private coinsTransactionsRepository: ICoinsTransactionsRepository, // @inject('CoinsRepository') // private coinsRepository: ICoinsRepository,
  ) {}

  public async execute({
    validated,
    engine_result,
    transaction,
  }: IRipllePaymentNotificationParams): Promise<string> {
    if (!validated || engine_result !== 'tesSUCCESS' || !transaction)
      return 'not_a_payment';

    const { Amount, Destination, DestinationTag, TransactionType, hash } =
      transaction;

    if (!Amount || !Destination || !DestinationTag || !TransactionType || !hash)
      return 'not_a_payment';

    if (Destination !== xrpConfig.address) return 'not_a_payment_wallet';
    if (TransactionType !== 'Payment') return 'not_a_payment_transaction';

    const customerWallet =
      await this.customersCoinsWalletsRepository.findByIndex(DestinationTag);

    if (!customerWallet) return 'not_a_customer_payment_transaction';

    const alreadyExists =
      await this.cryptoCoinsTransactionsRepository.findCryptoTransaction({
        address_to: xrpConfig.address,
        txid: hash,
        type: 'deposit',
      });
    if (alreadyExists) return 'payment_already_exists';

    // const xrp = await this.coinsRepository.findBySymbol('XRP');
    // if (!xrp) throw new Error('Erro inesperado, moeda xrp não encontrada');

    // const xrpValue = new BigNumber(Amount).dividedBy('1000000').toString();

    // const coinTransaction = await this.coinsTransactionsRepository.create({
    //   coin_id: xrp.id,
    //   customer_id: customerWallet.customer_id,
    //   description: 'Depósito em XRP',
    //   fee_value: '0',
    //   net_value: xrpValue,
    //   status: 'confirmed',
    //   total_value: xrpValue,
    //   type: 'input',
    //   operation: 'deposit',
    // });
    // await this.cryptoCoinsTransactionsRepository.create({
    //   address_to: xrpConfig.address,
    //   type: 'deposit',
    //   txid: hash,
    //   transaction_id: coinTransaction.id,
    //   confirmations: 1,
    // });

    return 'success';
  }
}
export default ProcessXrpPaymentsService;
