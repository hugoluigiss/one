/* eslint-disable max-classes-per-file */
import { Field, ObjectType } from 'type-graphql';

@ObjectType()
class BinanceCoin {
  @Field()
  coin: string;

  @Field()
  free: string;

  @Field()
  freeze: string;

  @Field()
  name: string;
}

export default BinanceCoin;
