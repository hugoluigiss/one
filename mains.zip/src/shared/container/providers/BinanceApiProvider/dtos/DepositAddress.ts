import { Field, ObjectType } from 'type-graphql';

@ObjectType()
class DepositAddress {
  @Field()
  address: string;

  @Field()
  coin: string;

  @Field()
  tag: string;

  @Field()
  url: string;
}

export default DepositAddress;
