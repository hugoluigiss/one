/* eslint-disable max-classes-per-file */
import { Field, ObjectType } from 'type-graphql';

@ObjectType()
class SymbolPrice {
  @Field()
  symbol: string;

  @Field()
  price: string;
}

export default SymbolPrice;
