import axios from 'axios';
import crypto from 'crypto';
import binancewallet from '../../../../../config/binancewallet';

import BinanceCoin from '../dtos/BinanceCoin';
import DepositAddress from '../dtos/DepositAddress';
import SymbolPrice from '../dtos/SymbolPrice';
import IBinanceWallet from '../models/IBinanceWallet';

class BinanceWallet implements IBinanceWallet {
  private async makePrivateRequest<T>({
    method,
    endpoint,
    params = {},
  }: {
    endpoint: string;
    method: 'GET' | 'POST';
    params?: {
      [key: string]: string | number;
    };
  }): Promise<T> {
    let query = Object.keys(params).reduce((acc, key, index) => {
      return index === 0
        ? `${key}=${params[key]}&`
        : `${acc}${key}=${params[key]}&`;
    }, '');
    const timestamp = Number(new Date().getTime()).toFixed(0);
    query += `timestamp=${timestamp}`;
    const signature = crypto
      .createHmac('sha256', binancewallet.api_secret)
      .update(query)
      .digest('hex');

    try {
      const response = await axios.request<T>({
        method,
        headers: { 'X-MBX-APIKEY': binancewallet.api_key },
        url: `${binancewallet.url}${endpoint}`,
        params: { ...params, timestamp, signature },
      });

      return response.data;
    } catch (err) {
      throw new Error(`BINANCE API ERROR - ${err.response?.data?.msg}`);
    }
  }

  private async makeRequest<T>({
    method,
    endpoint,
    params = {},
  }: {
    endpoint: string;
    method: 'GET';
    params?: {
      [key: string]: string | number;
    };
  }): Promise<T> {
    try {
      const response = await axios.request<T>({
        method,
        headers: { 'X-MBX-APIKEY': binancewallet.api_key },
        url: `${binancewallet.url}${endpoint}`,
        params: { ...params },
      });

      return response.data;
    } catch (err) {
      throw new Error(`BINANCE API ERROR - ${err.response?.data?.msg}`);
    }
  }

  public async getAllCoins(): Promise<BinanceCoin[]> {
    return this.makePrivateRequest<BinanceCoin[]>({
      method: `GET`,
      endpoint: '/sapi/v1/capital/config/getall',
    });
  }

  public async getSymbolPrice(symbol: string): Promise<SymbolPrice> {
    return this.makeRequest<SymbolPrice>({
      method: `GET`,
      endpoint: '/api/v3/ticker/price',
      params: { symbol },
    });
  }

  public async createOrder(params: {
    [key: string]: string | number;
  }): Promise<void> {
    await this.makePrivateRequest({
      endpoint: '/api/v3/order',
      method: 'POST',
      params,
    });
  }

  public async getDepositAddress({
    coin,
  }: {
    coin: string;
  }): Promise<DepositAddress> {
    return this.makePrivateRequest<DepositAddress>({
      method: 'GET',
      endpoint: '/sapi/v1/capital/deposit/address',
      params: { coin },
    });
  }

  public async createWithdraw(params: {
    [key: string]: string | number;
  }): Promise<{ id: string }> {
    return this.makePrivateRequest<{ id: string }>({
      endpoint: '/sapi/v1/capital/withdraw/apply',
      method: 'POST',
      params,
    });
  }
}

export default BinanceWallet;
