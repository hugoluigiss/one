/* eslint-disable no-console */
import 'dotenv/config';
// import BinanceWallet from './BinanceWallet';

// new BinanceWallet()
//   .createWithdraw({
//     coin: 'ETH',
//     address: '0x38549143a45d85aa3c12ee9049a923365d393cdc',
//     addressTag: '',
//     amount: 0.0041958,
//   })
//   .then(r => console.log(r));
