import { container } from 'tsyringe';
import BinanceWallet from './implementations/BinanceWallet';
import IBinanceWallet from './models/IBinanceWallet';

container.registerSingleton<IBinanceWallet>('BinanceWallet', BinanceWallet);
