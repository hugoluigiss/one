import BinanceCoin from '../dtos/BinanceCoin';
import DepositAddress from '../dtos/DepositAddress';
import SymbolPrice from '../dtos/SymbolPrice';

export default interface IBinanceWallet {
  getAllCoins(): Promise<BinanceCoin[]>;
  getSymbolPrice(symbol: string): Promise<SymbolPrice>;
  createOrder(params: { [key: string]: string | number }): Promise<void>;
  getDepositAddress({ coin }: { coin: string }): Promise<DepositAddress>;
  createWithdraw(params: {
    [key: string]: string | number;
  }): Promise<{ id: string }>;
}
