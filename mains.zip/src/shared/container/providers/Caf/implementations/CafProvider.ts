/* eslint-disable no-console */
import CafDocument from 'src/modules/caf/infra/typeorm/entities/CafDocument';
import axios from 'axios';

import ICafProvider from '../models/ICafProvider';

import cafConfig from '../../../../../config/caf';

export interface ISendDocumentDataResponse {
  report: string;
  execution: string;
}

export interface IGetDocumentDataResponse {
  status: 'EM ANÁLISE' | 'PENDENTE' | 'APROVADO' | 'REPROVADO' | 'PROCESSANDO';
  fraud: boolean;
  data: {
    birthDate: string;
    cpf: string;
    name: string;
  };
}

class CafProvider implements ICafProvider {
  private accessToken: string | undefined;

  constructor() {
    this.accessToken = cafConfig.token;
  }

  public async sendDocument(
    document: CafDocument,
  ): Promise<ISendDocumentDataResponse | undefined> {
    try {
      const response = await axios.post<ISendDocumentDataResponse>(
        `https://api.combateafraude.com/execute/${cafConfig.report}?token=${this.accessToken}`,
        {
          type: document.type,
          front: document.front_url,
          back: document.back_url,
          selfie: document.selfie_url,
          parameters: {
            cpf: document.cpf,
            returnUrl: `https://lab.api.b4.exchange/caf`,
          },
        },
      );
      return response.data;
    } catch (e) {
      console.log(e.response.data);
      return undefined;
    }
  }

  public async getDocumentStatus(
    document: CafDocument,
  ): Promise<IGetDocumentDataResponse | undefined> {
    try {
      const response = await axios.get<IGetDocumentDataResponse>(
        `https://api.combateafraude.com/reports/${document.report}/executions/${document.execution}?token=${this.accessToken}`,
      );
      // axios
      //   .get(
      //     `https://api.combateafraude.com/executions?token=${this.accessToken}`,
      //   )
      //   .then(res => console.log(res.data));

      return response.data;
    } catch (e) {
      console.log(e);
      return undefined;
    }
  }
}

export default CafProvider;
