import { container } from 'tsyringe';
import ICafProvider from './models/ICafProvider';

import CafProvider from './implementations/CafProvider';

const cafProvider = new CafProvider();

container.registerInstance<ICafProvider>('CafProvider', cafProvider);
