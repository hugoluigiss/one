import CafDocument from '../../../../../modules/caf/infra/typeorm/entities/CafDocument';
import {
  ISendDocumentDataResponse,
  IGetDocumentDataResponse,
} from '../implementations/CafProvider';

export default interface ICafProvider {
  sendDocument(
    document: CafDocument,
  ): Promise<ISendDocumentDataResponse | undefined>;
  getDocumentStatus(
    document: CafDocument,
  ): Promise<IGetDocumentDataResponse | undefined>;
}
