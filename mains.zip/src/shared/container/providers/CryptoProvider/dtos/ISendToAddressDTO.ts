export default interface ISendToAddressDTO {
  address: string;
  dest_flag?: string;
  amount: string;
  subtract_fee_from_amount: boolean;
}
