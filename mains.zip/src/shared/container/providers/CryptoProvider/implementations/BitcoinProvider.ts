import BitcoinServer, { Server } from 'bitcoin-core';
import bitcoinConfig from '../../../../../config/bitcoin';
import ICryptoProvider from '../models/ICryptoProvider';
import ISendManyDTO from '../dtos/ISendManyDTO';

class BitcoinProvider implements ICryptoProvider {
  private client: Server;

  constructor() {
    const { connection } = bitcoinConfig;
    this.client = new BitcoinServer(connection);
  }

  public async getBalance(): Promise<string> {
    const balance = await this.client.getBalance();
    return String(balance);
  }

  public async getAllTransactionsByBlockNumber<T>(): Promise<T> {
    throw new Error('Não implementado para btc');
  }

  public async getBlock<T>(block_hash: string): Promise<T> {
    const block = await this.client.getBlock(block_hash);
    return block as unknown as T;
  }

  public async getCurrentBlockNumber(): Promise<number> {
    throw new Error('Não implementado para btc');
  }

  public async getTransactionByTxid<T>(txid: string): Promise<T> {
    const transaction = await this.client.getTransaction(txid);
    return transaction as unknown as T;
  }

  public async getNetworkFee(): Promise<string> {
    const { feerate } = await this.client.estimateSmartFee(1, 'ECONOMICAL');

    return String((feerate || 0) * 0.5);
  }

  public async sendToAddress(): Promise<string> {
    throw new Error('Não implementado para btc');
  }

  public async createNewAddress(): Promise<string> {
    return this.client.getNewAddress();
  }

  public async sendMany({
    amounts,
    minConf = 1,
    comment = '',
    subtractFeeFrom,
    replaceable = false,
    confTarget = 1,
    estimateMode = 'ECONOMICAL',
  }: ISendManyDTO): Promise<string> {
    const txid = await this.client.sendMany(
      '',
      amounts,
      minConf,
      comment,
      subtractFeeFrom,
      replaceable,
      confTarget,
      estimateMode,
    );

    return txid;
  }
}
export default BitcoinProvider;
