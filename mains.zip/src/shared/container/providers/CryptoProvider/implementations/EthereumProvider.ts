import Web3 from 'web3';
import axios from 'axios';
import { mnemonicToSeedSync } from 'bip39';
import { hdkey } from 'ethereumjs-wallet';
import { TxData, Transaction } from 'ethereumjs-tx';
import BigNumber from 'bignumber.js';
import ethereumConfig from '../../../../../config/ethereum';
import ICryptoProvider from '../models/ICryptoProvider';
import ISendToAddressDTO from '../dtos/ISendToAddressDTO';

class EthereumProvider implements ICryptoProvider {
  private client: Web3;

  constructor() {
    const url = ethereumConfig.host;
    this.client = new Web3(new Web3.providers.HttpProvider(url));
  }

  public async getBalance(address: string): Promise<string> {
    if (!address)
      throw new Error('Endereço obrigatório para saldo de carteira ETH');

    const url =
      ethereumConfig.chain === 'rinkeby'
        ? `https://api-rinkeby.etherscan.io/api?module=account&action=balance&address=${address}&tag=latest&apikey=${ethereumConfig.etherscan_api_key}`
        : `https://api.etherscan.io/api?module=account&action=balance&address=${address}&tag=latest&apikey=${ethereumConfig.etherscan_api_key}`;
    const response = await axios.get(url);
    const amount = response.data.result || 0.0;
    const eth = this.client.utils.fromWei(amount);

    // console.log({ getBalance: true, eth: { address, balance: amount } });

    return eth;
  }

  public async getAllTransactionsByBlockNumber<T>(
    blockNumber: number,
  ): Promise<T> {
    const url =
      ethereumConfig.chain === 'rinkeby'
        ? `https://api-rinkeby.etherscan.io/api?module=proxy&action=eth_getBlockByNumber&tag=0x${blockNumber.toString(
            16,
          )}&boolean=true&apikey=${ethereumConfig.etherscan_api_key}`
        : `https://api.etherscan.io/api?module=proxy&action=eth_getBlockByNumber&tag=0x${blockNumber.toString(
            16,
          )}&boolean=true&apikey=${ethereumConfig.etherscan_api_key}`;

    const response = await axios.get(url);
    const transactions = response.data.result
      ? response.data.result.transactions
      : [];

    return transactions.map((transaction: any) => ({
      ...transaction,
      eth_amount: this.client.utils.fromWei(transaction.value, 'ether'),
    })) as T;
  }

  public async getCurrentBlockNumber(): Promise<number> {
    return this.client.eth.getBlockNumber();
  }

  public async getTransactionByTxid<T>(): Promise<T> {
    // const transaction = await this.client.getTransaction(txid);
    return {} as unknown as T;
  }

  public async getBlock<T>(): Promise<T> {
    // const block = await this.client.getBlock(block_hash);
    return {} as unknown as T;
  }

  public async getNetworkFee(): Promise<string> {
    const weiGasPrice = await this.client.eth.getGasPrice();
    const gasLimit = this.client.utils.toBN(21000);
    const weiFee = gasLimit.mul(this.client.utils.toBN(weiGasPrice));
    const ethFee = this.client.utils.fromWei(weiFee, 'ether');
    return ethFee;
  }

  public async sendToAddress({
    address,
    amount,
    subtract_fee_from_amount,
  }: ISendToAddressDTO): Promise<string> {
    const mnemonic = ethereumConfig.secret_phrase;
    const hdwallet = hdkey.fromMasterSeed(mnemonicToSeedSync(mnemonic));
    const wallet_hdpath = ethereumConfig.hdpath;
    const wallet = hdwallet.derivePath(wallet_hdpath + String(0)).getWallet();
    const originAddress = wallet.getAddressString();

    const ethNetworkFee = await this.getNetworkFee();

    const ethToSend = subtract_fee_from_amount
      ? new BigNumber(amount).minus(ethNetworkFee).toFixed()
      : amount;

    const weiToSend = this.client.utils.toWei(ethToSend, 'ether');

    const txCount = await this.client.eth.getTransactionCount(originAddress);
    const weiNetworkFee = this.client.utils.toWei(ethNetworkFee, 'ether');
    const gasLimit = this.client.utils.toBN(21000);
    const gasPrice = this.client.utils.toBN(weiNetworkFee).div(gasLimit);

    const txObject = {
      nonce: this.client.utils.toHex(txCount),
      to: address,
      value: this.client.utils.toHex(weiToSend),
      gasLimit: this.client.utils.toHex(gasLimit),
      gasPrice: this.client.utils.toHex(gasPrice),
    } as TxData;

    const tx = new Transaction(txObject, { chain: ethereumConfig.chain });
    tx.sign(wallet.getPrivateKey());

    const serializedTransaction = tx.serialize();
    const raw = `0x${serializedTransaction.toString('hex')}`;

    const transaction = await this.client.eth.sendSignedTransaction(raw);

    return transaction.transactionHash;
  }

  public async sendMany(): Promise<string> {
    throw new Error('Não implementado para ETH');
  }

  public async createNewAddress(index: number): Promise<string> {
    const mnemonic = ethereumConfig.secret_phrase;
    const hdwallet = hdkey.fromMasterSeed(mnemonicToSeedSync(mnemonic));
    const wallet_hdpath = ethereumConfig.hdpath;
    const wallet = hdwallet
      .derivePath(wallet_hdpath + String(index))
      .getWallet();
    return wallet.getAddressString();
  }
}
export default EthereumProvider;
