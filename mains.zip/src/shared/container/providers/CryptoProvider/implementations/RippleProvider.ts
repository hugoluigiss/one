import { RippleAPI } from 'ripple-lib';
import WebSocket from 'ws';
import { container } from 'tsyringe';
import BigNumber from 'bignumber.js';
import EnqueueXRPNotificationsService from '../../../../../modules/xrp/services/EnqueueXRPNotificationsService';
import ICryptoProvider from '../models/ICryptoProvider';
import xrpConfig from '../../../../../config/xrp';
import IPaymentNotification from '../../../../../modules/xrp/dtos/IPaymentNotificationDTO';
import ISendToAddressDTO from '../dtos/ISendToAddressDTO';

class RippleProvider implements ICryptoProvider {
  private client: RippleAPI;

  private socket;

  constructor() {
    this.client = new RippleAPI({
      server: xrpConfig.host,
    });
    this.client.connect();
    this.socket = new WebSocket(xrpConfig.host);
    this.subscribeForPayments();
  }

  /**
   * {
  xAddress: 'X7iY5XwSHwXN3xeA3FFrxntipK9AKKZXvtP2FNa2bs2Q1nZ',
  secret: 'sp8fcLcr4nWDPZLL4JrYtiL2zfz7H',
  classicAddress: 'r3hMXQKaAiG6hwRcJeGLvzXsaPRKi7YLhU',
  address: 'r3hMXQKaAiG6hwRcJeGLvzXsaPRKi7YLhU'
}
   */

  // private async requireDestination(): Promise<void> {
  //   await this.client.connect();
  //   // const prepared = await this.client.prepareTransaction({
  //   //   TransactionType: 'AccountSet',
  //   //   Account: xrpConfig.address,
  //   //   SetFlag: 1, // RequireDest
  //   // });
  //   // console.log('Prepared transaction:', prepared.txJSON);
  //   // const max_ledger = prepared.instructions.maxLedgerVersion;
  //   // const signed = this.client.sign(prepared.txJSON, xrpConfig.secret);
  //   // console.log('Transaction hash:', signed.id);
  //   // const tx_id = signed.id;
  //   // const tx_blob = signed.signedTransaction;
  //   // const prelim_result = await this.client.request('submit', { tx_blob });
  //   // console.log('Preliminary result:', prelim_result);
  //   // const min_ledger = prelim_result.validated_ledger_index;

  //   // const account_info = await this.client.request('account_info', {
  //   //   account: xrpConfig.address,
  //   //   ledger_index: 'validated',
  //   // });
  //   // const flags = this.client.parseAccountFlags(
  //   //   account_info.account_data.Flags,
  //   // );
  //   // console.log(JSON.stringify(flags, null, 2));
  // }

  public async subscribeForPayments(): Promise<void> {
    this.socket.on('open', () => {
      this.socket.send(
        JSON.stringify({
          command: 'subscribe',
          accounts: [xrpConfig.address],
        }),
      );
    });
    this.socket.on('message', buffer => {
      const paymentNotification = JSON.parse(
        buffer.toString(),
      ) as IPaymentNotification;
      const enqueueXRPNotificationsService = container.resolve(
        EnqueueXRPNotificationsService,
      );
      enqueueXRPNotificationsService.execute(paymentNotification);
    });
  }

  public async createNewAddress(): Promise<string> {
    return xrpConfig.address;
  }

  public async getBalance(): Promise<string> {
    const balance = await this.client.getBalances(xrpConfig.address);

    const xrpBalance = balance.find(b => b.currency === `XRP`);
    if (!xrpBalance) return '0';
    return xrpBalance.value;
  }

  public async getAllTransactionsByBlockNumber<T>(): Promise<T> {
    throw new Error('Não implementado para xrp');
  }

  public async getBlock<T>(): Promise<T> {
    throw new Error('Não implementado para xrp');
  }

  public async getCurrentBlockNumber(): Promise<number> {
    throw new Error('Não implementado para xrp');
  }

  public async getTransactionByTxid<T>(): Promise<T> {
    throw new Error('Não implementado para xrp');
  }

  public async getNetworkFee(): Promise<string> {
    const server_info = await this.client.request('server_info');

    return String(
      server_info.info.load_factor *
        (server_info.info.validated_ledger?.base_fee_xrp || 0.00001),
    );
  }

  public async sendToAddress({
    address,
    amount,
    subtract_fee_from_amount,
    dest_flag,
  }: ISendToAddressDTO): Promise<string> {
    const network_fee = subtract_fee_from_amount
      ? await this.getNetworkFee()
      : '0';

    const net_value = new BigNumber(amount).minus(network_fee);

    const txObject = {
      TransactionType: 'Payment',
      Account: xrpConfig.address,
      Amount: this.client.xrpToDrops(net_value), // Same as "Amount": "22000000"
      Destination: address,
    };

    if (dest_flag)
      Object.assign(txObject, {
        DestinationTag: Number(dest_flag),
      });

    const preparedTx = await this.client.prepareTransaction(txObject, {
      // Expire this transaction if it doesn't execute within ~5 minutes:
      maxLedgerVersionOffset: 75,
    });
    const { maxLedgerVersion } = preparedTx.instructions;

    // Sign prepared instructions ------------------------------------------------
    const signed = this.client.sign(preparedTx.txJSON, xrpConfig.secret);
    const txID = signed.id;
    const tx_blob = signed.signedTransaction;

    // const earliestLedgerVersion = (await this.client.getLedgerVersion()) + 1;
    const result = await this.client.submit(tx_blob);
    console.log('Tentative result code:', result.resultCode);
    console.log('Tentative result message:', result.resultMessage);

    // Wait for validation -------------------------------------------------------
    let has_final_status = false;
    this.client.request('subscribe', { accounts: [address] });
    this.client.connection.on('transaction', event => {
      if (event.transaction.hash === txID) {
        console.log('Transaction has executed!', event);
        has_final_status = true;
      }
    });
    this.client.on('ledger', ledger => {
      if (ledger.ledgerVersion > (maxLedgerVersion || 0) && !has_final_status) {
        console.log('Ledger version', ledger.ledgerVersion, 'was validated.');
        console.log("If the transaction hasn't succeeded by now, it's expired");
        throw new Error(
          'If the transaction has not succeeded by now, it is expired',
        );
      }
    });

    // There are other ways to do this, but they're more complicated.
    // See https://xrpl.org/reliable-transaction-submission.html for details.
    while (!has_final_status) {
      // eslint-disable-next-line no-await-in-loop
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    return txID;
  }

  public async sendMany(): Promise<string> {
    throw new Error('Não implementado para xrp');
  }
}

export default RippleProvider;
