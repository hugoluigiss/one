import { container } from 'tsyringe';
import BitcoinProvider from './implementations/BitcoinProvider';
import EthereumProvider from './implementations/EthereumProvider';
import BnbProvider from './implementations/BnbProvider';
import RippleProvider from './implementations/RippleProvider';
import ICryptoProvider from './models/ICryptoProvider';

container.registerSingleton<ICryptoProvider>(
  'BitcoinProvider',
  BitcoinProvider,
);

container.registerSingleton<ICryptoProvider>(
  'EthereumProvider',
  EthereumProvider,
);

container.registerSingleton<ICryptoProvider>('BnbProvider', BnbProvider);

const rippleProvider = new RippleProvider();

container.registerInstance<ICryptoProvider>('RippleProvider', rippleProvider);
