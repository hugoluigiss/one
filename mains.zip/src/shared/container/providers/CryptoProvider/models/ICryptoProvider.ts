import ISendManyDTO from '../dtos/ISendManyDTO';
import ISendToAddressDTO from '../dtos/ISendToAddressDTO';

export default interface ICryptoProvider {
  createNewAddress(index?: number): Promise<string>;
  sendMany(data: ISendManyDTO): Promise<string>;
  sendToAddress(data: ISendToAddressDTO): Promise<string>;
  getNetworkFee(): Promise<string>;
  getTransactionByTxid<T>(txid: string): Promise<T>;
  getBlock<T>(block_hash: string): Promise<T>;
  getCurrentBlockNumber(): Promise<number>;
  getAllTransactionsByBlockNumber<T>(blockNumber: number): Promise<T>;
  getBalance(address?: string): Promise<string>;
}
