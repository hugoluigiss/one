export default interface ICheckCoinAddressDTO {
  coin_symbol: 'BTC' | 'ETH' | 'BNB' | 'USDT';
  address: string;
}
