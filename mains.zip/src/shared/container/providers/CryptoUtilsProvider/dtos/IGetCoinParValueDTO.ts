import { CoinsType } from 'src/modules/coins/infra/typeorm/entities/Coin';

export default interface IGetCoinParValueDTO {
  from: CoinsType;
  to: CoinsType;
}
