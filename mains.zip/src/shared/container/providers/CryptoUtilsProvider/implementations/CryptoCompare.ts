/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from 'axios';
import WAVvalidator from 'multicoin-address-validator';
import ethereumConfig from '../../../../../config/ethereum';
import IGetCoinParValueDTO from '../dtos/IGetCoinParValueDTO';
import ICryptoUtilsProvider from '../models/ICryptoUtilsProvider';
import ICheckCoinAddressDTO from '../dtos/ICheckCoinAddressDTO';

class CryptoCompare implements ICryptoUtilsProvider {
  private cryptocompareApikey: string;

  constructor() {
    this.cryptocompareApikey = ethereumConfig.crypto_compare_api_key;
  }

  public async checkValidAddress({
    address,
    coin_symbol,
  }: ICheckCoinAddressDTO): Promise<boolean> {
    return WAVvalidator.validate(address, coin_symbol.toLowerCase());
  }

  public async getCoinParValue({
    to,
    from,
  }: IGetCoinParValueDTO): Promise<string> {
    try {
      const response = await axios.get(
        `https://min-api.cryptocompare.com/data/price?fsym=${from}&tsyms=${to}&api_key=${this.cryptocompareApikey}`,
      );
      return String(response.data[to]);
    } catch {
      throw new Error('Erro na api CryptoCompare');
    }
  }

  public async getOscilationChartData(
    interval: 'hour' | 'day',
    value: number,
    coin_symbol: 'BTC' | 'ETH' | 'BNB',
  ): Promise<string> {
    try {
      const url = `https://min-api.cryptocompare.com/data/v2/histo${interval}?fsym=${coin_symbol}&tsym=BRL&limit=${value}&api_key=${this.cryptocompareApikey}`;

      const response = await axios.get(url);

      const variation =
        (response.data.Data.Data[response.data.Data.Data.length - 1].close /
          response.data.Data.Data[0].close -
          1.0) *
        100;

      const lastValue =
        response.data.Data.Data[response.data.Data.Data.length - 1].close;

      const high = Math.max(
        ...response.data.Data.Data.map((item: any) => item.high),
      );
      const low = Math.min(
        ...response.data.Data.Data.map((item: any) => item.low),
      );

      const chartData = response.data.Data.Data.map((item: any) => ({
        value: item.close,
        date: new Date(item.time * 1000),
      }));

      return JSON.stringify({ variation, chartData, lastValue, high, low });
    } catch {
      throw new Error('Erro na api CryptoCompare');
    }
  }
}

export default CryptoCompare;
