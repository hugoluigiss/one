import { container } from 'tsyringe';
import CryptoCompare from './implementations/CryptoCompare';
import ICryptoUtilsProvider from './models/ICryptoUtilsProvider';

container.registerSingleton<ICryptoUtilsProvider>(
  'CryptoUtilsProvider',
  CryptoCompare,
);
