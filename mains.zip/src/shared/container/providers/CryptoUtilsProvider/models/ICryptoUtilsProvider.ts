import ICheckCoinAddressDTO from '../dtos/ICheckCoinAddressDTO';
import IGetCoinParValueDTO from '../dtos/IGetCoinParValueDTO';

export default interface ICryptoUtilsProvider {
  getCoinParValue(data: IGetCoinParValueDTO): Promise<string>;
  checkValidAddress(data: ICheckCoinAddressDTO): Promise<boolean>;
  getOscilationChartData(
    interval: 'hour' | 'day',
    value: number,
    coin_symbol: 'BTC' | 'ETH' | 'BNB' | 'USDT',
  ): Promise<string>;
}
