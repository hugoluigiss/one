import { injectable, inject } from 'tsyringe';

import nodemailer, { Transporter } from 'nodemailer';
import SMTPTransport from 'nodemailer/lib/smtp-transport';

import { Auth } from 'googleapis';

import mailConfig from '../../../../../config/mail';

import IMailProvider from '../models/IMailProvider';
import ISendMailDTO from '../dtos/ISendMailDTO';
import IMailTemplateProvider from '../../MailTemplateProvider/models/IMailTemplateProvider';

// const oauth2Client = new Auth.OAuth2Client(
//   process.env.CLIENT_ID,
//   process.env.CLIENT_SECRET,
//   'https://developers.google.com/oauthplayground',
// );
// oauth2Client.setCredentials({
//   refresh_token: process.env.REFRESH_TOKEN,
// });

@injectable()
export default class GSuitMailProvider implements IMailProvider {
  // private client: Transporter;

  constructor(
    @inject('MailTemplateProvider')
    private mailTemplateProvider: IMailTemplateProvider,
  ) {
    // this.client = nodemailer.createTransport({
    //   service: 'gmail',
    //   auth: {
    //     type: 'OAuth2',
    //     user: process.env.EMAIL,
    //     accessToken,
    //     clientId: process.env.CLIENT_ID,
    //     clientSecret: process.env.CLIENT_SECRET,
    //     refreshToken: process.env.REFRESH_TOKEN,
    //   },
    //   // host: 'smtp.gmail.com',
    //   // port: 587,
    //   // secure: false,
    //   // auth: mailConfig.credentials.user ? mailConfig.credentials : null,
    //   // from: mailConfig.credentials.user,
    // } as SMTPTransport.Options);
  }

  createTransporter = async (): Promise<Transporter> => {
    const oauth2Client = new Auth.OAuth2Client(
      process.env.CLIENT_ID,
      process.env.CLIENT_SECRET,
      'https://developers.google.com/oauthplayground',
    );
    oauth2Client.setCredentials({
      refresh_token: process.env.REFRESH_TOKEN,
    });
    const accessToken = await new Promise((resolve, reject) => {
      oauth2Client.getAccessToken((err, token) => {
        if (err) {
          reject();
        }
        resolve(token);
      });
    });
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        type: 'OAuth2',
        user: process.env.EMAIL,
        accessToken,
        clientId: process.env.CLIENT_ID,
        clientSecret: process.env.CLIENT_SECRET,
        refreshToken: process.env.REFRESH_TOKEN,
      },
    } as SMTPTransport.Options);

    return transporter;
  };

  public async sendMail({
    to,
    from,
    subject,
    templateData,
  }: ISendMailDTO): Promise<void> {
    const { name } = mailConfig.defaults.from;

    const client = await this.createTransporter();

    await client.sendMail({
      from: {
        name: from?.name || name,
        address: process.env.EMAIL || '',
      },
      to: {
        name: to.name,
        address: to.email,
      },
      subject,
      html: await this.mailTemplateProvider.parse(templateData),
    });
  }
}
