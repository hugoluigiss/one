export default interface QueueJobOptionsDTO {
  repeat?: {
    cron: string;
  };
}
