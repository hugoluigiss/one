/* eslint-disable no-console */
import Bull, { Job } from 'bull';
import { injectable, container } from 'tsyringe';
import ProcessBtcBlockNotificationsService from '../../../../../modules/btc/services/ProcessBtcBlockNotificationsService';
import redisConfig from '../../../../../config/redis';
import IQueue from '../models/IQueue';

export interface IBlockNotificationsParams {
  block_hash: string;
}

@injectable()
class BitcoinBlockNotificationsQueue implements IQueue {
  private queue;

  constructor() {
    this.queue = new Bull('BitcoinBlockNotificationsQueue', {
      redis: redisConfig,
    });
    this.queue.process(this.process);
  }

  public async add<T>(params: IBlockNotificationsParams): Promise<T> {
    const job = await this.queue.add(params, {
      removeOnComplete: true,
      removeOnFail: 5,
      attempts: 2,
    });
    await job.finished();
    return 'done' as unknown as T;
  }

  private process = async (job: Job): Promise<string | undefined> => {
    try {
      const processBtcBlockNotificationsService = container.resolve(
        ProcessBtcBlockNotificationsService,
      );
      await processBtcBlockNotificationsService.execute();

      console.log(
        `${new Date().toISOString()} | BitcoinBlockNotificationsQueue - ${
          job.id
        } completed`,
      );
      return 'sucess';
    } catch (error) {
      console.log(
        `${new Date().toISOString()} | BitcoinBlockNotificationsQueue - ${
          job.id
        } failed`,
        error,
      );
      return undefined;
    }
  };
}
export default BitcoinBlockNotificationsQueue;
