/* eslint-disable no-console */
import Bull, { Job } from 'bull';
import { injectable, container } from 'tsyringe';
import redisConfig from '../../../../../config/redis';
import IQueue from '../models/IQueue';
import ProcessBtcTxidNotificationsService from '../../../../../modules/btc/services/ProcessBtcTxidNotificationsService';

export interface ITxidNotificationsParams {
  txid: string;
}

@injectable()
class BitcoinTxidNotificationsQueue implements IQueue {
  private queue;

  constructor() {
    this.queue = new Bull('BitcoinTxidNotificationsQueue', {
      redis: redisConfig,
    });
    this.queue.process(this.process);
  }

  public async add<T>(params: ITxidNotificationsParams): Promise<T> {
    const job = await this.queue.add(params, {
      removeOnComplete: true,
      removeOnFail: 5,
      attempts: 2,
    });
    await job.finished();
    return 'done' as unknown as T;
  }

  private process = async (job: Job): Promise<string | undefined> => {
    try {
      const { txid } = job.data as ITxidNotificationsParams;

      const processBtcTxidNotificationsService = container.resolve(
        ProcessBtcTxidNotificationsService,
      );
      await processBtcTxidNotificationsService.execute({ txid });

      console.log(
        `${new Date().toISOString()} | BitcoinTxidNotificationsQueue - ${
          job.id
        } completed`,
      );
      return 'sucess';
    } catch (error) {
      console.log(
        `${new Date().toISOString()} | BitcoinTxidNotificationsQueue - ${
          job.id
        } failed`,
        error,
      );
      return undefined;
    }
  };
}
export default BitcoinTxidNotificationsQueue;
