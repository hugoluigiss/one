/* eslint-disable no-console */
import Bull, { Job } from 'bull';
import { injectable, container } from 'tsyringe';
import redisConfig from '../../../../../config/redis';
import IQueue from '../models/IQueue';
import VerifyEthNewBlocksService from '../../../../../modules/eth/services/VerifyEthNewBlocksService';

@injectable()
class BnbNewBlocksVerificationQueue implements IQueue {
  private queue;

  constructor() {
    this.queue = new Bull('BnbNewBlocksVerificationQueue', {
      redis: redisConfig,
    });
    this.queue.process(this.process);
  }

  public async add<T>(): Promise<T> {
    const job = await this.queue.add(
      {},
      {
        removeOnComplete: true,
        removeOnFail: 5,
        attempts: 2,
        repeat: { cron: '*/1 * * * *' },
      },
    );
    await job.finished();
    return 'done' as unknown as T;
  }

  private process = async (job: Job): Promise<string | undefined> => {
    try {
      const verifyEthNewBlocksService = container.resolve(
        VerifyEthNewBlocksService,
      );
      await verifyEthNewBlocksService.execute();

      console.log(
        `${new Date().toISOString()} | BnbNewBlocksVerificationQueue - ${
          job.id
        } completed`,
      );
      return 'sucess';
    } catch (error) {
      console.log(
        `${new Date().toISOString()} | BnbNewBlocksVerificationQueue - ${
          job.id
        } failed`,
        error,
      );
      return undefined;
    }
  };
}
export default BnbNewBlocksVerificationQueue;
