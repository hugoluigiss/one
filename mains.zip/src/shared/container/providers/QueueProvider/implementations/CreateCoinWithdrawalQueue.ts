/* eslint-disable no-console */
import Bull, { Job } from 'bull';
import { container, injectable } from 'tsyringe';
import BigNumber from 'bignumber.js';
import { CoinsType } from 'src/modules/coins/infra/typeorm/entities/Coin';
import CreateCoinTransactionService from '../../../../../modules/coins/services/CreateCoinTransactionService';
import GetCustomerCoinWalletBalanceService from '../../../../../modules/coins/services/GetCustomerCoinWalletBalanceService';
import redisConfig from '../../../../../config/redis';
import IQueue from '../models/IQueue';

export interface ICreateCoinWithdrawalQueueParams {
  customer_id: string;
  coin_amount: string;
  fee_value: string;
  description: string;
  status: 'pending' | 'confirmed' | 'refused' | 'canceled';
  coin_symbol: CoinsType;
  operation: 'buy' | 'sell' | 'deposit' | 'withdrawal' | 'brl_transfer';
}

@injectable()
class CreateCoinWithdrawalQueue implements IQueue {
  private queue;

  constructor() {
    this.queue = new Bull('CreateCoinWithdrawalQueue', {
      redis: redisConfig,
    });
    this.queue.process(this.process);
  }

  private async awaitToComplete<T>(id: string): Promise<T> {
    const awaitToComplete = async (): Promise<T> => {
      await new Promise(r => setTimeout(r, 50));
      const job = await this.queue.getJob(id);
      const result = job?.returnvalue;
      if (!result) return awaitToComplete();
      if (result === 'failed') return undefined as unknown as T;
      await job.remove();
      return result;
    };
    return awaitToComplete();
  }

  public async add<T>(data: ICreateCoinWithdrawalQueueParams): Promise<T> {
    const job = await this.queue.add(data, {
      removeOnComplete: 20,
      removeOnFail: 5,
      attempts: 1,
    });

    return this.awaitToComplete<T>(String(job.id));
  }

  private process = async (job: Job): Promise<string> => {
    try {
      const {
        coin_symbol,
        customer_id,
        coin_amount,
        description,
        status,
        fee_value,
        operation,
      } = job.data as ICreateCoinWithdrawalQueueParams;

      const getCustomerCoinWalletBalanceService = container.resolve(
        GetCustomerCoinWalletBalanceService,
      );
      const balance = await getCustomerCoinWalletBalanceService.execute({
        coin_symbol,
        customer_id,
      });

      const hasEnoughBalance = new BigNumber(balance).isGreaterThanOrEqualTo(
        coin_amount,
      );
      if (!hasEnoughBalance) throw new Error('Saldo insuficiente');

      const createCoinTransactionService = container.resolve(
        CreateCoinTransactionService,
      );
      const transaction = await createCoinTransactionService.execute({
        coin_symbol,
        customer_id,
        total_value: coin_amount,
        fee_value,
        status,
        type: 'output',
        description,
        operation,
      });

      console.log(
        `${new Date().toISOString()} | CreateCoinWithdrawalQueue - ${
          job.id
        } completed`,
      );
      return transaction.id;
    } catch (error) {
      console.log(
        `${new Date().toISOString()} | CreateCoinWithdrawalQueue - ${
          job.id
        } failed: `,
        error,
      );
      return 'failed';
    }
  };
}
export default CreateCoinWithdrawalQueue;
