/* eslint-disable no-console */
import Bull, { Job } from 'bull';
import { injectable } from 'tsyringe';
import redisConfig from '../../../../../config/redis';
import IQueue from '../models/IQueue';
// import GetCustomersCfaDocumentsStatusService from '../../../../../modules/caf/services/GetCustomersCfaDocumentsStatusService';
// import SendCustomersCfaDocumentsService from '../../../../../modules/caf/services/SendCustomersCfaDocumentsService';

@injectable()
class GetCustomersCfaDocumentsStatusQueue implements IQueue {
  private queue;

  constructor() {
    this.queue = new Bull('GetCustomersCfaDocumentsStatusQueue', {
      redis: redisConfig,
    });
    this.queue.process(this.process);
  }

  public async add<T>(): Promise<T> {
    const job = await this.queue.add(
      {},
      {
        removeOnComplete: true,
        removeOnFail: 5,
        attempts: 2,
        repeat: { cron: '*/1 * * * *' },
      },
    );
    await job.finished();
    return 'done' as unknown as T;
  }

  private process = async (job: Job): Promise<string | undefined> => {
    try {
      // await container.resolve(SendCustomersCfaDocumentsService).execute();
      // await container.resolve(GetCustomersCfaDocumentsStatusService).execute();

      console.log(
        `${new Date().toISOString()} | GetCustomersCfaDocumentsStatusQueue - ${
          job.id
        } completed`,
      );
      return 'sucess';
    } catch (error) {
      console.log(
        `${new Date().toISOString()} | GetCustomersCfaDocumentsStatusQueue - ${
          job.id
        } failed`,
        error,
      );
      return undefined;
    }
  };
}
export default GetCustomersCfaDocumentsStatusQueue;
