/* eslint-disable no-console */
import Bull, { Job } from 'bull';
import { injectable, container } from 'tsyringe';
import ProcessBitcoinWithdrawalsService from '../../../../../modules/coins/services/ProcessBitcoinWithdrawalsService';
import ProcessEthereumWithdrawalsService from '../../../../../modules/coins/services/ProcessEthereumWithdrawalsService';
import ProcessRippleWithdrawalsService from '../../../../../modules/coins/services/ProcessRippleWithdrawalsService';
import redisConfig from '../../../../../config/redis';
import IQueue from '../models/IQueue';

@injectable()
class ProcessCryptoWithdrawalsQueue implements IQueue {
  private queue;

  constructor() {
    this.queue = new Bull('ProcessCryptoWithdrawalsQueue', {
      redis: redisConfig,
    });
    this.queue.process(this.process);
  }

  public async add<T>(): Promise<T> {
    const job = await this.queue.add(
      {},
      {
        removeOnComplete: true,
        removeOnFail: 5,
        attempts: 2,
        repeat: { cron: '*/5 * * * *' },
      },
    );
    await job.finished();
    return 'done' as unknown as T;
  }

  private process = async (job: Job): Promise<string | undefined> => {
    try {
      const processBitcoinWithdrawalsService = container.resolve(
        ProcessBitcoinWithdrawalsService,
      );
      await processBitcoinWithdrawalsService.execute();

      const processEthereumWithdrawalsService = container.resolve(
        ProcessEthereumWithdrawalsService,
      );
      await processEthereumWithdrawalsService.execute();

      const processRippleWithdrawalsService = container.resolve(
        ProcessRippleWithdrawalsService,
      );
      await processRippleWithdrawalsService.execute();

      console.log(
        `${new Date().toISOString()} | ProcessCryptoWithdrawalsQueue - ${
          job.id
        } completed`,
      );
      return 'sucess';
    } catch (error) {
      console.log(
        `${new Date().toISOString()} | ProcessCryptoWithdrawalsQueue - ${
          job.id
        } failed`,
        error,
      );
      return undefined;
    }
  };
}
export default ProcessCryptoWithdrawalsQueue;
