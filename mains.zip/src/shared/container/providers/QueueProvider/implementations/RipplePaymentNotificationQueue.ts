/* eslint-disable no-console */
import Bull, { Job } from 'bull';
import { injectable } from 'tsyringe';
import redisConfig from '../../../../../config/redis';
import IQueue from '../models/IQueue';
// import ProcessXrpPaymentsService from '../../../../../modules/xrp/services/ProcessXrpPaymentsService';

export interface IRipllePaymentNotificationParams {
  engine_result?: string;
  transaction?: {
    Amount?: string;
    DestinationTag?: number;
    Destination?: string;
    TransactionType?: string;
    hash?: string;
  };
  validated: boolean;
}

@injectable()
class RipplePaymentNotificationQueue implements IQueue {
  private queue;

  constructor() {
    this.queue = new Bull('RipplePaymentNotificationQueue', {
      redis: redisConfig,
    });
    this.queue.process(this.process);
  }

  public async add<T>(): Promise<T> {
    const job = await this.queue.add(
      {},
      {
        removeOnComplete: true,
        removeOnFail: 5,
        attempts: 2,
      },
    );
    await job.finished();
    return 'done' as unknown as T;
  }

  private process = async (job: Job): Promise<string | undefined> => {
    try {
      // const paymentData = job.data as IRipllePaymentNotificationParams;
      // const processXrpPaymentsService = container.resolve(
      //   ProcessXrpPaymentsService,
      // );
      // await processXrpPaymentsService.execute(paymentData);

      console.log(
        `${new Date().toISOString()} | RipplePaymentNotificationQueue - ${
          job.id
        } completed`,
      );
      return 'sucess';
    } catch (error) {
      console.log(
        `${new Date().toISOString()} | RipplePaymentNotificationQueue - ${
          job.id
        } failed`,
        error,
      );
      return undefined;
    }
  };
}
export default RipplePaymentNotificationQueue;
