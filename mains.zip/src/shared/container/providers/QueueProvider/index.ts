import { container } from 'tsyringe';

import IQueue from './models/IQueue';
import BitcoinTxidNotificationsQueue from './implementations/BitcoinTxidNotificationsQueue';
import BitcoinBlockNotificationsQueue from './implementations/BitcoinBlockNotificationsQueue';
import RipplePaymentNotificationQueue from './implementations/RipplePaymentNotificationQueue';
import EthereumNewBlocksVerificationQueue from './implementations/EthereumNewBlocksVerificationQueue';
import ProcessCryptoWithdrawalsQueue from './implementations/ProcessCryptoWithdrawalsQueue';
import CreateCoinWithdrawalQueue from './implementations/CreateCoinWithdrawalQueue';
import SendCustomersCfaDocumentsQueue from './implementations/SendCustomersCfaDocumentsQueue';
import GetCustomersCfaDocumentsStatusQueue from './implementations/GetCustomersCfaDocumentsStatusQueue';
import BnbNewBlocksVerificationQueue from './implementations/BnbNewBlocksVerificationQueue';

container.registerSingleton<IQueue>(
  'SendCustomersCfaDocumentsQueue',
  SendCustomersCfaDocumentsQueue,
);

container.registerSingleton<IQueue>(
  'CreateCoinWithdrawalQueue',
  CreateCoinWithdrawalQueue,
);

container.registerSingleton<IQueue>(
  'BitcoinTxidNotificationsQueue',
  BitcoinTxidNotificationsQueue,
);

container.registerSingleton<IQueue>(
  'BitcoinBlockNotificationsQueue',
  BitcoinBlockNotificationsQueue,
);

container.registerSingleton<IQueue>(
  'RipplePaymentNotificationQueue',
  RipplePaymentNotificationQueue,
);

const ethereumNewBlocksVerificationQueue =
  new EthereumNewBlocksVerificationQueue();
ethereumNewBlocksVerificationQueue.add();

const processCryptoWithdrawalsQueue = new ProcessCryptoWithdrawalsQueue();
processCryptoWithdrawalsQueue.add();

const getCustomersCfaDocumentsStatusQueue =
  new GetCustomersCfaDocumentsStatusQueue();
getCustomersCfaDocumentsStatusQueue.add();

const bnbNewBlocksVerificationQueue = new BnbNewBlocksVerificationQueue();
bnbNewBlocksVerificationQueue.add();
