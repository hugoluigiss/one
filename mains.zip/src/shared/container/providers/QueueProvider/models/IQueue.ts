import { IBlockNotificationsParams } from '../implementations/BitcoinBlockNotificationsQueue';
import { ITxidNotificationsParams } from '../implementations/BitcoinTxidNotificationsQueue';
import { IRipllePaymentNotificationParams } from '../implementations/RipplePaymentNotificationQueue';
import { ICreateCoinWithdrawalQueueParams } from '../implementations/CreateCoinWithdrawalQueue';

export default interface IQueue {
  add<T>(
    data:
      | ITxidNotificationsParams
      | IBlockNotificationsParams
      | IRipllePaymentNotificationParams
      | ICreateCoinWithdrawalQueueParams
      | undefined,
  ): Promise<T>;
}
