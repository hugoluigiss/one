import { ExpressContext } from 'apollo-server-express/dist/ApolloServer';
import { verify } from 'jsonwebtoken';
import { ApolloError } from 'apollo-server-express';
import authConfig from '../../../config/auth';

export interface MyContext {
  client_id?: string;
  customer_id?: string;
  admin_id?: string;
  customer_pf_id?: string;
}

interface TokenPayload {
  iat: number;
  ext: number;
  subject: string;
  customer_pf_id?: string;
}

export function createContext(context: ExpressContext): MyContext {
  const authHeader = context.req.headers.authorization;

  if (!authHeader) {
    return {};
  }

  const [, token] = authHeader.split(' ');

  const {
    jwt: { secret },
  } = authConfig;

  try {
    const decoded = verify(token, secret);

    const { subject, customer_pf_id } = decoded as TokenPayload;

    return { client_id: subject, customer_pf_id };
  } catch {
    throw new ApolloError('Unauthorized');
  }
}
