import { buildSchema, Resolver, Query } from 'type-graphql';

import BtcNotificationsResolver from '../../../modules/btc/infra/graphql/resolvers/BtcNotificationsResolver';
import CustomersResolvers from '../../../modules/customers/infra/graphql/resolvers';
import BanksResolvers from '../../../modules/banks/infra/graphql/resolvers';
import AdminsResolvers from '../../../modules/admins/infra/graphql/resolvers';

@Resolver()
class HelloResolver {
  @Query(() => String)
  async hello(): Promise<string> {
    return 'hello';
  }
}

function createSchema() {
  return buildSchema({
    resolvers: [
      HelloResolver,
      BtcNotificationsResolver,
      ...CustomersResolvers,
      ...BanksResolvers,
      ...AdminsResolvers,
    ],
    validate: false,
  });
}

export default createSchema();
