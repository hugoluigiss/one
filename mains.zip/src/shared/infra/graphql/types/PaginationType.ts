/* eslint-disable max-classes-per-file */
import { Field, ObjectType } from 'type-graphql';
import Customer from '../../../../modules/customers/infra/typeorm/entities/Customer';
import CoinTransaction from '../../../../modules/coins/infra/typeorm/entities/CoinTransaction';
import CustomerDocument from '../../../../modules/customers/infra/typeorm/entities/CustomerDocument';
import BrlDeposit from '../../../../modules/deposits/infra/typeorm/entities/BrlDeposit';
import BrlWithdrawal from '../../../../modules/withdrawals/infra/typeorm/entities/BrlWaithdrawal';
import Ticket from '../../../../modules/tickets/infra/typeorm/entities/Ticket';
import CafDocument from '../../../../modules/caf/infra/typeorm/entities/CafDocument';

@ObjectType()
class Edges {
  @Field(() => [BrlDeposit], { nullable: true })
  brl_deposits?: BrlDeposit[];

  @Field(() => [BrlWithdrawal], { nullable: true })
  brl_withdrawals?: BrlWithdrawal[];

  @Field(() => [CoinTransaction], { nullable: true })
  transactions?: CoinTransaction[];

  @Field(() => [CustomerDocument], { nullable: true })
  documents?: CustomerDocument[];

  @Field(() => [Customer], { nullable: true })
  customers?: Customer[];

  @Field(() => [Ticket], { nullable: true })
  tickets?: Ticket[];

  @Field(() => [CafDocument], { nullable: true })
  cafDocuments?: CafDocument[];
}

@ObjectType()
class PageInfo {
  @Field()
  hasPrevPage: boolean;

  @Field()
  hasNextPage: boolean;
}

@ObjectType()
class PaginationType {
  @Field()
  totalCount: number;

  @Field(() => Edges)
  edges: Edges;

  @Field(() => PageInfo)
  pageInfo: PageInfo;
}

export default PaginationType;
