import 'reflect-metadata';
import 'dotenv/config';

import express from 'express';

import 'express-async-errors';

import uploadConfig from '../../../config/upload';

import '../typeorm';

import '../../container';

const app = express();

app.use('/files', express.static(uploadConfig.uploadsFolder));

export default app;
