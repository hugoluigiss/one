import { ApolloServer } from 'apollo-server-express';
// import { GraphQLError } from 'graphql';
import { graphqlUploadExpress } from 'graphql-upload';
import app from './app';

import createSchema from '../graphql/Schema';
import { createContext as context } from '../graphql/Context';

import '../queue/index';

app.use(graphqlUploadExpress({ maxFileSize: 10000000, maxFiles: 10 }));

const main = async () => {
  const apolloServer = new ApolloServer({
    uploads: false,
    schema: await createSchema,
    context,
    playground: true,
    introspection: true,
    formatError: err => {
      console.log(err.message);
      // const message =
      //   err instanceof GraphQLError ? err.message : 'Erro interno';
      return {
        ...err,
        // message,
        locations: [],
        extensions: [],
      };
    },
  });

  apolloServer.applyMiddleware({
    app,
    cors: true,
  });

  app.listen(3333, () => console.log('Server listenning on port 3333!'));
};

main().catch(err => console.log(err));
