import 'reflect-metadata';
import 'dotenv/config';

import '../typeorm';

import '../../container';

// import BullQueueProvider from '../../container/providers/QueueProvider';

// BullQueueProvider.process();
// BullQueueProvider.addRepeatableJobs();

// console.log('🚀 Queue on');
