import { createConnections } from 'typeorm';

const connect = async () => {
  const connections = await createConnections();
  const defaultConnection = connections.find(c => c.name === 'default');
  if (defaultConnection) await defaultConnection.runMigrations();
};

connect();
