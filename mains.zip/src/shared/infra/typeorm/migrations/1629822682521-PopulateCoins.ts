import { MigrationInterface, QueryRunner } from 'typeorm';

export default class PopulateCoins1629822682521 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `INSERT INTO coins (name,type,symbol) values ('Bitcoin','spot','BTC')`,
    );
    await queryRunner.query(
      `INSERT INTO coins (name,type,symbol) values ('Ethereum','spot','ETH')`,
    );
    await queryRunner.query(
      `INSERT INTO coins (name,type,symbol) values ('Real','fiat','BRL')`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM coins`);
  }
}
