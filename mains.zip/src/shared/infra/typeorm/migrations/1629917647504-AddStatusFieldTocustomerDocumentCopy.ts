import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export default class AddStatusFieldTocustomerDocumentCopy1629917647504
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'customers_documents_copies',
      new TableColumn({
        name: 'status',
        type: 'varchar',
        isNullable: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn('customers_documents_copies', 'status');
  }
}
