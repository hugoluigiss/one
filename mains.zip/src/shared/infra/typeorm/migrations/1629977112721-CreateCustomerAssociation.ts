import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export default class CreateCustomerAssociation1629977112721
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'customers_associations',
        columns: [
          {
            name: 'id',
            type: 'uuid',
            isPrimary: true,
            generationStrategy: 'uuid',
            default: 'uuid_generate_v4()',
          },
          {
            name: 'customer_pf_id',
            type: 'uuid',
            isNullable: false,
          },
          {
            name: 'customer_pj_id',
            type: 'uuid',
            isNullable: false,
          },
          {
            name: 'created_at',
            type: 'timestamp with time zone',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamp with time zone',
            default: 'now()',
          },
        ],
        foreignKeys: [
          {
            name: 'customer_pf-customers_associations',
            referencedTableName: 'customers',
            referencedColumnNames: ['id'],
            columnNames: ['customer_pf_id'],
            onDelete: 'CASCADE',
            onUpdate: 'CASCADE',
          },
          {
            name: 'customer_pj-customers_associations',
            referencedTableName: 'customers',
            referencedColumnNames: ['id'],
            columnNames: ['customer_pj_id'],
            onDelete: 'CASCADE',
            onUpdate: 'CASCADE',
          },
        ],
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('customers_associations');
  }
}
