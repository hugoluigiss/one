import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export default class AddFantasyNameFieldToCustomer1629981187141
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'customers',
      new TableColumn({
        name: 'fantasy_name',
        type: 'varchar',
        isNullable: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn('customers', 'fantasy_name');
  }
}
