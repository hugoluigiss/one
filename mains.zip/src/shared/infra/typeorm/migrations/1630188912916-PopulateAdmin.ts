import { MigrationInterface, QueryRunner } from 'typeorm';
import { hashSync } from 'bcryptjs';

export default class PopulateAdmin1630188912916 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.manager.insert('admins', [
      {
        email: 'admin@exchange.com',
        password_hash: hashSync('123456789', 8),
      },
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('TRUNCATE admins');
  }
}
