import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export default class AddTypeToCoinsTransactions1630333580266
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'coins_transactions',
      new TableColumn({
        name: 'type',
        type: 'varchar',
        isNullable: true,
      }),
    );
    await queryRunner.addColumn(
      'coins_transactions',
      new TableColumn({
        name: 'description',
        type: 'varchar',
        isNullable: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn('coins_transactions', 'type');
    await queryRunner.dropColumn('coins_transactions', 'description');
  }
}
