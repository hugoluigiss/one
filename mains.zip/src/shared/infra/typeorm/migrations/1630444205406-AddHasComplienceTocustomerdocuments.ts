import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export default class AddHasComplienceTocustomerdocuments1630444205406
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'customers_documents',
      new TableColumn({
        name: 'has_complience',
        type: 'boolean',
        isNullable: false,
        default: false,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn('customers_documents', 'has_complience');
  }
}
