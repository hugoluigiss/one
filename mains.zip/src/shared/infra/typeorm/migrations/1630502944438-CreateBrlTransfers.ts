import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export default class CreateBrlTransfers1630502944438
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'brl_transfers',
        columns: [
          {
            name: 'id',
            type: 'uuid',
            isPrimary: true,
            generationStrategy: 'uuid',
            default: 'uuid_generate_v4()',
          },
          {
            name: 'sender_transaction_id',
            type: 'uuid',
          },
          {
            name: 'receiver_transaction_id',
            type: 'uuid',
          },
          {
            name: 'created_at',
            type: 'timestamp with time zone',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamp with time zone',
            default: 'now()',
          },
        ],
        foreignKeys: [
          {
            name: 'receiver_transaction_id-brl_transfers',
            referencedTableName: 'coins_transactions',
            referencedColumnNames: ['id'],
            columnNames: ['receiver_transaction_id'],
            onDelete: 'CASCADE',
            onUpdate: 'CASCADE',
          },
          {
            name: 'sender_transaction_id-brl_transfers',
            referencedTableName: 'coins_transactions',
            referencedColumnNames: ['id'],
            columnNames: ['sender_transaction_id'],
            onDelete: 'CASCADE',
            onUpdate: 'CASCADE',
          },
        ],
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('brl_transfers');
  }
}
