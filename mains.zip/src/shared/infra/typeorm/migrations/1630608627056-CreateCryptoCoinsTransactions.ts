import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export default class CreateCryptoCoinsTransactions1630608627056
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'crypto_coins_transactions',
        columns: [
          {
            name: 'id',
            type: 'uuid',
            isPrimary: true,
            generationStrategy: 'uuid',
            default: 'uuid_generate_v4()',
          },
          {
            name: 'transaction_id',
            type: 'uuid',
            isNullable: false,
            isUnique: true,
          },
          {
            name: 'txid',
            type: 'varchar',
            isNullable: true,
            isUnique: false,
          },
          {
            name: 'address_to',
            type: 'varchar',
            isNullable: false,
          },
          {
            name: 'fee_network',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'type',
            type: 'varchar',
            isNullable: false,
          },
          {
            name: 'created_at',
            type: 'timestamp with time zone',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamp with time zone',
            default: 'now()',
          },
        ],
        foreignKeys: [
          {
            name: 'coin_transaction-crypto_coins_transactions',
            referencedTableName: 'coins_transactions',
            referencedColumnNames: ['id'],
            columnNames: ['transaction_id'],
            onDelete: 'CASCADE',
            onUpdate: 'CASCADE',
          },
        ],
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('crypto_coins_transactions');
  }
}
