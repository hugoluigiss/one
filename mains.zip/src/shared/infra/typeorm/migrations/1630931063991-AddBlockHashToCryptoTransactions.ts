import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export default class AddBlockHashToCryptoTransactions1630931063991
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'crypto_coins_transactions',
      new TableColumn({
        name: 'blockhash',
        type: 'varchar',
        isNullable: true,
      }),
    );
    await queryRunner.addColumn(
      'crypto_coins_transactions',
      new TableColumn({
        name: 'confirmations',
        type: 'integer',
        isNullable: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn('crypto_coins_transactions', 'blockhash');
    await queryRunner.dropColumn('crypto_coins_transactions', 'confirmations');
  }
}
