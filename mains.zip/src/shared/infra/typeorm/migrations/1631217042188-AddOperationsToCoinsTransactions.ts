import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export default class AddOperationsToCoinsTransactions1631217042188
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'coins_transactions',
      new TableColumn({
        name: 'operation',
        type: 'varchar',
        isNullable: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn('coins_transactions', 'operation');
  }
}
