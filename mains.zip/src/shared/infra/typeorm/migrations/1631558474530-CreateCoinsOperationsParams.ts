import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export default class CreateCoinsOperationsParams1631558474530
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'coins_operations_params',
        columns: [
          {
            name: 'id',
            type: 'uuid',
            isPrimary: true,
            generationStrategy: 'uuid',
            default: 'uuid_generate_v4()',
          },
          {
            name: 'coin_id',
            type: 'uuid',
            isNullable: false,
          },
          {
            name: 'operation',
            type: 'varchar',
            isNullable: false,
          },
          {
            name: 'fixed_fee_brl_value',
            type: 'varchar',
            isNullable: false,
          },
          {
            name: 'min_brl_value',
            type: 'varchar',
            isNullable: false,
          },
          {
            name: 'max_brl_value',
            type: 'varchar',
            isNullable: false,
          },
          {
            name: 'validity_period_days',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'percentage_fee_value',
            type: 'varchar',
            isNullable: false,
          },
          {
            name: 'customer_type',
            type: 'varchar',
            isNullable: false,
          },
          {
            name: 'has_complience',
            type: 'boolean',
            isNullable: false,
          },
          {
            name: 'created_at',
            type: 'timestamp with time zone',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamp with time zone',
            default: 'now()',
          },
        ],
        foreignKeys: [
          {
            name: 'coin_operation_param-coin',
            referencedTableName: 'coins',
            referencedColumnNames: ['id'],
            columnNames: ['coin_id'],
            onDelete: 'CASCADE',
            onUpdate: 'CASCADE',
          },
        ],
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('coins_operations_params');
  }
}
