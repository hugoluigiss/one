import { MigrationInterface, QueryRunner } from 'typeorm';

export default class AddXRPToCoins1633857654737 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `INSERT INTO coins (name,type,symbol) values ('Ripple','spot','XRP')`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM coins where symbol = 'XRP'`);
  }
}
