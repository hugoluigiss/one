import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export default class AddDestFlagToCryptoCoinsWithdrawal1633986928644
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'crypto_coins_transactions',
      new TableColumn({
        name: 'dest_flag',
        type: 'varchar',
        isNullable: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn('crypto_coins_transactions', 'dest_flag');
  }
}
