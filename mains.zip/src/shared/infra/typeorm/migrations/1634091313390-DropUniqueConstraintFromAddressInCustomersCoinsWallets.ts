import { MigrationInterface, QueryRunner } from 'typeorm';

export default class DropUniqueConstraintFromAddressInCustomersCoinsWallets1634091313390
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const table = await queryRunner.getTable('customers_coins_wallets');

    if (table?.uniques[0]?.name)
      await queryRunner.dropUniqueConstraint(
        'customers_coins_wallets',
        table?.uniques[0].name,
      );
  }

  public async down(): Promise<void> {
    // donothing
  }
}
