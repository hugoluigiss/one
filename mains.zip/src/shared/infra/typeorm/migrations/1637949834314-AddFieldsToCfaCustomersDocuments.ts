import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export default class AddFieldsToCfaCustomersDocuments1637949834314
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'caf_customers_documents',
      new TableColumn({
        name: 'report',
        type: 'varchar',
        isNullable: true,
      }),
    );
    await queryRunner.addColumn(
      'caf_customers_documents',
      new TableColumn({
        name: 'execution',
        type: 'varchar',
        isNullable: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn('caf_customers_documents', 'execution');
    await queryRunner.dropColumn('caf_customers_documents', 'report');
  }
}
