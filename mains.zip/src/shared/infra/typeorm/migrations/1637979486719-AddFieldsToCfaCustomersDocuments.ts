import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export default class AddFieldsToCfaCustomersDocuments1637979486719
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'caf_customers_documents',
      new TableColumn({
        name: 'status',
        type: 'varchar',
        isNullable: false,
        default: "'EM ANÁLISE'",
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn('caf_customers_documents', 'status');
  }
}
