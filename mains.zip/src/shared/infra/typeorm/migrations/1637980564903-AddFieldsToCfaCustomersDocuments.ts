import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export default class AddFieldsToCfaCustomersDocuments1637980564903
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'caf_customers_documents',
      new TableColumn({
        name: 'fraud',
        type: 'boolean',
        isNullable: true,
      }),
    );
    await queryRunner.addColumn(
      'caf_customers_documents',
      new TableColumn({
        name: 'birth_date',
        type: 'varchar',
        isNullable: true,
      }),
    );
    await queryRunner.addColumn(
      'caf_customers_documents',
      new TableColumn({
        name: 'name',
        type: 'varchar',
        isNullable: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn('caf_customers_documents', 'fraud');
    await queryRunner.dropColumn('caf_customers_documents', 'name');
    await queryRunner.dropColumn('caf_customers_documents', 'birth_date');
  }
}
