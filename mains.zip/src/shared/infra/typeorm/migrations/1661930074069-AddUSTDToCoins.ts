import { MigrationInterface, QueryRunner } from 'typeorm';

export default class AddUSDTCoins1693857654737 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `INSERT INTO coins (name,type,symbol) values ('USDT','spot','USDT')`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM coins where symbol = 'USDT'`);
  }
}
