#!/usr/bin/env bash
set -euo pipefail

[ -d "vendor/neoscrypts/cryptitan" ] || exit 1;