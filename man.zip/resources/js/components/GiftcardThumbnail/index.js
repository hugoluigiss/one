export * from "./giftcardThumbnail";
export {default} from "./giftcardThumbnail";
