/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable react/require-default-props */
import { Container } from './styles';

type ButtonProps = {
  children: string | React.ReactNode;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset' | undefined;
  onPress?(): void;
};

export default function ButtonPrimary({
  children,
  disabled = false,
  type = 'button',
  onPress = () => {},
}: ButtonProps): JSX.Element {
  return (
    <Container type={type} onClick={onPress} disabled={disabled}>
      {children}
    </Container>
  );
}
