import styled from 'styled-components';

export const Container = styled.button`
  user-select: none;
  padding: 15px 35px;
  // border-radius: 100px;
  border: none;
  color: ##f4f4f4;
  font-weight: 600;
  font-size: 14px;
  text-transform: uppercase;
  cursor: pointer;
  background: #525050;
  transition: 250ms;
  letter-spacing: 0.78px;
  margin: 15px 0 0 0;

  &:hover {
    background: #5c5b5b;
    transition: 250ms;
  }

  &:active {
    transition: 50ms;
    background: #433e3e;
    top: 1.5px;
    position: relative;
  }

  &:disabled {
    background: #6c6c6c30;
    cursor: not-allowed;
    color: #26262940;
  }

  // // // //

  .btnTransparency {
    user-select: none;
    padding: 10px 35px;
    border-radius: 100px;
    border: none;
    color: #262629;
    font-weight: 600;
    font-size: 14px;
    text-transform: uppercase;
    cursor: pointer;
    transition: 250ms;
    letter-spacing: 0.78px;
    margin: 15px 0 0 0;
    background: transparent;
  }

  .btnTransparency:hover {
    transition: 250ms;
    color: #ffffff;
  }

  .btnTransparency:active {
    transition: 50ms;
    top: 1.5px;
    position: relative;
  }

  // // // //

  .btnLink {
    user-select: none;
    border-radius: 100px;
    border: none;
    color: #fff;
    // font-size: 14px;
    padding: 0;
    cursor: pointer;
    text-decoration: underline;
    transition: 250ms;
    background: transparent;
  }

  .btnLink:hover {
    transition: 250ms;
    background: transparent;
  }

  .btnLink:active {
    transition: 50ms;
    top: 1.5px;
    position: relative;
    background: transparent;
  }
`;

export const Def = styled.div``;
