import useGet from '../../hooks/useGet';
import { CoinsType } from '../../services/apitypes';
import CryptoCard from '../CryptoCard';
import ScrollDrag from '../Utils/ScrollDrag';
import colors from '../../utils/CryptoColors';

interface CardsPRops {
  collapsed: boolean;
}
export default function CardsCoins({ collapsed }: CardsPRops): JSX.Element {
  const [{ data: coins, loading }] = useGet<CoinsType[]>('/customer/coins');

  return (
    <ScrollDrag
      p="16px 16px 40px 16px"
      overflowX="auto"
      alignItems="start"
      position="relative"
      height={collapsed || loading ? '144px' : 'fit-content'}
      transition="600ms"
    >
      {coins &&
        coins.map((coin, i) => (
          <CryptoCard
            key={coin}
            coin={coin}
            collapse={collapsed}
            color={colors[i]}
          />
        ))}
    </ScrollDrag>
  );
}
