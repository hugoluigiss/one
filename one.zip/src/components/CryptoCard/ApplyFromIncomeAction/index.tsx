import {
  useDisclosure,
  Button,
  Text,
  FormLabel,
  FormControl,
  Input,
  Box,
  Skeleton,
  Stack,
  HStack,
  Collapse,
  Heading,
} from '@chakra-ui/react';
import { useState, useEffect, useCallback } from 'react';
import { toast } from 'react-toastify';
import useGet from '../../../hooks/useGet';
import usePost from '../../../hooks/usePost';
import ScrollDrag from '../../Utils/ScrollDrag';
import ActionProps from '../props';

interface ApplyProps extends ActionProps {
  plan: { label: string; value: string } | undefined;
}

export default function ApplyAction({
  coin,
  onOpenAction,
  onCloseAction,
  plan,
}: ApplyProps): JSX.Element {
  const [triggerOpen, setTriggerOpen] = useState(true);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const {
    isOpen: isOpenConfirm,
    onOpen: onOpenConfirm,
    onClose: onCloseConfirm,
  } = useDisclosure();

  const [valueFrom, setValueFrom] = useState('0');
  const [twofa, setTwofa] = useState('');

  const [{ data: application, loading }, makePost] = usePost<{ id: string }>(
    '/customer/application/from-income',
  );

  const [{ data }] = useGet<{ current_balance: string; coin: string }>(
    '/customer/balance/coin',
    {
      coin,
    },
  );

  const handleAction = (e: { preventDefault: () => void }) => {
    e.preventDefault();

    onOpenConfirm();
    onClose();
  };

  const handleSubmit = () => {
    if (!loading)
      makePost({
        coin,
        amount: valueFrom,
        twofa,
        application_type: plan?.value || '',
      });
  };

  const closeAll = useCallback(() => {
    onClose();
    setTriggerOpen(false);
    onCloseConfirm();
  }, [onClose, onCloseConfirm]);

  const closeConfirm = useCallback(() => {
    onOpen();
    onCloseConfirm();
  }, [onOpen, onCloseConfirm]);

  useEffect(() => {
    if (application) {
      toast.success(`Operacao criada, aguarde confirmacao`);
      closeAll();
    }
  }, [application, closeAll]);

  useEffect(() => {
    if (triggerOpen) {
      onOpen();
      if (onOpenAction) onOpenAction();
    } else if (onCloseAction) onCloseAction();
  }, [onOpen, triggerOpen, onCloseAction, onOpenAction]);

  return (
    <Collapse in={triggerOpen} animateOpacity>
      <Collapse in={isOpen} animateOpacity>
        <form style={{ width: '100%' }}>
          <Stack color="text.500" alignItems="center" mb={10} spacing={8}>
            <Stack w="90%">
              <Heading size="md" textAlign="center">
                Plano {plan?.label}
              </Heading>
              <FormControl>
                <FormLabel>Valor a ser locado:</FormLabel>
                <Input
                  placeholder="0.0000"
                  color="#000"
                  value={valueFrom}
                  onChange={e => {
                    let { value } = e.currentTarget;
                    const decimals = coin === 'BRL' || coin === 'USDT' ? 2 : 6;
                    value = value.replace(/\D/g, '');
                    value = value.padStart(decimals, '0');
                    value = [
                      value.slice(0, value.length - decimals),
                      '.',
                      value.slice(value.length - decimals),
                    ].join('');
                    if (value[0] === '0') value = value.slice(1, value.length);

                    e.currentTarget.value = value;
                    setValueFrom(value);
                  }}
                />
                {coin && (
                  <Skeleton isLoaded={!!data}>
                    <Button
                      variant="link"
                      onClick={() => setValueFrom(data?.current_balance || '0')}
                    >
                      <Text fontSize="sm" mt={1}>
                        Usar saldo: {`${data?.current_balance} `}
                        {data?.coin}
                      </Text>
                    </Button>
                  </Skeleton>
                )}
              </FormControl>

              {(valueFrom || Number(valueFrom) > 0) && (
                <HStack mt={2}>
                  <Text>Taxa:</Text>
                  <Text fontSize="sm" color="brand.800">
                    {Number(valueFrom) / 100} {coin}
                  </Text>
                </HStack>
              )}
            </Stack>

            <Stack spacing={4}>
              <Button
                onClick={handleAction}
                disabled={valueFrom === '0' || !coin}
                colorScheme="brandGray"
              >
                Locar
              </Button>
              <Button ml={3} onClick={closeAll} variant="link">
                Fechar
              </Button>
            </Stack>
          </Stack>
        </form>
      </Collapse>

      <Collapse in={isOpenConfirm} animateOpacity>
        <form style={{ width: '100%' }}>
          <Stack color="text.500" alignItems="center" mb={10} spacing={8}>
            <Stack w="90%">
              <Stack spacing={1}>
                <Text>Valor a ser Locado</Text>
                <ScrollDrag>
                  <Text as="strong" fontSize="4xl" color="brand.800">
                    {(Number(valueFrom) - Number(valueFrom) / 100).toFixed(6)}
                    {coin}
                  </Text>
                </ScrollDrag>
              </Stack>

              <HStack>
                <Text>Taxa:</Text>
                <Text color="brand.800">
                  <strong>
                    {Number(valueFrom) / 100} {coin}
                  </strong>
                </Text>
              </HStack>

              <Box mt={8}>
                <FormControl>
                  <FormLabel>Digite seu código 2FA</FormLabel>
                  <Input
                    type="text"
                    color="#000"
                    value={twofa}
                    onChange={e => setTwofa(e.target.value)}
                  />
                </FormControl>
              </Box>
            </Stack>

            <Stack spacing={4}>
              <Button
                onClick={handleSubmit}
                isLoading={loading}
                colorScheme="brandGray"
              >
                Confirmar
              </Button>
              <Button ml={3} onClick={closeConfirm} variant="link">
                Cancelar
              </Button>
            </Stack>
          </Stack>
        </form>
      </Collapse>
    </Collapse>
  );
}
