/* eslint-disable react/jsx-curly-newline */
import {
  Stack,
  useDisclosure,
  Button,
  HStack,
  Box,
  Skeleton,
  Collapse,
  Text,
  Spinner,
} from '@chakra-ui/react';
import { CopyIcon } from '@chakra-ui/icons';
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import QRCode from 'react-qr-code';
import useGet from '../../../hooks/useGet';
import { UserCoinWallet } from '../../../services/apitypes';
import ActionProps from '../props';

export default function WalletAction({
  coin,
  onOpenAction,
  onCloseAction,
}: ActionProps): JSX.Element {
  const [triggerOpen, setTriggerOpen] = useState(true);
  const { onOpen, onClose } = useDisclosure();

  const [{ data, loading }] = useGet<UserCoinWallet>('/customer/coins/wallet', {
    coin,
  });

  const closeAll = useCallback(() => {
    onClose();
    setTriggerOpen(false);
  }, [onClose, setTriggerOpen]);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Endereço copiado para a área de transferência.');
  };

  useEffect(() => {
    if (triggerOpen) {
      onOpen();
      if (onOpenAction) onOpenAction();
    } else if (onCloseAction) onCloseAction();
  }, [onOpen, triggerOpen, onCloseAction, onOpenAction]);

  return (
    <>
      <Collapse in={triggerOpen} animateOpacity>
        <Stack color="text.500" alignItems="center" mb={10}>
          <Stack>
            <Stack mb={3} spacing={4} alignItems="center">
              <Box p={2} bgColor="white" w="fit-content" transition="200ms">
                {!loading && <QRCode size={170} value={data?.address || ''} />}
                {loading && <Spinner size="xl" />}
              </Box>

              <Stack
                _hover={{ cursor: 'pointer' }}
                onClick={() => handleCopy(data?.address || '')}
              >
                <HStack>
                  <b>Rede:</b> <Text>{data?.network}</Text>
                </HStack>
                <HStack>
                  <b>Endereço:</b>{' '}
                  <Skeleton isLoaded={!loading} w="fit-content">
                    <Text maxW="120px" noOfLines={1}>
                      {data?.address}
                    </Text>
                  </Skeleton>
                  <CopyIcon />
                </HStack>
              </Stack>
            </Stack>
          </Stack>
          <Button ml={3} onClick={closeAll} variant="link">
            Cancelar
          </Button>
        </Stack>
      </Collapse>
    </>
  );
}
