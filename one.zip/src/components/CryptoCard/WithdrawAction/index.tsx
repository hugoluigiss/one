import {
  Stack,
  useDisclosure,
  Button,
  Text,
  FormLabel,
  FormControl,
  Input,
  Box,
  Skeleton,
  Collapse,
  HStack,
} from '@chakra-ui/react';
import { useState, useCallback, useEffect } from 'react';
import { toast } from 'react-toastify';
import useGet from '../../../hooks/useGet';
import usePost from '../../../hooks/usePost';
// import usePost from '../../../../hooks/usePost';
import {
  getApplicationCoin,
  IncomeWithdrawalType,
  // MakeApplication,
} from '../../../services/apitypes';
import ScrollDrag from '../../Utils/ScrollDrag';
import ActionProps from '../props';

export default function WithdrawAction({
  coin,
  onOpenAction,
  onCloseAction,
}: ActionProps): JSX.Element {
  const [triggerOpen, setTriggerOpen] = useState(true);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const {
    isOpen: isOpenConfirm,
    onOpen: onOpenConfirm,
    onClose: onCloseConfirm,
  } = useDisclosure();

  const [valueFrom, setValueFrom] = useState('0');
  const [addressTo, setAddressTo] = useState('');
  const [twofa, setTwofa] = useState('');

  const [{ data: application, loading: applicationLoading }, makePost] =
    usePost<IncomeWithdrawalType>('/customer/withdrawal');

  const [{ data }] = useGet<getApplicationCoin>(
    'customer/application/resume/coin',
    {
      coin,
    },
  );

  const [{ data: lastAddress }] = useGet<string>(
    '/customer/withdrawal/last-address',
    {
      coin,
    },
  );

  useEffect(() => {
    if (lastAddress) setAddressTo(lastAddress);
  }, [lastAddress]);

  const handleAction = (e: { preventDefault: () => void }) => {
    e.preventDefault();

    onOpenConfirm();
    onClose();
  };

  const closeAll = useCallback(() => {
    onClose();
    setTriggerOpen(false);
    onCloseConfirm();

    setValueFrom('');
  }, [onClose, onCloseConfirm, setTriggerOpen]);

  const handleSubmit = (e: { preventDefault: () => void }) => {
    e.preventDefault();

    try {
      makePost({ coin, amount: valueFrom, address_to: addressTo, twofa });
    } catch {
      toast.error('Não foi possível realizar a operação no momento');
    }
  };

  const closeConfirm = useCallback(() => {
    onOpen();
    onCloseConfirm();
  }, [onOpen, onCloseConfirm]);

  useEffect(() => {
    if (application) {
      toast.success(
        `Saque de Locação de ${application.coin_amount} ${application.coin} realizada com sucesso`,
      );
      closeAll();
    }
  }, [application, closeAll]);

  useEffect(() => {
    if (triggerOpen) {
      onOpen();
      if (onOpenAction) onOpenAction();
    } else if (onCloseAction) onCloseAction();
  }, [onOpen, triggerOpen, onCloseAction, onOpenAction]);

  return (
    <Collapse in={triggerOpen} animateOpacity>
      <Collapse in={isOpen} animateOpacity>
        <form style={{ width: '100%' }}>
          <Stack color="text.500" alignItems="center" mb={10} spacing={8}>
            <Stack w="90%">
              <FormControl>
                <FormLabel>Valor a ser sacado</FormLabel>
                <Input
                  placeholder="0.0000"
                  color="#000"
                  value={valueFrom}
                  onChange={e => {
                    let { value } = e.currentTarget;
                    const decimals = coin === 'BRL' || coin === 'USDT' ? 2 : 6;
                    value = value.replace(/\D/g, '');
                    value = value.padStart(decimals, '0');
                    value = [
                      value.slice(0, value.length - decimals),
                      '.',
                      value.slice(value.length - decimals),
                    ].join('');
                    if (value[0] === '0') value = value.slice(1, value.length);

                    e.currentTarget.value = value;
                    setValueFrom(value);
                  }}
                />
                {coin && (
                  <Skeleton isLoaded={!!data}>
                    <Button
                      variant="link"
                      onClick={() => setValueFrom(data?.income || '0')}
                    >
                      <Text fontSize="sm" mt={1}>
                        Sacar toda rentabilidade: {`${data?.income} `}
                        {coin}
                      </Text>
                    </Button>
                  </Skeleton>
                )}
              </FormControl>

              <FormControl mt={2}>
                <FormLabel>Endereço da Carteira</FormLabel>
                <Input
                  placeholder="Endereço"
                  color="#000"
                  value={addressTo}
                  onChange={e => setAddressTo(e.target.value)}
                />
              </FormControl>
            </Stack>

            <Stack spacing={4}>
              <Button
                type="submit"
                onClick={handleAction}
                disabled={valueFrom === '0' || !coin}
                colorScheme="brandGray"
              >
                Sacar
              </Button>
              <Button ml={3} onClick={closeAll} variant="link">
                Cancelar
              </Button>
            </Stack>
          </Stack>
        </form>
      </Collapse>

      <Collapse in={isOpenConfirm} animateOpacity>
        <form style={{ width: '100%' }}>
          <Stack color="text.500" alignItems="center" mb={10} spacing={8}>
            <Stack w="90%">
              <Stack spacing={1}>
                <Text>Valor a ser sacado</Text>
                <ScrollDrag>
                  <Text as="strong" fontSize="4xl" color="brand.800">
                    <strong>
                      {Number(valueFrom).toFixed(6)}
                      {coin}
                    </strong>
                  </Text>
                </ScrollDrag>
              </Stack>

              <HStack>
                <Text>Wallet:</Text>
                <ScrollDrag>
                  <Text color="brand.800">
                    <strong>{addressTo}</strong>
                  </Text>
                </ScrollDrag>
              </HStack>

              <Box mt={8}>
                <FormControl>
                  <FormLabel>Digite seu código 2FA</FormLabel>
                  <Input
                    type="text"
                    color="#000"
                    value={twofa}
                    onChange={e => setTwofa(e.target.value)}
                  />
                </FormControl>
              </Box>
            </Stack>

            <Stack spacing={4}>
              <Button
                type="submit"
                onClick={handleSubmit}
                colorScheme="brandGray"
                isLoading={applicationLoading}
              >
                Confirmar
              </Button>
              <Button ml={3} onClick={closeConfirm} variant="link">
                Cancelar
              </Button>
            </Stack>
          </Stack>
        </form>
      </Collapse>
    </Collapse>
  );
}
