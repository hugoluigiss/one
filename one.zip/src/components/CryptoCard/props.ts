export default interface ActionProps {
  coin: string;
  onOpenAction?: () => void;
  onCloseAction?: () => void;
}

export type ActionTypes =
  | ''
  | 'withdraw'
  | 'apply'
  | 'apply-from-income'
  | 'wallet';
