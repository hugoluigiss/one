/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import { InputHTMLAttributes, useState } from 'react';

import { Container, EyeOpen, EyeClose } from '../styles';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  errorText?: string;
  error?: boolean;
}

export default function InputPassword({
  errorText,
  ...rest
}: InputProps): JSX.Element {
  const [showPass, setShowPass] = useState(false);

  const handleEye = (): void => {
    setShowPass(!showPass);
  };

  return (
    <Container>
      <div className="inputPasswordContainer">
        <input type={showPass ? 'text' : 'password'} {...rest} />
        {showPass ? (
          <EyeOpen onClick={handleEye} />
        ) : (
          <EyeClose onClick={handleEye} />
        )}
        {/* <div
          onClick={handleEye}
          className={showPass ? 'eyeOpen' : 'eyeClose'}
        /> */}
      </div>
      {errorText && <span style={{ color: 'red' }}>{errorText}</span>}
    </Container>
  );
}
