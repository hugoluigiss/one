import { InputHTMLAttributes } from 'react';

import { Container } from '../styles';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  errorText?: string;
  error?: boolean;
  dark?: boolean;
}

export default function InputText({
  dark,
  errorText,
  ...rest
}: InputProps): JSX.Element {
  return (
    <Container isDark={dark}>
      <input {...rest} />
      {errorText && <span style={{ color: 'red' }}>{errorText}</span>}
    </Container>
  );
}
