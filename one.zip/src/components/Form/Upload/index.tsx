/* eslint-disable react/require-default-props */
import { ReactNode, useCallback, useEffect } from 'react';
import Dropzone from 'react-dropzone';

import { FiUploadCloud } from 'react-icons/fi';
import { useUploadFile } from '../../../hooks/useUploadFile';

import { DropContainer, UploadMessage } from './styles';

interface UploadProps {
  setFileName: (file: string) => void;
}

export default function Upload({
  setFileName,
}: // fileUrl = '',
UploadProps): JSX.Element {
  const [setFile, fileInfo, uploadProgress, uploading] = useUploadFile();

  useEffect(() => {
    if (fileInfo && fileInfo.filename) setFileName(fileInfo.filename);
  }, [fileInfo, setFileName]);
  // const [file, setFile] = useState('');

  // const [selectedFileUrl, setSelectedFileUrl] = useState(fileUrl);

  function renderDragMessage(
    isDragActive: boolean,
    isDragRejest: boolean,
  ): ReactNode {
    if (!isDragActive) {
      return (
        <UploadMessage>
          <FiUploadCloud size={24} />
          Selecionar arquivo.
        </UploadMessage>
      );
    }

    if (isDragRejest) {
      return <UploadMessage type="error">Arquivo nao aceito</UploadMessage>;
    }
    return <UploadMessage type="success">Selecionar arquivo</UploadMessage>;
  }

  const handlerUpload = useCallback(
    (files: File[]) => {
      if (files[0]) setFile(files[0]);
      // setFile(URL.createObjectURL(files[0]));
      // onUpload(files[0]);
      // setSelectedFileUrl(files[0].path);
    },
    [setFile],
  );

  return (
    <div style={{ marginBottom: 12 }}>
      <Dropzone
        accept={{ 'image/*': [], 'application/pdf': [] }}
        onDropAccepted={files => handlerUpload(files)}
        multiple={false}
      >
        {({ getRootProps, getInputProps, isDragActive, isDragReject }): any => (
          <DropContainer
            {...getRootProps()}
            isDragActive={isDragActive}
            isDragReject={isDragReject}
          >
            <input {...getInputProps()} data-testid="upload" />

            {!uploading && renderDragMessage(isDragActive, isDragReject)}

            {uploading && <p>{uploadProgress}</p>}

            {!uploading &&
              fileInfo &&
              fileInfo.filename.indexOf('.pdf') === -1 && (
                <img src={fileInfo.file_url} alt="point thumbnail" />
              )}

            {fileInfo && fileInfo.filename.indexOf('.pdf') !== -1 && (
              <embed src={fileInfo.file_url} />
            )}
          </DropContainer>
        )}
      </Dropzone>
    </div>
  );
}
