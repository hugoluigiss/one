/* eslint-disable react/jsx-closing-tag-location */
/* eslint-disable react/jsx-wrap-multilines */
import {
  Avatar,
  Text,
  SkeletonCircle,
  SkeletonText,
  Stack,
  HStack,
  Menu,
  MenuButton,
  MenuList,
  Hide,
  Show,
  Tooltip,
  Box,
  MenuItem,
  // Box,
  // Tooltip,
} from '@chakra-ui/react';
import { NavLink } from 'react-router-dom';
import useGet from '../../../hooks/useGet';
import { Unilevel, User } from '../../../services/apitypes';
import Logo from '../../Logo';

import {
  AppbarContainer,
  RightContainer,
  NotifContainer,
  NotifIcon,
  NotifBadge,
  ActionBox,
  ProfileBox,
} from './styles';

interface AppbarProps {
  me: User | undefined;
  collapse: boolean;
}

export default function AppBar({ me, collapse }: AppbarProps): JSX.Element {
  const [{ data }] = useGet<Unilevel>('/unilevel/uplines');

  const consultant = data?.higher;

  const manager = consultant?.higher;

  return (
    <Stack
      color="text.500"
      ml={['0', '0', collapse ? '120px' : '257px']}
      w={[
        '100%',
        '100%',
        collapse ? 'calc(100vw - 120px)' : 'calc(100vw - 259px)',
      ]}
      h="86px"
      position="relative"
      transition="200ms"
      bg="brandBg.500"
      zIndex={10}
    >
      <AppbarContainer>
        <Hide below="md">
          <Tooltip
            label={
              <Stack py={2}>
                <Text>
                  <strong>- Consultor:</strong>{' '}
                  {consultant?.user.personal_document?.first_name}
                </Text>
                <Text>
                  <strong>- Telefone:</strong> {consultant?.user.phone_number}
                </Text>
                <Text>
                  <strong>- E-mail:</strong> {consultant?.user.email}
                </Text>
              </Stack>
            }
          >
            <Box
              ml={12}
              py="12px"
              px="24px"
              bg="brandBg.900"
              borderWidth={1}
              borderRadius="10px"
              borderColor="cardBorder.500"
              overflowX="auto"
            >
              <Text>
                {manager && `Unidade: ${manager?.user.username} |`}
                {` Consultor: ${data?.user.username}`}
              </Text>
            </Box>
          </Tooltip>
          <div />
        </Hide>
        <Show below="md">
          <Stack ml={[4, 12]}>
            <Menu offset={[0, -15]}>
              <MenuButton>
                <Logo collapse />
              </MenuButton>
              <MenuList>
                <Stack py={2} px={2} color="brandBg.500">
                  <Text>
                    <strong>- Consultor:</strong>{' '}
                    {consultant?.user.personal_document?.first_name}
                  </Text>
                  <Text>
                    <strong>- Telefone:</strong> {consultant?.user.phone_number}
                  </Text>
                  <Text>
                    <strong>- E-mail:</strong> {consultant?.user.email}
                  </Text>
                </Stack>
              </MenuList>
            </Menu>
          </Stack>
        </Show>
        <RightContainer>
          <ActionBox>
            <Menu>
              <MenuButton>
                <NotifContainer>
                  <NotifIcon />
                  {(!me?.account || me?.account?.status !== 'approved') && (
                    <NotifBadge>!</NotifBadge>
                  )}
                </NotifContainer>
              </MenuButton>
              <MenuList color="brandBg.500">
                {!me?.account ? (
                  <NavLink to="/profile">
                    <MenuItem>
                      Conta inativa, entre em contato com o suporte
                    </MenuItem>
                  </NavLink>
                ) : null}
                {me?.account && me?.account?.status === 'pending' ? (
                  <NavLink to="/profile">
                    <MenuItem>Documentação pendente</MenuItem>
                  </NavLink>
                ) : (
                  <Text ml={10}>Não há notificações</Text>
                )}
              </MenuList>
            </Menu>
          </ActionBox>
          <ProfileBox>
            <NavLink to="/profile/0">
              <HStack>
                <SkeletonCircle isLoaded={!!me} size="12">
                  <Avatar
                    size="md"
                    name={me?.email}
                    src={`https://ui-avatars.com/api/?name=${me?.email}`}
                  />
                </SkeletonCircle>
                <Hide below="md">
                  <SkeletonText isLoaded={!!me} noOfLines={2}>
                    <Stack minW={20} spacing={0.4}>
                      <Text color="white">{`Olá, ${
                        me?.personal_document?.first_name || 'Usuário'
                      }`}</Text>
                      <Text color="#cbcdd4">{me?.email}</Text>
                    </Stack>
                  </SkeletonText>
                </Hide>
              </HStack>
            </NavLink>
          </ProfileBox>
        </RightContainer>
      </AppbarContainer>
    </Stack>
  );
}
