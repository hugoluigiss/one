import {
  Flex,
  Stack,
  Text,
  Spacer,
  Button,
  HStack,
  Hide,
  Show,
} from '@chakra-ui/react';
// import { GoPrimitiveDot } from 'react-icons/go';
import { FaInstagram, FaWhatsapp } from 'react-icons/fa';
import { MdEmail, MdLocationPin } from 'react-icons/md';
import Logo from '../../Logo';

export default function Footer() {
  return (
    <Stack color="text.800" mb={['90px', '90px', '0']}>
      <Flex
        borderTop="2px"
        borderTopColor="cardBorder.500"
        p="2px 8px"
        h={['110px', '110px', '300px']}
      >
        <Hide below="md">
          <Stack w="407px" alignItems="center" justifyContent="center">
            <Logo />
          </Stack>
        </Hide>
        <Show below="md">
          <Stack w="100px" pl={4} alignItems="start" justifyContent="center">
            <Logo collapse />
          </Stack>
        </Show>
        <Spacer />
        <Hide below="lg">
          <Stack w="350px" justifyContent="center">
            <Text>Siga-nos</Text>
            <Stack pl={2} alignItems="start" justifyContent="center">
              {/* <Button colorScheme="text.800" variant="link" height="20px">
                <FaTwitter />
                <Text>/onealliance</Text>
              </Button>
              <Button colorScheme="text.800" variant="link" height="20px">
                <MdLanguage />
                <Text>onealliance.com.br</Text>
              </Button>

              <Button colorScheme="text.800" variant="link" height="20px">
                <FaFacebook />
                <Text>/onealliance</Text>
              </Button> */}

              <a
                href="https://instagram.com/onealliance_oficial"
                target="_blank"
                rel="noreferrer"
              >
                <Button colorScheme="text.800" variant="link" height="20px">
                  <FaInstagram />
                  <Text>/onealliance</Text>
                </Button>
              </a>
            </Stack>
          </Stack>
          <Spacer />
        </Hide>
        <Hide below="md">
          <Stack w="350px" justifyContent="center">
            <Text>Fale conosco</Text>
            <Stack pl={2} justifyContent="center">
              <HStack>
                <FaWhatsapp /> <Text>(84) 98173-3506</Text>
              </HStack>
              <HStack>
                <MdEmail />
                <Text>ouvidoria@onealliance.app</Text>
              </HStack>

              <HStack>
                <MdLocationPin />{' '}
                <Text>
                  Rua Cel Auris Coelho, 45 - Lagoa Nova, Natal/RN - Cep:
                  59075-050
                </Text>
              </HStack>
            </Stack>
          </Stack>
          <Spacer />
        </Hide>

        {/* <Stack
          w="350px"
          direction={['column', 'row']}
          alignItems={['end', 'start']}
          justifyContent="center"
          mt={2}
        >
          <Button colorScheme="text.800" variant="link" height="20px">
            Política de Privacidade
          </Button>
          <Hide below="sm">
            <Stack pt={1}>
              <GoPrimitiveDot />
            </Stack>
          </Hide>
          <Button colorScheme="text.800" variant="link" height="20px">
            Termos de Uso
          </Button>
        </Stack> */}
      </Flex>
      <Stack alignItems="center" pb={2}>
        <Text textAlign="center">
          Copyright 2022 © One Alliance. Todos os Direitos Reservados.
        </Text>
      </Stack>
    </Stack>
  );
}
