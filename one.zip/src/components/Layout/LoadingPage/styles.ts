import styled from 'styled-components';
import bg from '../../../assets/images/bg-image.png';

export const Container = styled.div`
  width: 100vw;
  height: 100vh;

  overflow-x: hidden;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  background-image: url(${bg});
`;

export const LogoAnimated = styled.div`
  @keyframes breath {
    0% {
      opacity: 1;
    }

    100% {
      opacity: 0;
    }
  }

  animation: breath 5s alternate infinite;
`;
