import { useAuth } from '../../../../hooks/useAuth';
import {
  Container,
  ItemMenu,
  Dashboard,
  Extract,
  Contracts,
  SingOutContainer,
  SignOut,
} from './styles';

export default function MenuMobile(): JSX.Element {
  const { setToken } = useAuth();

  return (
    <Container>
      <ItemMenu to="/dashboard">
        <Dashboard />
        <span>Dashboard</span>
      </ItemMenu>

      <ItemMenu to="/extract">
        <Extract />
        <span>Extrato</span>
      </ItemMenu>

      <ItemMenu to="/contracts">
        <Contracts />
        <span>Meus Contratos</span>
      </ItemMenu>

      <SingOutContainer
        onClick={async () => {
          setToken(null);
        }}
      >
        <SignOut />
      </SingOutContainer>
    </Container>
  );
}
