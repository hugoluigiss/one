import styled from 'styled-components';
import { NavLink } from 'react-router-dom';
import {
  DashboardIcon,
  ExtractIcon,
  ContractsIcon,
  SignOutIcon,
} from '../icons';

export const ItemMenu = styled(NavLink)`
  position: relative;

  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  text-decoration: none;
  user-select: none;
  cursor: pointer;
  transition: 200ms;

  font-family: 'Roboto';

  span {
    display: block;
    transition: 200ms;
    visibility: visible;
    color: #a8aab4;

    font-weight: 400;
    font-size: 10px;
    margin-top: 8px;
  }

  &.active {
    span {
      color: #fff;
    }

    svg {
      stroke: #fff;
      fill: #fff;
    }
  }

  &:hover {
    span {
      color: #fff;
    }

    svg {
      stroke: #fff;
      fill: #fff;
    }
  }
`;

export const SingOutContainer = styled.div`
  position: relative;

  box-sizing: border-box;

  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  text-decoration: none;
  user-select: none;
  cursor: pointer;
  transition: 200ms;

  font-family: 'Roboto';

  span {
    display: block;
    transition: 200ms;
    visibility: visible;
    color: #a8aab4;

    font-weight: 400;
    font-size: 16px;
    margin-left: 14px;
  }

  &.active {
    span {
      color: #fff;
    }

    svg {
      stroke: #fff;
      fill: #fff;
    }
  }

  &:hover {
    span {
      color: #fff;
    }

    svg {
      stroke: #fff;
      fill: #fff;
    }
  }
`;

export const BackLayerOpen = styled.div`
  transition: 200ms;
  opacity: 1;
  visibility: visible;
  backdrop-filter: blur(9px);
  background-color: rgba($color: #000, $alpha: 0.6);
`;

export const Container = styled.div`
  background: #1f2128;
  position: fixed;
  bottom: 0;
  width: 100vw;
  height: 80px;
  left: 0;
  box-sizing: border-box;
  transition: 300ms all;
  z-index: 10;
  display: flex;
  justify-content: space-around;
  align-items: center;

  transition: 200ms;
`;

export const Dashboard = styled(DashboardIcon)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  transition: 200ms;

  stroke: #a8aab4;
  fill: #a8aab4;
`;

export const Extract = styled(ExtractIcon)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  transition: 200ms;

  stroke: #a8aab4;
  fill: #a8aab4;
`;

export const Contracts = styled(ContractsIcon)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  transition: 200ms;
  stroke: #a8aab4;
  fill: #a8aab4;
`;

export const SignOut = styled(SignOutIcon)`
  display: block;
  height: 24px;
  width: 24px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  transition: 200ms;
  fill: #a8aab4;
  stroke: #a8aab4;
`;
