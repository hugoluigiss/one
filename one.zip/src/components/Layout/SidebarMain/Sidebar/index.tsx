import { Stack, Tooltip } from '@chakra-ui/react';
import { useAuth } from '../../../../hooks/useAuth';
import Logo from '../../../Logo';
import {
  Container,
  Content,
  Toggle,
  ItemMenu,
  Dashboard,
  Extract,
  Contracts,
  SingOutContainer,
  SignOut,
} from './styles';

interface AppbarProps {
  collapse: [boolean, React.Dispatch<React.SetStateAction<boolean>>];
}

export default function Sidebar({ collapse }: AppbarProps): JSX.Element {
  const [isCollapsed, setIsCollapsed] = collapse;

  const { setToken } = useAuth();

  const handleMenu = (): void => {
    setIsCollapsed(!isCollapsed);
  };

  return (
    <Container isCollapsed={!!isCollapsed}>
      <Stack pb="2" alignItems="center">
        <Logo collapse={!!isCollapsed} />
        <Toggle onClick={handleMenu} collapse={!!isCollapsed} />
      </Stack>

      <Content>
        <Tooltip label="Dashboard">
          <ItemMenu to="/dashboard">
            <Dashboard />
            <span>Dashboard</span>
          </ItemMenu>
        </Tooltip>

        <Tooltip label="Extrato">
          <ItemMenu to="/extract">
            <Extract />
            <span>Extrato</span>
          </ItemMenu>
        </Tooltip>

        <Tooltip label="Meus Contratos">
          <ItemMenu to="/contracts">
            <Contracts />
            <span>Meus Contratos</span>
          </ItemMenu>
        </Tooltip>

        <SingOutContainer
          onClick={async () => {
            setToken(null);
          }}
        >
          <SignOut />
          <span>Sair</span>
        </SingOutContainer>
      </Content>
    </Container>
  );
}
