import styled, { css } from 'styled-components';
import { NavLink } from 'react-router-dom';
import {
  DashboardIcon,
  ExtractIcon,
  ContractsIcon,
  SignOutIcon,
} from '../icons';
import { ReactComponent as BurgerMenu } from '../../../../assets/icons/sidebar/burger-menu.svg';
import { appearFromLeft, hideToLeft } from '../../../../styles/animations';

export const ItemMenu = styled(NavLink)`
  position: relative;

  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: start;

  height: 30px;

  text-decoration: none;
  user-select: none;
  cursor: pointer;
  transition: 200ms;

  margin: 0 0 34px 27px;

  font-family: 'Roboto';

  span {
    position: absolute;
    display: block;
    transition: 200ms;
    visibility: visible;
    color: #a8aab4;

    font-weight: 400;
    font-size: 16px;
    left: 32px;

    animation: ${appearFromLeft} 500ms ease forwards;
  }

  &.active {
    span {
      color: #fff;
    }

    svg {
      stroke: #fff;
      fill: #fff;
    }

    &::before {
      content: '';

      position: absolute;
      left: -32px;

      width: 10px;
      height: 10px;
      border-radius: 50%;

      background: #fff;
    }

    &::after {
      content: '';

      position: absolute;
      left: -42px;

      width: 30px;
      height: 30px;
      border-radius: 50%;

      animation: pulse 2s ease infinite;

      background: radial-gradient(#ffffffcc, #ffffff5c, #ffffff00);
    }

    @keyframes pulse {
      0% {
        transform: scale(0.7, 0.7);
        opacity: 0;
      }
      50% {
        transform: scale(1, 1);
        opacity: 1;
      }
      100% {
        transform: scale(0.7, 0.7);
        opacity: 0;
      }
    }
  }

  &:hover {
    span {
      color: #fff;
    }

    svg {
      stroke: #fff;
      fill: #fff;
    }
  }
`;

export const SingOutContainer = styled.div`
  border-top: 1px solid #7e7e83;

  position: relative;

  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: end;

  text-decoration: none;
  user-select: none;
  cursor: pointer;
  transition: 200ms;

  margin: 32px 24px;
  padding-top: 34px;

  font-family: 'Roboto';

  span {
    position: absolute;
    display: block;
    transition: 200ms;
    visibility: visible;
    color: #a8aab4;

    font-weight: 400;
    font-size: 16px;
    margin-left: 14px;

    animation: ${appearFromLeft} 500ms ease forwards;
  }

  svg {
    margin-right: 40px;
    height: 18px;
    width: 18px;
  }

  &.active {
    span {
      color: #fff;
    }

    svg {
      stroke: #fff;
      fill: #fff;
    }
  }

  &:hover {
    span {
      color: #fff;
    }

    svg {
      stroke: #fff;
      fill: #fff;
    }
  }
`;

interface ItemMenuProps {
  isCollapsed?: boolean;
}
export const Container = styled.div<ItemMenuProps>`
  background: #1f2128;
  border-right: 1px solid #3d404b;
  position: fixed;
  width: ${props => (props.isCollapsed ? 120 : 257)}px;
  height: 100vh;
  top: 0;
  left: 0;
  box-sizing: border-box;
  transition: 300ms all;
  z-index: 10;
  display: flex;
  flex-direction: column;
  transition: all 200ms;

  ${props =>
    props.isCollapsed &&
    css`
      ${ItemMenu} > span {
        animation: ${hideToLeft} 250ms ease forwards;
      }

      ${ItemMenu} > svg {
        width: 34px;
        height: 34px;
        margin-left: 13px;
      }

      ${ItemMenu} {
        margin-bottom: 64px;
      }

      ${SingOutContainer} > span {
        animation: ${hideToLeft} 500ms ease forwards;
      }

      ${SingOutContainer} > svg {
        width: 34px;
        height: 34px;
        margin-left: 12px;
        margin-right: 0;
      }

      ${SingOutContainer} {
        justify-content: start;
        padding-top: 64px;
      }
    `}
`;

export const Content = styled.div`
  margin-top: 32px;
  overflow: hidden;
  scrollbar-width: thin;

  &:hover {
    overflow-y: auto;
  }
`;

interface ToggleProps {
  collapse: boolean;
}
export const Toggle = styled(BurgerMenu)<ToggleProps>`
  display: block;
  height: 40px;
  width: 40px;
  margin: 0 0 34px 27px;
  padding: 8px;

  position: absolute;
  right: -24px;
  top: 20px;

  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  transition: 200ms;

  stroke: #3d404b;
  background: #1f2128;
  border: 2px solid #3d404b;
  border-radius: 50%;
  cursor: pointer;

  transition: 200ms;
  transform: rotateZ(${props => (props.collapse ? '180deg' : '0deg')});
`;

export const Dashboard = styled(DashboardIcon)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  transition: 200ms;

  stroke: #a8aab4;
`;

export const Extract = styled(ExtractIcon)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  transition: 200ms;

  stroke: #a8aab4;
  fill: #a8aab4;
`;

export const Contracts = styled(ContractsIcon)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  transition: 200ms;
  fill: #a8aab4;
`;

export const SignOut = styled(SignOutIcon)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  transition: 200ms;
  fill: #a8aab4;
  stroke: #a8aab4;
`;
