import styled, { css } from 'styled-components';
import { NavLink } from 'react-router-dom';
import { DashboardIcon, ExtractIcon, ClientsIcon } from '../icons';

export const ItemMenu = styled(NavLink)`
  position: relative;

  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: start;

  height: 30px;

  text-decoration: none;
  user-select: none;
  cursor: pointer;
  transition: 200ms;

  margin: 0 0 34px 27px;

  font-family: 'Roboto';

  span {
    display: block;
    transition: 200ms;
    visibility: visible;
    color: #a8aab4;

    font-weight: 400;
    font-size: 16px;
    margin-left: 14px;
  }

  &.active {
    span {
      color: #fff;
    }

    svg {
      stroke: #fff;
    }

    &::before {
      content: '';

      position: absolute;
      left: -32px;

      width: 10px;
      height: 10px;
      border-radius: 50%;

      background: #fff;
    }

    &::after {
      content: '';

      position: absolute;
      left: -42px;

      width: 30px;
      height: 30px;
      border-radius: 50%;

      animation: pulse 2s ease infinite;

      background: radial-gradient(#ffffffcc, #ffffff5c, #ffffff00);
    }

    @keyframes pulse {
      0% {
        transform: scale(0.7, 0.7);
        opacity: 0;
      }
      50% {
        transform: scale(1, 1);
        opacity: 1;
      }
      100% {
        transform: scale(0.7, 0.7);
        opacity: 0;
      }
    }
  }

  &:hover {
    span {
      color: #fff;
    }

    svg {
      stroke: #fff;
    }
  }
`;

export const BackLayerOpen = styled.div`
  transition: 200ms;
  opacity: 1;
  visibility: visible;
  backdrop-filter: blur(9px);
  background-color: rgba($color: #000, $alpha: 0.6);
`;

interface ItemMenuProps {
  isCollapsed?: boolean;
}
export const Container = styled.div<ItemMenuProps>`
  transform: translateX(0%);

  background: #212226;
  position: fixed;
  top: 80px;
  width: 257px;
  height: calc(100vh - 80px);
  left: 0;
  box-sizing: border-box;
  transition: 300ms all;
  z-index: 10;
  display: flex;
  flex-direction: column;
  padding-top: 12px;
  transition: 200ms;

  ${props =>
    props.isCollapsed &&
    css`
      transform: translateX(-100%);
    `}
`;

export const TopContainer = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;

  align-items: center;
  margin-bottom: 24px;
`;

export const UserLink = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;

  cursor: pointer;
  overflow: hidden;

  height: 52px;
  width: 90%;
  max-width: 463px;
  border-radius: 100px;
  padding: 0 26px;
  margin-bottom: 12px;

  background: #ffffff1f;
  border: 1px solid #ffffff33;

  font-family: 'Lato';

  span {
    color: #fff;
    font-size: 14px;
  }
`;

export const InfoContainer = styled.div`
  display: flex;
  flex-direction: column;
`;

export const Content = styled.div`
  overflow-y: auto;

  scrollbar-width: thin;
`;

export const Dashboard = styled(DashboardIcon)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  transition: 200ms;

  stroke: #fff;
`;

export const Extract = styled(ExtractIcon)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  transition: 200ms;

  stroke: #fff;
  fill: #fff;
`;

export const Clients = styled(ClientsIcon)`
  display: block;
  height: 20px;
  width: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  transition: 200ms;
  stroke: #fff;
`;

export const SignOut = styled.div`
  margin: 0 0 34px 27px;

  color: #fff;
  cursor: pointer;
  width: fit-content;
`;
