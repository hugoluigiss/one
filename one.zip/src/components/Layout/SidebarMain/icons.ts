import { ReactComponent as Dashboard } from '../../../assets/icons/sidebar/dashboard.svg';
import { ReactComponent as Extract } from '../../../assets/icons/sidebar/extract.svg';
import { ReactComponent as Clients } from '../../../assets/icons/sidebar/clients.svg';
import { ReactComponent as Contracts } from '../../../assets/icons/sidebar/contracts.svg';
import { ReactComponent as SignOut } from '../../../assets/icons/sidebar/signout.svg';

export const DashboardIcon = Dashboard;
export const ExtractIcon = Extract;
export const ClientsIcon = Clients;
export const ContractsIcon = Contracts;
export const SignOutIcon = SignOut;
