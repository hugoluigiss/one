import React from 'react';

import Container from './styles';

type TagProps = {
  children: React.ReactNode;
};

export default function Tag({ children }: TagProps) {
  return <Container>{children}</Container>;
}
