/* eslint-disable jsx-a11y/iframe-has-title */
import React from 'react';

import { Container, ContentContainer, Content } from './styles';

const CoinsCarousel: React.FC = () => {
  return (
    <Container>
      <div className="leftBlur" />
      <ContentContainer>
        <Content>
          <iframe
            src="https://widget.coinlib.io/widget?type=horizontal_v2&theme=dark&pref_coin_id=1505&invert_hover=no"
            width="100%"
            height="36px"
            scrolling="auto"
          />
        </Content>
      </ContentContainer>
      <div className="rightBlur" />
    </Container>
  );
};

export default CoinsCarousel;
