import React, { useEffect, useState } from 'react';
import { CoinsType } from '../../../services/apitypes';

import Container from './styles';

type CurrecyProps = {
  currency?: string;
  iconName: CoinsType;
  color?: string;
  collapsed?: boolean;
};

const CurrencyWithIcon: React.FC<CurrecyProps> = ({
  currency,
  iconName,
  color = '#fff',
  collapsed = false,
  ...rest
}: CurrecyProps) => {
  const styleBG = `/icons/coins/${iconName.toLocaleLowerCase()}.svg`;
  const [cryptoName, setCryptoName] = useState('');

  const getCryptoName = (coin: CoinsType): string => {
    if (coin === 'BTC') return 'Biticoin';
    if (coin === 'ETH') return 'Ethereum';
    if (coin === 'BNB') return 'Bnb';
    if (coin === 'USDT') return 'USDT';

    return '';
  };

  useEffect(() => {
    setCryptoName(getCryptoName(iconName));
  }, [iconName]);

  return (
    <Container color={color} {...rest}>
      <div
        className="icon"
        style={{
          backgroundImage: `${styleBG}`,
          backgroundColor: color,
          WebkitMask: `url(${styleBG}) no-repeat center`,
          mask: `url(${styleBG}) no-repeat center`,
          borderRadius: '50%',
          padding: '14px',
        }}
      />
      {/* <img className="icon" src={styleBG} alt="coin" /> */}
      {!collapsed && (
        <div className="labelInfo">
          <h1>{currency || cryptoName}</h1>
          <h2>{iconName}</h2>
        </div>
      )}
    </Container>
  );
};

export default CurrencyWithIcon;
