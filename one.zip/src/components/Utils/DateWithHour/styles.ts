import styled from 'styled-components';

export default styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;

  h3 {
    color: #fbfbfb;
    margin: 0 4px;
  }

  span {
    color: #fbfbfb;
    margin: 0 4px;
  }
`;
