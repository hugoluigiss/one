/* eslint-disable react/require-default-props */
import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { FiUpload } from 'react-icons/fi';

import Container from './styles';

interface IProps {
  onFileUploaded: (file: File) => void;
  fileUrl?: string;
}

export default function Dropzone({
  onFileUploaded,
  fileUrl = '',
}: IProps): JSX.Element {
  const [selectedFileUrl, setSelectedFileUrl] = useState('');

  React.useEffect(() => setSelectedFileUrl(fileUrl), [fileUrl]);

  const onDrop = useCallback(
    (acceptedFiles: any[]) => {
      const file = acceptedFiles[0];

      const file_url = URL.createObjectURL(file);
      setSelectedFileUrl(file_url);
      onFileUploaded(file);
    },
    [onFileUploaded],
  );

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png'],
      'application/pdf': ['.pdf'],
    },
  });

  return (
    <Container {...getRootProps()}>
      <input {...getInputProps()} accept="image/*" />
      {selectedFileUrl ? (
        <img src={selectedFileUrl} alt="point thumbnail" />
      ) : (
        <p
          style={{
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <FiUpload />
          Selecione ou arraste o arquivo aqui
        </p>
      )}
    </Container>
  );
}
