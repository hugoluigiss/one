import { Text } from '@chakra-ui/react';

interface TextProps {
  children: React.ReactNode;
}

export default function SmallText({ children }: TextProps) {
  return (
    <Text fontSize="sm" color="gray.700">
      {children}
    </Text>
  );
}
