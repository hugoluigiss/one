import React from 'react';
import app from '../config/app';

export interface AuthContextData {
  token: string | null;
  setToken: (t: string | null) => void;
}

export const AuthContext = React.createContext<AuthContextData>(
  {} as AuthContextData,
);

export function AuthProvider({
  children,
}: {
  children: React.ReactNode;
}): JSX.Element {
  const [token, setToken] = React.useState<string | null>(() => {
    return localStorage.getItem(app.local_storage_token_key);
  });

  React.useEffect(() => {
    if (token) localStorage.setItem(app.local_storage_token_key, token);
    if (!token) localStorage.removeItem(app.local_storage_token_key);
  }, [token]);

  return (
    <AuthContext.Provider value={{ token, setToken }}>
      {children}
    </AuthContext.Provider>
  );
}
