/* eslint-disable import/prefer-default-export */
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'react-toastify';

export function useAddressFinder(defaultValue: string | (() => string)): [
  {
    zip_code: string;
    state: string;
    city: string;
    district: string;
    street: string;
    number: string;
    complement?: string;
  },
  React.Dispatch<React.SetStateAction<string>>,
  React.Dispatch<
    React.SetStateAction<{
      zip_code: string;
      state: string;
      city: string;
      district: string;
      street: string;
      number: string;
      complement?: string;
    }>
  >,
] {
  const [zipCode, setZipCode] = useState(() => {
    if (typeof defaultValue === 'function') return defaultValue();
    return defaultValue;
  });

  const [address, setAddress] = useState<{
    zip_code: string;
    state: string;
    city: string;
    district: string;
    street: string;
    number: string;
    complement?: string;
  }>({
    zip_code: '',
    state: '',
    city: '',
    district: '',
    street: '',
    number: '',
    complement: '',
  });
  const handleSearchZipcode = useCallback((cep: string) => {
    fetch(`https://viacep.com.br/ws/${cep}/json/`, { mode: 'cors' })
      .then(response => response.json())
      .then(response => {
        if (response.erro) toast.error('Cep não encontrado');
        else
          setAddress(state => ({
            ...state,
            city: response?.localidade || '',
            complement: response?.complemento || '',
            district: response?.bairro || '',
            state: response?.uf || '',
            street: response?.logradouro || '',
            zip_code: response?.cep?.replace(/\D/g, '') || '',
            number: '',
          }));
      })
      .catch(() => toast.info('Erro ao pesquisar CEP, verifique sua conexção'));
  }, []);

  useEffect(() => {
    const parsed_cep = zipCode.replace(/\D/g, '').slice(0, 8);
    if (parsed_cep.length === 8) handleSearchZipcode(parsed_cep);
  }, [handleSearchZipcode, zipCode]);

  return [address, setZipCode, setAddress];
}
