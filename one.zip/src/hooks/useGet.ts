import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import FetchApi from '../services/FetchApi';
import { useAuth } from './useAuth';

interface IParams {
  [key: string]: string | number;
}

const instance = FetchApi.getInstance();

export default function useGet<T>(
  defaultPath: string | (() => string),
  defaultParams?: IParams | (() => IParams),
): [
  { loading: boolean; data?: T },
  React.Dispatch<React.SetStateAction<IParams>>,
  IParams,
] {
  const { setToken, token } = useAuth();
  const [path] = useState<string>(() => {
    if (typeof defaultPath === 'function') return defaultPath();
    return defaultPath;
  });
  const [params, setParams] = useState<IParams>(() => {
    if (typeof defaultParams === 'function') return defaultParams();
    return defaultParams || {};
  });
  const [response, setResponse] = useState<{ loading: boolean; data?: T }>({
    loading: false,
    data: undefined,
  });

  useEffect(() => {
    setResponse({ loading: true, data: undefined });

    instance.get<T>({ path, params, token }).then(res => {
      if (res.error) {
        toast.error(res.error.message);
        if (res.error.status === 401 && !!token) setToken(null);
      }

      setResponse({ loading: false, data: res.data });
    });
  }, [params, path, setToken, token]);

  return [response, setParams, params];
}
