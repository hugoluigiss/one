import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import FetchApi from '../services/FetchApi';
import AppResponse from '../services/AppResponse';
import { useAuth } from './useAuth';

export interface IBody {
  [key: string]: string | { [key: string]: string | boolean } | boolean;
}

const instance = FetchApi.getInstance();

export default function usePost<T>(defaultPath: string | (() => string)): [
  {
    loading: boolean;
    data?: T;
  },
  React.Dispatch<React.SetStateAction<IBody>>,
] {
  const { setToken, token } = useAuth();
  const [response, setResponse] = useState<{
    loading: boolean;
    data?: T;
  }>({
    loading: false,
    data: undefined,
  });
  const [body, setBody] = useState<IBody>(undefined as unknown as IBody);
  const [path] = useState<string>(() => {
    if (typeof defaultPath === 'function') return defaultPath();
    return defaultPath;
  });
  useEffect(() => {
    if (body) {
      instance.post<T>({ path, body, token }).then((res: AppResponse) => {
        if (res.error) {
          toast.error(res.error.message);
          if (res.error.status === 401 && !!token) setToken(null);
        }
        setResponse({ loading: false, data: res.data });
      });
    }
  }, [body, path, setToken, token]);

  return [response, setBody];
}
