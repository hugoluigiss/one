import { Stack, Heading, Button } from '@chakra-ui/react';

export default function FinishSignup() {
  return (
    <Stack mt={8} spacing={8}>
      <Heading textAlign="center">
        Obrigado, enviaremos um email assim que sua documentação for aprovada.
      </Heading>

      <Stack alignItems="center">
        <a href="http://localhost:3000/">
          <Button
            borderRadius={0}
            color="#fff"
            height="49px"
            alignSelf="center"
            colorScheme="green"
            w="280px"
          >
            Voltar
          </Button>
        </a>
      </Stack>
    </Stack>
  );
}
