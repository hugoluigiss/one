import {
  Text,
  Button,
  FormControl,
  FormLabel,
  Heading,
  HStack,
  Stack,
  SimpleGrid,
  Checkbox,
  Box,
} from '@chakra-ui/react';
import { toast } from 'react-toastify';
import { Form, Formik, FormikProps } from 'formik';
import { useCallback, useEffect, useState } from 'react';

import axios from 'axios';

import {
  IPJFormData,
  pjSchema,
} from '../../../../../utils/form-validation-schemas';

import Input from '../../../../../components/Form/Inputs/InputText';

import Upload from '../../../../../components/Form/Upload';
import usePost from '../../../../../hooks/usePost';
import { stepPropsVerification } from '../props';

interface AddressProps {
  CNPJ: string;
  'RAZAO SOCIAL': string;
  'NOME FANTASIA': string;
}

export default function JuridicDetails({
  nextStep,
  setSignupdata,
  signupData,
}: stepPropsVerification) {
  const [{ data, loading }, checkCNPJ] = usePost<string>('/public/signup/cnpj');

  useEffect(() => {
    if (data) {
      nextStep();
    }
  }, [data, nextStep]);

  const [addJuridic, setAddJuridic] = useState<boolean>(false);
  const [cnpjFilename, setCnpjFilename] = useState<string>('');
  const [corporateFileName, setCorporateFilename] = useState<string>('');

  const [timeoutRef, setTimeoutRef] = useState<number>();
  const [CnpjApiInfo, setCnpjApiInfo] = useState<AddressProps>();

  useEffect(() => {
    if (signupData.company_document) {
      setCnpjFilename(signupData.company_document?.cnpj_file);
      setCorporateFilename(signupData.company_document?.social_contract_file);
    }
  }, [signupData]);

  const skip = () => {
    if (!addJuridic) nextStep();
  };

  const fetchCnpjInfo = useCallback(
    (inputValue: string) => {
      if (inputValue.length < 14) return;

      clearTimeout(timeoutRef);
      const timeout = window.setTimeout(() => {
        axios
          .get(
            `https://api-publica.speedio.com.br/buscarcnpj?cnpj=${inputValue}`,
          )
          .then((res: any) => {
            setCnpjApiInfo(res.data);
          })
          .catch(() => {
            // console.log(err);
          });
      }, 1000);
      setTimeoutRef(timeout);
    },
    [timeoutRef],
  );

  const FormPiece = (
    <Formik
      enableReinitialize
      initialValues={{
        cnpj: CnpjApiInfo?.CNPJ || signupData.company_document?.cnpj || '',
        company_name:
          CnpjApiInfo?.['RAZAO SOCIAL'] ||
          signupData.company_document?.company_name ||
          '',
        fantasy_name:
          CnpjApiInfo?.['NOME FANTASIA'] ||
          signupData.company_document?.fantasy_name ||
          '',
      }}
      validationSchema={pjSchema}
      onSubmit={(values, actions) => {
        if (addJuridic) checkCNPJ({ cnpj: values.cnpj, type: 'customer' });
        else nextStep();

        if (addJuridic && (!cnpjFilename || !corporateFileName)) {
          toast.error('Selecione seus documentos');
          actions.setSubmitting(false);
          return;
        }
        setSignupdata({
          ...signupData,
          company_document: {
            cnpj: values.cnpj,
            cnpj_file: cnpjFilename,
            social_contract_file: corporateFileName,
            company_name: values.company_name,
            fantasy_name: values.fantasy_name,
          },
        });
      }}
    >
      {({
        values,
        errors,
        isSubmitting,
        handleChange,
      }: FormikProps<IPJFormData>) => (
        <Form>
          <Checkbox
            checked={addJuridic}
            mb={4}
            onChange={e => setAddJuridic(e.target.checked)}
          >
            Desejo cadastrar os dados da minha empresa
          </Checkbox>
          <SimpleGrid columns={3} spacing={10}>
            <FormControl isRequired>
              <FormLabel>CNPJ</FormLabel>
              <Input
                disabled={isSubmitting || !addJuridic}
                name="cnpj"
                value={values.cnpj}
                onChange={async e => {
                  if (e.target.value.length > 18) return;

                  const maskedEvent = e;
                  maskedEvent.target.value = e.target.value
                    .replace(/\D/g, '')
                    .replace(
                      /^(\d{0,2})(\d{0,3})(\d{0,3})(\d{0,4})(\d{0,2}$)/,
                      '$1.$2.$3/$4-$5',
                    );

                  handleChange(maskedEvent);
                  const { value } = e.target;

                  fetchCnpjInfo(value.replace(/\D/g, ''));
                }}
                placeholder="Digite o CNPJ"
                errorText={errors.cnpj}
              />
            </FormControl>

            <FormControl isRequired>
              <FormLabel>Razão Social</FormLabel>
              <Input
                disabled={isSubmitting || !addJuridic}
                name="company_name"
                value={values.company_name}
                onChange={handleChange}
                placeholder="Razão social"
                errorText={errors.company_name}
              />
            </FormControl>

            <FormControl isRequired>
              <FormLabel>Nome Fantasia</FormLabel>
              <Input
                name="fantasy_name"
                disabled={isSubmitting || !addJuridic}
                value={values.fantasy_name}
                onChange={handleChange}
                placeholder="Nome fantasia"
                errorText={errors.fantasy_name}
              />
            </FormControl>
          </SimpleGrid>

          <SimpleGrid columns={2} spacing={10}>
            <div>
              <span>CNPJ</span>
              {addJuridic ? (
                <Upload setFileName={setCnpjFilename} />
              ) : (
                <Box
                  w="275px"
                  h="100px"
                  border="1px dotted gray"
                  borderRadius={8}
                  cursor="not-allowed"
                >
                  <Text textAlign="center" color="text.800">
                    Anexar arquivos
                  </Text>
                </Box>
              )}
            </div>
            <div>
              <span>Contrato Social</span>
              {addJuridic ? (
                <Upload setFileName={setCorporateFilename} />
              ) : (
                <Box
                  w="275px"
                  h="100px"
                  border="1px dotted gray"
                  borderRadius={8}
                  cursor="not-allowed"
                >
                  <Text textAlign="center" color="text.800">
                    Anexar arquivos
                  </Text>
                </Box>
              )}
            </div>
          </SimpleGrid>

          <Stack m={4}>
            {addJuridic && (
              <Button
                type="submit"
                isLoading={loading}
                borderRadius={0}
                color="#1A1B21"
                height="49px"
                alignSelf="center"
                w="280px"
              >
                Avançar
              </Button>
            )}
            {!addJuridic && (
              <Button
                isLoading={loading}
                onClick={skip}
                borderRadius={0}
                color="#1A1B21"
                height="49px"
                alignSelf="center"
                w="280px"
              >
                Avançar
              </Button>
            )}
          </Stack>
        </Form>
      )}
    </Formik>
  );

  return (
    <Stack>
      <Stack alignItems="center">
        <HStack color="white" m={4}>
          <Heading fontSize="lg">Dados da Empresa (opcional)</Heading>
        </HStack>
        <Stack maxWidth="603px" color="white">
          {FormPiece}
        </Stack>
      </Stack>
    </Stack>
  );
}
