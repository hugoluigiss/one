// import ReactFlagsSelect from 'react-flags-select';
import {
  Heading,
  Button,
  // Avatar,
  FormControl,
  FormLabel,
  HStack,
  Stack,
  SimpleGrid,
  GridItem,
} from '@chakra-ui/react';
import { toast } from 'react-toastify';
import { Form, Formik, FormikProps } from 'formik';
import { useEffect, useState } from 'react';

import {
  IPFCreateData,
  pfCreateSchema,
} from '../../../../../utils/form-validation-schemas';
import usePost from '../../../../../hooks/usePost';

import Input from '../../../../../components/Form/Inputs/InputText';
import Upload from '../../../../../components/Form/Upload';
import { stepPropsVerification } from '../props';

export default function UserDetails({
  nextStep,
  setSignupdata,
  signupData,
  type,
}: stepPropsVerification) {
  const [{ data, loading }, checkCPF] = usePost<string>('/signup/cpf');

  useEffect(() => {
    if (data) {
      nextStep();
    }
  }, [data, nextStep]);

  const [front, setFront] = useState<string>();
  const [back, setBack] = useState<string>();

  const [selfie, setSelfie] = useState<string>();

  // useEffect(() => {
  //   if (signupData.personal_document.status !== 'rejected') {
  //     setFront(signupData.personal_document.front);
  //     setBack(signupData.personal_document.back);
  //     setSelfie(signupData.personal_document.selfie);
  //   }
  // }, [signupData]);

  const FormPiece = (
    <Formik
      enableReinitialize
      initialValues={{
        birthdate: signupData.personal_document.birthdate,
        cpf: signupData.personal_document.cpf,
        first_name: signupData.personal_document.first_name,
        last_name: '',
        phone_number: '',
      }}
      validationSchema={pfCreateSchema}
      onSubmit={(values, actions) => {
        if (!values.birthdate) {
          actions.setSubmitting(false);
          return;
        }
        if (!back || !front || !selfie) {
          toast.error('Selecione seus documentos');
          actions.setSubmitting(false);
          return;
        }

        const nameParts: string[] = values.first_name.split(' ');
        const first_name: string = nameParts.shift() || '';
        const last_name = nameParts.join(' ');
        setSignupdata({
          ...signupData,
          phone_number: values.phone_number,
          personal_document: {
            birthdate: values.birthdate,
            cpf: values.cpf,
            first_name,
            last_name,
            back,
            selfie,
            front,
            user_id: signupData.personal_document.user_id,
          },
        });

        checkCPF({ cpf: values.cpf, type });
      }}
    >
      {({ values, errors, handleChange }: FormikProps<IPFCreateData>) => (
        <Form>
          <SimpleGrid columns={1} spacing={10}>
            <FormControl isRequired>
              <FormLabel>Nome Completo</FormLabel>
              <Input
                disabled={loading}
                name="first_name"
                value={values.first_name}
                onChange={handleChange}
                placeholder="Digite seu nome"
                errorText={errors.first_name}
              />
            </FormControl>
          </SimpleGrid>

          <SimpleGrid columns={3} spacing={10}>
            <GridItem>
              <FormControl isRequired>
                <FormLabel>CPF</FormLabel>
                <Input
                  name="cpf"
                  disabled={loading}
                  value={values.cpf}
                  onChange={async e => {
                    if (e.target.value.length > 15) return;

                    const maskedEvent = e;
                    maskedEvent.target.value = e.target.value
                      .replace(/\D/g, '')
                      .replace(
                        /^(\d{0,3})(\d{0,3})(\d{0,3})(\d{0,2})/,
                        '$1.$2.$3-$4',
                      );

                    handleChange(maskedEvent);
                  }}
                  placeholder="Digite seu CPF"
                  errorText={errors.cpf}
                />
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl isRequired>
                <FormLabel>Telefone</FormLabel>
                <Input
                  disabled={loading}
                  name="phone_number"
                  type="tel"
                  onChange={async e => {
                    const maskedEvent = e;
                    maskedEvent.target.value = e.target.value
                      .replace(/\D/g, '')
                      .replace(/^(\d{0,2})(\d{0,5})(\d{0,4}$)/, '($1) $2-$3');

                    handleChange(maskedEvent);
                  }}
                  placeholder="Digite seu telefone"
                  errorText={errors.phone_number}
                />
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl isRequired>
                <FormLabel>Nascimento</FormLabel>
                <Input
                  name="birthdate"
                  type="date"
                  disabled={loading}
                  value={values.birthdate}
                  onChange={handleChange}
                  errorText={errors.birthdate}
                />
              </FormControl>
            </GridItem>
          </SimpleGrid>

          <SimpleGrid columns={3} spacing={10}>
            <div>
              <span>Documento Frente</span>
              <Upload setFileName={setFront} />
            </div>
            <div>
              <span>Documento Verso</span>
              <Upload setFileName={setBack} />
            </div>
            <div>
              <span>Selfie com documento</span>
              <Upload setFileName={setSelfie} />
            </div>
          </SimpleGrid>

          <Stack m={4}>
            <Button
              type="submit"
              isLoading={loading}
              colorScheme="brandGray"
              alignSelf="center"
              borderRadius="0"
              w="280px"
            >
              Avançar
            </Button>
          </Stack>
        </Form>
      )}
    </Formik>
  );

  return (
    <Stack>
      <Stack alignItems="center">
        <HStack color="white" m={4}>
          <Heading fontSize="lg">Dados do Titular</Heading>
        </HStack>
        <Stack maxWidth="603px" color="white">
          {FormPiece}
        </Stack>
      </Stack>
    </Stack>
  );
}
