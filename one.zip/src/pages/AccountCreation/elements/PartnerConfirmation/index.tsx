import { Collapse, Stack } from '@chakra-ui/react';
import { Step, Steps, useSteps } from 'chakra-ui-steps';
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import { useParams } from 'react-router-dom';
import UserAddressDetails from './UserAddressDetails';
import UserDetails from './UserDetails';
import JuridicDetails from './JuridicDetails';
import JuridicAddressDetails from './JuridicAddressDetails';
import LoadingPage from '../../../../components/Layout/LoadingPage';
import { ISignupData } from './props';
import usePost from '../../../../hooks/usePost';
import useGet from '../../../../hooks/useGet';
import { UnilevelTypes } from '../../../../services/apitypes';
import FinishSignup from './FinishSignup';

interface RouteParams {
  token_id: string;
}

export default function PartnerConfirmation() {
  const { token_id } = useParams<RouteParams>();

  const { nextStep, setStep, activeStep } = useSteps({
    initialStep: 0,
  });
  const [sendData, setSendData] = useState(false);

  const [signupData, setSignupdata] = useState<ISignupData>({
    phone_number: '',
    email: '',
    code: '',
    token_id,
    personal_document: {
      back: '',
      front: '',
      selfie: '',
      birthdate: '',
      cpf: '',
      first_name: '',
      last_name: '',
      status: '',
      user_id: '',
    },
    personal_address: {
      city: '',
      complement: '',
      district: '',
      file_name: '',
      number: '',
      state: '',
      street: '',
      zip_code: '',
      status: '',
      user_id: '',
    },
    company_address: {
      city: '',
      complement: '',
      district: '',
      file_name: '',
      number: '',
      state: '',
      street: '',
      zip_code: '',
      status: '',
      user_id: '',
    },
    company_document: {
      company_name: '',
      fantasy_name: '',
      cnpj: '',
      cnpj_file: '',
      social_contract_file: '',
      status: '',
      user_id: '',
    },
  });
  const [{ data: token, loading }] = useGet<{
    email: string;
    code: string;
    indicator_code: string;
    type: UnilevelTypes;
  }>('/signup/token', {
    token_id,
  });

  const [{ data }, signUp] = usePost('/signup');

  useEffect(() => {
    if (data) {
      toast.success('Documentos enviados para análise');
      nextStep();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  useEffect(() => {
    if (sendData) {
      let userData = {};

      if (signupData.company_document.cnpj) userData = { ...signupData };
      else
        userData = {
          ...signupData,
          company_address: undefined,
          company_document: undefined,
        };

      signUp({ ...userData });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sendData, signUp, signupData]);

  useEffect(() => {
    if (token)
      setSignupdata(s => ({
        ...s,
        email: token.email,
        code: token.code,
      }));
  }, [token]);

  const renderSteps = useCallback(() => {
    const steps = [
      {
        id: '3',
        label: '',
        content: (
          <UserDetails
            nextStep={nextStep}
            setSignupdata={setSignupdata}
            signupData={signupData}
            type={token?.type || 'consultant'}
          />
        ),
      },
      {
        id: '4',
        label: '',
        content: (
          <UserAddressDetails
            nextStep={nextStep}
            setSignupdata={setSignupdata}
            signupData={signupData}
          />
        ),
      },
      {
        id: '5',
        label: '',
        content: (
          <JuridicDetails
            nextStep={nextStep}
            setSignupdata={setSignupdata}
            signupData={signupData}
            type={token?.type || 'consultant'}
          />
        ),
      },
      {
        id: '6',
        label: '',
        content: (
          <JuridicAddressDetails
            nextStep={() => setSendData(true)}
            setStep={() => setStep(0)}
            setSignupdata={setSignupdata}
            signupData={signupData}
            personal_address={signupData.personal_address}
          />
        ),
      },
      {
        id: '7',
        label: '',
        content: <FinishSignup />,
      },
    ];

    return steps.map(({ label, content, id }) => {
      return (
        <Step label={label} key={id}>
          {content}
        </Step>
      );
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [signupData, token?.type]);

  return (
    <>
      <Stack mt={8} color="white">
        {loading && <LoadingPage />}

        {token && (
          <Collapse in>
            <Steps activeStep={activeStep} margin="auto" maxW="800px">
              {renderSteps()}
            </Steps>
          </Collapse>
        )}
      </Stack>
    </>
  );
}
