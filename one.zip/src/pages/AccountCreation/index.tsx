import { Stack, Heading, HStack } from '@chakra-ui/react';
import Logo from '../../components/Logo';
import PartnerConfirmation from './elements/PartnerConfirmation';

export default function AccountCreation() {
  return (
    <Stack alignItems="center" spacing={29} color="white">
      <Logo />

      <Heading>Confirmação de documentos</Heading>
      <HStack justifyContent="center" w="full" spacing={29}>
        <PartnerConfirmation />
      </HStack>
    </Stack>
  );
}
