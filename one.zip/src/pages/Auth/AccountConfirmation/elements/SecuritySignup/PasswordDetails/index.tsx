// import ReactFlagsSelect from 'react-flags-select';
import {
  Heading,
  Button,
  // Avatar,
  FormControl,
  FormLabel,
  HStack,
  Stack,
  SimpleGrid,
} from '@chakra-ui/react';
import { Form, Formik, FormikProps } from 'formik';
import { useEffect } from 'react';

import {
  AuthConfirmationSchema,
  IAuthConfirmationFormData,
} from '../../../../../../utils/form-validation-schemas';
// import usePost from '../../../../../../hooks/usePost';

import stepProps from '../props';
import InputPassword from '../../../../../../components/Form/Inputs/InputPassword';
import usePost from '../../../../../../hooks/usePost';

export default function PasswordDetails({ nextStep, account_id }: stepProps) {
  const [{ data, loading }, setPassword] = usePost<string>('/signup/password');

  useEffect(() => {
    if (data) nextStep();
  }, [data, nextStep]);

  const FormPiece = (
    <Formik
      enableReinitialize
      initialValues={{
        password: '',
        password_confirmation: '',
      }}
      validationSchema={AuthConfirmationSchema}
      onSubmit={values => {
        setPassword({ account_id, password: values.password });
      }}
    >
      {({
        touched,
        errors,
        handleChange,
      }: FormikProps<IAuthConfirmationFormData>) => (
        <Form>
          <SimpleGrid columns={2} spacing={10} minChildWidth="120px">
            <FormControl isRequired>
              <FormLabel>Senha</FormLabel>
              <InputPassword
                disabled={loading}
                name="password"
                onChange={handleChange}
                placeholder="Digite sua senha"
                errorText={touched.password ? errors.password : ''}
              />
            </FormControl>
            <FormControl isRequired>
              <FormLabel>Confirme sua senha</FormLabel>
              <InputPassword
                disabled={loading}
                name="password_confirmation"
                onChange={handleChange}
                placeholder="Confirme sua senha"
                errorText={
                  touched.password_confirmation
                    ? errors.password_confirmation
                    : ''
                }
              />
            </FormControl>
          </SimpleGrid>

          <Stack m={4}>
            <Button
              type="submit"
              isLoading={false}
              colorScheme="brandGray"
              alignSelf="center"
              borderRadius="0"
              w="280px"
            >
              Avançar
            </Button>
          </Stack>
        </Form>
      )}
    </Formik>
  );

  return (
    <Stack>
      <Stack alignItems="center">
        <HStack color="white" m={4}>
          <Heading fontSize="lg">Cadastre sua senha</Heading>
        </HStack>
        <Stack maxWidth="603px" color="white" w="100%">
          {FormPiece}
        </Stack>
      </Stack>
    </Stack>
  );
}
