import { Box, Button, Stack, FormControl, FormLabel } from '@chakra-ui/react';
import QRCode from 'react-qr-code';
import { Form, Formik, FormikProps } from 'formik';
import * as Yup from 'yup';
import { useEffect } from 'react';
import stepProps from '../props';
import Input from '../../../../../../components/Form/Inputs/InputText';

import { Container, Header, Content } from './styles';
import usePost from '../../../../../../hooks/usePost';

interface ITwoFaFormData {
  code: string;
}
const twoFaSchema = Yup.object().shape({
  code: Yup.string().required('Código 2FA obrigatório'),
});

export default function TwoFADetails({
  nextStep,
  qrCode,
  account_id,
}: stepProps) {
  const [{ data, loading }, check2FA] = usePost<string>('/signup/twofa');

  useEffect(() => {
    if (data) nextStep();
  }, [data, nextStep]);

  return (
    <Container>
      <Content>
        <Header stretched>
          <h3>Escaneie o QR Code e habilite sua 2FA</h3>
        </Header>
        <Content maxWidth="603px">
          <Stack alignItems="center">
            <Box
              p={2}
              bgColor="white"
              w="fit-content"
              minH={16}
              minW={16}
              mb={4}
            >
              <QRCode size={160} value={qrCode || ''} />
            </Box>
            <Formik
              enableReinitialize
              initialValues={{
                code: '',
              }}
              validationSchema={twoFaSchema}
              onSubmit={values => {
                check2FA({ account_id, code: values.code });
              }}
            >
              {({
                values,
                errors,
                handleChange,
              }: FormikProps<ITwoFaFormData>) => (
                <Form>
                  <FormControl isRequired>
                    <FormLabel>Código 2FA</FormLabel>
                    <Input
                      disabled={loading}
                      name="code"
                      value={values.code}
                      onChange={handleChange}
                      placeholder="Digite seu código 2FA"
                      errorText={errors.code}
                    />
                  </FormControl>

                  <Stack my={6}>
                    <Button
                      type="submit"
                      isLoading={loading}
                      colorScheme="brandGray"
                      alignSelf="center"
                      borderRadius="0"
                      w="280px"
                    >
                      Avançar
                    </Button>
                  </Stack>
                </Form>
              )}
            </Formik>
          </Stack>
        </Content>
      </Content>
    </Container>
  );
}
