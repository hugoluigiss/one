import {
  Collapse,
  Stack,
  // CloseButton,
} from '@chakra-ui/react';

import { useParams } from 'react-router-dom';
import { Step, Steps, useSteps } from 'chakra-ui-steps';
import PasswordDetails from './PasswordDetails';
import TwoFADetails from './TwoFADetails';
import LoadingPage from '../../../../../components/Layout/LoadingPage';
import FinishAccountConfirmation from './FinishAccountConfirmation';
import useGet from '../../../../../hooks/useGet';

interface RouteParams {
  account_id: string;
}

export default function SecuritySignup() {
  const { account_id } = useParams<RouteParams>();

  const [{ data, loading }] = useGet<{ qrcode: string }>(
    '/signup/account-confirmation',
    {
      account_id,
    },
  );

  const { nextStep, activeStep } = useSteps({
    initialStep: 0,
  });

  const steps = [
    {
      id: '1',
      label: '',
      content: (
        <TwoFADetails
          nextStep={nextStep}
          qrCode={data?.qrcode}
          account_id={account_id}
        />
      ),
    },
    {
      id: '2',
      label: '',
      content: <PasswordDetails nextStep={nextStep} account_id={account_id} />,
    },
    {
      id: '3',
      label: '',
      content: <FinishAccountConfirmation />,
    },
  ];

  return (
    <>
      {loading && <LoadingPage />}

      {data?.qrcode && (
        <Collapse in animateOpacity>
          <Stack>
            <Stack>
              <Steps activeStep={activeStep} margin="auto" maxW="800px">
                {steps.map(({ label, content, id }) => (
                  <Step label={label} key={id}>
                    {content}
                  </Step>
                ))}
              </Steps>
            </Stack>
          </Stack>
        </Collapse>
      )}
    </>
  );
}
