export default interface stepProps {
  nextStep: () => void;
  account_id: string;
  qrCode?: string;
}
