import { Heading, HStack } from '@chakra-ui/react';
import Logo from '../../../components/Logo';
// import useGet from '../../../hooks/useGet';
import SecuritySignup from './elements/SecuritySignup';

export default function Layout() {
  return (
    <>
      <Logo />

      <Heading color="white">Segurança</Heading>
      <HStack justifyContent="center" w="full" spacing={29} color="white">
        <SecuritySignup />
      </HStack>
    </>
  );
}
