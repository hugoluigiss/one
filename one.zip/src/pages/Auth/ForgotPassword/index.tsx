import { Formik, Form, FormikProps } from 'formik';

import { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { toast } from 'react-toastify';
import PropagateLoader from 'react-spinners/PropagateLoader';
import { Stack } from '@chakra-ui/react';
import ButtonPrimary from '../../../components/ButtonPrimary';
import InputPassword from '../../../components/Form/Inputs/InputPassword';
import Input from '../../../components/Form/Inputs/InputText';
import Logo from '../../../components/Logo';

import {
  formFotgotPasswordSchema,
  IForgotPasswordFormData,
} from '../../../utils/form-validation-schemas';

import { FormBox, FormLink } from '../styles';
import usePost from '../../../hooks/usePost';

export default function ForgotPassword(): JSX.Element {
  const history = useHistory();
  const [codeSent, setCodeSent] = useState(false);
  const [{ data: message }, sendCode] = usePost<string>('/password/recover');
  const [{ data }, resetPass] = usePost<string>('/password/reset');
  useEffect(() => {
    if (message) {
      toast.success(message);
      setCodeSent(true);
    }
  }, [message]);
  useEffect(() => {
    if (data) {
      toast.success(data);
      history.push('/');
    }
  }, [data, history]);

  return (
    <>
      <Logo />

      <FormBox>
        <h1>Recuperar senha</h1>
        <Formik
          initialValues={{
            email: '',
            code: '',
            password: '',
            confirm_password: '',
          }}
          validationSchema={formFotgotPasswordSchema}
          onSubmit={(values: IForgotPasswordFormData) => {
            resetPass({ ...values });
          }}
        >
          {({
            touched,
            errors,
            handleChange,
            isSubmitting,
            values,
          }: FormikProps<IForgotPasswordFormData>) => (
            <Form>
              <Input
                disabled={isSubmitting}
                name="email"
                onChange={handleChange}
                placeholder="Digite seu e-mail"
                errorText={errors.email}
              />

              {!codeSent && (
                <ButtonPrimary
                  type="button"
                  disabled={!!errors.email}
                  onPress={() => {
                    sendCode({ email: values.email });
                  }}
                >
                  SOLICITAR CÓDIGO
                </ButtonPrimary>
              )}

              {codeSent && (
                <>
                  <Input
                    disabled={isSubmitting}
                    name="code"
                    onChange={handleChange}
                    placeholder="Digite o codigo recebido"
                    errorText={touched.code ? errors.code : ''}
                  />

                  <InputPassword
                    disabled={isSubmitting}
                    name="password"
                    type="password"
                    onChange={handleChange}
                    placeholder="Digite nova senha"
                    errorText={touched.password ? errors.password : ''}
                  />

                  <InputPassword
                    disabled={isSubmitting}
                    name="confirm_password"
                    type="password"
                    onChange={handleChange}
                    placeholder="Confirme nova senha"
                    errorText={
                      touched.confirm_password ? errors.confirm_password : ''
                    }
                  />

                  <ButtonPrimary type="submit" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <PropagateLoader color="white" loading />
                    ) : (
                      'ENVIAR'
                    )}
                  </ButtonPrimary>
                </>
              )}
            </Form>
          )}
        </Formik>
        <Stack mt={4}>
          <FormLink to="/">Voltar para login</FormLink>
        </Stack>
      </FormBox>
    </>
  );
}
