import { Form, Formik, FormikProps } from 'formik';
import { toast } from 'react-toastify';
import PropagateLoader from 'react-spinners/PropagateLoader';
import { useEffect } from 'react';
import ButtonPrimary from '../../../components/ButtonPrimary';
import Input from '../../../components/Form/Inputs/InputText';
import {
  ISignupStep1FormData,
  signupStep1Schema,
} from '../../../utils/form-validation-schemas';

import { FormBox, FormLink } from '../styles';
import usePost from '../../../hooks/usePost';

export default function Step1({
  indicator_code,
  nextStep,
}: {
  indicator_code: string;
  nextStep: () => void;
}) {
  const [{ data, loading }, sendToken] = usePost<string>('/signup/token');
  useEffect(() => {
    if (data) {
      toast.success(data);
      nextStep();
    }
  }, [data, nextStep]);

  return (
    <FormBox>
      <Formik
        initialValues={{ email: '' }}
        validationSchema={signupStep1Schema}
        onSubmit={values => {
          sendToken({ ...values, indicator_code });
        }}
      >
        {({
          touched,
          errors,
          handleChange,
        }: FormikProps<ISignupStep1FormData>) => (
          <Form>
            <Input
              disabled={loading}
              name="email"
              onChange={handleChange}
              placeholder="Digite seu e-mail"
              errorText={touched.email ? errors.email : ''}
            />

            <ButtonPrimary type="submit" disabled={loading}>
              {loading ? <PropagateLoader color="white" loading /> : 'AVANÇAR'}
            </ButtonPrimary>
          </Form>
        )}
      </Formik>
      <FormLink to="/">Ir para login</FormLink>
    </FormBox>
  );
}
