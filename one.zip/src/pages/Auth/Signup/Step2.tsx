import { Form, Formik, FormikProps } from 'formik';
import { useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { toast } from 'react-toastify';
import PropagateLoader from 'react-spinners/PropagateLoader';
import ButtonPrimary from '../../../components/ButtonPrimary';
import InputPassword from '../../../components/Form/Inputs/InputPassword';
import Input from '../../../components/Form/Inputs/InputText';
// import { useCreateUserMutation } from '../../../graphql/generated/graphql';
import {
  ISignupStep2FormData,
  signupStep2Schema,
} from '../../../utils/form-validation-schemas';

import { FormBox, FormLink } from '../styles';
import usePost from '../../../hooks/usePost';

export default function Step2() {
  // const [createUser] = useCreateUserMutation();
  const history = useHistory();
  const [{ data, loading }, createAccount] = usePost<{ id: string }>('/signup');

  useEffect(() => {
    if (data) {
      toast.success('Conta criada com sucesso!!!');
      history.push('/');
    }
  }, [data, history]);

  return (
    <FormBox>
      <Formik
        initialValues={{
          password: '',
          password_confirmation: '',
          code: '',
        }}
        validationSchema={signupStep2Schema}
        onSubmit={values => createAccount({ ...values })}
      >
        {({
          touched,
          errors,
          handleChange,
        }: FormikProps<ISignupStep2FormData>) => (
          <Form>
            <Input
              disabled={loading}
              name="code"
              onChange={handleChange}
              placeholder="Codigo"
              errorText={touched.code ? errors.code : ''}
            />

            <InputPassword
              disabled={loading}
              name="password"
              type="password"
              onChange={handleChange}
              placeholder="Digite senha"
              errorText={touched.password ? errors.password : ''}
            />

            <InputPassword
              disabled={loading}
              name="password_confirmation"
              type="password"
              onChange={handleChange}
              placeholder="Confirme senha"
              errorText={
                touched.password_confirmation
                  ? errors.password_confirmation
                  : ''
              }
            />

            <ButtonPrimary type="submit" disabled={loading}>
              {loading ? (
                <PropagateLoader color="white" loading />
              ) : (
                'CRIAR CONTA'
              )}
            </ButtonPrimary>
          </Form>
        )}
      </Formik>
      <FormLink to="/">Ir para login</FormLink>
    </FormBox>
  );
}
