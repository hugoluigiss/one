// import ReactFlagsSelect from 'react-flags-select';
import {
  Heading,
  Button,
  // Avatar,
  HStack,
  Stack,
  PinInput,
  PinInputField,
  Text,
} from '@chakra-ui/react';
import { useEffect } from 'react';
import { toast } from 'react-toastify';
import stepProps from '../props';
import usePost from '../../../../../../hooks/usePost';

export default function CodeConfirmation({
  nextStep,
  setSignupdata,
  signupData,
}: stepProps) {
  const [{ data, loading }, sendToken] = usePost<{ id: string }>(
    '/signup/token',
  );
  const [{ data: code }, checkCode] = usePost<string>('/signup/code');
  useEffect(() => {
    if (data && data.id) {
      toast.success('Acesse seu e-mail para continuar');
    }
  }, [data]);
  const getCode = (value: string) => {
    checkCode({ email: signupData.email, code: value });
  };
  useEffect(() => {
    if (code) {
      setSignupdata({ ...signupData, code });
      nextStep();
    }
  }, [code, data, nextStep, setSignupdata, signupData]);

  const resendCode = () => {
    sendToken({
      email: signupData.email,
      indicator_code: signupData.indicator_code,
    });
  };

  const onSubmit = () => {
    nextStep();
  };

  return (
    <Stack>
      <Stack alignItems="center">
        <HStack color="white" m={4}>
          <Heading fontSize="lg">Confirme seu e-mail</Heading>
        </HStack>
        <Stack maxWidth="603px" color="white">
          <Text>Código enviado por e-mail</Text>
          <HStack my={4}>
            <PinInput type="alphanumeric" onComplete={getCode}>
              <PinInputField />
              <PinInputField />
              <PinInputField />
              <PinInputField />
              <PinInputField />
              <PinInputField />
            </PinInput>
          </HStack>
          <Stack alignItems="flex-end">
            <Button
              colorScheme="teal"
              variant="link"
              w="fit-content"
              onClick={resendCode}
            >
              Reenviar
            </Button>
          </Stack>

          <Stack my={4}>
            <Button
              isLoading={loading}
              colorScheme="brandGray"
              alignSelf="center"
              borderRadius="0"
              w="280px"
              onClick={onSubmit}
            >
              AVANÇAR
            </Button>
          </Stack>
        </Stack>
      </Stack>
    </Stack>
  );
}
