// import ReactFlagsSelect from 'react-flags-select';
import {
  Heading,
  Button,
  // Avatar,
  // FormControl,
  // FormLabel,
  HStack,
  // Skeleton,
  Stack,
  // SimpleGrid,
} from '@chakra-ui/react';
import { Form, Formik, FormikProps } from 'formik';
import { useEffect } from 'react';
import { toast } from 'react-toastify';
import { useParams } from 'react-router-dom';
import {
  // IPFFormData,
  ISignupStep1FormData,
  // pfSchema,
  signupStep1Schema,
} from '../../../../../../utils/form-validation-schemas';
import Input from '../../../../../../components/Form/Inputs/InputText';
// import Upload from '../../../../../components/Form/Upload';
import stepProps from '../props';
import usePost from '../../../../../../hooks/usePost';
import { Unilevel } from '../../../../../../services/apitypes';
import useGet from '../../../../../../hooks/useGet';

export default function EmailVerification({
  nextStep,
  setSignupdata,
  signupData,
}: stepProps) {
  const { indicator_code } = useParams() as {
    indicator_code: string;
  };
  const [{ data: myIndicator }] = useGet<Unilevel>('/signup/indicator', {
    indicator_code,
  });
  const [{ data, loading }, sendToken] = usePost<{ id: string }>(
    '/signup/token',
  );

  useEffect(() => {
    if (data && data.id) {
      toast.success('Acesse seu e-mail para continuar');
      nextStep();
    }
  }, [data, nextStep]);

  return (
    <Stack>
      <Stack alignItems="center">
        <HStack color="white" m={4}>
          <Heading fontSize="lg">Informe o e-mail</Heading>
        </HStack>
        <Stack maxWidth="603px" color="white">
          {myIndicator && (
            <Formik
              initialValues={{ email: '' }}
              validationSchema={signupStep1Schema}
              onSubmit={values => {
                sendToken({
                  ...values,
                  indicator_code,
                  type: 'customer',
                });
                setSignupdata({
                  ...signupData,
                  indicator_code,
                  email: values.email,
                });
              }}
            >
              {({
                touched,
                errors,
                handleChange,
              }: FormikProps<ISignupStep1FormData>) => (
                <Form>
                  <Input
                    disabled={loading}
                    name="email"
                    onChange={handleChange}
                    placeholder="Digite seu e-mail"
                    errorText={touched.email ? errors.email : ''}
                  />

                  <Button
                    type="submit"
                    isLoading={loading}
                    colorScheme="brandGray"
                    alignSelf="center"
                    borderRadius="0"
                    w="280px"
                  >
                    AVANÇAR
                  </Button>
                </Form>
              )}
            </Formik>
          )}
        </Stack>
      </Stack>
    </Stack>
  );
}
