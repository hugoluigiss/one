import {
  useDisclosure,
  Button,
  Collapse,
  HStack,
  Stack,
  Text,
  // CloseButton,
} from '@chakra-ui/react';

import { Steps, useSteps } from 'chakra-ui-steps';
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'react-toastify';
// import UserAddressDetails from './UserAddressDetails';
// import UserDetails from './UserDetails';
import EmailVerification from './EmailVerification';
// import CodeConfirmation from './CodeConfirmation';
// import JuridicDetails from './JuridicDetails';
// import JuridicAddressDetails from './JuridicAddressDetails';
import { ISignupData } from './props';
import usePost from '../../../../../hooks/usePost';

export default function UnitSignup() {
  const { isOpen: openSteps, onToggle: toggleSteps } = useDisclosure();
  const { nextStep, reset, activeStep } = useSteps({
    initialStep: 0,
  });
  const [isJuridic, setIsJuridic] = useState(false);
  const [sendData] = useState(false);

  const [signupData, setSignupdata] = useState<ISignupData>({
    email: '',
    code: '',
    indicator_code: '',
    phone_number: '',
    personal_document: {
      back: '',
      front: '',
      selfie: '',
      birthdate: '',
      cpf: '',
      first_name: '',
      last_name: '',
    },
    personal_address: {
      city: '',
      complement: '',
      district: '',
      file_name: '',
      number: '',
      state: '',
      street: '',
      zip_code: '',
    },
    company_address: {
      city: '',
      complement: '',
      district: '',
      file_name: '',
      number: '',
      state: '',
      street: '',
      zip_code: '',
    },
    company_document: {
      company_name: '',
      fantasy_name: '',
      cnpj: '',
      cnpj_file: '',
      social_contract_file: '',
    },
  });
  const [{ data }, signUp] = usePost<{ id: string }>('/signup');

  useEffect(() => {
    if (data && data.id) {
      toast.success('Conta criada com sucesso');
      reset();
    }
  }, [data, reset]);

  useEffect(() => {
    if (sendData) {
      let userData = {};

      if (isJuridic) userData = { ...signupData };
      else
        userData = {
          ...signupData,
          company_address: undefined,
          company_document: undefined,
        };

      signUp({
        ...userData,
      });
    }
  }, [isJuridic, sendData, signUp, signupData]);

  const handleSelectAccountType = useCallback(
    (juridic: boolean) => {
      if (juridic) setIsJuridic(juridic);

      toggleSteps();
    },
    [toggleSteps],
  );

  // const renderSteps = useCallback(() => {
  //   const steps = [
  //     {
  //       id: '1',
  //       label: '',
  //       content: (
  //         <EmailVerification
  //           nextStep={nextStep}
  //           setSignupdata={setSignupdata}
  //           signupData={signupData}
  //         />
  //       ),
  //     },
  //     {
  //       id: '2',
  //       label: '',
  //       content: (
  //         <CodeConfirmation
  //           nextStep={nextStep}
  //           setSignupdata={setSignupdata}
  //           signupData={signupData}
  //         />
  //       ),
  //     },
  //     {
  //       id: '3',
  //       label: '',
  //       content: (
  //         <UserDetails
  //           nextStep={nextStep}
  //           setSignupdata={setSignupdata}
  //           signupData={signupData}
  //         />
  //       ),
  //     },
  //   ];

  //   const juridicSteps = [
  //     {
  //       id: '4',
  //       label: '',
  //       content: (
  //         <UserAddressDetails
  //           nextStep={nextStep}
  //           setSignupdata={setSignupdata}
  //           signupData={signupData}
  //         />
  //       ),
  //     },
  //     {
  //       id: '5',
  //       label: '',
  //       content: (
  //         <JuridicDetails
  //           nextStep={nextStep}
  //           setSignupdata={setSignupdata}
  //           signupData={signupData}
  //         />
  //       ),
  //     },
  //     {
  //       id: '6',
  //       label: '',
  //       content: (
  //         <JuridicAddressDetails
  //           nextStep={() => setSendData(true)}
  //           setSignupdata={setSignupdata}
  //           signupData={signupData}
  //           personal_address={signupData.personal_address}
  //         />
  //       ),
  //     },
  //   ];

  //   if (isJuridic) {
  //     const unitSteps = steps.concat(juridicSteps);

  //     return unitSteps.map(({ label, content, id }) => {
  //       return (
  //         <Step label={label} key={id}>
  //           {content}
  //         </Step>
  //       );
  //     });
  //   }

  //   const userSteps = steps.concat([
  //     {
  //       id: '4',
  //       label: '',
  //       content: (
  //         <UserAddressDetails
  //           nextStep={() => setSendData(true)}
  //           setSignupdata={setSignupdata}
  //           signupData={signupData}
  //         />
  //       ),
  //     },
  //   ]);
  //   return userSteps.map(({ label, content, id }) => {
  //     return (
  //       <Step label={label} key={id}>
  //         {content}
  //       </Step>
  //     );
  //   });
  // }, [nextStep, signupData, isJuridic]);

  return (
    <>
      <Collapse in animateOpacity>
        <Stack mt={8} color="white">
          {/* <HStack justifyContent="flex-end">
            <Button mt={4} onClick={onToggle} colorScheme="brandGray">
              <CloseButton />
            </Button>
          </HStack> */}

          <Collapse in={!openSteps}>
            <Stack alignItems="center">
              <Text>Deseja se cadastrar como pessoa física ou jurídica?</Text>
              <HStack>
                <Button
                  colorScheme="brandGray"
                  onClick={() => handleSelectAccountType(false)}
                >
                  Pessoa Física
                </Button>
                <Button
                  colorScheme="brandGray"
                  onClick={() => handleSelectAccountType(true)}
                >
                  Pessoa Jurídica
                </Button>
              </HStack>
            </Stack>
          </Collapse>
          <Collapse in={openSteps}>
            <Steps activeStep={activeStep} margin="auto" maxW="800px">
              <EmailVerification
                nextStep={nextStep}
                setSignupdata={setSignupdata}
                signupData={signupData}
              />
            </Steps>
          </Collapse>
        </Stack>
      </Collapse>
    </>
  );
}
