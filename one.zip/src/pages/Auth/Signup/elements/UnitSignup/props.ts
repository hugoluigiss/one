export interface AddressType {
  user_id?: string;
  zip_code: string;
  state: string;
  city: string;
  district: string;
  street: string;
  number: string;
  complement?: string;
  file_name: string;
}

export interface ISignupData {
  email: string;
  code: string;
  phone_number: string;
  indicator_code: string;
  personal_document: {
    front: string;
    back: string;
    selfie: string;
    birthdate: string;
    first_name: string;
    last_name: string;
    cpf: string;
  };
  personal_address: AddressType;
  company_document: {
    cnpj: string;
    company_name: string;
    fantasy_name: string;
    cnpj_file: string;
    social_contract_file: string;
  };
  company_address: AddressType;
}

export default interface stepProps {
  nextStep: () => void;
  setSignupdata: (d: ISignupData) => void;
  signupData: ISignupData;
}
