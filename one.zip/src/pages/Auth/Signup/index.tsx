import { useParams } from 'react-router-dom';
import { Text, Box, Stack } from '@chakra-ui/react';
import { PropagateLoader } from 'react-spinners';
import { ReactComponent as NotFound } from '../../../assets/icons/notfound/not_found.svg';
import Logo from '../../../components/Logo';
import useGet from '../../../hooks/useGet';
import UnitSignup from './elements/UnitSignup';

export default function SignUp() {
  const { indicator_code } = useParams() as {
    indicator_code: string;
  };

  const [{ data, loading }] = useGet<{ id: string }>('/signup/indicator', {
    indicator_code,
  });

  return (
    <>
      <Logo />

      <Box color="white" mt={8}>
        {loading && (
          <Stack>
            <PropagateLoader color="white" loading />
            <Text>Verificando link de indicação...</Text>
          </Stack>
        )}
        {!loading && !data && (
          <Stack alignItems="center">
            <NotFound width={400} />
            <Text>Link de indicacao inválido!!!</Text>
          </Stack>
        )}
      </Box>

      {!loading && data?.id && <UnitSignup />}
    </>
  );
}
