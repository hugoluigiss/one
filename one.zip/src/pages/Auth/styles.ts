import styled from 'styled-components';
import { Link } from 'react-router-dom';

export const FormBox = styled.div`
  margin: 24px 0 0 0;
  width: 100%;
  max-width: 381px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  form {
    width: 100%;

    color: #dcdee3;
  }

  input {
    border: 1px solid #a8aab4;
  }

  button {
    width: 100%;
  }
`;

export const FormLink = styled(Link)`
  cursor: pointer;
  width: fit-content;
  color: #f2f2f2;
  transition: 250ms;
  font-size: 14px;
  user-select: none;
  text-decoration: none;
  display: flex;
  justify-content: center;
  align-items: center;

  svg {
    margin-right: 12px;
  }

  a:hover {
    color: #fff;
    transition: 250ms;
  }
`;
