/* eslint-disable jsx-a11y/control-has-associated-label */
/* eslint-disable import/no-duplicates */
import { useEffect, useState } from 'react';
import { MdCancel, MdDownload } from 'react-icons/md';
// import formatDistance from 'date-fns/formatDistance';
import formatDistanceToNow from 'date-fns/formatDistanceToNow';
import { ptBR } from 'date-fns/locale';

// import { useTranslation } from 'react-i18next';
// import { DatePicker, LocalizationProvider } from '@mui/lab';
// import ptLocale from 'date-fns/locale/pt-BR';
// import AdapterDateFns from '@mui/lab/AdapterDateFns';
// import { TextFieldProps, TextField } from '@mui/material';
import { HStack, Button, Tooltip, Box, Heading, Stack } from '@chakra-ui/react';
import { useParams } from 'react-router-dom';
import DateWithHour from '../../../../components/Utils/DateWithHour';
// import ButtonPrimary from '../../../../components/ButtonPrimary';
// import DownloadIcon from '../UtilsComponents/DownloadIcon';
// import SelectorTableButton from '../../../../components/Utils/SelectorTableButton';

// import { formatPrice, formatAmount } from '~/utils/format';

import { Container, SeeMoreButton } from './styles';
import CurrencyWithIcon from '../../../../components/Utils/CurrencyWithIcon';
import useGet from '../../../../hooks/useGet';
import { CoinsType } from '../../../../services/apitypes';
import ButtonPrimary from '../../../../components/ButtonPrimary';
import { getColorByCoin } from '../../../../utils/CryptoColors';
// import DateWithoutHour from '../../../../components/Utils/DateWithoutHour';

const limit = 10;
interface RouteParams {
  coinParam: CoinsType;
}

export default function ContractsTable() {
  const { coinParam } = useParams<RouteParams>();
  const [coinFilter, setCoinFilter] = useState<CoinsType | undefined>();
  const [{ data: coins, loading }] = useGet<CoinsType[]>('/customer/coins');
  const [{ data }, setParams, params] = useGet<{
    count: number;
    applications: {
      id: string;
      sequence: number;
      file_url?: string;
      signature_key?: string;
      coin: CoinsType;
      amount: string;
      txid: string;
      parsed_status: string;
      created_at: Date;
    }[];
  }>('/customer/application', {
    limit,
    offset: 0,
    coin: coinParam || coinFilter || '',
  });

  const [transfers, setTransfers] = useState<
    {
      id: string;
      sequence: number;
      file_url?: string;
      signature_key?: string;
      coin: CoinsType;
      parsed_status: string;
      amount: string;
      txid: string;
      created_at: Date;
    }[]
  >([]);

  const selectCoin = (coin: CoinsType): void => {
    setCoinFilter(state => (state === coin ? undefined : coin));
  };

  useEffect(() => {
    if (data) setTransfers(t => [...t, ...data.applications]);
    if (data && data.applications.length === 0) setTransfers([]);
  }, [data]);

  useEffect(() => {
    if (coinParam) {
      setParams({ limit, offset: 0, coin: coinParam });
      setCoinFilter(coinParam);
    }
  }, [coinParam, setParams]);

  // console.log(data);

  return (
    <Container>
      <div className="header">
        <h3>Meus Contratos</h3>
        <div className="headerinline">
          <HStack spacing={4}>
            {!loading &&
              coins &&
              coins.map(coin => (
                <Box key={coin} onClick={() => selectCoin(coin as CoinsType)}>
                  <CurrencyWithIcon
                    collapsed
                    iconName={coin.toLowerCase() as CoinsType}
                    currency={coin}
                    color={
                      coinFilter === coin
                        ? getColorByCoin(coin as CoinsType)
                        : '#9B9B9B'
                    }
                  />
                </Box>
              ))}
            {/* <Text color="#979daf">ATIVO</Text>
            <Select
              color="white"
              size="sm"
              onChange={v => {
                setTransfers([]);
                setParams(s => ({ ...s, coin: v.target.value, offset: 0 }));
              }}
            >
              <option label="..." />
              {coins &&
                coins.map(coin => (
                  <option key={coin} label={coin}>
                    {coin}
                  </option>
                ))}
            </Select> */}
          </HStack>
          {/* <HStack>
            <Text color="white">MÊS</Text>
            <Select size="sm" placeholder="ABR - 2022" color="white" />
          </HStack> */}
          {/* <LocalizationProvider dateAdapter={AdapterDateFns} locale={ptLocale}>
            <DatePicker
              className="monthPicker"
              views={['year', 'month']}
              minDate={new Date('2018-03-01')}
              maxDate={new Date()}
              value={value}
              onChange={(newValue: React.SetStateAction<Date | null>) => {
                setValue(newValue);
              }}
              renderInput={(
                params: JSX.IntrinsicAttributes & TextFieldProps,
              ) => <TextField {...params} helperText={null} size="small" />}
            />
          </LocalizationProvider> */}
        </div>
      </div>

      <div className="tableContainer">
        <table>
          <thead>
            <tr>
              <th />
              <th>ID</th>
              <th>Valor</th>
              <th>Data</th>
              <th>Validade</th>
              {/* <th>Ganhos</th> */}
              <th>Status</th>
              <th>Download</th>
              <th>Cancelar</th>
            </tr>
          </thead>

          <tbody>
            {transfers &&
              transfers.map(transaction => (
                <tr key={transaction.sequence}>
                  <td>
                    <CurrencyWithIcon
                      iconName={transaction.coin.toLowerCase() as CoinsType}
                      currency={transaction.coin}
                      color={getColorByCoin(transaction.coin as CoinsType)}
                    />
                  </td>
                  <td># {transaction.sequence}</td>
                  <td>
                    <span className="badge" style={{ color: 'white' }}>
                      {transaction.amount}
                    </span>
                  </td>
                  <td>
                    <Tooltip
                      hasArrow
                      label={formatDistanceToNow(
                        new Date(transaction.created_at),
                        { locale: ptBR },
                      )}
                      bg="gray.300"
                      color="black"
                    >
                      <div>
                        <DateWithHour dateValue={transaction.created_at} />
                      </div>
                    </Tooltip>
                  </td>
                  <td>
                    {`${new Date(transaction.created_at).getDate()}/${new Date(
                      transaction.created_at,
                    ).getMonth()}/${
                      new Date(transaction.created_at).getFullYear() + 1
                    }`}
                  </td>
                  {/* <td>
                    <Tooltip
                      hasArrow
                      label={formatDistance(
                        new Date(),
                        new Date('07-01-2023'),
                        { locale: ptBR },
                      )}
                      bg="gray.300"
                      color="black"
                    >
                      <div>
                        <DateWithoutHour dateValue="07-01-2023" />
                      </div>
                    </Tooltip>
                  </td> */}
                  {/* <td>0.100 {transaction.coin} - 10%</td> */}
                  <td>{transaction.parsed_status}</td>
                  <td>
                    {transaction.file_url && (
                      <Button
                        leftIcon={<MdDownload size={24} />}
                        colorScheme="blue"
                        variant="link"
                        size="lg"
                        onClick={() => window.open(transaction.file_url)}
                      />
                    )}
                  </td>
                  <td>
                    <Button
                      leftIcon={<MdCancel size={24} />}
                      colorScheme="brandBlack"
                      variant="link"
                      size="lg"
                    />
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
        {((data &&
          data.applications.filter(t =>
            coinFilter ? t.coin === coinFilter : true,
          ).length === 0) ||
          !data) && (
          <Stack alignItems="center" color="text.500">
            <Heading>
              Nenhum contrato encontrado {coinFilter && `para ${coinFilter}`}
            </Heading>
          </Stack>
        )}
        {data && data.applications.length >= limit && (
          <SeeMoreButton>
            <ButtonPrimary
              onPress={() => {
                setParams({ ...params, offset: Number(params.offset) + 1 });
              }}
            >
              Ver mais
            </ButtonPrimary>
          </SeeMoreButton>
        )}
      </div>
    </Container>
  );
}
