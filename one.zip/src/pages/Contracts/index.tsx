import { Stack } from '@chakra-ui/react';
import ContractsTable from './elements/ContractsTable';
import CardContainer from '../../components/CardContainer';

export default function Extract() {
  return (
    <Stack>
      <CardContainer>
        <ContractsTable />
      </CardContainer>
    </Stack>
  );
}
