export interface BannerProps {
  image?: string;
  title?: string | JSX.Element;
  subtitle?: string | JSX.Element;
  link?: string;
}
