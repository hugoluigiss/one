/* eslint-disable react/jsx-curly-newline */
import React from 'react';
// import Axios from 'axios';
import ScrollContainer from 'react-indiana-drag-scroll';
import {
  HStack,
  Stack,
  Select,
  Tag,
  TagLabel,
  Heading,
  Wrap,
  Spacer,
} from '@chakra-ui/react';
import { Container } from './styles';

import Chart from './Chart';
import colors from '../../../../utils/CryptoColors';
import { CoinsType } from '../../../../services/apitypes';
import useGet from '../../../../hooks/useGet';
import ScrollDrag from '../../../../components/Utils/ScrollDrag';

interface IOption {
  name: string;
  value: number;
  interval: string;
}

const options: IOption[] = [
  { name: '24h', value: 24, interval: 'hour' },
  { name: '7d', value: 7, interval: 'day' },
  { name: '30d', value: 30, interval: 'day' },
  { name: '90d', value: 90, interval: 'day' },
  { name: '1a', value: 366, interval: 'day' },
];

const OscillationChart: React.FC = () => {
  const [period, setPeriod] = React.useState<IOption>(options[0]);

  const [{ data: coins }] = useGet<CoinsType[]>('/customer/coins');

  const getCryptoName = (coin: string): string => {
    if (coin === 'USDT') return 'USDT';
    if (coin === 'BTC') return 'Bitcoin';
    if (coin === 'ETH') return 'Ethereum';

    return 'Bnb';
  };

  return (
    <Container>
      <Wrap color="#fff" mb={6}>
        <Stack direction="row">
          <Heading size="md">CRIPTOMERCADO</Heading>
        </Stack>
        <Spacer />
        <ScrollDrag>
          <HStack>
            <div className="headerinline">
              <ScrollContainer className="headercoins">
                <HStack spacing={4}>
                  {coins?.map((c, i) => (
                    <Tag
                      key={c}
                      size="lg"
                      borderRadius="full"
                      variant="solid"
                      backgroundColor={colors[i]}
                    >
                      <TagLabel>{getCryptoName(c)}</TagLabel>
                    </Tag>
                  ))}
                </HStack>
              </ScrollContainer>
            </div>

            <HStack>
              <Select
                size="sm"
                w="96px"
                color="white"
                onChange={ev =>
                  options.map(option =>
                    option.value.toString() === ev.target.value
                      ? setPeriod(option)
                      : null,
                  )
                }
              >
                {options &&
                  options.map(option => (
                    <option key={`market-${option.name}`} value={option.value}>
                      {option.name}
                    </option>
                  ))}
              </Select>
            </HStack>
          </HStack>
        </ScrollDrag>
      </Wrap>
      <Chart
        coins={coins || []}
        interval={period.interval}
        value={period.value}
      />
    </Container>
  );
};

export default OscillationChart;
