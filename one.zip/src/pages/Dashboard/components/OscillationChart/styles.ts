import styled from 'styled-components';

export const Container = styled.div`
  position: relative;

  > span {
    font-size: 18px;
  }

  .header {
    height: 40px;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 12px;
    margin: 20px 0;

    h3 {
      color: #fff;
      font-weight: 500;
      text-transform: uppercase;
      font-size: 14px;
      margin-right: 12px;
    }
    .headerinline {
      display: flex;
      overflow: hidden;
      padding-right: 16px;
    }
    .headercoins {
      display: flex;
      overflow-x: auto;
    }
  }
`;

export const ChartContainer = styled.div`
  height: 340px;
  width: 100%;
`;
