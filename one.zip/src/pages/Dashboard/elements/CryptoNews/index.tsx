import { Stack, Text, Image, Wrap, HStack, Hide, Box } from '@chakra-ui/react';
import ScrollDrag from '../../../../components/Utils/ScrollDrag';

export default function CryptoNews() {
  const important = [
    {
      id: 1,
      img: '',
      title:
        'Halving: Qual impacto nos ciclos do Bitcoin, shiba Inu perde 33 mil usuários em um único dia, mas tem ganhos de 14%',
    },
  ];

  const highlight = [
    { id: 1, img: '', title: 'Halving: Qual impacto nos ciclos do Bitcoin?' },
    {
      id: 2,
      img: '',
      title:
        'Shiba Inu perde 33 mil usuários em um único dia, mas tem ganhos de 14%',
    },
    {
      id: 3,
      img: '',
      title: 'Mercado de criptomoedas volta aos R$ 10 trilhões',
    },
  ];

  const newsList = [
    { id: 4, img: '', title: 'Halving: Qual impacto nos ciclos do Bitcoin?' },
    {
      id: 5,
      img: '',
      title:
        'Shiba Inu perde 33 mil usuários em um único dia, mas tem ganhos de 14%',
    },
    {
      id: 6,
      img: '',
      title: 'Mercado de criptomoedas volta aos R$ 10 trilhões',
    },
    { id: 7, img: '', title: 'Halving: Qual impacto nos ciclos do Bitcoin?' },
    {
      id: 8,
      img: '',
      title:
        'Shiba Inu perde 33 mil usuários em um único dia, mas tem ganhos de 14%',
    },
    {
      id: 9,
      img: '',
      title: 'Mercado de criptomoedas volta aos R$ 10 trilhões',
    },
    { id: 40, img: '', title: 'Halving: Qual impacto nos ciclos do Bitcoin?' },
    {
      id: 50,
      img: '',
      title:
        'Shiba Inu perde 33 mil usuários em um único dia, mas tem ganhos de 14%',
    },
    {
      id: 51,
      img: '',
      title: 'Mercado de criptomoedas volta aos R$ 10 trilhões',
    },
    { id: 60, img: '', title: 'Halving: Qual impacto nos ciclos do Bitcoin?' },
    {
      id: 70,
      img: '',
      title:
        'Shiba Inu perde 33 mil usuários em um único dia, mas tem ganhos de 14%',
    },
    {
      id: 80,
      img: '',
      title: 'Mercado de criptomoedas volta aos R$ 10 trilhões',
    },
  ];

  return (
    <Stack color="text.500" spacing={6} mt={4} px={6}>
      <Wrap spacing={6}>
        <Box h="300px" flex={1} position="relative">
          <Image
            h="300px"
            w="100%"
            objectFit="cover"
            src="gibbresh.png"
            fallbackSrc="https://via.placeholder.com/800"
          />
          <Stack
            background="#00000059"
            maxH="30%"
            w="100%"
            position="absolute"
            bottom="0"
            p={4}
            overflowY="auto"
          >
            <Text>{important[0].title}</Text>
          </Stack>
        </Box>
        <Hide below="xl">
          <Stack minW="356px" spacing={8}>
            {highlight.map(news => (
              <HStack w="356px" key={`${news.id}-highlight`}>
                <Image
                  h="78px"
                  objectFit="cover"
                  src={news.img}
                  fallbackSrc="https://via.placeholder.com/200"
                />
                <Text>{news.title}</Text>
              </HStack>
            ))}
          </Stack>
        </Hide>
      </Wrap>

      <ScrollDrag alignItems="start">
        {newsList.map(news => (
          <Stack w="200px" minW="200px" key={news.id}>
            <Image
              h="130px"
              objectFit="cover"
              src={news.img}
              fallbackSrc="https://via.placeholder.com/200"
            />
            <Text>{news.title}</Text>
          </Stack>
        ))}
      </ScrollDrag>
    </Stack>
  );
}
