import { Stack } from '@chakra-ui/react';
import styled from 'styled-components';

export const Container = styled(Stack)``;

export const BannerImg = styled.div`
  margin-top: 32px;

  width: 100%;
  height: 265px;

  background: #3e3e3e;
  color: #fff;

  display: flex;
  justify-content: center;
  align-items: center;
`;

export const CryptosContainer = styled.div`
  margin-top: 28px;
`;

export const Header = styled.div`
  display: flex;
  justify-content: space-between;
`;

export const Title = styled.div`
  color: #fff;

  font-size: 24px;
  font-weight: 300;
`;

export const Text = styled.p`
  font-size: 12px;
  color: #fff;
`;

interface DataMarketProps {
  isPositive?: boolean;
}
export const DataMarket = styled.div<DataMarketProps>`
  margin-left: 4px;
  color: ${props => (props.isPositive ? '#2DB625' : '#ED0116')};
`;
