import { Collapse, Stack } from '@chakra-ui/react';
import { Step, Steps, useSteps } from 'chakra-ui-steps';
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import { useHistory } from 'react-router-dom';
import UserAddressDetails from './UserAddressDetails';
import UserDetails from './UserDetails';
import JuridicDetails from './JuridicDetails';
import JuridicAddressDetails from './JuridicAddressDetails';
import LoadingPage from '../../../../components/Layout/LoadingPage';
import { ISignupData, IUpdateData } from './props';
import usePost from '../../../../hooks/usePost';
import useGet from '../../../../hooks/useGet';
import { User } from '../../../../services/apitypes';
import TwoFADetails from './TwoFADetails';
import PasswordDetails from './PasswordDetails';

// interface RouteParams {
//   account_id: string;
// }

export default function PartnerConfirmation({ me }: { me: User }) {
  const history = useHistory();
  // const { account_id } = useParams<RouteParams>();

  const { nextStep, reset, activeStep, setStep } = useSteps({
    initialStep: 0,
  });
  const [sendData, setSendData] = useState(false);
  const [{ data: twofa }] = useGet<{ qrcode: string }>(
    '/signup/account-confirmation',
    {
      account_id: me?.account.id,
    },
  );

  const [signupData, setSignupdata] = useState<ISignupData>({
    personal_document: {
      back: '',
      front: '',
      selfie: '',
      birthdate: '',
      cpf: '',
      first_name: '',
      last_name: '',
      status: '',
      user_id: '',
    },
    personal_address: {
      city: '',
      complement: '',
      district: '',
      file_name: '',
      number: '',
      state: '',
      street: '',
      zip_code: '',
      status: '',
      user_id: '',
    },
    company_address: {
      city: '',
      complement: '',
      district: '',
      file_name: '',
      number: '',
      state: '',
      street: '',
      zip_code: '',
      status: '',
      user_id: '',
    },
    company_document: {
      company_name: '',
      fantasy_name: '',
      cnpj: '',
      cnpj_file: '',
      social_contract_file: '',
      status: '',
      user_id: '',
    },
  });
  const [{ data: userInfo, loading }] = useGet<IUpdateData>('/signup/account', {
    account_id: me.account.id,
  });
  const [{ data }, signUp] = usePost('/signup/update');

  useEffect(() => {
    if (data === 'updated') {
      toast.success('Documentos enviados para análise');
      reset();
      history.push('/');
    }
  }, [data, reset, history]);

  useEffect(() => {
    if (sendData) {
      let userData = {};

      if (signupData.company_document.cnpj) userData = { ...signupData };
      else
        userData = {
          ...signupData,
          company_address: undefined,
          company_document: undefined,
        };

      signUp({ ...userData });
    }
  }, [sendData, signUp, signupData]);

  useEffect(() => {
    if (userInfo)
      setSignupdata({
        personal_document: {
          back: userInfo.personal_document?.back,
          front: userInfo.personal_document?.front,
          selfie: userInfo.personal_document?.selfie,
          birthdate: userInfo.personal_document?.birthdate,
          cpf: userInfo.personal_document?.cpf,
          first_name: userInfo.personal_document?.first_name,
          last_name: userInfo.personal_document?.last_name,
          status: userInfo.personal_document?.status,
          user_id: userInfo.personal_document?.user_id || me.id,
        },
        personal_address: {
          city: userInfo.personal_address?.city,
          complement: userInfo.personal_address?.complement,
          district: userInfo.personal_address?.district,
          file_name: userInfo.personal_address?.file_name,
          number: userInfo.personal_address?.number,
          state: userInfo.personal_address?.state,
          street: userInfo.personal_address?.street,
          zip_code: userInfo.personal_address?.zip_code,
          status: userInfo.personal_address?.status,
          user_id: userInfo.personal_address?.user_id || me.id,
        },
        company_address: {
          city: userInfo.company_address?.city,
          complement: userInfo.company_address?.complement,
          district: userInfo.company_address?.district,
          file_name: userInfo.company_address?.file_name,
          number: userInfo.company_address?.number,
          state: userInfo.company_address?.state,
          street: userInfo.company_address?.street,
          zip_code: userInfo.company_address?.zip_code,
          status: userInfo.company_address?.status,
          user_id: userInfo.company_address?.user_id || me.id,
        },
        company_document: {
          company_name: userInfo.company_document?.company_name,
          fantasy_name: userInfo.company_document?.fantasy_name,
          cnpj: userInfo.company_document?.cnpj,
          cnpj_file: userInfo.company_document?.cnpj_file,
          social_contract_file: userInfo.company_document?.social_contract_file,
          status: userInfo.company_document?.status,
          user_id: userInfo.company_document?.user_id || me.id,
        },
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userInfo]);

  const renderSteps = useCallback(() => {
    const steps = [
      {
        id: '1',
        label: '',
        content: (
          <UserDetails
            nextStep={nextStep}
            setSignupdata={setSignupdata}
            signupData={signupData}
          />
        ),
      },
      {
        id: '2',
        label: '',
        content: (
          <UserAddressDetails
            nextStep={nextStep}
            setSignupdata={setSignupdata}
            signupData={signupData}
          />
        ),
      },
    ];

    const juridicSteps = [
      {
        id: '5',
        label: '',
        content: (
          <JuridicDetails
            nextStep={nextStep}
            setSignupdata={setSignupdata}
            signupData={signupData}
          />
        ),
      },
      {
        id: '6',
        label: '',
        content: (
          <JuridicAddressDetails
            nextStep={
              userInfo?.personal_document ? () => setSendData(true) : nextStep
            }
            setSignupdata={setSignupdata}
            signupData={signupData}
            personal_address={signupData.personal_address}
          />
        ),
      },
    ];

    const authSteps = [
      {
        id: '7',
        label: '',
        content: (
          <TwoFADetails
            nextStep={nextStep}
            qrCode={twofa?.qrcode}
            account_id={me.account.id}
          />
        ),
      },
      {
        id: '8',
        label: '',
        content: (
          <PasswordDetails
            nextStep={() => setSendData(true)}
            account_id={me.account.id}
            goBack={() => setStep(0)}
          />
        ),
      },
    ];

    const unitSteps = steps.concat(juridicSteps);
    if (!userInfo?.personal_document) {
      const signupSteps = unitSteps.concat(authSteps);

      return signupSteps.map(({ label, content, id }) => {
        return (
          <Step label={label} key={id}>
            {content}
          </Step>
        );
      });
    }

    return unitSteps.map(({ label, content, id }) => {
      return (
        <Step label={label} key={id}>
          {content}
        </Step>
      );
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [me, signupData, twofa]);

  return (
    <>
      <Stack mt={8} color="white">
        {loading && <LoadingPage />}

        {userInfo && (
          <Collapse in>
            <Steps
              activeStep={activeStep}
              margin="auto"
              maxW="800px"
              onClickStep={step => setStep(step)}
            >
              {renderSteps()}
            </Steps>
          </Collapse>
        )}
      </Stack>
    </>
  );
}
