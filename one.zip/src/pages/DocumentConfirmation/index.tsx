import { Stack, Heading, HStack, Text } from '@chakra-ui/react';
import { CheckCircleIcon, TimeIcon } from '@chakra-ui/icons';
import useGet from '../../hooks/useGet';
import { User } from '../../services/apitypes';
import PartnerConfirmation from './elements/PartnerConfirmation';
import Profile from '../Profile';

export default function Layout() {
  const [{ data: me }] = useGet<User>('/profile/me');

  if (me?.account.status === 'approved') return <Profile />;

  return (
    <Stack alignItems="center" spacing={29} color="white">
      <Heading>Confirmação de documentos</Heading>
      <HStack>
        {me?.account.status !== 'pending' ? (
          <>
            <CheckCircleIcon color="green.400" />
            <Text fontSize={18}>Conta aprovada</Text>
          </>
        ) : null}
        {me?.personal_document?.status === 'pending' ? (
          <>
            <TimeIcon color="blue.400" />
            <Text fontSize={18}>Documentação em análise</Text>
          </>
        ) : null}
        {me?.personal_document ? (
          <>
            <CheckCircleIcon color="green.400" />
            <Text fontSize={18}>2FA Habilitado</Text>
          </>
        ) : null}
      </HStack>
      <HStack justifyContent="center" w="full" spacing={29}>
        {me &&
          (me.account.status === 'rejected' ||
            me.account.status === 'pending') && <PartnerConfirmation me={me} />}
      </HStack>
    </Stack>
  );
}
