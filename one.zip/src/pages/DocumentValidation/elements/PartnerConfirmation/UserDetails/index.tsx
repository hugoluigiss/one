// import ReactFlagsSelect from 'react-flags-select';
import {
  Heading,
  Button,
  // Avatar,
  FormControl,
  FormLabel,
  HStack,
  Stack,
  SimpleGrid,
} from '@chakra-ui/react';
import { toast } from 'react-toastify';
import { Form, Formik, FormikProps } from 'formik';
import { useEffect, useState } from 'react';

import {
  IPFUpdateData,
  pfUpdateSchema,
} from '../../../../../utils/form-validation-schemas';
import usePost from '../../../../../hooks/usePost';

import Input from '../../../../../components/Form/Inputs/InputText';
import Upload from '../../../../../components/Form/Upload';
import stepProps from '../props';

export default function UserDetails({
  nextStep,
  setSignupdata,
  signupData,
}: stepProps) {
  const [{ data, loading }, checkCPF] = usePost<string>('/signup/cpf');

  useEffect(() => {
    if (data) {
      nextStep();
    }
  }, [data, nextStep]);

  const [front, setFront] = useState<string>();
  const [back, setBack] = useState<string>();

  const [selfie, setSelfie] = useState<string>();

  useEffect(() => {
    if (signupData.personal_document.status !== 'rejected') {
      setFront(signupData.personal_document.front);
      setBack(signupData.personal_document.back);
      setSelfie(signupData.personal_document.selfie);
    }
  }, [signupData]);

  const FormPiece = (
    <Formik
      enableReinitialize
      initialValues={{
        birthdate: signupData.personal_document.birthdate,
        cpf: signupData.personal_document.cpf,
        first_name: signupData.personal_document.first_name,
        last_name: signupData.personal_document.last_name,
      }}
      validationSchema={pfUpdateSchema}
      onSubmit={(values, actions) => {
        if (!values.birthdate) {
          actions.setSubmitting(false);
          return;
        }
        if (!back || !front || !selfie) {
          toast.error('Selecione seus documentos');
          actions.setSubmitting(false);
          return;
        }

        setSignupdata({
          ...signupData,
          personal_document: {
            birthdate: values.birthdate,
            cpf: values.cpf,
            first_name: values.first_name,
            last_name: values.last_name,
            back,
            selfie,
            front,
            user_id: signupData.personal_document.user_id,
          },
        });

        checkCPF({ cpf: values.cpf });
      }}
    >
      {({
        values,
        errors,
        isSubmitting,
        handleChange,
      }: FormikProps<IPFUpdateData>) => (
        <Form>
          <SimpleGrid columns={2} spacing={10}>
            <FormControl isRequired>
              <FormLabel>Nome</FormLabel>
              <Input
                disabled={
                  isSubmitting ||
                  signupData.personal_document.status !== 'rejected'
                }
                name="first_name"
                value={values.first_name}
                onChange={handleChange}
                placeholder="Digite seu nome"
                errorText={errors.first_name}
              />
            </FormControl>
            <FormControl isRequired>
              <FormLabel>Sobrenome</FormLabel>
              <Input
                disabled={
                  isSubmitting ||
                  signupData.personal_document.status !== 'rejected'
                }
                name="last_name"
                value={values.last_name}
                onChange={handleChange}
                placeholder="Digite seu sobrenome"
                errorText={errors.last_name}
              />
            </FormControl>
          </SimpleGrid>

          <SimpleGrid columns={3} spacing={10}>
            <HStack>
              <FormControl isRequired>
                <FormLabel>Documento</FormLabel>
                <Input
                  name="cpf"
                  disabled={
                    isSubmitting ||
                    signupData.personal_document.status !== 'rejected'
                  }
                  value={values.cpf}
                  onChange={handleChange}
                  placeholder="Número do documento"
                  errorText={errors.cpf}
                />
              </FormControl>
            </HStack>
            <FormControl isRequired>
              <FormLabel>Nascimento</FormLabel>
              <Input
                name="birthdate"
                type="date"
                disabled={
                  isSubmitting ||
                  signupData.personal_document.status !== 'rejected'
                }
                value={values.birthdate}
                onChange={handleChange}
                errorText={errors.birthdate}
              />
            </FormControl>
          </SimpleGrid>

          {signupData.personal_document.status === 'rejected' && (
            <SimpleGrid columns={3} spacing={10}>
              <div>
                <span>Documento Frente</span>
                <Upload setFileName={setFront} />
              </div>
              <div>
                <span>Documento Verso</span>
                <Upload setFileName={setBack} />
              </div>
              <div>
                <span>Selfie com documento</span>
                <Upload setFileName={setSelfie} />
              </div>
            </SimpleGrid>
          )}

          <Stack m={4}>
            <Button
              type="submit"
              isLoading={loading}
              colorScheme="brandGray"
              alignSelf="center"
              borderRadius="0"
              w="280px"
            >
              Avançar
            </Button>
          </Stack>
        </Form>
      )}
    </Formik>
  );

  return (
    <Stack>
      <Stack alignItems="center">
        <HStack color="white" m={4}>
          <Heading fontSize="lg">Dados do Titular da Unidade</Heading>
        </HStack>
        <Stack maxWidth="603px" color="white">
          {FormPiece}
        </Stack>
      </Stack>
    </Stack>
  );
}
