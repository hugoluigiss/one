import { Stack } from '@chakra-ui/react';
import ExtractTable from './elements/ExtractTable';
import CardContainer from '../../components/CardContainer';

export default function Extract() {
  return (
    <Stack>
      <CardContainer>
        <ExtractTable />
      </CardContainer>
    </Stack>
  );
}
