import styled from 'styled-components';

export default styled.div`
  display: flex;
  align-items: center;
  background: transparent;
  height: 50px;
  width: 100%;

  > div:first-child {
    margin: 0;
    width: 60px;
    background: transparent;
  }
  > div {
    margin: 0 0 0 18px;
    border-left: 1px solid rgb(168, 170, 180, 1);
    height: 28px;
    display: flex;
    justify-content: center;
  }
  input {
    border: none;
    background: transparent;
  }
  label {
    margin: 0 !important;
  }

  .inputSelectCustom {
    height: 40px;
    border: none;
    border-radius: 4px;
    outline: none;
    width: 100%;
    padding: 5px 0 0 0;
    margin: 5px 0 6px 0;

    button {
      border: none;
    }
  }
  .inputSelectCustom > button {
    font-size: 16px;
    color: #40546d;
    padding: 2px 10px;
  }
  .inputSelectCustom > button > span > span:last-child {
    display: none;
  }

  .inputSelectCustom > button::placeholder {
    color: rgba(255, 255, 255, 0.5);
  }
`;
