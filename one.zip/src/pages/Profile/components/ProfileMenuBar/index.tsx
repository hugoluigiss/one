import { Stack } from '@chakra-ui/react';
import React, { useCallback, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
// import { useAuth } from '../../../../hooks/useAuth';
import useGet from '../../../../hooks/useGet';
import { getMyUnilevel } from '../../../../services/apitypes';

import {
  // DocumentIcon,
  // LockIcon,
  AddressIcon,
  NavLink,
  PageName,
  UserIcon,
  // WalletIcon,
  UserJuridicIcon,
  // SingOut,
} from './styles';

type ProfileMenuProps = {
  selectedPage: number;
  setSelectedPage: React.Dispatch<number>;
};

const ProfileMenuBar: React.FC<ProfileMenuProps> = ({
  selectedPage,
  setSelectedPage,
}: ProfileMenuProps) => {
  const [{ data: unilevel }] = useGet<getMyUnilevel>('/unilevel');

  const history = useHistory();
  const [selectedMenu, setSelectedMenu] = React.useState([
    true,
    false,
    false,
    false,
  ]);
  // const { setToken } = useAuth();

  const handleSelect = useCallback(
    (index: number): void => {
      let selected = -1;
      const newSelection = selectedMenu.map(
        (_selection: boolean, i): boolean => {
          if (i === index) {
            selected = i;
            return true;
          }

          return false;
        },
      );
      setSelectedMenu(newSelection);
      setSelectedPage(selected);
    },
    [selectedMenu, setSelectedPage],
  );

  useEffect(() => {
    handleSelect(selectedPage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedPage]);

  return (
    <Stack
      width={['100%', '100%', '100%', '100%', '273px']}
      minHeight={['unset', 'unset', 'unset', 'unset', '600px']}
      direction={['row', 'row', 'row', 'row', 'column']}
      spacing={0}
    >
      <NavLink
        selected={selectedMenu[0]}
        onClick={() => history.push('/profile/0')}
      >
        <UserIcon />
        <PageName>Dados pessoais</PageName>
      </NavLink>

      <NavLink
        selected={selectedMenu[1]}
        onClick={() => history.push('/profile/1')}
      >
        <AddressIcon />
        <PageName>Endereço pessoal</PageName>
      </NavLink>

      {unilevel && unilevel.type !== 'customer' && (
        <NavLink
          selected={selectedMenu[2]}
          onClick={() => history.push('/profile/2')}
        >
          <UserJuridicIcon />
          <PageName>Dados da Empresa</PageName>
        </NavLink>
      )}
      {unilevel && unilevel.type !== 'customer' && (
        <NavLink
          selected={selectedMenu[3]}
          onClick={() => history.push('/profile/3')}
        >
          <AddressIcon />
          <PageName>Endereço da Empresa</PageName>
        </NavLink>
      )}

      {/* <NavLink
        selected={selectedMenu[2]}
        onClick={() => history.push('/profile/2')}
      >
        <LockIcon />
        <PageName>2FA</PageName>
      </NavLink> */}

      {/* <SingOut
        onClick={async () => {
          setToken(null);
        }}
      >
        <span>Sair</span>
      </SingOut> */}
    </Stack>
  );
};

export default ProfileMenuBar;
