import {
  Badge,
  Button,
  FormControl,
  FormLabel,
  HStack,
  Skeleton,
  Stack,
} from '@chakra-ui/react';
import { toast } from 'react-toastify';
import { Form, Formik, FormikProps } from 'formik';
import { useCallback, useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import axios from 'axios';
import { Container, Header, Content, Line, UserIcon } from '../styles';

import {
  IPJFormData,
  pjSchema,
} from '../../../../../utils/form-validation-schemas';
import useGet from '../../../../../hooks/useGet';
import {
  getMyUnilevel,
  UserPjDocument,
} from '../../../../../services/apitypes';
import Input from '../../../../../components/Form/Inputs/InputText';

import Upload from '../../../../../components/Form/Upload';
import usePost from '../../../../../hooks/usePost';

interface AddressProps {
  CNPJ: string;
  'RAZAO SOCIAL': string;
  'NOME FANTASIA': string;
}

export default function UserJuridicDetails() {
  const history = useHistory();
  const [{ data: unilevel }] = useGet<getMyUnilevel>('/unilevel');

  const [{ data: userDocument, loading: loadingDocs }, reloadDoc] =
    useGet<UserPjDocument>('/documents/pj');

  const [{ data, loading }, addUserInfo] =
    usePost<UserPjDocument>('/documents/pj');

  const [cnpjFilename, setCnpjFilename] = useState<string>();
  const [corporateFileName, setCorporateFilename] = useState<string>();

  const [timeoutRef, setTimeoutRef] = useState<number>();
  const [CnpjApiInfo, setCnpjApiInfo] = useState<AddressProps>();

  const enableInputByDocStatus = (): boolean => {
    return (
      userDocument?.status === 'pending' || userDocument?.status === 'approved'
    );
  };

  const fetchCnpjInfo = useCallback(
    (inputValue: string) => {
      if (inputValue.length < 14) return;

      clearTimeout(timeoutRef);
      const timeout = window.setTimeout(() => {
        axios
          .get(
            `https://api-publica.speedio.com.br/buscarcnpj?cnpj=${inputValue}`,
          )
          .then((res: any) => {
            setCnpjApiInfo(res.data);
          })
          .catch(() => {
            // console.log(err);
          });
      }, 1000);
      setTimeoutRef(timeout);
    },
    [timeoutRef],
  );

  useEffect(() => {
    if (!data) return;
    toast.success('Documentos atualizados com sucesso!\nAguarde confirmação');
    reloadDoc({});
    window.setTimeout(() => {
      history.push('/profile/1');
    }, 1000);
  }, [data, reloadDoc, history]);

  const FormPiece = (
    <Formik
      enableReinitialize
      initialValues={{
        cnpj: userDocument?.value || CnpjApiInfo?.CNPJ || '',
        company_name:
          userDocument?.company_name || CnpjApiInfo?.['RAZAO SOCIAL'] || '',
        fantasy_name:
          userDocument?.fantasy_name || CnpjApiInfo?.['NOME FANTASIA'] || '',
      }}
      validationSchema={pjSchema}
      onSubmit={(values, actions) => {
        if (!cnpjFilename || !corporateFileName) {
          toast.error('Selecione seus documentos');
          actions.setSubmitting(false);
          return;
        }
        addUserInfo({
          cnpj: cnpjFilename,
          company_name: values.company_name,
          social_contract: corporateFileName,
          fantasy_name: values.fantasy_name,
          value: values.cnpj,
        });
      }}
    >
      {({
        values,
        errors,
        isSubmitting,
        handleChange,
      }: FormikProps<IPJFormData>) => (
        <Form>
          <Line>
            <FormControl isRequired>
              <FormLabel>CNPJ</FormLabel>
              <Input
                dark
                disabled={isSubmitting || enableInputByDocStatus()}
                name="value"
                value={values.cnpj}
                onChange={async e => {
                  if (e.target.value.length > 18) return;

                  const maskedEvent = e;
                  maskedEvent.target.value = e.target.value
                    .replace(/\D/g, '')
                    .replace(
                      /^(\d{0,2})(\d{0,3})(\d{0,3})(\d{0,4})(\d{0,2}$)/,
                      '$1.$2.$3/$4-$5',
                    );

                  handleChange(maskedEvent);
                  const { value } = e.target;

                  fetchCnpjInfo(value.replace(/\D/g, ''));
                }}
                placeholder="Digite o CNPJ"
                errorText={errors.cnpj}
              />
            </FormControl>
            <FormControl isRequired>
              <FormLabel>Razão Social</FormLabel>
              <Input
                dark
                disabled={isSubmitting || enableInputByDocStatus()}
                name="company_name"
                value={values.company_name}
                onChange={handleChange}
                placeholder="Digite a razão social"
                errorText={errors.company_name}
              />
            </FormControl>
          </Line>

          <Line>
            <FormControl isRequired>
              <FormLabel>Nome Fantasia</FormLabel>
              <Input
                dark
                name="fantasy_name"
                disabled={isSubmitting || enableInputByDocStatus()}
                value={values.fantasy_name}
                onChange={handleChange}
                placeholder="Digite  o nome fantasia"
                errorText={errors.fantasy_name}
              />
            </FormControl>
          </Line>

          {userDocument?.status === 'rejected' && (
            <Stack>
              <Badge colorScheme="red" w="fit-content">
                Documento Rejeitado, por favor envie, novamente
              </Badge>
            </Stack>
          )}

          {!userDocument || userDocument.status === 'rejected' ? (
            <>
              <Line>
                <div>
                  <span>CNPJ</span>
                  <Upload setFileName={setCnpjFilename} />
                </div>
                <div>
                  <span>Contrato Social</span>
                  <Upload setFileName={setCorporateFilename} />
                </div>
              </Line>
            </>
          ) : (
            <Stack>
              <Badge colorScheme="green" w="fit-content">
                {userDocument?.status === 'approved'
                  ? 'Documento aprovado'
                  : 'Documento enviado'}
              </Badge>
              {userDocument?.status !== 'approved' && (
                <Badge colorScheme="blue" w="fit-content">
                  Aguardando confirmação
                </Badge>
              )}
            </Stack>
          )}

          {(!userDocument || userDocument.status === 'rejected') && (
            <Button type="submit" isLoading={loading}>
              Avançar
            </Button>
          )}
        </Form>
      )}
    </Formik>
  );

  const loadingForm = (
    <Stack spacing={30}>
      <HStack>
        <Skeleton h={50} w={300} />
        <Skeleton h={50} w={300} />
      </HStack>

      <HStack>
        <Skeleton h={50} w={300} />
        <Skeleton h={50} w={150} />
      </HStack>
      <HStack>
        <Skeleton h={50} w={300} />
      </HStack>
    </Stack>
  );

  if (unilevel?.type === 'customer') return <div />;

  return (
    <Container>
      <Content>
        <Header stretched>
          <UserIcon />

          <h3>Pessoa Jurídica</h3>
        </Header>
        <Content maxWidth="603px">
          {loadingDocs ? loadingForm : FormPiece}
        </Content>
      </Content>
    </Container>
  );
}
