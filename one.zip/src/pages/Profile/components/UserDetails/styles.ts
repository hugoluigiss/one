import styled from 'styled-components';
import { ReactComponent as Camera } from '../../../../assets/icons/camera.svg';
import { ReactComponent as User } from '../../../../assets/icons/user.svg';
import { ReactComponent as Address } from '../../../../assets/icons/address.svg';

export const Container = styled.div`
  width: 100%;
`;

export const Header = styled.div<{ stretched?: boolean }>`
  display: flex;
  align-items: center;

  margin-bottom: ${props => (props.stretched ? '24px' : '48px')};
`;

export const AvatarContainer = styled.div`
  margin-right: 24px;
`;

export const Content = styled.div<{ justify?: string; maxWidth?: string }>`
  display: flex;
  flex-direction: column;
  justify-content: ${props => props.justify || 'flex-start'};
  max-width: ${props => props.maxWidth || 'unset'};

  h2 {
    font-size: 20px;
    margin-bottom: 10px;
  }
`;

export const Line = styled.div`
  display: flex;
  margin-bottom: 24px;

  > div:not(:last-child) {
    margin-right: 28px;
  }
`;

export const CameraIcon = styled(Camera)`
  stroke: #2b2a7e;
`;
export const UserIcon = styled(User)`
  stroke: #2b2a7e;
  margin-right: 12px;
`;
export const AddressIcon = styled(Address)`
  stroke: #2b2a7e;
  margin-right: 12px;
`;

export const CountryInputContainer = styled.div`
  display: flex;
  align-items: center;
  background: ${props => props.theme.colors.background};
  width: 100%;

  > div:first-child {
    margin: 0;
    width: 60px;
    background: transparent;
  }
  div:last-child {
    height: 28px;
    display: flex;
    justify-content: center;
  }
  input {
    border: none;
    background: transparent;
  }
  label {
    margin: 0 !important;
  }

  .inputSelectCustom {
    height: 40px;
    border: none;
    border-radius: 4px;
    outline: none;
    width: 100%;
    padding: 5px 0 0 0;
    margin: 5px 0 6px 0;

    button {
      border: none;
    }
  }
  .inputSelectCustom > button {
    font-size: 16px;
    color: #40546d;
    padding: 2px 10px;
  }

  .inputSelectCustom > button::placeholder {
    color: rgba(255, 255, 255, 0.5);
  }
`;
