import { Stack, Heading, Box } from '@chakra-ui/react';
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import ProfileMenuBar from './components/ProfileMenuBar';
import Address from './pages/Address';
import UserInfo from './pages/UserInfo';
import UserJuridic from './pages/UserJuridic';

interface RouteParams {
  id: string;
}

export default function Profile() {
  const { id } = useParams<RouteParams>();
  const [selectedPage, setSelectedPage] = useState(parseInt(id, 10));

  useEffect(() => {
    setSelectedPage(parseInt(id || '0', 10));
  }, [id]);

  return (
    <Stack>
      <Heading mb="12px" color="whiteAlpha.800">
        Perfil
      </Heading>

      <Stack
        direction={['column', 'column', 'column', 'column', 'row']}
        alignItems="flex-start"
        w="full"
        spacing={29}
      >
        <Box
          background="#1f2128"
          width="fit-content"
          borderRadius={10}
          overflow="hidden"
        >
          <ProfileMenuBar
            selectedPage={selectedPage}
            setSelectedPage={setSelectedPage}
          />
        </Box>

        <Box background="#eee" w="full" borderRadius={10}>
          {selectedPage === 0 && <UserInfo />}
          {selectedPage === 1 && <Address />}
          {selectedPage === 2 && <UserJuridic />}
        </Box>
      </Stack>
    </Stack>
  );
}
