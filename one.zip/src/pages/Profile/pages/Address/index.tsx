import AddressDetails from '../../components/UserDetails/AddressDetails';

import { Card, Container } from './styles';

export default function Address() {
  return (
    <Container>
      <Card>
        <AddressDetails />
      </Card>
    </Container>
  );
}
