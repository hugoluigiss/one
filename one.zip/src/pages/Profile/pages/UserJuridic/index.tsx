import UserJuridicDetails from '../../components/UserDetails/UserJuridicDetails';

import { Card, Container } from './styles';

export default function UserJuridic() {
  return (
    <Container>
      <Card>
        <UserJuridicDetails />
      </Card>
    </Container>
  );
}
