import { useEffect, useState } from 'react';
import { Hide, Show, Stack, IconButton } from '@chakra-ui/react';
import { NavLink, useLocation } from 'react-router-dom';
import { toast } from 'react-toastify';
import AppBar from '../../../components/Layout/AppBar';
import Sidebar from '../../../components/Layout/SidebarMain/Sidebar';
import useWindowDimensions from '../../../hooks/useWindowDimensions';
import { ReactComponent as CollapseMenu } from '../../../assets/icons/collapse-coins.svg';

import { InternContent, Content } from './styles';
import useGet from '../../../hooks/useGet';
import CoinsCarousel from '../../../components/Utils/CoinsCarousel';
import CardsCoins from '../../../components/CoinCards';
import { User } from '../../../services/apitypes';
import MenuMobile from '../../../components/Layout/SidebarMain/MenuMobile';
import Footer from '../../../components/Layout/Footer';

interface LayoutProps {
  children?: React.ReactNode;
}

const MOBILE_WIDTH = 768;

export default function DashboardLayout({
  children,
}: LayoutProps): JSX.Element {
  const location = useLocation();
  const collapse = useState(false);
  const { width } = useWindowDimensions();

  const [{ data: me }] = useGet<User>('/profile/me');

  const [collapsed, setCollapsed] = useState(false);

  const toggleCollapse = () => {
    setCollapsed(state => !state);
  };

  useEffect(() => {
    if (width < MOBILE_WIDTH) collapse[1](true);
  }, [collapse, width]);

  useEffect(() => {
    if (!location.pathname.includes('dashboard')) setCollapsed(true);
    else setCollapsed(false);
  }, [location]);

  useEffect(() => {
    if (me?.account?.status === 'pending' && !me.personal_document)
      toast.warning(
        <NavLink to="/profile">
          Clique aqui para enviar sua documentação
        </NavLink>,
      );

    if (me && !me?.account)
      toast.error('Conta inativa, entre em contato com o suporte');
  }, [me]);

  return (
    <>
      <AppBar me={me} collapse={collapse[0]} />

      <Hide below="md">
        <Sidebar collapse={collapse} />
      </Hide>

      <Show below="md">
        <MenuMobile />
      </Show>

      <InternContent isCollapsed={collapse[0]} mobileWidth={MOBILE_WIDTH}>
        <Stack w="100%" bg="brandBg.300">
          <CoinsCarousel />
          <Stack position="relative" h="auto">
            <CardsCoins collapsed={collapsed} />

            <IconButton
              m="0 !important"
              position="absolute"
              aria-label="minimizar moedas"
              colorScheme="transparent"
              icon={<CollapseMenu />}
              bottom="0"
              left="calc(50% - 20px)"
              transform={`scale(1, ${collapsed ? -1 : 1})`}
              transition="200ms"
              onClick={toggleCollapse}
            />
          </Stack>
        </Stack>
        <Content>{children}</Content>

        <Footer />
      </InternContent>
    </>
  );
}
