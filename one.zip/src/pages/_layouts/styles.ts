import styled from 'styled-components';
import logo from '../../assets/images/bg-image.png';

export const Container = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;

  height: 100vh;
  width: 100%;
  position: relative;
  background: linear-gradient(221deg, #2f274094, #1a1b2194, #2f274094);

  background-size: 600% 600%;
  -webkit-animation: LoginBG 48s ease infinite;
  -moz-animation: LoginBG 48s ease infinite;
  animation: LoginBG 48s ease infinite;

  @-webkit-keyframes LoginBG {
    0% {
      background-position: 0% 74%;
    }
    50% {
      background-position: 100% 27%;
    }
    100% {
      background-position: 0% 74%;
    }
  }
  @-moz-keyframes LoginBG {
    0% {
      background-position: 0% 74%;
    }
    50% {
      background-position: 100% 27%;
    }
    100% {
      background-position: 0% 74%;
    }
  }
  @keyframes LoginBG {
    0% {
      background-position: 0% 74%;
    }
    50% {
      background-position: 100% 27%;
    }
    100% {
      background-position: 0% 74%;
    }
  }
`;

export const BgOverlay = styled.div`
  position: absolute;
  width: 100vw;
  height: 100vh;
  z-index: -1;

  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  background-image: url(${logo});

  -webkit-animation: image_blur 5s infinite alternate ease-in-out;

  @-webkit-keyframes image_blur {
    0% {
      -webkit-filter: blur(0px);
    }
    100% {
      -webkit-filter: blur(28px);
    }
  }
`;

export const BoxContainer = styled.div`
  width: 360px;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
`;
export const ActionBox = styled.div`
  width: 100%;
  padding: 20px;
  box-sizing: border-box;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  h1 {
    color: #fff;
    font-size: 24px;
    margin: 40px 0 0 0;
    text-align: center;
  }
`;
