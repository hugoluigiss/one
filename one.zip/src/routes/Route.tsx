import {
  Route as ReactDOMRoute,
  RouteProps as ReactDOMRouterProps,
  Redirect,
} from 'react-router-dom';
import Logged from '../pages/_layouts/dashboard';
import Auth from '../pages/_layouts/auth';
import { useAuth } from '../hooks/useAuth';

interface RouterProps extends ReactDOMRouterProps {
  isPrivate?: boolean;
  component: React.ComponentType;
}

export default function Route({
  isPrivate = false,
  component: Component,
  ...rest
}: RouterProps): JSX.Element {
  const { token } = useAuth();

  const signed = !!token;

  const Layout = signed ? Logged : Auth;

  return (
    <ReactDOMRoute
      {...rest}
      render={({ location }) => {
        return isPrivate === signed ? (
          <Layout>
            <Component />
          </Layout>
        ) : (
          <Redirect
            to={{
              pathname: isPrivate ? '/' : '/dashboard',
              state: { from: location },
            }}
          />
        );
      }}
    />
  );
}
