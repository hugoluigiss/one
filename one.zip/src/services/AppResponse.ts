export default class AppResponse {
  constructor(input: AppResponse) {
    Object.assign(this, input);
  }

  data?: any;

  error?: {
    status: number;
    message: string;
  };
}
