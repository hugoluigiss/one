import { extendTheme } from '@chakra-ui/react';
import { StepsStyleConfig as Steps } from 'chakra-ui-steps';

const config = {
  initialColorMode: 'light',
  useSystemColorMode: false,
};

const colors = {
  text: {
    500: '#E1D9D9',
    800: '#626572',
  },
  brandBlack: {
    100: '#454545',
    200: '#393939',
    300: '#343434',
    400: '#2C2C2C',
    500: '#000000',
    600: '#222222',
    700: '#191919',
    800: '#0B0B0B',
    900: '#000000',
  },
  brandGray: {
    100: '#888888',
    200: '#7C7C7C',
    300: '#717171',
    400: '#5D5D5D',
    500: '#525050',
    600: '#4B4949',
    700: '#3B3939',
    800: '#333030',
    900: '#292727',
  },
  brandBg: {
    300: '#25252C',
    500: '#1f2128',
    900: '#0f0f12',
  },
  cardBg: {
    500: '#1F2128',
  },
  cardBorder: {
    500: '#3D404B',
  },
};

// const CustomSteps = {
//   ...Steps,
//   baseStyle: {
//     steps: {
//       color: 'red',
//     },
//     label: {
//       color: 'red',
//     },
//   },
// };

const theme = extendTheme({
  config,
  colors,
  components: {
    Steps,
    Modal: {
      baseStyle: () => ({
        dialog: {
          bg: '#E2E2E2',
          borderRadius: 0,
        },
      }),
    },
    Input: {
      baseStyle: {
        field: {
          bg: '#E2E2E2',
          border: 'solid 1px #707070',
          borderRadius: 'none',
        },
      },
      defaultProps: {
        variant: null,
      },
    },
    Select: {
      sizes: {
        sm: {
          field: {
            borderRadius: '11px',
          },
        },
      },
    },
  },
});

export default theme;
