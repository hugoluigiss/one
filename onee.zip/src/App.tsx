import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { ThemeProvider } from 'styled-components';
import { ApolloProvider } from '@apollo/client';

import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import defaultTheme from './styles/themes/default';

import AppProvider from './context';

import Routes from './routes';

import apolloClient from './services/apollo';

const App: React.FC = () => {
  return (
    <ApolloProvider client={apolloClient}>
      <ThemeProvider theme={defaultTheme}>
        <Router>
          <AppProvider>
            <Routes />
            <ToastContainer autoClose={3000} />
          </AppProvider>
        </Router>
      </ThemeProvider>
    </ApolloProvider>
  );
};

export default App;
