/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React, { useState } from 'react';
import cx from 'classnames';
import { useHistory } from 'react-router-dom';
// import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';
import Logo from '../Logo';
import style from './appbar.module.scss';

// import notifications from '../../assets/images/notifications.svg';
// import settings from '../../assets/images/settings.svg';
import useAuth from '~/hooks/useAuth';
import {
  useGetMyProfileQuery,
  useGetMyAssociatedAccountsQuery,
  useCreateSwitchAccountMutation,
} from '~/graphql/generated/graphql';
// import useToast from '~/hooks/useToast';

interface Account {
  id: string;
  avatar_url: string;
  full_name: string;
}

const AppBar: React.FC = () => {
  // const { addToast } = useToast();

  const [isCollapse, setCollapse] = useState(false);
  const handleMenu = (): void => {
    setCollapse(!isCollapse);
  };

  const { data: me } = useGetMyProfileQuery();
  const { data: accounts } = useGetMyAssociatedAccountsQuery();

  const [doSwitchAccount] = useCreateSwitchAccountMutation();

  const handleNav = useHistory();
  const { signOut } = useAuth();

  const [selectedAccount, setSelectedAccount] = useState<Account>();
  const [isSwitching, setIsSwitching] = useState(false);

  const handleSwitchAccount = (account: Account): void => {
    setSelectedAccount(account);
    setIsSwitching(true);
    doSwitchAccount({ variables: { to_customer_id: account.id } })
      .then(resp => {
        const token = resp.data?.CreateSwitchAccount.token;
        if (!token) return;

        localStorage.setItem('@OneExchange-client:token', token);

        setTimeout(() => window.location.reload(true), 2000);
      })
      .catch(err => {
        // addToast({
        //   type: 'error',
        //   title: 'Oooops, Ocorreu um erro!',
        //   description: err.message,
        // });
        toast.error(err.message);
        return 'error';
      });
  };

  return (
    <div className={style.container}>
      <div className={style.logoArea}>
        <Logo />
      </div>

      <div className={style.actionBox}>
        {/* <div className={style.iconAction}>
          <img src={notifications} alt="notification" />
        </div> */}

        {/* <div className={style.iconAction}>
          <img src={settings} alt="settings" />
        </div> */}

        <div className={style.profileFigureAction}>
          <img
            onClick={handleMenu}
            src={me?.GetMyProfile.avatar_url}
            alt={me?.GetMyProfile.full_name}
          />
          <h6 onClick={handleMenu}>{me?.GetMyProfile.full_name}</h6>
          <div className={style.arrowAction} onClick={handleMenu} />

          {isCollapse && <div className={style.overlay} onClick={handleMenu} />}

          <div
            className={cx(
              style.optionsMenu,
              isCollapse ? style.optionsMenuCollapsed : null,
            )}
          >
            <div className={style.accountsList}>
              {accounts?.GetMyAssociatedAccounts.map(account => {
                return (
                  <a
                    onClick={() => handleSwitchAccount(account)}
                    key={account.id}
                  >
                    <div className={style.item}>
                      {account.full_name}

                      <div className={style.iconSwitch} />
                    </div>
                  </a>
                );
              })}
            </div>
            <a onClick={() => handleNav.push('/profile')}>Meu perfil</a>
            <a onClick={() => signOut()}>Sair</a>
          </div>
        </div>
      </div>

      {isSwitching && (
        <div className={style.accountSwitchContainer}>
          <h1>Aguarde, você será direcionado para outra conta</h1>

          <div className={style.account1}>
            <img
              src={me?.GetMyProfile.avatar_url}
              alt={me?.GetMyProfile.full_name}
            />
          </div>
          <div className={style.account2}>
            <img
              src={selectedAccount?.avatar_url}
              alt={selectedAccount?.full_name}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default AppBar;
