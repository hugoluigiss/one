import React, { useState } from 'react';

import style from './balance.module.scss';
import ButtonSecondary from '../ButtonSecondary';
import ModalActionDeposit from '../ModalActionDeposit';
import ModalActionWithdraw from '../ModalActionWithdraw';
import { useGetMyCoinWalletBySymbolQuery } from '~/graphql/generated/graphql';

const Balance: React.FC = () => {
  const [activeModalDeposit, setActiveModalDeposit] = useState(false);
  const [activeModalWithdraw, setActiveModalWithdraw] = useState(false);
  const { data: brlWallet } = useGetMyCoinWalletBySymbolQuery({
    variables: { symbol: 'BRL' },
  });

  return (
    <div className={style.container}>
      {activeModalDeposit && (
        <ModalActionDeposit
          activeModal={activeModalDeposit}
          onHandleClose={() => setActiveModalDeposit(false)}
        />
      )}

      {activeModalWithdraw && (
        <ModalActionWithdraw
          activeModal={activeModalWithdraw}
          onHandleClose={() => setActiveModalWithdraw(false)}
        />
      )}

      <span>
        Saldo em <b>R$</b>
      </span>
      <h2>{brlWallet?.GetMyCoinWalletBySymbol.formatted_balance}</h2>

      <div className={style.groupButtons}>
        <ButtonSecondary
          secondaryBtn={false}
          onPress={() => setActiveModalDeposit(!activeModalDeposit)}
        >
          Depositar
        </ButtonSecondary>
        <ButtonSecondary
          secondaryBtn
          onPress={() => setActiveModalWithdraw(!activeModalWithdraw)}
        >
          Saque
        </ButtonSecondary>
      </div>
    </div>
  );
};

export default Balance;
