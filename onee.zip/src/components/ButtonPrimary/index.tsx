/* eslint-disable react/require-default-props */
import React from 'react';
import cx from 'classnames';
import style from './buttonprimary.module.scss';

type ButtonProps = {
  children: string;
  transparency?: boolean;
  link?: boolean;
  disabled?: boolean;
  onPress(): void;
};

const ButtonPrimary: React.FC<ButtonProps> = ({
  children,
  transparency = false,
  link = false,
  disabled = false,
  onPress,
}: ButtonProps) => {
  return (
    <button
      type="button"
      onClick={onPress}
      disabled={disabled}
      className={cx(
        transparency ? style.btnTransparency : style.btn,
        link && style.btnLink,
      )}
    >
      {children}
    </button>
  );
};

export default ButtonPrimary;
