import React from 'react';
import { useGetOscilationChartDataQuery } from '~/graphql/generated/graphql';

import CurrencyWithIcon from '../UtilsComponents/CurrencyWithIcon';
// import ButtonSecondary from '../ButtonSecondary';
// import StatusPriceDisplay from '../UtilsComponents/StatusPriceDisplay';
import StatusPercentage from '../UtilsComponents/StatusPercentage';

import { formatPrice } from '~/utils/format';

interface IParams {
  interval: string;
  coin_symbol: string;
  coin_name: string;
  value: number;
}
interface IParsedResponse {
  variation: number;
  lastValue: number;
  high: number;
  low: number;
}
const CoinRow: React.FC<IParams> = ({
  interval,
  coin_symbol,
  value,
  coin_name,
}: IParams) => {
  const { data, loading } = useGetOscilationChartDataQuery({
    variables: {
      coin_symbol,
      interval,
      value,
    },
  });

  const { variation, high, lastValue, low }: IParsedResponse =
    data && data.GetOscilationChartData
      ? JSON.parse(data.GetOscilationChartData)
      : { variation: 0, low: 0, lastValue: 0, high: 0 };

  if (loading) return <tr />;

  return (
    <tr>
      <td>
        <CurrencyWithIcon
          hover={false}
          iconName={coin_symbol.toLowerCase()}
          currency={coin_name}
        />
      </td>
      <td>
        <StatusPercentage value={variation} />
      </td>
      <td>{formatPrice(lastValue)}</td>
      <td>{formatPrice(high)}</td>
      <td>{formatPrice(low)}</td>
    </tr>
  );
};

export default CoinRow;
