import React from 'react';

import style from './coinstable.module.scss';

import SelectorTableButton from '../UtilsComponents/SelectorTableButton';

import CoinRow from './CoinRow';

interface IOption {
  name: string;
  value: number;
  interval: string;
}

const options: IOption[] = [
  { name: '1h', value: 1, interval: 'hour' },
  { name: '24h', value: 24, interval: 'hour' },
  { name: '7d', value: 7, interval: 'day' },
  { name: '30d', value: 30, interval: 'day' },
  { name: '90d', value: 90, interval: 'day' },
  { name: '1a', value: 366, interval: 'day' },
  // { name: 'tudo', value: 2000, interval: 'day' },
];

const coins = [
  {
    coin_symbol: 'BTC',
    coin_name: 'Bitcoin',
  },
  {
    coin_symbol: 'ETH',
    coin_name: 'Ethereum',
  },
  {
    coin_symbol: 'BNB',
    coin_name: 'BNB',
  },
  {
    coin_symbol: 'USDT',
    coin_name: 'USDT',
  },
];

const CoinsTable: React.FC = () => {
  const [period, setPeriod] = React.useState<IOption>(options[1]);

  return (
    <div className={style.container}>
      <div className={style.header}>
        <div className={style.headerinline}>
          <h3>Moedas</h3>
          {/* <StatusPercentage value={-83.0184} /> */}
        </div>
        <SelectorTableButton
          options={options}
          selectedOption={period}
          setSelectedOption={setPeriod}
        />
      </div>

      <div className={style.tableContainer}>
        <table>
          <thead>
            <tr>
              <th>Moeda</th>
              <th>Variação</th>
              <th>Última</th>
              <th>Maior</th>
              <th>Menor</th>
              {/* <th>Volume</th> */}
            </tr>
          </thead>

          <tbody>
            {coins.map(coin => (
              <CoinRow
                key={coin.coin_symbol}
                {...coin}
                interval={period.interval}
                value={period.value}
              />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CoinsTable;
