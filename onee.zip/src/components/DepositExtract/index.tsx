import React from 'react';

import style from './depositextractTable.module.scss';
import CurrencyWithIcon from '../UtilsComponents/CurrencyWithIcon';
import DateWithHour from '../UtilsComponents/DateWithHour';
import ButtonSecondary from '../ButtonSecondary';
import DownloadIcon from '../UtilsComponents/DownloadIcon';
import CircleStatusIndicator from '../UtilsComponents/CircleStatusIndicator';

import { useGetMyStatmentQuery } from '~/graphql/generated/graphql';

interface ITransaction {
  id: string;
  created_at: string;
  description: string;
  formatted_total_value: string;
  formatted_net_value: string;
  formatted_fee_value: string;
  status: string;
  coin: {
    name: string;
    symbol: string;
  };
  file_url?: string;
}

const DepositExtract: React.FC = () => {
  // const [transactions, setTransactions] = React.useState<ITransaction[]>([]);
  const offset = React.useRef(0);

  // const [getMyStatment, { data }] = useGetMyStatmentLazyQuery({
  //   fetchPolicy: 'no-cache',
  // });

  // const handleFetchMore = React.useCallback(async () => {
  //   offset.current += 1;
  //   getMyStatment({
  //     variables: {
  //       final_date: new Date(),
  //       start_date: new Date(2020),
  //       offset: offset.current,
  //       limit,
  //       coin_symbol: 'BRL',
  //       operation: 'deposit',
  //     },
  //   });
  // }, [getMyStatment]);

  // React.useEffect(() => {
  //   setTransactions([]);
  //   offset.current = 0;
  //   getMyStatment({
  //     variables: {
  //       final_date: new Date(),
  //       start_date: new Date(2020),
  //       offset: offset.current,
  //       limit,
  //       coin_symbol: 'BRL',
  //       operation: 'deposit',
  //     },
  //   });
  // }, [getMyStatment]);

  // React.useEffect(() => {
  //   if (data && data.GetMyStatment.edges.transactions) {
  //     const newData = data.GetMyStatment.edges.transactions.map(t => ({
  //       id: t.id,
  //       created_at: t.created_at,
  //       description: t.description,
  //       formatted_fee_value: t.formatted_fee_value,
  //       formatted_net_value: t.formatted_net_value,
  //       formatted_total_value: t.formatted_total_value,
  //       status: t.status,
  //       coin: {
  //         name: t.coin.name,
  //         symbol: t.coin.symbol,
  //       },
  //       file_url: t.brl_deposit?.file_url,
  //     }));
  //     setTransactions(state => [...state, ...newData]);
  //   }
  // }, [data]);

  const { fetchMore, data } = useGetMyStatmentQuery({
    variables: {
      coin_symbol: 'BRL',
      operation: 'deposit',
    },
    // fetchPolicy: 'no-cache',
  });
  const handleFetchMore = React.useCallback(async () => {
    offset.current += 1;
    fetchMore({
      variables: {
        offset: offset.current,
        coin_symbol: 'BRL',
        operation: 'deposit',
      },
      updateQuery: (prev, { fetchMoreResult }) => {
        if (!fetchMoreResult) return prev;

        return {
          GetMyStatment: {
            pageInfo: { ...fetchMoreResult.GetMyStatment.pageInfo },
            totalCount: fetchMoreResult.GetMyStatment.totalCount,
            edges: {
              transactions:
                fetchMoreResult.GetMyStatment.edges.transactions &&
                prev.GetMyStatment.edges.transactions
                  ? [
                      ...prev.GetMyStatment.edges.transactions,
                      ...fetchMoreResult.GetMyStatment.edges.transactions,
                    ]
                  : undefined,
            },
          },
        };
      },
    });
  }, [fetchMore]);

  const transactions: ITransaction[] =
    data && data.GetMyStatment.edges.transactions
      ? data.GetMyStatment.edges.transactions.map(t => ({
          id: t.id,
          created_at: t.created_at,
          description: t.description,
          formatted_fee_value: t.formatted_fee_value,
          formatted_net_value: t.formatted_net_value,
          formatted_total_value: t.formatted_total_value,
          status: t.status,
          coin: {
            name: t.coin.name,
            symbol: t.coin.symbol,
          },
          file_url:
            t.brl_deposit?.file_url || t.brl_withdrawal?.file_url || undefined,
        }))
      : [];

  const hasFileUrl = !!transactions.find(t => t.file_url);

  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>Meus depósitos</h3>
        <CircleStatusIndicator indicator />
      </div>

      <div className={style.tableContainer}>
        <table>
          <thead>
            <tr>
              <th>Data</th>
              <th>Moeda</th>
              {/* <th>Transação</th> */}
              {/* <th>Valor Total</th> */}
              {/* <th>Taxa</th> */}
              <th>Valor Líquido</th>
              <th>Status</th>
              {hasFileUrl && <th>Comprovante</th>}
            </tr>
          </thead>

          <tbody>
            {transactions.map(transaction => (
              <tr key={transaction.id}>
                <td>
                  <DateWithHour dateValue={transaction.created_at} />
                </td>
                <td>
                  <CurrencyWithIcon
                    iconName={transaction.coin.symbol.toLowerCase()}
                    currency={transaction.coin.name}
                    hover={false}
                  />
                </td>
                {/* <td>{transaction.description}</td> */}
                {/* <td>{transaction.formatted_total_value}</td> */}
                {/* <td>{transaction.formatted_fee_value}</td> */}
                <td>{transaction.formatted_net_value}</td>
                <td>{transaction.status}</td>
                {transaction.file_url && (
                  <td>
                    <DownloadIcon
                      onPress={() => window.open(transaction.file_url)}
                    />
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>

        {data?.GetMyStatment.pageInfo.hasNextPage && (
          <div className={style.seeMoreButton}>
            <ButtonSecondary onPress={() => handleFetchMore()} secondaryBtn>
              Ver mais
            </ButtonSecondary>
          </div>
        )}
      </div>
    </div>
  );
};

export default DepositExtract;
