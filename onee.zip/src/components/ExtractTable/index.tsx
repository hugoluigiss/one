import React from 'react';

// import { useTranslation } from 'react-i18next';
import style from './extractTable.module.scss';
import CurrencyWithIcon from '../UtilsComponents/CurrencyWithIcon';
import DateWithHour from '../UtilsComponents/DateWithHour';
import ButtonSecondary from '../ButtonSecondary';
import DownloadIcon from '../UtilsComponents/DownloadIcon';
import SelectorTableButton from '../UtilsComponents/SelectorTableButton';
import FilterPeriodDate from '../UtilsComponents/FilterPeriodDate';

// import { formatPrice, formatAmount } from '~/utils/format';
import { useGetMyStatmentQuery } from '~/graphql/generated/graphql';

interface ITransaction {
  id: string;
  created_at: string;
  description: string;
  formatted_total_value: string;
  formatted_net_value: string;
  formatted_fee_value: string;
  status: string;
  coin: {
    name: string;
    symbol: string;
  };
  file_url?: string;
}

interface IRange {
  startDate: Date;
  endDate: Date;
}

interface IOption {
  name: string;
  value: number;
  interval: string;
  symbol?: string;
}

const options: IOption[] = [
  {
    name: 'BTC',
    symbol: 'BTC',
    value: 3,
    interval: '',
  },
  {
    name: 'ETH',
    symbol: 'ETH',
    value: 4,
    interval: '',
  },
  {
    name: 'BRL',
    symbol: 'BRL',
    value: 1,
    interval: '',
  },
  {
    name: 'Todas as Moedas',
    value: 0,
    interval: '',
  },
];

const operations: IOption[] = [
  {
    name: 'Todas as operações',
    value: 0,
    interval: 'all',
  },
  {
    name: 'Depósito',
    value: 0,
    interval: 'deposit',
  },
  {
    name: 'Saque',
    value: 0,
    interval: 'withdrawal',
  },
  {
    name: 'Troca',
    value: 0,
    interval: 'buy',
  },
];

const ExtractTable: React.FC = () => {
  const [range, setRange] = React.useState<IRange>({
    endDate: new Date(),
    startDate: new Date(2020),
  } as IRange);

  const [selectedOption, setSelectedOption] = React.useState<IOption>(
    options[3],
  );

  const [selectedOperation, setSelectedOperation] = React.useState<IOption>(
    operations[0],
  );

  const offset = React.useRef(0);
  const limit = 10;

  const { fetchMore, data } = useGetMyStatmentQuery({
    variables: {
      final_date: range.endDate,
      start_date: range.startDate,
      limit,
      coin_symbol: selectedOption.symbol,
      operation: selectedOperation.interval,
    },
  });

  const handleFetchMore = React.useCallback(async () => {
    offset.current += 1;
    fetchMore({
      variables: {
        final_date: range.endDate,
        start_date: range.startDate,
        offset: offset.current,
        limit,
        coin_symbol: selectedOption.symbol,
        operation: selectedOperation.interval,
      },
      updateQuery: (prev, { fetchMoreResult }) => {
        if (!fetchMoreResult) return prev;

        return {
          GetMyStatment: {
            pageInfo: { ...fetchMoreResult.GetMyStatment.pageInfo },
            totalCount: fetchMoreResult.GetMyStatment.totalCount,
            edges: {
              transactions:
                fetchMoreResult.GetMyStatment.edges.transactions &&
                prev.GetMyStatment.edges.transactions
                  ? [
                      ...prev.GetMyStatment.edges.transactions,
                      ...fetchMoreResult.GetMyStatment.edges.transactions,
                    ]
                  : undefined,
            },
          },
        };
      },
    });
  }, [
    fetchMore,
    range.endDate,
    range.startDate,
    selectedOperation.interval,
    selectedOption.symbol,
  ]);

  const transactions: ITransaction[] =
    data && data.GetMyStatment.edges.transactions
      ? data.GetMyStatment.edges.transactions.map(t => ({
          id: t.id,
          created_at: t.created_at,
          description: t.description,
          formatted_fee_value: t.formatted_fee_value,
          formatted_net_value: t.formatted_net_value,
          formatted_total_value: t.formatted_total_value,
          status: t.status,
          coin: {
            name: t.coin.name,
            symbol: t.coin.symbol,
          },
          file_url:
            t.brl_deposit?.file_url || t.brl_withdrawal?.file_url || undefined,
        }))
      : [];

  const hasFileUrl = !!transactions.find(t => t.file_url);

  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>Extrato</h3>
        <div className={style.headerinline}>
          <FilterPeriodDate setRange={setRange} />
          <SelectorTableButton
            options={options}
            selectedOption={selectedOption}
            setSelectedOption={setSelectedOption}
          />
          <SelectorTableButton
            options={operations}
            selectedOption={selectedOperation}
            setSelectedOption={setSelectedOperation}
          />
        </div>
      </div>

      <div className={style.tableContainer}>
        <table>
          <thead>
            <tr>
              <th>Data</th>
              <th>Moeda</th>
              <th>Transação</th>
              <th>Valor Total</th>
              <th>Taxa</th>
              <th>Valor Líquido</th>
              <th>Status</th>
              {hasFileUrl && <th>Comprovante</th>}
            </tr>
          </thead>

          <tbody>
            {transactions.map(transaction => (
              <tr key={transaction.id}>
                <td>
                  <DateWithHour dateValue={transaction.created_at} />
                </td>
                <td>
                  <CurrencyWithIcon
                    iconName={transaction.coin.symbol.toLowerCase()}
                    currency={transaction.coin.name}
                    hover={false}
                  />
                </td>
                <td>{transaction.description}</td>
                <td>{transaction.formatted_total_value}</td>
                <td>{transaction.formatted_fee_value}</td>
                <td>{transaction.formatted_net_value}</td>
                <td>{transaction.status}</td>
                {transaction.file_url && (
                  <td>
                    <DownloadIcon
                      onPress={() => window.open(transaction.file_url)}
                    />
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
        {data?.GetMyStatment.pageInfo.hasNextPage && (
          <div className={style.seeMoreButton}>
            <ButtonSecondary onPress={() => handleFetchMore()} secondaryBtn>
              Ver mais
            </ButtonSecondary>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExtractTable;
