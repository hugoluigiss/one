import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  InputHTMLAttributes,
} from 'react';
import { useField } from '@unform/core';

import { Container, Error } from './styles';

interface Props extends InputHTMLAttributes<HTMLInputElement> {
  name: string;
  className?: string;
  icon?: JSX.Element;
}

const Input: React.FC<Props> = ({
  name,
  className = '',
  icon: Icon,
  disabled,
  ...rest
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const [isFocused, setIsFocused] = useState(false);
  const [isFilled, setIsFilled] = useState(false);

  const { fieldName, defaultValue, registerField, error } = useField(name);

  const handleInputFocus = useCallback(() => {
    setIsFocused(true);
  }, []);

  const handleInputBlur = useCallback(() => {
    setIsFocused(false);

    setIsFilled(!!inputRef.current?.value);
  }, []);

  useEffect(() => {
    registerField({
      name: fieldName,
      ref: inputRef.current,
      path: 'value',
    });
  }, [fieldName, registerField]);

  return (
    <>
      <Container
        className={className}
        isFilled={isFilled}
        isErrored={!!error}
        isFocused={isFocused}
        isDisabled={disabled}
        data-testid="input-container"
      >
        {Icon}

        <input
          ref={inputRef}
          defaultValue={defaultValue}
          onFocus={handleInputFocus}
          onBlur={handleInputBlur}
          disabled={disabled}
          {...rest}
        />
      </Container>

      {error && <Error>{error}</Error>}
    </>
  );
};

export default Input;
