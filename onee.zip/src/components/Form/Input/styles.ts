import styled, { css } from 'styled-components';
import { shade } from 'polished';

interface ContainerProps {
  isDisabled?: boolean;
  isErrored?: boolean;
  isFocused?: boolean;
  isFilled?: boolean;
}

export const Container = styled.div<ContainerProps>`
  height: 50px;
  width: 100%;
  padding: 16px;
  border-radius: 5px;
  background: ${props => props.theme.colors.background};

  border: 1px solid ${props => shade(0.3, props.theme.colors.background)};
  color: #666360;

  display: flex;
  align-items: center;

  transition: border-color 0.2s, color 0.2s;

  & + div {
    margin-top: 8px;
  }

  ${props =>
    props.isErrored &&
    css`
      border-color: #fb6f91;
    `}

  ${props =>
    props.isFocused &&
    css`
      border-color: ${props.theme.colors.primary};
      color: ${props.theme.colors.primary};
    `}

  ${props =>
    props.isFilled &&
    css`
      color: ${props.theme.colors.primary};
    `}

    ${props =>
      props.isDisabled &&
      css`
        color: #777;
        background: #bbbbbb;
        opacity: 0.5;
      `}

  input {
    flex: 1;
    border: 0;
    color: ${props => props.theme.colors.text};
    background: transparent;
    font-size: ${props => props.theme.fontSize.normal};

    &::placeholder {
      color: #666360;
    }
  }

  svg {
    margin-right: 16px;
  }
`;

export const Input = styled.input`
  transition: border 0.2s ease 0s;

  &:focus {
    border-color: ${props => props.theme.colors.primary};
  }
`;

export const Error = styled.span`
  display: block;
  margin: 4px 0 8px;
  color: #fb6f91;
  font-size: 14px;
  font-weight: bold;
`;
