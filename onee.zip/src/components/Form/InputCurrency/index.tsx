import React, {
  useCallback,
  useState,
  useRef,
  useEffect,
  KeyboardEvent,
} from 'react';
import { useField } from '@unform/core';

import { Container, Error } from './styles';

interface Props {
  className?: string;
  max: number;
  min?: number;
  onValueChange: (value: number) => void;
  style?: React.CSSProperties;
  currencyValue: number;
  icon?: JSX.Element;
  name: string;
}

const VALID_FIRST = /^[1-9]{1}$/;
const VALID_NEXT = /^[0-9]{1}$/;
const DELETE_KEY_CODE = 8;

const CurrencyInput: React.FC<Props> = ({
  className = '',
  max,
  onValueChange,
  style = {},
  currencyValue,
  icon: Icon,
  name,
  ...rest
}) => {
  const inputRef = useRef(null);
  const { fieldName, registerField, defaultValue, error } = useField(name);

  const [isFocused, setIsFocused] = useState(false);
  const [isFilled, setIsFilled] = useState(false);

  const handleInputFocus = useCallback(() => {
    setIsFocused(true);
  }, []);

  const handleInputBlur = useCallback(() => {
    setIsFocused(false);

    setIsFilled(!!inputRef.current);
  }, []);

  const valueAbsTrunc = Math.trunc(Math.abs(currencyValue));
  if (
    currencyValue !== valueAbsTrunc ||
    !Number.isFinite(currencyValue) ||
    Number.isNaN(currencyValue)
  ) {
    // throw new Error(`invalid value property`);
    console.log('sad');
  }

  const handleKeyDown = useCallback(
    (e: KeyboardEvent<HTMLDivElement>): void => {
      const { key, keyCode } = e;
      if (
        (currencyValue === 0 && !VALID_FIRST.test(key)) ||
        (currencyValue !== 0 &&
          !VALID_NEXT.test(key) &&
          keyCode !== DELETE_KEY_CODE)
      ) {
        return;
      }
      const valueString = currencyValue.toString();
      let nextValue: number;
      if (keyCode !== DELETE_KEY_CODE) {
        const nextValueString: string =
          currencyValue === 0 ? key : `${valueString}${key}`;
        nextValue = Number.parseInt(nextValueString, 10);
      } else {
        const nextValueString = valueString.slice(0, -1);
        nextValue =
          nextValueString === '' ? 0 : Number.parseInt(nextValueString, 10);
      }
      if (nextValue > max) {
        return;
      }
      onValueChange(nextValue);
    },
    [max, onValueChange, currencyValue],
  );

  const handleChange = useCallback(() => {
    // DUMMY TO AVOID REACT WARNING
  }, []);

  const valueDisplay = (currencyValue / 100).toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });

  useEffect(() => {
    registerField({
      name: fieldName,
      ref: inputRef.current,
      path: 'value',
      setValue(ref: any, value: string) {
        ref.setInputValue(value);
      },
    });
  }, [fieldName, registerField]);

  return (
    <>
      <Container isErrored={!!error} isFilled={isFilled} isFocused={isFocused}>
        {Icon}
        <input
          ref={inputRef}
          onBlur={handleInputBlur}
          onFocus={handleInputFocus}
          className={className}
          inputMode="numeric"
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          style={style}
          value={valueDisplay}
          defaultValue={defaultValue}
          {...rest}
        />
      </Container>

      {error && <Error>{error}</Error>}
    </>
  );
};

export default CurrencyInput;
