import styled, { css } from 'styled-components';
import { shade } from 'polished';

interface ContainerProps {
  isErrored?: boolean;
  isFocused?: boolean;
  isFilled?: boolean;
}

export const Container = styled.div<ContainerProps>`
  display: flex;
  align-items: center;

  height: 50px;
  margin-bottom: 8px;
  padding: 16px;
  border: 1px solid ${props => shade(0.3, props.theme.colors.background)};
  border-radius: 4px;
  background: ${props => props.theme.colors.background};
  color: #666360;

  ${props =>
    props.isErrored &&
    css`
      border-color: #fb6f91;
    `}


  ${props =>
    props.isFocused &&
    css`
      border-color: ${props.theme.colors.primary};
      color: ${props.theme.colors.primary};
    `}

  ${props =>
    props.isFilled &&
    css`
      color: ${props.theme.colors.primary};
    `}

  svg {
    margin-right: 16px;
  }

  input {
    flex: 1;

    width: 100%;
    border-color: transparent;
    color: #666360;
    background-color: transparent;
    font-size: ${props => props.theme.fontSize.normal};

    &::placeholder {
      color: #666360;
    }
  }
`;

export const Error = styled.span`
  display: block;
  margin: 4px 0 8px;
  color: #fb6f91;
  font-size: 14px;
  font-weight: bold;
`;
