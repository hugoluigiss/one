import styled, { keyframes } from 'styled-components';
import { Form } from '@unform/web';

export const FadeIn = keyframes`
  from { opacity: 0; }
  to { opacity: 1; }
`;

const Cols = (): string => {
  let styles = '';

  for (let i = 1; i < 12; i += 1) {
    styles += `
      &.col-${i}{ width: calc(${(100 * i) / 12}% - 8px); }
    `;
  }

  return styles;
};

export const FormContainer = styled(Form)`
  width: 100%;
`;

export const FormGroup = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;

  &:last-of-type {
    margin-bottom: 0;
  }

  &.flex-end {
    justify-content: flex-end;
  }

  button {
    width: max-content;
  }

  @media screen and (max-width: 575px) {
    flex-direction: column;
    margin-bottom: 0;
  }
`;

export const GroupCol = styled.div`
  position: relative;
  border: 1px solid transparent;

  > span {
    position: absolute;
    bottom: -17px;
    left: 20px;
    margin: 0;
  }

  ${Cols};
  > div {
    margin: 0;
  }

  &.col-12 {
    width: 100%;
  }

  @media screen and (max-width: 575px) {
    &[class*='col'] {
      width: 100%;
      margin-bottom: 16px;
    }
  }
`;
