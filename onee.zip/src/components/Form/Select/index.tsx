import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactSelect, {
  OptionTypeBase,
  Props as SelectProps,
} from 'react-select';
import { useField } from '@unform/core';

import { Container, Error } from './styles';

interface TypeOption extends OptionTypeBase {
  label: string;
  value: string | number;
}

interface Props extends SelectProps<OptionTypeBase> {
  name: string;
  icon?: JSX.Element;
}

const Select: React.FC<Props> = ({ name, icon: Icon, ...rest }) => {
  const selectRef = useRef(null);

  const [currentValue, setCurrentValue] = useState(null);
  const [isFocused, setIsFocused] = useState(false);
  const [isFilled, setIsFilled] = useState(false);

  const { fieldName, defaultValue, registerField, error } = useField(name);

  const handleInputFocus = useCallback(() => {
    setIsFocused(true);
  }, []);

  const handleInputBlur = useCallback(() => {
    setIsFocused(false);

    setIsFilled(!!currentValue);
  }, [currentValue]);

  useEffect(() => {
    registerField({
      name: fieldName,
      ref: selectRef.current,
      getValue: (ref: any) => {
        const { value } = ref.state;

        if (rest.isMulti) {
          if (!value) return [];

          return value.map((option: TypeOption) => option.value);
        }

        if (!value) return '';

        setCurrentValue(value.value);

        return value.value;
      },
    });
  }, [fieldName, registerField, rest.isMulti]);

  return (
    <>
      <Container isErrored={!!error} isFilled={isFilled} isFocused={isFocused}>
        {Icon}

        <ReactSelect
          ref={selectRef}
          defaultValue={defaultValue}
          classNamePrefix="react-select"
          onFocus={handleInputFocus}
          onBlur={handleInputBlur}
          {...rest}
        />
      </Container>

      {error && <Error>{error}</Error>}
    </>
  );
};

export default Select;
