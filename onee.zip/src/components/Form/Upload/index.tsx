/* eslint-disable react/require-default-props */
import React, { ReactNode, useState, useCallback } from 'react';
import Dropzone from 'react-dropzone';

import { FiUploadCloud } from 'react-icons/fi';

import { DropContainer, UploadMessage } from './styles';

interface UploadProps {
  onUpload: (file: File) => void;
  fileUrl?: string;
}

const Upload: React.FC<UploadProps> = ({
  onUpload,
  fileUrl = '',
}: UploadProps) => {
  const [file, setFile] = useState('');

  const [selectedFileUrl, setSelectedFileUrl] = useState('');

  React.useEffect(() => setSelectedFileUrl(fileUrl), [fileUrl]);

  function renderDragMessage(
    isDragActive: boolean,
    isDragRejest: boolean,
  ): ReactNode {
    if (!isDragActive) {
      return (
        <UploadMessage>
          <FiUploadCloud size={24} />
          Selecione ou arraste o arquivo aqui.
        </UploadMessage>
      );
    }

    if (isDragRejest) {
      return <UploadMessage type="error">Arquivo não suportado</UploadMessage>;
    }

    return <UploadMessage type="success">Solte o arquivo aqui</UploadMessage>;
  }

  const handlerUpload = useCallback(
    files => {
      setFile(URL.createObjectURL(files[0]));
      onUpload(files[0]);
      setSelectedFileUrl('');
    },
    [onUpload],
  );

  return (
    <div style={{ marginBottom: 12 }}>
      <Dropzone
        accept="image/jpeg,image/png"
        onDropAccepted={files => handlerUpload(files)}
        multiple={false}
      >
        {({ getRootProps, getInputProps, isDragActive, isDragReject }): any => (
          <DropContainer
            {...getRootProps()}
            isDragActive={isDragActive}
            isDragReject={isDragReject}
          >
            <input {...getInputProps()} data-testid="upload" />

            {renderDragMessage(isDragActive, isDragReject)}

            {selectedFileUrl && (
              <img src={selectedFileUrl} alt="point thumbnail" />
            )}

            {file && <img src={file} alt="" />}
          </DropContainer>
        )}
      </Dropzone>
    </div>
  );
};

export default Upload;
