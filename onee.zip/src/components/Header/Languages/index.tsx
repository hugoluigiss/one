import React, { useState, useCallback, useEffect, useRef } from 'react';
import { AiOutlineGlobal } from 'react-icons/ai';

import { useTranslation } from 'react-i18next';

import { Container, Scroll, LanguageList, Language, Badge } from './styles';

interface Language {
  id: number;
  name: string;
  value: string;
}

const languages: Language[] = [
  {
    id: 1,
    name: 'Português',
    value: 'pt-BR',
  },
  {
    id: 2,
    name: 'English',
    value: 'en',
  },
  {
    id: 3,
    name: 'Español',
    value: 'es',
  },
];

const Notifications: React.FC = () => {
  const menuRef = useRef<HTMLDivElement>(null);

  const { i18n } = useTranslation();

  const [visible, setVisible] = useState(false);

  const handleToggleVisible = useCallback(() => {
    setVisible(prevVisible => !prevVisible);
  }, []);

  const handleLanguageSelect = useCallback(
    (lang: Language) => {
      i18n.changeLanguage(lang.value);
      setVisible(prevVisible => !prevVisible);
    },
    [i18n],
  );

  const handleClickOutside = useCallback(
    (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setVisible(false);
      }
    },
    [menuRef],
  );

  useEffect(() => {
    document.addEventListener('click', handleClickOutside, true);

    return () => {
      document.removeEventListener('click', handleClickOutside, true);
    };
  }, [handleClickOutside]);

  return (
    <Container>
      <Badge onClick={handleToggleVisible}>
        <AiOutlineGlobal color="#a17725" size={24} />
      </Badge>

      <LanguageList visible={visible} ref={menuRef}>
        <Scroll>
          {languages.map(language => (
            <Language
              key={language.id}
              onClick={() => handleLanguageSelect(language)}
            >
              {language.name}
            </Language>
          ))}
        </Scroll>
      </LanguageList>
    </Container>
  );
};

export default Notifications;
