import styled, { css } from 'styled-components';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { lighten } from 'polished';

interface LanguageList {
  visible: boolean;
}

export const Container = styled.div`
  position: relative;

  width: 40px;
`;

export const Badge = styled.button`
  position: relative;
  border: 0;
  background: none;
  cursor: pointer;
`;

export const LanguageList = styled.div<LanguageList>`
  z-index: 1;
  position: absolute;
  top: calc(100% + 30px);
  right: 5px;

  opacity: 0;
  visibility: hidden;

  width: 140px;
  padding: 15px 5px;
  border-radius: 4px;
  background-color: #ffffff;
  box-shadow: 1px 0px 5px rgba(0, 0, 0, 0.5);
  transition: opacity 0.3s ease 0s, visibility 0.3s ease 0s;

  ${props =>
    props.visible &&
    css`
      opacity: 1;
      visibility: visible;
    `}
`;

export const Scroll = styled(PerfectScrollbar)`
  display: flex;
  flex-direction: column;

  max-height: 100px;
  padding: 5px 15px;
`;

export const Language = styled.button`
  padding: 5px 0;
  border: 0;
  color: #adadab;
  background: none;

  font-size: 14px;
  text-align: left;

  cursor: pointer;

  &:hover {
    color: ${lighten(0.2, '#a17725')};
  }
`;
