import React, {
  useState,
  useMemo,
  useEffect,
  useCallback,
  useRef,
} from 'react';
import { MdNotifications } from 'react-icons/md';

import { parseISO, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

import api from '~/services/api';

import {
  Container,
  Badge,
  Scroll,
  NotificationList,
  Notification,
} from './styles';

interface Notification {
  id: string;
  read: boolean;
  content: string;
  created_at: string;
}

const Notifications: React.FC = () => {
  const menuRef = useRef<HTMLDivElement>(null);

  const [visible, setVisible] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const handleToggleVisible = useCallback(() => {
    setVisible(prevVisible => !prevVisible);
  }, []);

  const handleMarkAsRead = useCallback(
    (id: string) => {
      api.put(`notifications/me/${id}`);

      setNotifications(
        notifications.map(notification =>
          notification.id === id
            ? { ...notification, read: true }
            : notification,
        ),
      );
    },
    [notifications],
  );

  const handleClickOutside = useCallback(
    (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setVisible(false);
      }
    },
    [menuRef],
  );

  useEffect(() => {
    document.addEventListener('click', handleClickOutside, true);

    return () => {
      document.removeEventListener('click', handleClickOutside, true);
    };
  }, [handleClickOutside]);

  useEffect(() => {
    api.get('notifications/me').then(response => {
      setNotifications(response.data);
    });
  }, []);

  const hasUnread = useMemo(
    () => !!notifications.find(notification => notification?.read !== true),
    [notifications],
  );

  const notificationsFormatted = useMemo(() => {
    return notifications.map(notification => ({
      ...notification,
      createdAtFormatted: formatDistanceToNow(
        parseISO(notification.created_at),
        {
          addSuffix: true,
          locale: ptBR,
        },
      ),
    }));
  }, [notifications]);

  return (
    <Container>
      <Badge onClick={handleToggleVisible} hasUnread={hasUnread}>
        <MdNotifications color="#a17725" size={24} />
      </Badge>

      <NotificationList ref={menuRef} visible={visible}>
        <Scroll>
          {notificationsFormatted.map(notification => (
            <Notification key={notification.id} unread={!notification.read}>
              <p>{notification.content}</p>
              <time>{notification.createdAtFormatted}</time>

              {!notification.read && (
                <button
                  type="button"
                  onClick={() => handleMarkAsRead(notification.id)}
                >
                  Marcar como lida
                </button>
              )}
            </Notification>
          ))}
        </Scroll>
      </NotificationList>
    </Container>
  );
};

export default Notifications;
