import styled, { css } from 'styled-components';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { lighten } from 'polished';

interface BadgeProps {
  hasUnread: boolean;
}

interface NotificationList {
  visible: boolean;
}

interface Notification {
  unread: boolean;
}

export const Container = styled.div`
  position: relative;
`;

export const Badge = styled.button<BadgeProps>`
  position: relative;
  border: 0;
  background: none;
  cursor: pointer;

  ${props =>
    props.hasUnread &&
    css`
      &::after {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #ff892c;
      }
    `}
`;

export const NotificationList = styled.div<NotificationList>`
  z-index: 1;
  position: absolute;
  top: calc(100% + 30px);
  left: calc(50% - 130px);

  opacity: 0;
  visibility: hidden;

  width: 260px;
  padding: 15px 5px;
  border-radius: 4px;
  background-color: #ffffff;
  box-shadow: 1px 0px 5px rgba(0, 0, 0, 0.5);
  transition: opacity 0.3s ease 0s, visibility 0.3s ease 0s;

  ${props =>
    props.visible &&
    css`
      opacity: 1;
      visibility: visible;
    `}
`;

export const Scroll = styled(PerfectScrollbar)`
  max-height: 260px;
  padding: 5px 15px;
`;

export const Notification = styled.div<Notification>`
  color: #fff;

  & + div {
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
  }

  p {
    line-height: 18px;
    color: #adadab;
    font-size: 13px;
  }

  time {
    opacity: 0.6;
    display: block;

    margin-bottom: 5px;
    color: rgba(0, 0, 0, 0.5);
    font-size: 12px;
  }

  button {
    border: 0;
    font-size: 12px;
    color: ${lighten(0.2, '#a17725')};
    background: none;
    cursor: pointer;
  }

  ${props =>
    props.unread &&
    css`
      &::after {
        content: '';
        display: inline-block;
        width: 8px;
        height: 8px;
        margin-left: 10px;
        border-radius: 50%;
        background: #ff892e;
      }
    `}
`;
