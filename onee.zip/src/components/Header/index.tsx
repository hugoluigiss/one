import React from 'react';
import { Link } from 'react-router-dom';

import { useTranslation } from 'react-i18next';

import useAuth from '~/hooks/useAuth';

import Notifications from './Notifications';
import Languages from './Languages';

import {
  Container,
  Content,
  LogoHorizontal,
  LogoMobile,
  Profile,
  ProfileName,
} from './styles';

const Header: React.FC = ({ ...rest }) => {
  const { t } = useTranslation();

  const { user } = useAuth();

  return (
    <Container {...rest}>
      <Content>
        <nav>
          <Link to="/">
            <LogoHorizontal />
            <LogoMobile />
          </Link>
        </nav>

        <aside>
          <Languages />
          <Notifications />

          <Profile>
            <ProfileName>
              <strong>{user.name}</strong>
              <Link to="/account">{t('Meu Perfil')}</Link>
            </ProfileName>

            <Link to="/account">
              <img src={user.avatar_url} alt={user.name} />
            </Link>
          </Profile>
        </aside>
      </Content>
    </Container>
  );
};

export default Header;
