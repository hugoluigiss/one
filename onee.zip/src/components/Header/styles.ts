import styled from 'styled-components';
import { transparentize } from 'polished';
import LogoColored from '~/assets/logos/X6_logo_P2_cores.png';
import LogoGoldIcon from '~/assets/logos/logo-mobile.png';

export const Container = styled.div`
  background: ${props => props.theme.colors.boxBackground};
  position: relative;

  &::after {
    content: '';
    position: absolute;
    top: 100%;
    width: 100%;
    height: 64px;
    background: linear-gradient(
      118deg,
      ${({ theme }) => theme.colors.primary},
      ${({ theme }) => transparentize(0.3, theme.colors.primary)}
    );
  }
`;

export const LogoHorizontal = styled.img.attrs(() => ({
  src: LogoColored,
}))`
  display: none;
  width: 150px;

  @media screen and (min-width: 576px) {
    display: block;
  }
`;

export const LogoMobile = styled.img.attrs(() => ({
  src: LogoGoldIcon,
}))`
  display: none;
  height: 60px;
  width: auto;
  object-fit: contain;

  @media screen and (max-width: 575px) {
    display: block;
  }
`;

export const Content = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;

  max-width: 1150px;
  height: 120px;
  margin: 0 auto;
  padding: 0 16px;

  aside {
    display: flex;
    align-items: center;
  }

  @media screen and (max-width: 575px) {
    height: 80px;
  }
`;

export const Profile = styled.div`
  display: flex;
  margin-left: 20px;
  padding-left: 20px;
  border-left: 1px solid #eee;

  img {
    width: 56px;
    height: 56px;
    border-radius: 50%;
  }
`;

export const ProfileName = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;

  margin-right: 10px;
  text-align: right;

  strong {
    display: block;
    color: #777;
  }

  a {
    display: block;
    margin-top: 2px;
    font-size: 12px;
    color: #a17725;

    &:hover {
      text-decoration: underline;
    }
  }

  @media screen and (max-width: 575px) {
    display: none;
  }
`;
