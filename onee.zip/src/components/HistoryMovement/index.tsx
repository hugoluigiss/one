import React from 'react';

import style from './historymovement.module.scss';
import CurrencyWithIcon from '../UtilsComponents/CurrencyWithIcon';
import DateWithHour from '../UtilsComponents/DateWithHour';
// import ButtonPrimary from '../ButtonPrimary';
// import DownloadIcon from '../UtilsComponents/DownloadIcon';

import { useGetMyStatmentQuery } from '~/graphql/generated/graphql';

interface ITransaction {
  id: string;
  created_at: string;
  description: string;
  formatted_total_value: string;
  formatted_net_value: string;
  formatted_fee_value: string;
  status: string;
  coin: {
    name: string;
    symbol: string;
  };
  file_url?: string;
}

const HistoryMovement: React.FC = () => {
  const { data } = useGetMyStatmentQuery({});

  const transactions: ITransaction[] =
    data && data.GetMyStatment.edges.transactions
      ? data.GetMyStatment.edges.transactions.map(t => ({
          id: t.id,
          created_at: t.created_at,
          description: t.description,
          formatted_fee_value: t.formatted_fee_value,
          formatted_net_value: t.formatted_net_value,
          formatted_total_value: t.formatted_total_value,
          status: t.status,
          coin: {
            name: t.coin.name,
            symbol: t.coin.symbol,
          },
          file_url:
            t.brl_deposit?.file_url || t.brl_withdrawal?.file_url || undefined,
        }))
      : [];

  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>Movimentação</h3>
      </div>

      <div className={style.tableContainer}>
        <table>
          <thead>
            <tr>
              <th>Data</th>
              <th>Moeda</th>
              <th>Transação</th>
              <th>Valor Total</th>
              <th>Taxa</th>
              <th>Valor Líquido</th>
              <th>Status</th>
              {/* {hasFileUrl && <th>Comprovante</th>} */}
            </tr>
          </thead>

          <tbody>
            {transactions.map(transaction => (
              <tr key={transaction.id}>
                <td>
                  <DateWithHour dateValue={transaction.created_at} />
                </td>
                <td>
                  <CurrencyWithIcon
                    iconName={transaction.coin.symbol.toLowerCase()}
                    currency={transaction.coin.name}
                    hover={false}
                  />
                </td>
                <td>{transaction.description}</td>
                <td>{transaction.formatted_total_value}</td>
                <td>{transaction.formatted_fee_value}</td>
                <td>{transaction.formatted_net_value}</td>
                <td>{transaction.status}</td>
                {/* {transaction.file_url && (
                  <td>
                    <DownloadIcon
                      onPress={() => window.open(transaction.file_url)}
                    />
                  </td>
                )} */}
              </tr>
            ))}
          </tbody>
        </table>

        {/* {transactions.length > 19 && (
          <div className={style.seeMoreButton}>
            <ButtonSecondary
              onPress={() => setPage(state => state + 1)}
              secondaryBtn
            >
              Ver mais
            </ButtonSecondary>
          </div>
        )} */}
      </div>
    </div>
  );
};

export default HistoryMovement;
