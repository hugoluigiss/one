/* eslint-disable @typescript-eslint/ban-types */
/* eslint-disable react/require-default-props */
/* eslint-disable jsx-a11y/label-has-associated-control */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React, { useState } from 'react';
import cx from 'classnames';
import { cpfMask, dateMask, cepMask, cnpjMask } from './mask';
import styles from './inputprimary.module.scss';

type InputProps = {
  labelValue: string;
  placeholder: string;
  value: string;
  onChangeText: Function;
  cpf?: boolean;
  cep?: boolean;
  cnpj?: boolean;
  standard?: boolean;
  isPasswordType?: boolean;
  datetype?: boolean;
  size?: string;
};

const InputPrimary: React.FC<InputProps> = ({
  labelValue,
  placeholder,
  value,
  onChangeText,
  isPasswordType = false,
  cpf = false,
  cep = false,
  cnpj = false,
  standard = false,
  datetype = false,
  size = '',
}: InputProps) => {
  const [showPass, setShowPass] = useState(false);

  const handleEye = (): void => {
    setShowPass(!showPass);
  };

  return (
    <div className={cx(styles.container, styles[size])}>
      <label>{labelValue}</label>

      {cpf && (
        <input
          value={value}
          onChange={e => onChangeText(cpfMask(e.target.value))}
          placeholder={placeholder}
        />
      )}
      {cep && (
        <input
          value={value}
          onChange={e => {
            e.preventDefault();
            onChangeText(cepMask(e.target.value));
          }}
          placeholder={placeholder}
        />
      )}
      {cnpj && (
        <input
          value={value}
          onChange={e => {
            e.preventDefault();
            onChangeText(cnpjMask(e.target.value));
          }}
          placeholder={placeholder}
        />
      )}
      {standard && (
        <input
          value={value}
          onChange={e => onChangeText(e.target.value)}
          placeholder={placeholder}
        />
      )}

      {datetype && (
        <input
          // data-mask="dd/mm/yyyy"
          value={value}
          onChange={e => onChangeText(dateMask(e.target.value))}
          placeholder={placeholder}
        />
      )}

      {isPasswordType && (
        <div className={styles.inputPassword}>
          <input
            type={!showPass ? 'password' : 'text'}
            value={value}
            onChange={e => onChangeText(e.target.value)}
            placeholder={placeholder}
            autoComplete="new-password"
          />
          <div
            onClick={handleEye}
            className={cx(showPass ? styles.eyeClose : styles.eyeOpen)}
          />
        </div>
      )}
    </div>
  );
};

export default InputPrimary;
