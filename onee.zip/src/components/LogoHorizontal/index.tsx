import React from 'react';

import logo from '../../assets/images/logo_branco.png';

const Logo: React.FC = () => {
  return <img src={logo} alt="Logo" height="98px" />;
};

export default Logo;
