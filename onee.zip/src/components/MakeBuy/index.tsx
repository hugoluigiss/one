/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React from 'react';

import * as Yup from 'yup';
import { toast } from 'react-toastify';
import style from './maketransfer.module.scss';

import SmallButton from '../SmallButton';

import IconCurrencyOnly from '../UtilsComponents/IconCurrencyOnly';
// import useToast from '~/hooks/useToast';

import { formatAmount, formatPrice } from '~/utils/format';
import getValidationErrors from '~/utils/getValidationErrors';
import {
  GetMyCoinWalletBySymbolDocument,
  GetMyCoinWalletsDocument,
  GetMyStatmentDocument,
  useCreateCryptoBuyMutation,
  useCreateMyOneTimeCodeMutation,
  useGetCoinOperationParamQuery,
  useGetMyCoinWalletBySymbolQuery,
} from '~/graphql/generated/graphql';

interface IProps {
  onHandleClose: () => void;
  iconName: string;
  walletName: string;
  coinPrice: number;
}

const MakeBuy: React.FC<IProps> = ({
  onHandleClose,
  iconName,
  walletName,
  coinPrice,
}: IProps) => {
  const { data: param } = useGetCoinOperationParamQuery({
    variables: {
      coin_symbol: iconName.toUpperCase(),
      operation: 'buy',
    },
  });
  const { data: brlWallet } = useGetMyCoinWalletBySymbolQuery({
    variables: { symbol: 'BRL' },
  });

  const [createMyOneTimeCode, { loading: sendingCode }] =
    useCreateMyOneTimeCodeMutation();

  const [codeInterval, setCodeInterval] = React.useState(false);

  const handleSendOneTimeCode = React.useCallback(async () => {
    if (sendingCode || codeInterval) return;
    try {
      setCodeInterval(true);
      const response = await createMyOneTimeCode();
      setTimeout(() => setCodeInterval(false), 1000 * 10);
      toast.success(response.data?.CreateMyOneTimeCode);
    } catch {
      // do nothing
    }
  }, [codeInterval, createMyOneTimeCode, sendingCode]);

  const [token, setToken] = React.useState('');
  const [inputValue, setInputValue] = React.useState('0.00');
  const fixed_fee = param
    ? Number(param.GetCoinOperationParam.fixed_fee_brl_value)
    : 0;
  const percentage_fee = React.useMemo(() => {
    return param
      ? Number(param.GetCoinOperationParam.percentage_fee_value) *
          Number(inputValue)
      : 0;
  }, [param, inputValue]);
  const total_fee = fixed_fee + percentage_fee;
  const net_value = Number(inputValue) - total_fee;
  const [buyCrypto, { loading: loadingBuyCrypto }] =
    useCreateCryptoBuyMutation();

  const handleSubmit = React.useCallback(async () => {
    try {
      const schema = Yup.object().shape({
        token: Yup.string()
          .length(6, 'O código de verificação deve conter 6 caracteres.')
          .required('O código de verificação é obrigatório.'),
        brl_amount: Yup.number().required('A quantidade é obrigatória.'),
      });

      await schema.validate(
        { token, brl_amount: Number(inputValue) },
        { abortEarly: false },
      );

      await buyCrypto({
        variables: {
          coin_symbol: iconName.toUpperCase(),
          two_fa: token,
          value_brl: inputValue,
        },
        refetchQueries: [
          { query: GetMyCoinWalletsDocument },
          {
            query: GetMyCoinWalletBySymbolDocument,
            variables: { symbol: 'BRL' },
          },
          {
            query: GetMyStatmentDocument,
          },
          {
            query: GetMyStatmentDocument,
            variables: {
              coin_symbol: iconName.toUpperCase(),
            },
          },
        ],
      });
      // addToast({
      //   type: 'info',
      //   title: 'Compra em processamento',
      //   description: 'Verifique seu extrato em instantes.',
      // });
      toast.info('Verifique seu extrato em instantes.');
      setInputValue('');
      setToken('');
      onHandleClose();
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: '', description: errors[key] }),
          toast.info(errors[key]),
        );
      }
    }
  }, [buyCrypto, iconName, inputValue, onHandleClose, token]);

  return (
    <div className={style.container}>
      <div className={style.headerWallet}>
        <IconCurrencyOnly iconName={iconName} iconType />
        <h4>{`Comprar ${walletName}`}</h4>
      </div>
      <div className={style.containerItem}>
        <div className={style.infoDepositContainer}>
          <div
            className={style.inputGroup}
            style={{ marginTop: 12, display: 'flex' }}
          >
            <input
              type="text"
              className={style.inputValue}
              value={formatPrice(Number(inputValue))}
              onChange={e => {
                let { value } = e.currentTarget;

                value = value.replace(/\D/g, '');
                value = value.replace(/^0/, '');

                if (value.length === 1) value = '0';
                value = [
                  value.slice(0, value.length - 2),
                  '.',
                  value.slice(value.length - 2),
                ].join('');

                setInputValue(value);
              }}
            />
            {brlWallet && (
              <a
                onClick={() => {
                  setInputValue(
                    brlWallet.GetMyCoinWalletBySymbol.balance || '0',
                  );
                }}
              >
                <p className={style.balance}>
                  {formatPrice(
                    Number(brlWallet.GetMyCoinWalletBySymbol.balance),
                  )}
                </p>
                Saldo disponível
              </a>
            )}
          </div>

          <div className={style.descriptionBox}>
            <span>
              <b>Cotação: </b>
              {`${formatPrice(coinPrice)}   |   1 ${iconName}`}
            </span>

            <span>
              <b>Taxa Fixa: </b>
              {`${formatPrice(fixed_fee)}  |  ${formatAmount(
                fixed_fee / coinPrice,
              )}  ${iconName}`}
            </span>

            {Number(inputValue) > 0 && (
              <>
                <span>
                  <b>Taxa Percentual: </b>
                  {`${formatPrice(percentage_fee)}  |  ${formatAmount(
                    percentage_fee / coinPrice,
                  )}  ${iconName}`}
                </span>
                <span>
                  <b>Líquido:</b>{' '}
                  {`${formatPrice(net_value)}  |   ${formatAmount(
                    net_value / coinPrice,
                  )} ${iconName}`}
                </span>
              </>
            )}
          </div>

          <div
            className={style.inputGroup}
            style={{ marginTop: 12, display: 'flex' }}
          >
            <input
              type="text"
              className={style.inputValue}
              placeholder="Codigo de Verificação"
              value={token}
              onChange={e => setToken(e.target.value)}
              maxLength={6}
            />
            <a onClick={() => handleSendOneTimeCode()}>
              Obter codigo por email
            </a>
          </div>
          <div style={{ marginTop: 24 }}>
            <SmallButton
              disabled={loadingBuyCrypto}
              blue
              green={false}
              red={false}
              onPress={handleSubmit}
            >
              Enviar
            </SmallButton>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MakeBuy;
