/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
// import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import style from './makedeposit.module.scss';
import SmallButton from '../SmallButton';
// import api from '~/services/api';

// import useToast from '~/hooks/useToast';

import { formatPrice } from '~/utils/format';
import getValidationErrors from '~/utils/getValidationErrors';
import {
  GetMyStatmentDocument,
  useCreateBrlDepositMutation,
  useGetDepositAccountQuery,
} from '~/graphql/generated/graphql';

type ActiveProps = {
  onHandleClose?: () => void;
};

const MakeDeposit: React.FC<ActiveProps> = ({ onHandleClose = () => {} }) => {
  const { data: depositAccount } = useGetDepositAccountQuery();
  // const { t } = useTranslation();
  // const { addToast } = useToast();

  // const [bank, setBank] = React.useState<Account>();

  // const [minimumParameter, setMinimumParameter] = React.useState(0);
  const [inputValue, setInputValue] = React.useState('0');
  const [file, setFile] = React.useState<File | undefined>();

  const [createDeposit] = useCreateBrlDepositMutation();

  const handleSubmit = React.useCallback(async () => {
    try {
      // setLoading(true);

      const schema = Yup.object().shape({
        amount: Yup.string().required('O valor do depósito é obrigatório.'),
      });

      await schema.validate({ amount: inputValue }, { abortEarly: false });

      if (!file) {
        // addToast({
        //   type: 'error',
        //   title: '',
        //   description: 'Comprovante é obrigatório',
        // });
        toast.error('Comprovante é obrigatório');

        return;
      }

      await createDeposit({
        variables: {
          file,
          value_brl: inputValue,
        },
        refetchQueries: [
          {
            query: GetMyStatmentDocument,
            variables: {
              coin_symbol: 'BRL',
              operation: 'deposit',
            },
          },
          {
            query: GetMyStatmentDocument,
          },
        ],
      });

      // addToast({
      //   type: 'success',
      //   title: 'Sucesso no depósito',
      //   description: 'Requisição de depósito criado com sucesso!',
      // });
      toast.success('Requisição de depósito criado com sucesso!');
      setInputValue('0');
      setFile(undefined);
      onHandleClose();
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: '', description: errors[key] }),
          toast.error(errors[key]),
        );
      }
    }
  }, [createDeposit, file, inputValue, onHandleClose]);
  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>Dados para depósito</h3>
      </div>

      <div className={style.containerItem}>
        <div className={style.selectBankContainer}>
          {/* <div className={style.iconLeft} /> */}
          {/* <div className={style.iconRight} /> */}

          <div className={style.bankItem}>
            {/* <div className={style.bankImage}>
              <img src={imageExample} alt="Logo do Banco" />
            </div> */}

            <div className={style.descriptionBox}>
              {depositAccount && (
                <>
                  <span>
                    <b>
                      {`${depositAccount.GetDepositAccount.bank.name} - ${depositAccount.GetDepositAccount.bank.code}`}
                    </b>
                  </span>
                  <span>
                    <b>Agência:</b> {depositAccount.GetDepositAccount.agency}
                  </span>
                  <span>
                    <b>Conta:</b> {depositAccount.GetDepositAccount.account}
                  </span>
                  <span>
                    <b>PIX - CNPJ:</b> {depositAccount.GetDepositAccount.pix}
                  </span>
                  <span>
                    <b>Titularidade:</b>{' '}
                    {depositAccount.GetDepositAccount.owner}
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        <div className={style.infoDepositContainer}>
          <h4>Fez um depósito?</h4>

          <p>Por favor, informe o valor e envie o comprovante abaixo.</p>

          <input
            type="text"
            className={style.inputValue}
            placeholder="Digite o valor do depósito"
            value={formatPrice(Number(inputValue))}
            onChange={e => {
              let { value } = e.target;

              value = value.replace(/\D/g, '');

              value = value.replace(/^0/, '');

              value = [
                value.slice(0, value.length - 2),
                '.',
                value.slice(value.length - 2),
              ].join('');

              setInputValue(value);
            }}
          />

          <div className={style.boxFileUpload}>
            <div className={style.iconUpload} />
            <input
              className={style.typeFile}
              type="file"
              id="fileAdd"
              accept="image/png, image/jpeg"
              onChange={e => {
                const { files } = e.target;
                if (!files) return;
                setFile(files[0]);
              }}
            />
          </div>

          <SmallButton
            blue
            green={false}
            red={false}
            onPress={() => handleSubmit()}
          >
            Enviar
          </SmallButton>
        </div>
      </div>
    </div>
  );
};

export default MakeDeposit;
