/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React from 'react';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import style from './maketransfer.module.scss';

import SmallButton from '../SmallButton';

import IconCurrencyOnly from '../UtilsComponents/IconCurrencyOnly';
// import useToast from '~/hooks/useToast';

import { formatAmount, formatPrice } from '~/utils/format';
import getValidationErrors from '~/utils/getValidationErrors';

import {
  GetMyCoinWalletBySymbolDocument,
  GetMyCoinWalletsDocument,
  GetMyStatmentDocument,
  useCreateCryptoSellMutation,
  useGetCoinOperationParamQuery,
  useCreateMyOneTimeCodeMutation,
  // useGetFeesQuery,
} from '~/graphql/generated/graphql';

interface IProps {
  onHandleClose: () => void;
  iconName: string;
  walletName: string;
  walletBalance: string;
  coinPrice: number;
}

const MakeSell: React.FC<IProps> = ({
  onHandleClose,
  iconName,
  walletName,
  coinPrice,
  walletBalance,
}: IProps) => {
  // const { addToast } = useToast();

  const [token, setToken] = React.useState('');
  const [inputValue, setInputValue] = React.useState('0.00');
  const { data: param } = useGetCoinOperationParamQuery({
    variables: {
      coin_symbol: iconName.toUpperCase(),
      operation: 'sell',
    },
  });

  const percentage_fee = React.useMemo(() => {
    return param
      ? Number(param.GetCoinOperationParam.percentage_fee_value) *
          Number(inputValue)
      : 0;
  }, [param, inputValue]);
  const fixed_brl_fee = param
    ? Number(param.GetCoinOperationParam.fixed_fee_brl_value)
    : 0;
  const total_fee = (fixed_brl_fee / coinPrice) * percentage_fee;
  const net_value = Number(inputValue) - total_fee;

  const [sellCrypto, { loading }] = useCreateCryptoSellMutation();
  const handleSubmit = React.useCallback(async () => {
    try {
      const schema = Yup.object().shape({
        token: Yup.string()
          .length(6, 'O código de verificação deve conter 6 caracteres.')
          .required('O código de verificação é obrigatório.'),
        coin_amount: Yup.number().required(
          'A quantidade de bitcoins é obrigatória.',
        ),
      });

      await schema.validate(
        { token, coin_amount: Number(inputValue) },
        { abortEarly: false },
      );

      await sellCrypto({
        variables: {
          coin_amount: inputValue,
          coin_symbol: iconName.toUpperCase(),
          two_fa: token,
        },
        refetchQueries: [
          {
            query: GetMyCoinWalletsDocument,
          },
          {
            query: GetMyCoinWalletBySymbolDocument,
            variables: {
              symbol: 'BRL',
            },
          },
          {
            query: GetMyStatmentDocument,
          },
          {
            query: GetMyStatmentDocument,
            variables: {
              coin_symbol: iconName.toUpperCase(),
            },
          },
        ],
      });

      // addToast({
      //   type: 'info',
      //   title: 'Compra em processamento',
      //   description: 'Verifique seu extrato em instantes.',
      // });
      setInputValue('');
      setToken('');
      onHandleClose();
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: '', description: errors[key] }),
          toast.error(errors[key]),
        );
      }
    }
  }, [iconName, inputValue, onHandleClose, sellCrypto, token]);

  const [createMyOneTimeCode, { loading: sendingCode }] =
    useCreateMyOneTimeCodeMutation();

  const [codeInterval, setCodeInterval] = React.useState(false);

  const handleSendOneTimeCode = React.useCallback(async () => {
    if (sendingCode || codeInterval) return;
    try {
      setCodeInterval(true);
      const response = await createMyOneTimeCode();
      setTimeout(() => setCodeInterval(false), 1000 * 10);
      toast.success(response.data?.CreateMyOneTimeCode);
    } catch {
      // do nothing
    }
  }, [codeInterval, createMyOneTimeCode, sendingCode]);

  return (
    <div className={style.container}>
      <div className={style.headerWallet}>
        <IconCurrencyOnly iconName={iconName} iconType />
        <h4>{`Vender ${walletName}`}</h4>
      </div>
      <div className={style.containerItem}>
        <div className={style.infoDepositContainer}>
          <div
            className={style.inputGroup}
            style={{ marginTop: 12, display: 'flex' }}
          >
            <input
              type="text"
              className={style.inputValue}
              placeholder="Digite o valor do saque"
              value={`${iconName.toUpperCase()} ${inputValue}`}
              onChange={e => {
                let { value } = e.currentTarget;
                value = value.replace(/\D/g, '');
                value = value.padStart(10, '0');
                value = [
                  value.slice(0, value.length - 8),
                  '.',
                  value.slice(value.length - 8),
                ].join('');
                if (value[0] === '0') value = value.slice(1, value.length);
                setInputValue(value);
              }}
            />
            <a
              onClick={() => {
                setInputValue(walletBalance);
              }}
            >
              <p className={style.balance}>
                {`${iconName.toUpperCase()} ${walletBalance}`}
              </p>
              Saldo disponível
            </a>
          </div>

          <div className={style.descriptionBox}>
            <span>
              <b>Cotação: </b> {`1 ${iconName}   |   ${formatPrice(coinPrice)}`}
            </span>

            <span>
              <b>Taxa Fixa: </b>
              {`${formatAmount(
                fixed_brl_fee / coinPrice,
              )}  ${iconName}  |   ${formatPrice(fixed_brl_fee)}  `}
            </span>

            {Number(inputValue) > 0 && (
              <>
                <span>
                  <b>Taxa Percentual: </b>
                  {`${formatAmount(percentage_fee)} ${iconName} | ${formatPrice(
                    percentage_fee * coinPrice,
                  )} `}
                </span>

                <span>
                  <b>Líquido:</b>{' '}
                  {`${formatAmount(net_value)} ${iconName}  |  ${formatPrice(
                    net_value * coinPrice,
                  )}`}
                </span>
              </>
            )}
          </div>

          <div
            className={style.inputGroup}
            style={{ marginTop: 12, display: 'flex' }}
          >
            <input
              type="text"
              className={style.inputValue}
              placeholder="Codigo de Verificação"
              value={token}
              onChange={e => setToken(e.target.value)}
              maxLength={6}
            />
            <a onClick={() => handleSendOneTimeCode()}>
              Obter codigo por email
            </a>
          </div>
          <div style={{ marginTop: 24 }}>
            <SmallButton
              disabled={loading}
              blue
              green={false}
              red={false}
              onPress={handleSubmit}
            >
              Enviar
            </SmallButton>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MakeSell;
