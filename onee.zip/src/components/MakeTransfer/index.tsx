/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React from 'react';

import * as Yup from 'yup';
import { toast } from 'react-toastify';
import style from './maketransfer.module.scss';

import SmallButton from '../SmallButton';

import IconCurrencyOnly from '../UtilsComponents/IconCurrencyOnly';
// import useToast from '~/hooks/useToast';

import { formatPrice } from '~/utils/format';
import getValidationErrors from '~/utils/getValidationErrors';

import {
  GetMyCoinWalletBySymbolDocument,
  GetMyCoinWalletsDocument,
  GetMyStatmentDocument,
  useCreateCryptoWithdrawalMutation,
  useGetCoinOperationParamQuery,
  useCreateMyOneTimeCodeMutation,
  // useGetFeesQuery,
} from '~/graphql/generated/graphql';

interface IProps {
  onHandleClose: () => void;
  iconName: string;
  walletName: string;
  walletBalance: number;
  coinPrice: number;
}

const MakeTransfer: React.FC<IProps> = ({
  onHandleClose,
  iconName,
  walletName,
  walletBalance,
  coinPrice,
}: IProps) => {
  // const { addToast } = useToast();

  const [token, setToken] = React.useState('');
  const [address, setAddress] = React.useState('');
  const [destFlag, setDestFlag] = React.useState<string | null>(null);
  const [inputValue, setInputValue] = React.useState('0.00000000');

  const { data: param } = useGetCoinOperationParamQuery({
    variables: {
      coin_symbol: iconName.toLocaleUpperCase(),
      operation: 'withdrawal',
    },
  });

  const fee = React.useMemo(() => {
    if (param) {
      const fixed_brl_fee = Number(
        param.GetCoinOperationParam.fixed_fee_brl_value,
      );
      const percentual_brl_fee =
        Number(inputValue) *
        Number(param.GetCoinOperationParam.percentage_fee_value) *
        coinPrice;
      return fixed_brl_fee + percentual_brl_fee;
    }
    return 0;
  }, [coinPrice, inputValue, param]);

  const network_fee = React.useMemo(() => {
    if (param)
      return Number(param.GetCoinOperationParam.network_fee) * coinPrice;
    return 0;
  }, [coinPrice, param]);

  const total = React.useMemo(() => {
    return Number(inputValue) * coinPrice;
  }, [coinPrice, inputValue]);

  const net_value = React.useMemo(() => {
    return total - fee - network_fee;
  }, [fee, network_fee, total]);

  const [createWithdrawal, { loading }] = useCreateCryptoWithdrawalMutation();

  const handleSubmit = React.useCallback(async () => {
    try {
      const schema = Yup.object().shape({
        token: Yup.string()
          .length(6, 'O código de verificação deve conter 6 caracteres.')
          .required('O código de verificação é obrigatório.'),
        address: Yup.string().required('O endereço de destino é obrigatório.'),
        netAmount: Yup.number().min(
          0,
          'A valor líquido deve ser maior que zero.',
        ),
      });

      await schema.validate(
        { token, address, amount: Number(inputValue), net_value },
        { abortEarly: false },
      );

      await createWithdrawal({
        variables: {
          address_to: address,
          coin_symbol: iconName.toUpperCase(),
          coin_amount: inputValue,
          two_fa: token,
          dest_flag: destFlag,
        },
        refetchQueries: [
          {
            query: GetMyCoinWalletsDocument,
          },
          {
            query: GetMyStatmentDocument,
          },
          {
            query: GetMyCoinWalletBySymbolDocument,
            variables: {
              symbol: 'BRL',
            },
          },
          {
            query: GetMyStatmentDocument,
            variables: {
              coin_symbol: iconName.toUpperCase(),
            },
          },
        ],
      });
      // addToast({
      //   type: 'info',
      //   title: 'Transferencia em processamento',
      //   description: 'Verifique seu extrato em instantes.',
      // });
      toast.info('Verifique seu extrato em instantes.');

      setInputValue('');
      setToken('');
      setAddress('');
      onHandleClose();
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: '', description: errors[key] }),
          toast.error(errors[key]),
        );
      }
    }
  }, [
    address,
    createWithdrawal,
    iconName,
    inputValue,
    net_value,
    onHandleClose,
    token,
    destFlag,
  ]);

  const [createMyOneTimeCode, { loading: sendingCode }] =
    useCreateMyOneTimeCodeMutation();

  const [codeInterval, setCodeInterval] = React.useState(false);

  const handleSendOneTimeCode = React.useCallback(async () => {
    if (sendingCode || codeInterval) return;
    try {
      setCodeInterval(true);
      const response = await createMyOneTimeCode();
      setTimeout(() => setCodeInterval(false), 1000 * 10);
      toast.success(response.data?.CreateMyOneTimeCode);
    } catch {
      // do nothing
    }
  }, [codeInterval, createMyOneTimeCode, sendingCode]);

  return (
    <div className={style.container}>
      <div className={style.headerWallet}>
        <IconCurrencyOnly iconName={iconName} iconType />
        <h4>{`Transferir ${walletName}`}</h4>
      </div>
      <div className={style.containerItem}>
        <div className={style.infoDepositContainer}>
          <div className={style.inputGroup}>
            <input
              type="text"
              className={style.inputValue}
              placeholder="Endereço de destino"
              value={address}
              onChange={e => setAddress(e.target.value)}
            />
          </div>

          {iconName === 'xrp' && (
            <div
              className={style.inputGroup}
              style={{ marginTop: 12, display: 'flex' }}
            >
              <input
                type="text"
                className={style.inputValue}
                placeholder="DEST FLAG - Opcional"
                value={destFlag || ''}
                onChange={e => setDestFlag(e.target.value)}
              />
            </div>
          )}

          <div
            className={style.inputGroup}
            style={{ marginTop: 12, display: 'flex' }}
          >
            <input
              type="text"
              className={style.inputValue}
              placeholder="Digite o valor do saque"
              value={inputValue}
              onChange={e => {
                let { value } = e.currentTarget;
                value = value.replace(/\D/g, '');
                value = value.padStart(10, '0');
                value = [
                  value.slice(0, value.length - 8),
                  '.',
                  value.slice(value.length - 8),
                ].join('');
                if (value[0] === '0') value = value.slice(1, value.length);
                setInputValue(value);
              }}
            />
            <a
              onClick={() => {
                setInputValue(walletBalance.toString());
              }}
            >
              <p className={style.balance}>
                {`${iconName.toUpperCase()} ${walletBalance}`}
              </p>
              Saldo disponível
            </a>
          </div>

          <div className={style.descriptionBox}>
            <span>
              <b>Total:</b> {formatPrice(total)}
            </span>
            <span>
              <b>Taxa:</b> {formatPrice(fee)}
            </span>

            {Number(inputValue) > 0 && (
              <>
                <span>
                  <b>Taxa da rede (Aprox.):</b> {formatPrice(network_fee)}
                </span>
                <span>
                  <b>Líquido (Aprox.):</b> {formatPrice(net_value)}
                </span>
              </>
            )}
          </div>

          <div
            className={style.inputGroup}
            style={{ marginTop: 12, display: 'flex' }}
          >
            <input
              type="text"
              className={style.inputValue}
              placeholder="Codigo de Verificação"
              value={token}
              onChange={e => setToken(e.target.value)}
              maxLength={6}
            />
            <a onClick={() => handleSendOneTimeCode()}>
              Obter codigo por email
            </a>
          </div>
          <div style={{ marginTop: 24 }}>
            <SmallButton
              disabled={loading}
              blue
              green={false}
              red={false}
              onPress={handleSubmit}
            >
              Enviar
            </SmallButton>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MakeTransfer;
