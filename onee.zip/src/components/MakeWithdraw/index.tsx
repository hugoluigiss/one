/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable react/jsx-curly-newline */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React from 'react';
import * as Yup from 'yup';
// import { useTranslation } from 'react-i18next';
// import { useHistory } from 'react-router-dom';
import { toast } from 'react-toastify';
import style from './makewithdraw.module.scss';
// import imageExample from '../../assets/icons/sample.png';
import SmallButton from '../SmallButton';
// import api from '~/services/api';
// import useToast from '~/hooks/useToast';
import getValidationErrors from '~/utils/getValidationErrors';
import { formatPrice } from '~/utils/format';
import {
  GetMyCoinWalletBySymbolDocument,
  GetMyCoinWalletsDocument,
  GetMyStatmentDocument,
  useCreateBrlWithdrawalMutation,
  useGetCoinOperationParamQuery,
  useGetMyBankAccountsQuery,
  useGetMyCoinWalletBySymbolQuery,
  useCreateMyOneTimeCodeMutation,
} from '~/graphql/generated/graphql';

interface BankProps {
  id: string;
  bankName: string;
  agency: string;
  account: string;
  pix: string;
}

// interface ParameterProps {
//   value: number;
// }

type ActiveProps = {
  onHandleClose?: () => void;
};

const MakeWithdraw: React.FC<ActiveProps> = ({ onHandleClose }) => {
  // const { t } = useTranslation();
  // const { addToast } = useToast();
  // const history = useHistory();
  const { data: param } = useGetCoinOperationParamQuery({
    variables: {
      coin_symbol: 'BRL',
      operation: 'withdrawal',
    },
  });

  const { data: bankAccounts } = useGetMyBankAccountsQuery();
  const { data: brlWallet } = useGetMyCoinWalletBySymbolQuery({
    variables: { symbol: 'BRL' },
  });
  const [selectedBank, setSelectedBank] = React.useState<BankProps>();
  const myBankAccounts = React.useMemo(() => {
    if (bankAccounts && bankAccounts.GetMyBankAccounts.length > 0)
      setSelectedBank({
        account: bankAccounts.GetMyBankAccounts[0].account,
        agency: bankAccounts.GetMyBankAccounts[0].agency,
        bankName: `${bankAccounts.GetMyBankAccounts[0].bank.name} (${bankAccounts.GetMyBankAccounts[0].bank.code})`,
        id: bankAccounts.GetMyBankAccounts[0].id,
        pix: bankAccounts.GetMyBankAccounts[0].pix || '',
      });
    return !bankAccounts
      ? []
      : bankAccounts.GetMyBankAccounts.map(account => ({
          id: account.id,
          bankName: `${account.bank.name} (${account.bank.code})`,
          agency: account.agency,
          account: account.account,
          pix: account.pix || '',
        }));
  }, [bankAccounts]);

  const [inputValue, setInputValue] = React.useState('0');
  const [token, setToken] = React.useState('');

  const fixed_fee = param
    ? Number(param.GetCoinOperationParam.fixed_fee_brl_value)
    : 0;
  const percentage_fee = React.useMemo(() => {
    return param
      ? Number(param.GetCoinOperationParam.percentage_fee_value) *
          Number(inputValue)
      : 0;
  }, [param, inputValue]);
  const total_fee = fixed_fee + percentage_fee;
  const net_value = Number(inputValue) - total_fee;

  const handleChangeBank = React.useCallback(
    (positionOffset: number) => {
      if (!selectedBank) return;
      const selectedPosition = myBankAccounts.findIndex(
        bank => selectedBank.id === bank.id,
      );
      let newPosition = selectedPosition + positionOffset;
      newPosition = Math.max(newPosition, 0);
      newPosition = Math.min(newPosition, myBankAccounts.length - 1);

      setSelectedBank(myBankAccounts[newPosition]);
    },
    [myBankAccounts, selectedBank],
  );

  const [createWithdrawal, { loading }] = useCreateBrlWithdrawalMutation();
  const handleSubmit = React.useCallback(async () => {
    try {
      const schema = Yup.object().shape({
        token: Yup.string()
          .length(6, 'O código de verificação deve conter 6 caracteres.')
          .required('O código de verificação é obrigatório.'),
        account: Yup.string().required('A conta bancária é obrigatória.'),
        amount: Yup.string().required('O valor do saque é obrigatório.'),
      });
      await schema.validate(
        {
          token,
          account: selectedBank?.id,
          amount: inputValue,
        },
        { abortEarly: false },
      );

      await createWithdrawal({
        variables: {
          bank_account_id: selectedBank?.id || '',
          two_fa: token,
          value_brl: inputValue,
        },
        refetchQueries: [
          {
            query: GetMyCoinWalletBySymbolDocument,
            variables: { symbol: 'BRL' },
          },
          {
            query: GetMyStatmentDocument,
            variables: {
              coin_symbol: 'BRL',
              operation: 'withdrawal',
            },
          },
          {
            query: GetMyStatmentDocument,
          },
          {
            query: GetMyCoinWalletsDocument,
          },
        ],
      });

      // addToast({
      //   type: 'success',
      //   title: 'Sucesso no saque',
      //   description: 'Requisição de saque criada com sucesso!',
      // });
      toast.success('Requisição de saque criada com sucesso!');

      if (onHandleClose) onHandleClose();
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: '', description: errors[key] }),
          toast.error(errors[key]),
        );
      }
    }
  }, [createWithdrawal, inputValue, onHandleClose, selectedBank, token]);

  const [createMyOneTimeCode, { loading: sendingCode }] =
    useCreateMyOneTimeCodeMutation();

  const [codeInterval, setCodeInterval] = React.useState(false);

  const handleSendOneTimeCode = React.useCallback(async () => {
    if (sendingCode || codeInterval) return;
    try {
      setCodeInterval(true);
      const response = await createMyOneTimeCode();
      setTimeout(() => setCodeInterval(false), 1000 * 10);
      toast.success(response.data?.CreateMyOneTimeCode);
    } catch {
      // do nothing
    }
  }, [codeInterval, createMyOneTimeCode, sendingCode]);

  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>Dados para saque</h3>
      </div>

      <div className={style.containerItem}>
        {selectedBank && (
          <div className={style.selectBankContainer}>
            <div
              className={style.iconLeft}
              onClick={() => handleChangeBank(-1)}
            />
            <div
              className={style.iconRight}
              onClick={() => handleChangeBank(1)}
            />

            <div className={style.bankItem}>
              {/* <div className={style.bankImage}>
                <img src={imageExample} alt="Logo do Banco" />
              </div> */}

              <div className={style.descriptionBox}>
                <span>
                  <b>{selectedBank.bankName}</b>
                </span>
                <span>
                  <b>Agência:</b> {selectedBank.agency}
                </span>
                <span>
                  <b>Conta:</b> {selectedBank.account}
                </span>
                <span>
                  <b>PIX:</b> {selectedBank.pix}
                </span>
              </div>
            </div>
          </div>
        )}

        <div className={style.infoDepositContainer}>
          <h4>Informe um valor</h4>

          <p>Enviaremos um comprovante assim que possível</p>

          <div className={style.inputGroup}>
            <input
              type="text"
              className={style.inputValue}
              placeholder="Digite o valor do saque"
              value={formatPrice(Number(inputValue))}
              onChange={e => {
                let { value } = e.target;
                value = value.replace(/\D/g, '');
                value = value.replace(/^0/, '');
                value = [
                  value.slice(0, value.length - 2),
                  '.',
                  value.slice(value.length - 2),
                ].join('');
                setInputValue(value);
              }}
            />
            <a
              onClick={() =>
                setInputValue(brlWallet?.GetMyCoinWalletBySymbol.balance || '0')
              }
            >
              <p className={style.balance}>
                {formatPrice(
                  Number(brlWallet?.GetMyCoinWalletBySymbol.balance),
                )}
              </p>
              Saldo disponível
            </a>
          </div>

          <div className={style.descriptionBox}>
            <span>
              <b>Taxa Fixa: </b>
              {`${formatPrice(fixed_fee)}`}
            </span>

            <span>
              <b>Taxa Percentual: </b>
              {`${formatPrice(percentage_fee)} `}
            </span>
            <span>
              <b>Líquido:</b> {`${formatPrice(net_value)} `}
            </span>
          </div>

          <div
            className={style.inputGroup}
            style={{ marginTop: 12, display: 'flex' }}
          >
            <input
              type="text"
              className={style.inputValue}
              placeholder="Codigo de Verificação"
              value={token}
              onChange={e => setToken(e.target.value)}
              maxLength={6}
            />
            <a onClick={() => handleSendOneTimeCode()}>
              Obter codigo por email
            </a>
          </div>

          <SmallButton
            disabled={loading}
            blue
            green={false}
            red={false}
            onPress={() => handleSubmit()}
          >
            Realizar saque
          </SmallButton>
        </div>
      </div>
    </div>
  );
};

export default MakeWithdraw;
