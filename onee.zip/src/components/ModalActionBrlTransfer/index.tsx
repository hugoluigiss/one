/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React from 'react';
import cx from 'classnames';
import style from './modalaction.module.scss';
// import MakeTransfer from '../MakeTransfer';
import MakeBrlTransfer from '../MakeBrlTransfer';

type ActiveProps = {
  activeModal: boolean;
  onHandleClose(): any;
  iconName: string;
  walletName: string;
  walletBalance: number;
  // coinPrice: number;
};

const ModalActionBrlTransfer: React.FC<ActiveProps> = ({
  activeModal = false,
  onHandleClose,
  iconName,
  walletBalance,
  walletName,
}: // iconName,
// walletName,
// walletBalance,
// coinPrice,
// selectedWallet,
ActiveProps) => {
  return (
    <>
      <div
        onClick={onHandleClose}
        className={cx(style.backLayer, activeModal && style.backLayerOpen)}
      />
      <div className={cx(style.container, activeModal && style.containerShow)}>
        <div className={style.containItem}>
          {activeModal && (
            <MakeBrlTransfer
              iconName={iconName}
              walletBalance={walletBalance}
              walletName={walletName}
              onHandleClose={onHandleClose}
            />
          )}
        </div>
      </div>
    </>
  );
};

export default ModalActionBrlTransfer;
