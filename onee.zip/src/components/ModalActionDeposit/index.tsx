/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React from 'react';
import cx from 'classnames';
import style from './modalaction.module.scss';
import MakeDeposit from '../MakeDeposit';

type ActiveProps = {
  activeModal: boolean;
  onHandleClose(): any;
};

const ModalActionDeposit: React.FC<ActiveProps> = ({
  activeModal = false,
  onHandleClose,
}: ActiveProps) => {
  return (
    <>
      {activeModal && (
        <>
          <div
            onClick={onHandleClose}
            className={cx(style.backLayer, activeModal && style.backLayerOpen)}
          />
          <div
            className={cx(style.container, activeModal && style.containerShow)}
          >
            <div className={style.containItem}>
              <MakeDeposit onHandleClose={onHandleClose} />
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default ModalActionDeposit;
