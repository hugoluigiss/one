/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React from 'react';
import cx from 'classnames';
import style from './modalaction.module.scss';
import MakeTransfer from '../MakeTransfer';

interface IWallet {
  id: string;
  address: string;
  balance: number;
  brl_balance_formatted: string;
  balance_formatted: string;
  type_wallet: {
    name: string;
    id: string;
    description: string;
  };
}

type ActiveProps = {
  activeModal: boolean;
  onHandleClose(): any;
  iconName: string;
  walletName: string;
  walletBalance: number;
  coinPrice: number;
};

const ModalActionTransfer: React.FC<ActiveProps> = ({
  activeModal = false,
  onHandleClose,
  iconName,
  walletName,
  walletBalance,
  coinPrice,
}: // selectedWallet,
ActiveProps) => {
  return (
    <>
      <div
        onClick={onHandleClose}
        className={cx(style.backLayer, activeModal && style.backLayerOpen)}
      />
      <div className={cx(style.container, activeModal && style.containerShow)}>
        <div className={style.containItem}>
          {activeModal && (
            <MakeTransfer
              coinPrice={coinPrice}
              iconName={iconName}
              walletBalance={walletBalance}
              walletName={walletName}
              onHandleClose={onHandleClose}
            />
          )}
        </div>
      </div>
    </>
  );
};

export default ModalActionTransfer;
