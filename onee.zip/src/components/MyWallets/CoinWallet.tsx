import React from 'react';

import style from './mywallets.module.scss';
import CurrencyWithIcon from '../UtilsComponents/CurrencyWithIcon';

import SmallButton from '../SmallButton';

import ModalActionTransfer from '~/components/ModalActionTransfer';
import ModalActionSell from '~/components/ModalActionSell';
import ModalActionBuy from '~/components/ModalActionBuy';

interface IProps {
  formatted_brl_balance: string;
  iconName: string;
  currency: string;
  totalBrlBalance: number;
  brl_balance: number;
  walletBalance: number;
  coinPrice: number;
}

export default function CoinWallet({
  formatted_brl_balance,
  totalBrlBalance,
  brl_balance,
  iconName,
  currency,
  walletBalance,
  coinPrice,
}: IProps): JSX.Element {
  const [activeModalTransfer, setActiveModalTransfer] = React.useState(false);
  const [activeModalBuy, setActiveModalBuy] = React.useState(false);
  const [activeModalSell, setActiveModalSell] = React.useState(false);

  return (
    <tr>
      <td>
        <CurrencyWithIcon
          iconName={iconName}
          currency={currency}
          hover={false}
        />
      </td>
      <td>{formatted_brl_balance}</td>
      <td>
        {(
          (100 * brl_balance) /
          (totalBrlBalance > 0 ? totalBrlBalance : 1)
        ).toFixed(2)}{' '}
        %
      </td>
      <td>
        <div className={style.groupButtonsList}>
          <SmallButton
            red={false}
            blue={false}
            green
            onPress={() => setActiveModalBuy(true)}
          >
            Comprar
          </SmallButton>
          <SmallButton
            red
            blue={false}
            green={false}
            onPress={() => setActiveModalSell(true)}
          >
            Vender
          </SmallButton>

          <SmallButton
            red={false}
            blue
            green={false}
            onPress={() => setActiveModalTransfer(true)}
          >
            Transferir
          </SmallButton>
          <ModalActionTransfer
            activeModal={activeModalTransfer}
            onHandleClose={() => setActiveModalTransfer(false)}
            coinPrice={coinPrice}
            iconName={iconName}
            walletBalance={walletBalance}
            walletName={currency}
          />
          <ModalActionSell
            activeModal={activeModalSell}
            onHandleClose={() => setActiveModalSell(false)}
            coinPrice={coinPrice}
            iconName={iconName}
            walletBalance={String(walletBalance)}
            walletName={currency}
          />
          <ModalActionBuy
            activeModal={activeModalBuy}
            onHandleClose={() => setActiveModalBuy(false)}
            coinPrice={coinPrice}
            iconName={iconName}
            walletName={currency}
          />
        </div>
      </td>
    </tr>
  );
}
