import React from 'react';
import { useHistory } from 'react-router-dom';
import style from './mywallets.module.scss';
import CurrencyWithIcon from '../UtilsComponents/CurrencyWithIcon';
import StatusPriceDisplay from '../UtilsComponents/StatusPriceDisplay';
import SmallButton from '../SmallButton';
// import { formatPrice } from '~/utils/format';
import { useGetMyCoinWalletsQuery } from '~/graphql/generated/graphql';
import CoinWallet from './CoinWallet';
import ModalActionBrlTransfer from '../ModalActionBrlTransfer';

const MyWallets: React.FC = () => {
  const { data: wallets } = useGetMyCoinWalletsQuery();
  const totalBrlBalance = React.useMemo(() => {
    return wallets?.GetMyCoinWallets
      ? wallets.GetMyCoinWallets.reduce(
          (acc, curr) => acc + Number(curr.brl_balance),
          0,
        )
      : 0;
  }, [wallets]);

  const history = useHistory();

  const brlWallet = wallets?.GetMyCoinWallets.find(
    w => w.coin.symbol === 'BRL',
  );

  const [activeModalBrlTransfer, setActiveModalBrlTransfer] =
    React.useState(false);

  return (
    <div className={style.container}>
      <div className={style.header}>
        <div className={style.headerinline}>
          <h3>Minhas Carteiras</h3>
          {wallets && <StatusPriceDisplay value={totalBrlBalance} />}
        </div>
      </div>

      <div className={style.tableContainer}>
        <table>
          <thead>
            <tr>
              <th>Moeda</th>
              <th>Valor</th>
              <th>%</th>
              <th>Acões</th>
            </tr>
          </thead>

          <tbody>
            {brlWallet && (
              <tr>
                <td>
                  <CurrencyWithIcon
                    iconName="brl"
                    currency="Real"
                    hover={false}
                  />
                </td>
                <td>{brlWallet.formatted_brl_balance}</td>
                <td>
                  {(
                    (100 * Number(brlWallet.balance)) /
                    (totalBrlBalance === 0 ? 1 : totalBrlBalance)
                  ).toFixed(2)}
                  %
                </td>
                <td>
                  <div className={style.groupButtonsList}>
                    <SmallButton
                      red={false}
                      blue={false}
                      green
                      onPress={() => history.push('/deposit')}
                    >
                      Depositar
                    </SmallButton>
                    <SmallButton
                      red
                      blue={false}
                      green={false}
                      onPress={() => history.push('/withdraw')}
                    >
                      Sacar
                    </SmallButton>

                    <SmallButton
                      red={false}
                      blue
                      green={false}
                      onPress={() => setActiveModalBrlTransfer(true)}
                    >
                      Transferir
                    </SmallButton>

                    <ModalActionBrlTransfer
                      activeModal={activeModalBrlTransfer}
                      onHandleClose={() => setActiveModalBrlTransfer(false)}
                      iconName="brl"
                      walletBalance={Number(brlWallet.balance)}
                      walletName={brlWallet.coin.name}
                    />
                  </div>
                </td>
              </tr>
            )}

            {wallets?.GetMyCoinWallets.filter(
              wallet => wallet.coin.type === 'spot',
            ).map(wallet => (
              <CoinWallet
                key={wallet.coin_id}
                brl_balance={Number(Number(wallet.brl_balance).toFixed(2))}
                formatted_brl_balance={wallet.formatted_brl_balance}
                totalBrlBalance={totalBrlBalance}
                currency={wallet.coin.name}
                iconName={wallet.coin.symbol.toLocaleLowerCase()}
                walletBalance={Number(wallet.balance)}
                coinPrice={Number(wallet.brl_price)}
              />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MyWallets;
