import React from 'react';

import style from './oscillationchart.module.scss';

import {
  create,
  setTheme,
  XYChart,
  DateAxis,
  ValueAxis,
  XYCursor,
  animatedTheme,
  darkTheme,
  Bullet,
  LineSeries,
  color,
} from '../../plugins/amcharts4';
import { useGetOscilationChartDataQuery } from '~/graphql/generated/graphql';

interface IChartData {
  date: string;
  value: number;
}

interface IParams {
  interval: string;
  coin_symbol: string;
  value: number;
}

interface IParsedResponse {
  variation: number;
  chartData: IChartData[];
}

const Chart: React.FC<IParams> = ({
  interval,
  coin_symbol,
  value,
}: IParams) => {
  const { data, loading } = useGetOscilationChartDataQuery({
    variables: {
      coin_symbol,
      interval,
      value,
    },
  });

  const { chartData, variation }: IParsedResponse =
    data && data.GetOscilationChartData
      ? JSON.parse(data.GetOscilationChartData)
      : { chartData: [], variation: 0 };

  React.useEffect(() => {
    function createGraph(): void {
      // Themes begin
      setTheme(animatedTheme);
      setTheme(darkTheme);
      // Create chart instance
      const chart = create('coin-chart', XYChart);
      // Add data
      chart.data = chartData.map(i => ({
        value: i.value,
        date: new Date(i.date),
      }));

      // Create axes
      const categoryAxis = chart.xAxes.push(new DateAxis());
      categoryAxis.renderer.labels.template.disabled = true;
      categoryAxis.renderer.grid.template.disabled = true;
      categoryAxis.tooltipDateFormat =
        interval === 'hour' ? 'HH:mm' : 'dd/MM/yyyy';

      // Create value axis
      const valueAxis = chart.yAxes.push(new ValueAxis());
      valueAxis.renderer.labels.template.disabled = true;
      valueAxis.renderer.grid.template.disabled = true;
      valueAxis.cursorTooltipEnabled = false;
      // Create series
      const series = chart.series.push(new LineSeries());
      series.dataFields.valueY = 'value';
      series.dataFields.dateX = 'date';
      series.strokeWidth = 2;
      series.stroke = color(variation < 0 ? 'red' : '#60BC3F');
      series.fill = color(variation < 0 ? 'red' : '#60BC3F');
      const bullet = series.bullets.push(new Bullet());

      bullet.tooltipText = 'R$ {value}';

      chart.cursor = new XYCursor();

      // return chart && chart.dispose();
    }
    if (chartData.length > 0) createGraph();
  }, [chartData, interval, variation]);

  if (loading) return <div />;

  return <div className={style.chart} id="coin-chart" />;
};

export default Chart;
