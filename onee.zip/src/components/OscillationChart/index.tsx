import React from 'react';
// import Axios from 'axios';
// import { format, toDate } from 'date-fns';
import SelectorTableButton from '../UtilsComponents/SelectorTableButton';
import style from './oscillationchart.module.scss';
// import StatusPercentage from '../UtilsComponents/StatusPercentage';

import Chart from './Chart';

interface IOption {
  name: string;
  value: number;
  interval: string;
}

const options: IOption[] = [
  { name: '24h', value: 24, interval: 'hour' },
  { name: '7d', value: 7, interval: 'day' },
  { name: '30d', value: 30, interval: 'day' },
  { name: '90d', value: 90, interval: 'day' },
  { name: '1a', value: 366, interval: 'day' },
];

const coins: IOption[] = [
  { name: 'BTC', value: 1, interval: '' },
  { name: 'ETH', value: 2, interval: '' },
  { name: 'BNB', value: 3, interval: '' },
  { name: 'USDT', value: 3, interval: '' },
];

const OscillationChart: React.FC = () => {
  const [period, setPeriod] = React.useState<IOption>(options[0]);
  const [coin, setCoin] = React.useState<IOption>(coins[0]);
  // const [variation, setVariation] = React.useState(0);

  // const [chartData, setChartData] = React.useState<IChartData[]>([]);

  // React.useEffect(() => {
  //   const url = `https://min-api.cryptocompare.com/data/v2/histo${
  //     period.interval
  //   }?fsym=${coin.name}&tsym=BRL&limit=${period.value}${
  //     period.value === 2000 ? '&allData=true' : ''
  //   }`;
  //   Axios.get(url).then(response => {
  //     setVariation(
  //       (response.data.Data.Data[response.data.Data.Data.length - 1].close /
  //         response.data.Data.Data[0].close -
  //         1.0) *
  //         100,
  //     );
  //     setChartData(
  //       response.data.Data.Data.map((item: any) => ({
  //         value: item.close,
  //         date: new Date(item.time * 1000),
  //       })),
  //     );
  //   });
  // }, [coin.name, period]);

  return (
    <div className={style.container}>
      <div className={style.header}>
        <div className={style.headerinline}>
          {/* <StatusPercentage value={variation} /> */}
        </div>
        <SelectorTableButton
          options={coins}
          selectedOption={coin}
          setSelectedOption={setCoin}
        />
        <SelectorTableButton
          options={options}
          selectedOption={period}
          setSelectedOption={setPeriod}
        />
      </div>
      <Chart
        coin_symbol={coin.name}
        interval={period.interval}
        value={period.value}
      />
    </div>
  );
};

export default OscillationChart;
