import { darken, lighten } from 'polished';
import styled, { css, keyframes } from 'styled-components';

interface ShimmerProps {
  type?: 'image' | 'title' | 'body' | 'line';
  width?: string;
  height?: string;
}

const progress = keyframes`
  0% {
      background-position: -200px 0;
  }
  100% {
      background-position: calc(200px + 100%) 0;
  }
`;

const types = {
  image: css`
    height: 52px;
    width: 52px;
    border-radius: 50%;
  `,
  title: css`
    height: 25px;
    width: 86%;
    margin: 20px 0;

    @media (max-width: 768px) {
      width: 50%;
    }
  `,
  body: css`
    margin: 3px 0;
  `,

  line: css`
    width: 100%;
    height: 100%;
  `,
};

const ShimmerEffect = styled.div<ShimmerProps>`
  display: block;
  width: 100%;
  height: 13px;
  border-radius: 3px;
  border: 1px solid #ababab;
  background-image: linear-gradient(
    90deg,
    rgba(0, 0, 0, 0),
    ${lighten(1, '#fff')},
    rgba(0, 0, 0, 0)
  );
  background-color: ${darken(0.3, '#fff')};
  background-size: 200px 100%;
  background-repeat: no-repeat;

  line-height: 1;

  opacity: 0.1;
  animation: ${progress} 1.2s ease-in-out infinite;

  ${props => props.type && types[props.type]}

  ${props =>
    props.width &&
    css`
      width: ${props.width};
    `}

  ${props =>
    props.height &&
    css`
      height: ${props.height};
    `}
`;

export default ShimmerEffect;
