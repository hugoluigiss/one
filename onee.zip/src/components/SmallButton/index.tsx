/* eslint-disable react/require-default-props */
import React from 'react';
import classNames from 'classnames/bind';
import style from './smallbutton.module.scss';

type ButtonProps = {
  children: string;
  onPress(): void;
  green?: boolean;
  blue?: boolean;
  red?: boolean;
  disabled?: boolean;
};

const SmallButton: React.FC<ButtonProps> = ({
  children,
  onPress,
  green = false,
  blue = false,
  red = false,
  disabled = false,
}: ButtonProps) => {
  const cx = classNames.bind(style);

  // const btnSelected = (): string => {
  //   return style.blue;
  // };

  const className = cx({
    btn: true,
    green,
    blue,
    red,
  });

  return (
    <button
      disabled={disabled}
      type="button"
      onClick={onPress}
      className={className}
    >
      {children}
    </button>
  );
};

export default SmallButton;
