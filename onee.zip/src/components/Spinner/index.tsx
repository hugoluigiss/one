import React from 'react';
import BounceLoader from 'react-spinners/BounceLoader';

import { Container } from './styles';

const Spinner: React.FC = () => {
  return (
    <Container>
      <BounceLoader size={150} color="green" loading />
    </Container>
  );
};

export default Spinner;
