export {};
// import React, { useEffect } from 'react';
// import {
//   FiAlertCircle,
//   FiCheckCircle,
//   FiInfo,
//   FiXCircle,
// } from 'react-icons/fi';

// // import useToast from '~/hooks/useToast';
// import { ToastMessage } from '~/context/toast';

// import { Container } from './styles';

// interface ToastProps {
//   message: ToastMessage;
//   // style: object;
// }

// const icons = {
//   info: <FiInfo size={24} />,
//   error: <FiAlertCircle size={24} />,
//   success: <FiCheckCircle size={24} />,
// };

// const Toast: React.FC<ToastProps> = ({ message }) => {
//   // const { removeToast } = useToast();

//   useEffect(() => {
//     const timer = setTimeout(() => {
//       // removeToast(message.id);
//     }, 3000);

//     // this return executes when the component of the useEffect params stop existing
//     return () => {
//       clearTimeout(timer);
//     };
//   }, [message.id]);

//   return (
//     <Container
//       data-testid={`toast-${message.id}`}
//       type={message.type}
//       hasdescription={Number(!!message.description)}
//       // style={style}
//     >
//       {icons[message.type || 'info']}
//       <div>
//         <strong>{message.title}</strong>
//         {message.description && <p>{message.description}</p>}
//       </div>

//       <button
//         data-testid={`toast-button-${message.id}`}
//         // onClick={() => removeToast(message.id)}
//         type="button"
//       >
//         <FiXCircle size={18} />
//       </button>
//     </Container>
//   );
// };

// export default Toast;
