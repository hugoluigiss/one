export {};
// import React from 'react';
// import { useTransition } from 'react-spring';

// import { ToastMessage } from '../../context/toast';
// import Toast from './Toast';

// import { Container } from './styles';

// interface ToastContainerProps {
//   messages: ToastMessage[];
// }

// const ToastContainer: React.FC<ToastContainerProps> = ({ messages }) => {
//   const messagesWithTransitions = useTransition(
//     messages, // item who will animated
//     message => message.id, // unique id
//     {
//       from: { right: '-120%', opacity: 0 },
//       enter: { right: '0%', opacity: 1 },
//       leave: { right: '-120%', opacity: 0 },
//     }, // animations
//   );

//   return (
//     <Container>
//       {messagesWithTransitions.map(({ item, key, props }) => (
//         <Toast key={key} style={props} message={item} />
//       ))}
//     </Container>
//   );
// };

// export default ToastContainer;
