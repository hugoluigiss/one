import React from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import style from './datewithhour.module.scss';

type DateWithHourProps = {
  dateValue: any;
};

const DateWithHour: React.FC<DateWithHourProps> = ({
  dateValue,
}: DateWithHourProps) => {
  return (
    <div className={style.container}>
      <h3>{format(new Date(dateValue), 'dd/MM/yyyy', { locale: ptBR })}</h3>
      <span>{format(new Date(dateValue), 'kk:mm', { locale: ptBR })}</span>
    </div>
  );
};

export default DateWithHour;
