/* eslint-disable jsx-a11y/control-has-associated-label */
import React from 'react';

import style from './donwloadicon.module.scss';

type DownloadProps = {
  onPress: () => void;
};

const DownloadIcon: React.FC<DownloadProps> = ({ onPress }: DownloadProps) => {
  return <button type="submit" className={style.icon} onClick={onPress} />;
};

export default DownloadIcon;
