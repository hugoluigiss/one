/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React, { useState } from 'react';
import cx from 'classnames';

import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import { DateRange } from 'react-date-range';
import { format, subDays } from 'date-fns';
import ptLocale from 'date-fns/locale/pt';
import style from './FilterPeriodDate.module.scss';

interface IRange {
  startDate: Date;
  endDate: Date;
}
interface IProps {
  setRange: (data: IRange) => void;
}

const FilterPeriodDate: React.FC<IProps> = ({ setRange }: IProps) => {
  const [isCollapse, setIsCollapse] = useState(false);
  const [customPeriod, setCustomPeriod] = useState(true);
  const [state, setState] = useState([
    {
      startDate: new Date(2021, 1, 1),
      endDate: new Date(),
      key: 'selection',
    },
  ]);

  React.useEffect(() => {
    setRange({ startDate: state[0].startDate, endDate: state[0].endDate });
  }, [setRange, state]);

  const handleMenu = (): void => {
    setIsCollapse(!isCollapse);
  };

  const handleCustomPeriod = (): void => {
    setCustomPeriod(!customPeriod);
  };

  const handleWeek = (): void => {
    setState([
      {
        endDate: new Date(),
        startDate: subDays(new Date(), 7),
        key: 'selection',
      },
    ]);
    setIsCollapse(false);
  };

  const handleMonth = (): void => {
    setState([
      {
        endDate: new Date(),
        startDate: subDays(new Date(), 30),
        key: 'selection',
      },
    ]);
    setIsCollapse(false);
  };

  const handleAllPeriod = (): void => {
    setState([
      {
        startDate: new Date(2021, 1, 1),
        endDate: new Date(),
        key: 'selection',
      },
    ]);
    setIsCollapse(false);
  };

  return (
    <div className={style.container}>
      <div onClick={handleMenu} className={style.buttonSelector}>
        <span>
          {format(state[0].startDate, 'dd/MM/yyyy')} -{' '}
          {format(state[0].endDate, 'dd/MM/yyyy')}
        </span>
        <div className={style.icon} />
      </div>

      <div
        className={cx(
          style.modalSelector,
          isCollapse ? style.modalSelectorCollapsed : null,
        )}
      >
        <a onClick={handleWeek}>Últimos 7 dias</a>
        <a onClick={handleMonth}>Últimos 30 dias</a>
        <a onClick={handleAllPeriod}>Todo o período</a>
        <a onClick={handleCustomPeriod}>Personalizado</a>

        <DateRange
          editableDateInputs
          onChange={(item: any) => {
            setState([item.selection]);
            setCustomPeriod(true);
            setIsCollapse(false);
          }}
          moveRangeOnFirstSelection={false}
          ranges={state}
          locale={ptLocale}
          className={cx(
            style.customPeriodCalendar,
            customPeriod && style.calendarHiddenCustom,
          )}
        />
      </div>
    </div>
  );
};

export default FilterPeriodDate;
