/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React, { useState } from 'react';
import cx from 'classnames';
import style from './selectortablebutton.module.scss';

interface IOption {
  name: string;
  value: number;
  interval: string;
}

interface IProps {
  options: IOption[];
  setSelectedOption: (option: IOption) => void;
  selectedOption: IOption;
}

const SelectorTableButton: React.FC<IProps> = ({
  options,
  setSelectedOption,
  selectedOption,
}: IProps) => {
  const [isCollapse, setIsCollapse] = useState(false);

  const handleMenu = (): void => {
    setIsCollapse(!isCollapse);
  };

  return (
    <div className={style.container}>
      <div onClick={handleMenu} className={style.buttonSelector}>
        <span>{selectedOption.name}</span>
        <div className={style.icon} />
      </div>

      <div
        className={cx(
          style.modalSelector,
          isCollapse ? style.modalSelectorCollapsed : null,
        )}
      >
        {options.map(option => (
          <a
            key={option.name}
            onClick={() => {
              setSelectedOption(option);
              handleMenu();
            }}
          >
            {option.name}
          </a>
        ))}
      </div>
    </div>
  );
};

export default SelectorTableButton;
