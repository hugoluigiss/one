import React, { createContext, useCallback, useState } from 'react';
import {
  // CustomerSession,
  useCreateCustomerSessionMutation,
} from '~/graphql/generated/graphql';

// import api from '~/services/api';

interface User {
  id: number;
  name: string;
  email: string;
  avatar_url?: string;
  document: string;
  born: Date;
  mother_name?: string;
  phone?: string;
}

// interface AuthState {
//   token: string;
//   user: User;
// }

interface SignInCredentials {
  email: string;
  password: string;
}

export interface AuthContextData {
  token: string | null;
  signIn(credentials: SignInCredentials): Promise<void>;
  user: User;
  signOut(): void;
  // updateUser(user: User): void;
}

export const AuthContext = createContext<AuthContextData>(
  {} as AuthContextData,
);

export const AuthProvider: React.FC = ({ children }) => {
  const [tokenSession, setTokenSession] = useState<string | null>(() => {
    const token = localStorage.getItem('@OneExchange-client:token');
    return token;
  });

  const [createSession] = useCreateCustomerSessionMutation();
  const signIn = useCallback(
    async ({ email, password }) => {
      const response = await createSession({ variables: { password, email } });
      const token = response.data?.CreateCustomerSession.token;
      if (!token) return;
      localStorage.setItem('@OneExchange-client:token', token);
      setTokenSession(token);
    },
    [createSession],
  );

  const signOut = useCallback(() => {
    localStorage.removeItem('@OneExchange-client:token');
    setTokenSession(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{ signIn, token: tokenSession, user: {} as User, signOut }}
    >
      {children}
    </AuthContext.Provider>
  );
};
