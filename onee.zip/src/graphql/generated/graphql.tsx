import { gql } from '@apollo/client';
import * as Apollo from '@apollo/client';
export type Maybe<T> = T | null;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
const defaultOptions =  {}
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
  /** The javascript `Date` as string. Type represents date and time as the ISO Date string. */
  DateTime: any;
  /** The `Upload` scalar type represents a file upload. */
  Upload: any;
};

export type Admin = {
  __typename?: 'Admin';
  id: Scalars['String'];
  email: Scalars['String'];
};

export type AdminCryptoWallet = {
  __typename?: 'AdminCryptoWallet';
  id: Scalars['String'];
  address: Scalars['String'];
  coin_id: Scalars['String'];
  coin: Coin;
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
  balance: Scalars['String'];
  brl_balance: Scalars['String'];
  total_customers_balance: Scalars['String'];
  total_customers_brl_balance: Scalars['String'];
  total_customers_brl_balance_formatted: Scalars['String'];
  brl_balance_formatted: Scalars['String'];
};

export type AdminSession = {
  __typename?: 'AdminSession';
  token: Scalars['String'];
  admin: Admin;
};

export type Bank = {
  __typename?: 'Bank';
  id: Scalars['String'];
  code: Scalars['Float'];
  name: Scalars['String'];
};

export type BrlDeposit = {
  __typename?: 'BrlDeposit';
  id: Scalars['String'];
  transaction: CoinTransaction;
  file_url: Scalars['String'];
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
};

export type BrlWithdrawal = {
  __typename?: 'BrlWithdrawal';
  id: Scalars['String'];
  bank_account: CustomerBankAccount;
  transaction: CoinTransaction;
  file_url?: Maybe<Scalars['String']>;
  admin_comment?: Maybe<Scalars['String']>;
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
};

export type CafDocument = {
  __typename?: 'CafDocument';
  id: Scalars['String'];
  customer_id: Scalars['String'];
  status: Scalars['String'];
};

export type Coin = {
  __typename?: 'Coin';
  id: Scalars['String'];
  name: Scalars['String'];
  type: Scalars['String'];
  symbol: Scalars['String'];
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
};

export type CoinOperationParam = {
  __typename?: 'CoinOperationParam';
  id: Scalars['String'];
  coin: Coin;
  operation: Scalars['String'];
  name: Scalars['String'];
  fixed_fee_brl_value: Scalars['String'];
  fixed_fee_brl_value_formatted: Scalars['String'];
  min_brl_value: Scalars['String'];
  min_brl_value_formatted: Scalars['String'];
  max_brl_value: Scalars['String'];
  max_brl_value_formatted: Scalars['String'];
  validity_period_days: Scalars['Float'];
  network_fee: Scalars['String'];
  percentage_fee_value: Scalars['String'];
  percentage_fee_value_formatted: Scalars['String'];
  customer_type: Scalars['String'];
  has_complience: Scalars['Boolean'];
};

export type CoinTransaction = {
  __typename?: 'CoinTransaction';
  id: Scalars['String'];
  operation: Scalars['String'];
  brl_deposit?: Maybe<BrlDeposit>;
  brl_withdrawal?: Maybe<BrlWithdrawal>;
  coin: Coin;
  customer: Customer;
  status: Scalars['String'];
  type: Scalars['String'];
  description: Scalars['String'];
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
  formatted_net_value: Scalars['String'];
  formatted_fee_value: Scalars['String'];
  formatted_total_value: Scalars['String'];
};

export type Customer = {
  __typename?: 'Customer';
  id: Scalars['String'];
  email: Scalars['String'];
  full_name: Scalars['String'];
  two_fa?: Maybe<CustomerTwoFa>;
  birth_date: Scalars['DateTime'];
  document: CustomerDocument;
  address: CustomerAddress;
  fantasy_name?: Maybe<Scalars['String']>;
  type: Scalars['String'];
  avatar_url: Scalars['String'];
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
};

export type CustomerAddress = {
  __typename?: 'CustomerAddress';
  zip_code: Scalars['String'];
  country: Scalars['String'];
  state: Scalars['String'];
  city: Scalars['String'];
  district: Scalars['String'];
  street: Scalars['String'];
  number: Scalars['String'];
  complement: Scalars['String'];
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
};

export type CustomerBankAccount = {
  __typename?: 'CustomerBankAccount';
  id: Scalars['String'];
  bank: Bank;
  account: Scalars['String'];
  agency: Scalars['String'];
  pix?: Maybe<Scalars['String']>;
};

export type CustomerCoinWallet = {
  __typename?: 'CustomerCoinWallet';
  customer_id: Scalars['String'];
  coin_id: Scalars['String'];
  coin: Coin;
  address?: Maybe<Scalars['String']>;
  balance: Scalars['String'];
  network: Scalars['String'];
  memo: Scalars['String'];
  formatted_balance: Scalars['String'];
  formatted_brl_balance: Scalars['String'];
  brl_balance: Scalars['String'];
  brl_price: Scalars['String'];
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
};

export type CustomerDocument = {
  __typename?: 'CustomerDocument';
  customer: Customer;
  copies?: Maybe<Array<CustomerDocumentCopy>>;
  type: Scalars['String'];
  nationality: Scalars['String'];
  has_complience?: Maybe<Scalars['Boolean']>;
  document_value: Scalars['String'];
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
};

export type CustomerDocumentCopy = {
  __typename?: 'CustomerDocumentCopy';
  id: Scalars['String'];
  name: Scalars['String'];
  document: CustomerDocument;
  status: Scalars['String'];
  admin_answear?: Maybe<Scalars['String']>;
  type: Scalars['String'];
  description: Scalars['String'];
  file_url?: Maybe<Scalars['String']>;
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
};

export type CustomerSession = {
  __typename?: 'CustomerSession';
  token: Scalars['String'];
  customer: Customer;
};

export type CustomerTwoFa = {
  __typename?: 'CustomerTwoFa';
  secret: Scalars['String'];
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
};


export type DepositAccount = {
  __typename?: 'DepositAccount';
  bank: Bank;
  agency: Scalars['String'];
  account: Scalars['String'];
  pix: Scalars['String'];
  owner: Scalars['String'];
};

export type Edges = {
  __typename?: 'Edges';
  brl_deposits?: Maybe<Array<BrlDeposit>>;
  brl_withdrawals?: Maybe<Array<BrlWithdrawal>>;
  transactions?: Maybe<Array<CoinTransaction>>;
  documents?: Maybe<Array<CustomerDocument>>;
  customers?: Maybe<Array<Customer>>;
  tickets?: Maybe<Array<Ticket>>;
};

export type Mutation = {
  __typename?: 'Mutation';
  CreateTxidNotification: Scalars['String'];
  CreateBlockNotification: Scalars['String'];
  SendEmailConfirmationToken: Scalars['String'];
  ConfirmEmailToken: Scalars['String'];
  CreateCustomerPF: Customer;
  CreateCustomerSession: CustomerSession;
  SendForgotPasswordEmail: Scalars['String'];
  CreateNewCustomerPassword: Scalars['String'];
  CreateMyTwoFa: Scalars['String'];
  DeleteTwoFa: Scalars['String'];
  UpdateMyPassword: Scalars['String'];
  CreateCustomerPJ: Customer;
  CreateSwitchAccount: CustomerSession;
  CreateMyBankAccount: Scalars['String'];
  UpdateMyBankAccount: Scalars['String'];
  SendMyDocumentFile: Scalars['String'];
  CreateBrlDeposit: Scalars['String'];
  CreateBrlWithdrawal: Scalars['String'];
  CreateBrlTransfer: Scalars['String'];
  CreateCryptoBuy: Scalars['String'];
  CreateCryptoSell: Scalars['String'];
  CreateCryptoWithdrawal: Scalars['String'];
  CreateTicket: Scalars['String'];
  createCfaDocument: Scalars['String'];
  CreateMyOneTimeCode: Scalars['String'];
  CreateAdminSession: AdminSession;
  ConfirmCustomerBrlDeposit: Scalars['String'];
  RefuseCustomerBrlDeposit: Scalars['String'];
  ConfirmCustomerBrlWithdrawal: Scalars['String'];
  RefuseCustomerBrlWithdrawal: Scalars['String'];
  ApproveCustomerDocumentCopy: Scalars['String'];
  ReproveCustomerDocumentCopy: Scalars['String'];
  CreateAdminCryptoWithdrawal: Scalars['String'];
  UpdateCoinOperationParam: Scalars['String'];
};


export type MutationCreateTxidNotificationArgs = {
  txid: Scalars['String'];
};


export type MutationCreateBlockNotificationArgs = {
  block_hash: Scalars['String'];
};


export type MutationSendEmailConfirmationTokenArgs = {
  email: Scalars['String'];
};


export type MutationConfirmEmailTokenArgs = {
  token: Scalars['String'];
  email: Scalars['String'];
};


export type MutationCreateCustomerPfArgs = {
  complement: Scalars['String'];
  number: Scalars['String'];
  street: Scalars['String'];
  district: Scalars['String'];
  city: Scalars['String'];
  state: Scalars['String'];
  country: Scalars['String'];
  zipcode: Scalars['String'];
  document: Scalars['String'];
  nationality: Scalars['String'];
  password: Scalars['String'];
  birth_date: Scalars['DateTime'];
  full_name: Scalars['String'];
  email: Scalars['String'];
};


export type MutationCreateCustomerSessionArgs = {
  password: Scalars['String'];
  email: Scalars['String'];
};


export type MutationSendForgotPasswordEmailArgs = {
  email: Scalars['String'];
};


export type MutationCreateNewCustomerPasswordArgs = {
  new_password: Scalars['String'];
  token: Scalars['String'];
};


export type MutationCreateMyTwoFaArgs = {
  token: Scalars['String'];
  secret: Scalars['String'];
};


export type MutationDeleteTwoFaArgs = {
  customer_id: Scalars['String'];
};


export type MutationUpdateMyPasswordArgs = {
  new_password: Scalars['String'];
  current_password: Scalars['String'];
};


export type MutationCreateCustomerPjArgs = {
  complement: Scalars['String'];
  number: Scalars['String'];
  street: Scalars['String'];
  district: Scalars['String'];
  city: Scalars['String'];
  state: Scalars['String'];
  country: Scalars['String'];
  zipcode: Scalars['String'];
  cnpj: Scalars['String'];
  fantasy_name: Scalars['String'];
  birth_date: Scalars['DateTime'];
  full_name: Scalars['String'];
};


export type MutationCreateSwitchAccountArgs = {
  to_customer_id: Scalars['String'];
};


export type MutationCreateMyBankAccountArgs = {
  bank_id: Scalars['String'];
  pix?: Maybe<Scalars['String']>;
  account: Scalars['String'];
  agency: Scalars['String'];
};


export type MutationUpdateMyBankAccountArgs = {
  bank_id: Scalars['String'];
  pix?: Maybe<Scalars['String']>;
  account: Scalars['String'];
  agency: Scalars['String'];
};


export type MutationSendMyDocumentFileArgs = {
  document_id: Scalars['String'];
  file: Scalars['Upload'];
};


export type MutationCreateBrlDepositArgs = {
  value_brl: Scalars['String'];
  file: Scalars['Upload'];
};


export type MutationCreateBrlWithdrawalArgs = {
  bank_account_id: Scalars['String'];
  value_brl: Scalars['String'];
  two_fa: Scalars['String'];
};


export type MutationCreateBrlTransferArgs = {
  email_to: Scalars['String'];
  value_brl: Scalars['String'];
  two_fa: Scalars['String'];
};


export type MutationCreateCryptoBuyArgs = {
  coin_symbol: Scalars['String'];
  value_brl: Scalars['String'];
  two_fa: Scalars['String'];
};


export type MutationCreateCryptoSellArgs = {
  coin_symbol: Scalars['String'];
  coin_amount: Scalars['String'];
  two_fa: Scalars['String'];
};


export type MutationCreateCryptoWithdrawalArgs = {
  dest_flag?: Maybe<Scalars['String']>;
  address_to: Scalars['String'];
  coin_symbol: Scalars['String'];
  coin_amount: Scalars['String'];
  two_fa: Scalars['String'];
};


export type MutationCreateTicketArgs = {
  file?: Maybe<Scalars['Upload']>;
  category_value: Scalars['String'];
  subject: Scalars['String'];
  message: Scalars['String'];
};


export type MutationCreateCfaDocumentArgs = {
  cpf?: Maybe<Scalars['String']>;
  type: Scalars['String'];
  selfie: Scalars['Upload'];
  back: Scalars['Upload'];
  front: Scalars['Upload'];
};


export type MutationCreateAdminSessionArgs = {
  password: Scalars['String'];
  email: Scalars['String'];
};


export type MutationConfirmCustomerBrlDepositArgs = {
  deposit_id: Scalars['String'];
};


export type MutationRefuseCustomerBrlDepositArgs = {
  deposit_id: Scalars['String'];
};


export type MutationConfirmCustomerBrlWithdrawalArgs = {
  file?: Maybe<Scalars['Upload']>;
  withdrawal_id: Scalars['String'];
};


export type MutationRefuseCustomerBrlWithdrawalArgs = {
  comment?: Maybe<Scalars['String']>;
  withdrawal_id: Scalars['String'];
};


export type MutationApproveCustomerDocumentCopyArgs = {
  document_copy_id: Scalars['String'];
};


export type MutationReproveCustomerDocumentCopyArgs = {
  admin_answear: Scalars['String'];
  document_copy_id: Scalars['String'];
};


export type MutationCreateAdminCryptoWithdrawalArgs = {
  coin_symbol: Scalars['String'];
  amount: Scalars['String'];
  address_to: Scalars['String'];
};


export type MutationUpdateCoinOperationParamArgs = {
  validity_period_days?: Maybe<Scalars['Float']>;
  percentage_fee_value?: Maybe<Scalars['String']>;
  min_brl_value?: Maybe<Scalars['String']>;
  max_brl_value?: Maybe<Scalars['String']>;
  fixed_fee_brl_value?: Maybe<Scalars['String']>;
  id: Scalars['String'];
};

export type PageInfo = {
  __typename?: 'PageInfo';
  hasPrevPage: Scalars['Boolean'];
  hasNextPage: Scalars['Boolean'];
};

export type PaginationType = {
  __typename?: 'PaginationType';
  totalCount: Scalars['Float'];
  edges: Edges;
  pageInfo: PageInfo;
};

export type Query = {
  __typename?: 'Query';
  GetTwoFaData: TwoFaData;
  CheckMyTwoFaExists: Scalars['Boolean'];
  GetMyCoinWalletBySymbol: CustomerCoinWallet;
  GetMyCoinWallets: Array<CustomerCoinWallet>;
  GetCoins: Array<Coin>;
  GetMyProfile: Customer;
  GetMyAssociatedAccounts: Array<Customer>;
  GetMyBankAccounts: Array<CustomerBankAccount>;
  GetMyDocuments: Array<CustomerDocumentCopy>;
  GetDepositAccount: DepositAccount;
  GetMyBrlDeposits: PaginationType;
  GetMyBrlWithdrawals: PaginationType;
  GetMyStatment: PaginationType;
  GetCoinOperationParam: CoinOperationParam;
  GetAllCoinsOperationParams: Array<CoinOperationParam>;
  GetTicketCategories: Array<TicketCategory>;
  GetMyTickets: PaginationType;
  getCustomerNotReprovedCaf?: Maybe<CafDocument>;
  GetOscilationChartData: Scalars['String'];
  GetAllBanks: Array<Bank>;
  GetCustomersBrlDeposits: PaginationType;
  GetCustomersBrlWithdrawals: PaginationType;
  GetCustomersDocuments: PaginationType;
  GetAdminCryptoWallet: AdminCryptoWallet;
  GetAllCustomers: PaginationType;
  GetAllCoinsOperationParamsWithFilter: Array<CoinOperationParam>;
  GetCustomersStatments: PaginationType;
  hello: Scalars['String'];
};


export type QueryGetMyCoinWalletBySymbolArgs = {
  symbol: Scalars['String'];
};


export type QueryGetMyBrlDepositsArgs = {
  status?: Maybe<Scalars['String']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
};


export type QueryGetMyBrlWithdrawalsArgs = {
  status?: Maybe<Scalars['String']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
};


export type QueryGetMyStatmentArgs = {
  operation?: Maybe<Scalars['String']>;
  status?: Maybe<Scalars['String']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
  coin_symbol?: Maybe<Scalars['String']>;
  final_date?: Maybe<Scalars['DateTime']>;
  start_date?: Maybe<Scalars['DateTime']>;
};


export type QueryGetCoinOperationParamArgs = {
  operation: Scalars['String'];
  coin_symbol: Scalars['String'];
};


export type QueryGetMyTicketsArgs = {
  category_value?: Maybe<Scalars['String']>;
  status?: Maybe<Scalars['String']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
};


export type QueryGetOscilationChartDataArgs = {
  interval: Scalars['String'];
  coin_symbol: Scalars['String'];
  value: Scalars['Float'];
};


export type QueryGetCustomersBrlDepositsArgs = {
  status?: Maybe<Scalars['String']>;
  customer_id?: Maybe<Scalars['String']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
};


export type QueryGetCustomersBrlWithdrawalsArgs = {
  status?: Maybe<Scalars['String']>;
  customer_id?: Maybe<Scalars['String']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
};


export type QueryGetCustomersDocumentsArgs = {
  has_complience?: Maybe<Scalars['Boolean']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
  customer_id?: Maybe<Scalars['String']>;
};


export type QueryGetAdminCryptoWalletArgs = {
  coin_symbol: Scalars['String'];
};


export type QueryGetAllCustomersArgs = {
  order?: Maybe<Scalars['String']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
};


export type QueryGetAllCoinsOperationParamsWithFilterArgs = {
  has_complience?: Maybe<Scalars['Boolean']>;
  operation?: Maybe<Scalars['String']>;
  customer_type?: Maybe<Scalars['String']>;
};


export type QueryGetCustomersStatmentsArgs = {
  operation?: Maybe<Scalars['String']>;
  status?: Maybe<Scalars['String']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
  coin_symbol?: Maybe<Scalars['String']>;
};

export type Ticket = {
  __typename?: 'Ticket';
  id: Scalars['String'];
  category: Scalars['String'];
  message: Scalars['String'];
  status: Scalars['String'];
  admin_answear?: Maybe<Scalars['String']>;
  file_url?: Maybe<Scalars['String']>;
  subject: Scalars['String'];
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
};

export type TicketCategory = {
  __typename?: 'TicketCategory';
  name: Scalars['String'];
  value: Scalars['String'];
};

export type TwoFaData = {
  __typename?: 'TwoFaData';
  base32: Scalars['String'];
  otpauth_url?: Maybe<Scalars['String']>;
};


export type SendMyDocumentFileMutationVariables = Exact<{
  document_id: Scalars['String'];
  file: Scalars['Upload'];
}>;


export type SendMyDocumentFileMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'SendMyDocumentFile'>
);

export type ConfirmEmailTokenMutationVariables = Exact<{
  email: Scalars['String'];
  token: Scalars['String'];
}>;


export type ConfirmEmailTokenMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'ConfirmEmailToken'>
);

export type CreateBrlDepositMutationVariables = Exact<{
  value_brl: Scalars['String'];
  file: Scalars['Upload'];
}>;


export type CreateBrlDepositMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'CreateBrlDeposit'>
);

export type CreateBrlTransferMutationVariables = Exact<{
  email_to: Scalars['String'];
  value_brl: Scalars['String'];
  two_fa: Scalars['String'];
}>;


export type CreateBrlTransferMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'CreateBrlTransfer'>
);

export type CreateBrlWithdrawalMutationVariables = Exact<{
  bank_account_id: Scalars['String'];
  value_brl: Scalars['String'];
  two_fa: Scalars['String'];
}>;


export type CreateBrlWithdrawalMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'CreateBrlWithdrawal'>
);

export type CreateCryptoBuyMutationVariables = Exact<{
  coin_symbol: Scalars['String'];
  value_brl: Scalars['String'];
  two_fa: Scalars['String'];
}>;


export type CreateCryptoBuyMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'CreateCryptoBuy'>
);

export type CreateCryptoSellMutationVariables = Exact<{
  coin_symbol: Scalars['String'];
  coin_amount: Scalars['String'];
  two_fa: Scalars['String'];
}>;


export type CreateCryptoSellMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'CreateCryptoSell'>
);

export type CreateCryptoWithdrawalMutationVariables = Exact<{
  coin_symbol: Scalars['String'];
  coin_amount: Scalars['String'];
  two_fa: Scalars['String'];
  address_to: Scalars['String'];
  dest_flag?: Maybe<Scalars['String']>;
}>;


export type CreateCryptoWithdrawalMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'CreateCryptoWithdrawal'>
);

export type CreateCustomerPfMutationVariables = Exact<{
  complement: Scalars['String'];
  number: Scalars['String'];
  street: Scalars['String'];
  district: Scalars['String'];
  city: Scalars['String'];
  state: Scalars['String'];
  country: Scalars['String'];
  zipcode: Scalars['String'];
  document: Scalars['String'];
  nationality: Scalars['String'];
  password: Scalars['String'];
  birth_date: Scalars['DateTime'];
  full_name: Scalars['String'];
  email: Scalars['String'];
}>;


export type CreateCustomerPfMutation = (
  { __typename?: 'Mutation' }
  & { CreateCustomerPF: (
    { __typename?: 'Customer' }
    & Pick<Customer, 'id'>
  ) }
);

export type CreateCustomerPjMutationVariables = Exact<{
  complement: Scalars['String'];
  number: Scalars['String'];
  street: Scalars['String'];
  district: Scalars['String'];
  city: Scalars['String'];
  state: Scalars['String'];
  country: Scalars['String'];
  zipcode: Scalars['String'];
  cnpj: Scalars['String'];
  fantasy_name: Scalars['String'];
  birth_date: Scalars['DateTime'];
  full_name: Scalars['String'];
}>;


export type CreateCustomerPjMutation = (
  { __typename?: 'Mutation' }
  & { CreateCustomerPJ: (
    { __typename?: 'Customer' }
    & Pick<Customer, 'id'>
  ) }
);

export type CreateCustomerSessionMutationVariables = Exact<{
  email: Scalars['String'];
  password: Scalars['String'];
}>;


export type CreateCustomerSessionMutation = (
  { __typename?: 'Mutation' }
  & { CreateCustomerSession: (
    { __typename?: 'CustomerSession' }
    & Pick<CustomerSession, 'token'>
    & { customer: (
      { __typename?: 'Customer' }
      & Pick<Customer, 'id' | 'email' | 'full_name' | 'birth_date' | 'fantasy_name' | 'type' | 'avatar_url' | 'created_at' | 'updated_at'>
      & { document: (
        { __typename?: 'CustomerDocument' }
        & Pick<CustomerDocument, 'type' | 'nationality' | 'has_complience' | 'document_value'>
      ) }
    ) }
  ) }
);

export type CreateMyBankAccountMutationVariables = Exact<{
  bank_id: Scalars['String'];
  account: Scalars['String'];
  agency: Scalars['String'];
  pix?: Maybe<Scalars['String']>;
}>;


export type CreateMyBankAccountMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'CreateMyBankAccount'>
);

export type CreateMyOneTimeCodeMutationVariables = Exact<{ [key: string]: never; }>;


export type CreateMyOneTimeCodeMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'CreateMyOneTimeCode'>
);

export type CreateMyTwoFaMutationVariables = Exact<{
  secret: Scalars['String'];
  token: Scalars['String'];
}>;


export type CreateMyTwoFaMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'CreateMyTwoFa'>
);

export type CreateNewCustomerPasswordMutationVariables = Exact<{
  new_password: Scalars['String'];
  token: Scalars['String'];
}>;


export type CreateNewCustomerPasswordMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'CreateNewCustomerPassword'>
);

export type CreateSwitchAccountMutationVariables = Exact<{
  to_customer_id: Scalars['String'];
}>;


export type CreateSwitchAccountMutation = (
  { __typename?: 'Mutation' }
  & { CreateSwitchAccount: (
    { __typename?: 'CustomerSession' }
    & Pick<CustomerSession, 'token'>
    & { customer: (
      { __typename?: 'Customer' }
      & Pick<Customer, 'id' | 'email' | 'full_name' | 'birth_date'>
    ) }
  ) }
);

export type CreateTicketMutationVariables = Exact<{
  category_value: Scalars['String'];
  subject: Scalars['String'];
  message: Scalars['String'];
  file?: Maybe<Scalars['Upload']>;
}>;


export type CreateTicketMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'CreateTicket'>
);

export type SendEmailConfirmationTokenMutationVariables = Exact<{
  email: Scalars['String'];
}>;


export type SendEmailConfirmationTokenMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'SendEmailConfirmationToken'>
);

export type SendForgotPasswordEmailMutationVariables = Exact<{
  email: Scalars['String'];
}>;


export type SendForgotPasswordEmailMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'SendForgotPasswordEmail'>
);

export type UpdateMyPasswordMutationVariables = Exact<{
  new_password: Scalars['String'];
  current_password: Scalars['String'];
}>;


export type UpdateMyPasswordMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'UpdateMyPassword'>
);

export type CreateCfaDocumentMutationVariables = Exact<{
  front: Scalars['Upload'];
  back: Scalars['Upload'];
  selfie: Scalars['Upload'];
  type: Scalars['String'];
  cpf?: Maybe<Scalars['String']>;
}>;


export type CreateCfaDocumentMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'createCfaDocument'>
);

export type CheckMyTwoFaExistsQueryVariables = Exact<{ [key: string]: never; }>;


export type CheckMyTwoFaExistsQuery = (
  { __typename?: 'Query' }
  & Pick<Query, 'CheckMyTwoFaExists'>
);

export type GetAllBanksQueryVariables = Exact<{ [key: string]: never; }>;


export type GetAllBanksQuery = (
  { __typename?: 'Query' }
  & { GetAllBanks: Array<(
    { __typename?: 'Bank' }
    & Pick<Bank, 'id' | 'code' | 'name'>
  )> }
);

export type GetAllCoinsOperationParamsQueryVariables = Exact<{ [key: string]: never; }>;


export type GetAllCoinsOperationParamsQuery = (
  { __typename?: 'Query' }
  & { GetAllCoinsOperationParams: Array<(
    { __typename?: 'CoinOperationParam' }
    & Pick<CoinOperationParam, 'id' | 'max_brl_value_formatted' | 'percentage_fee_value_formatted' | 'validity_period_days' | 'min_brl_value_formatted' | 'fixed_fee_brl_value_formatted' | 'name'>
    & { coin: (
      { __typename?: 'Coin' }
      & Pick<Coin, 'name' | 'symbol'>
    ) }
  )> }
);

export type GetCoinOperationParamQueryVariables = Exact<{
  operation: Scalars['String'];
  coin_symbol: Scalars['String'];
}>;


export type GetCoinOperationParamQuery = (
  { __typename?: 'Query' }
  & { GetCoinOperationParam: (
    { __typename?: 'CoinOperationParam' }
    & Pick<CoinOperationParam, 'id' | 'fixed_fee_brl_value' | 'percentage_fee_value' | 'network_fee' | 'min_brl_value' | 'max_brl_value' | 'validity_period_days' | 'has_complience'>
  ) }
);

export type GetCoinsQueryVariables = Exact<{ [key: string]: never; }>;


export type GetCoinsQuery = (
  { __typename?: 'Query' }
  & { GetCoins: Array<(
    { __typename?: 'Coin' }
    & Pick<Coin, 'id' | 'name' | 'type' | 'symbol' | 'created_at' | 'updated_at'>
  )> }
);

export type GetDepositAccountQueryVariables = Exact<{ [key: string]: never; }>;


export type GetDepositAccountQuery = (
  { __typename?: 'Query' }
  & { GetDepositAccount: (
    { __typename?: 'DepositAccount' }
    & Pick<DepositAccount, 'agency' | 'account' | 'pix' | 'owner'>
    & { bank: (
      { __typename?: 'Bank' }
      & Pick<Bank, 'id' | 'code' | 'name'>
    ) }
  ) }
);

export type GetMyAssociatedAccountsQueryVariables = Exact<{ [key: string]: never; }>;


export type GetMyAssociatedAccountsQuery = (
  { __typename?: 'Query' }
  & { GetMyAssociatedAccounts: Array<(
    { __typename?: 'Customer' }
    & Pick<Customer, 'id' | 'email' | 'full_name' | 'birth_date' | 'fantasy_name' | 'type' | 'avatar_url' | 'created_at' | 'updated_at'>
  )> }
);

export type GetMyBankAccountsQueryVariables = Exact<{ [key: string]: never; }>;


export type GetMyBankAccountsQuery = (
  { __typename?: 'Query' }
  & { GetMyBankAccounts: Array<(
    { __typename?: 'CustomerBankAccount' }
    & Pick<CustomerBankAccount, 'id' | 'account' | 'agency' | 'pix'>
    & { bank: (
      { __typename?: 'Bank' }
      & Pick<Bank, 'id' | 'code' | 'name'>
    ) }
  )> }
);

export type GetMyBrlDepositsQueryVariables = Exact<{
  status?: Maybe<Scalars['String']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
}>;


export type GetMyBrlDepositsQuery = (
  { __typename?: 'Query' }
  & { GetMyBrlDeposits: (
    { __typename?: 'PaginationType' }
    & Pick<PaginationType, 'totalCount'>
    & { edges: (
      { __typename?: 'Edges' }
      & { brl_deposits?: Maybe<Array<(
        { __typename?: 'BrlDeposit' }
        & Pick<BrlDeposit, 'file_url'>
        & { transaction: (
          { __typename?: 'CoinTransaction' }
          & Pick<CoinTransaction, 'id' | 'status' | 'type' | 'description' | 'created_at' | 'updated_at' | 'formatted_net_value' | 'formatted_fee_value' | 'formatted_total_value'>
          & { coin: (
            { __typename?: 'Coin' }
            & Pick<Coin, 'id' | 'name' | 'type' | 'symbol'>
          ) }
        ) }
      )>> }
    ), pageInfo: (
      { __typename?: 'PageInfo' }
      & Pick<PageInfo, 'hasPrevPage' | 'hasNextPage'>
    ) }
  ) }
);

export type GetMyBrlWithdrawalsQueryVariables = Exact<{
  status?: Maybe<Scalars['String']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
}>;


export type GetMyBrlWithdrawalsQuery = (
  { __typename?: 'Query' }
  & { GetMyBrlWithdrawals: (
    { __typename?: 'PaginationType' }
    & Pick<PaginationType, 'totalCount'>
    & { edges: (
      { __typename?: 'Edges' }
      & { brl_withdrawals?: Maybe<Array<(
        { __typename?: 'BrlWithdrawal' }
        & Pick<BrlWithdrawal, 'file_url' | 'admin_comment'>
        & { transaction: (
          { __typename?: 'CoinTransaction' }
          & Pick<CoinTransaction, 'id' | 'status' | 'type' | 'description' | 'created_at' | 'updated_at' | 'formatted_net_value' | 'formatted_fee_value' | 'formatted_total_value'>
          & { coin: (
            { __typename?: 'Coin' }
            & Pick<Coin, 'id' | 'name' | 'type' | 'symbol'>
          ) }
        ), bank_account: (
          { __typename?: 'CustomerBankAccount' }
          & Pick<CustomerBankAccount, 'id' | 'account' | 'agency' | 'pix'>
          & { bank: (
            { __typename?: 'Bank' }
            & Pick<Bank, 'id' | 'code' | 'name'>
          ) }
        ) }
      )>> }
    ), pageInfo: (
      { __typename?: 'PageInfo' }
      & Pick<PageInfo, 'hasPrevPage' | 'hasNextPage'>
    ) }
  ) }
);

export type GetMyCoinWalletBySymbolQueryVariables = Exact<{
  symbol: Scalars['String'];
}>;


export type GetMyCoinWalletBySymbolQuery = (
  { __typename?: 'Query' }
  & { GetMyCoinWalletBySymbol: (
    { __typename?: 'CustomerCoinWallet' }
    & Pick<CustomerCoinWallet, 'customer_id' | 'coin_id' | 'address' | 'formatted_balance' | 'balance' | 'created_at' | 'updated_at'>
    & { coin: (
      { __typename?: 'Coin' }
      & Pick<Coin, 'id' | 'name' | 'type' | 'symbol' | 'created_at' | 'updated_at'>
    ) }
  ) }
);

export type GetMyCoinWalletsQueryVariables = Exact<{ [key: string]: never; }>;


export type GetMyCoinWalletsQuery = (
  { __typename?: 'Query' }
  & { GetMyCoinWallets: Array<(
    { __typename?: 'CustomerCoinWallet' }
    & Pick<CustomerCoinWallet, 'customer_id' | 'coin_id' | 'address' | 'formatted_balance' | 'formatted_brl_balance' | 'brl_price' | 'brl_balance' | 'balance' | 'created_at' | 'updated_at' | 'network' | 'memo'>
    & { coin: (
      { __typename?: 'Coin' }
      & Pick<Coin, 'id' | 'name' | 'type' | 'symbol'>
    ) }
  )> }
);

export type GetMyDocumentsQueryVariables = Exact<{ [key: string]: never; }>;


export type GetMyDocumentsQuery = (
  { __typename?: 'Query' }
  & { GetMyDocuments: Array<(
    { __typename?: 'CustomerDocumentCopy' }
    & Pick<CustomerDocumentCopy, 'id' | 'name' | 'status' | 'admin_answear' | 'type' | 'description' | 'file_url' | 'created_at' | 'updated_at'>
    & { document: (
      { __typename?: 'CustomerDocument' }
      & Pick<CustomerDocument, 'type' | 'nationality' | 'has_complience' | 'document_value'>
    ) }
  )> }
);

export type GetMyProfileQueryVariables = Exact<{ [key: string]: never; }>;


export type GetMyProfileQuery = (
  { __typename?: 'Query' }
  & { GetMyProfile: (
    { __typename?: 'Customer' }
    & Pick<Customer, 'id' | 'email' | 'full_name' | 'birth_date' | 'fantasy_name' | 'type' | 'avatar_url' | 'created_at' | 'updated_at'>
    & { document: (
      { __typename?: 'CustomerDocument' }
      & Pick<CustomerDocument, 'type' | 'nationality' | 'has_complience' | 'document_value' | 'created_at' | 'updated_at'>
    ), address: (
      { __typename?: 'CustomerAddress' }
      & Pick<CustomerAddress, 'zip_code' | 'country' | 'state' | 'city' | 'district' | 'street' | 'number' | 'complement' | 'created_at' | 'updated_at'>
    ) }
  ) }
);

export type GetMyStatmentQueryVariables = Exact<{
  status?: Maybe<Scalars['String']>;
  coin_symbol?: Maybe<Scalars['String']>;
  operation?: Maybe<Scalars['String']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
  final_date?: Maybe<Scalars['DateTime']>;
  start_date?: Maybe<Scalars['DateTime']>;
}>;


export type GetMyStatmentQuery = (
  { __typename?: 'Query' }
  & { GetMyStatment: (
    { __typename?: 'PaginationType' }
    & Pick<PaginationType, 'totalCount'>
    & { edges: (
      { __typename?: 'Edges' }
      & { transactions?: Maybe<Array<(
        { __typename?: 'CoinTransaction' }
        & Pick<CoinTransaction, 'id' | 'type' | 'description' | 'formatted_net_value' | 'formatted_total_value' | 'formatted_fee_value' | 'created_at' | 'status'>
        & { coin: (
          { __typename?: 'Coin' }
          & Pick<Coin, 'symbol' | 'name'>
        ), brl_deposit?: Maybe<(
          { __typename?: 'BrlDeposit' }
          & Pick<BrlDeposit, 'file_url'>
        )>, brl_withdrawal?: Maybe<(
          { __typename?: 'BrlWithdrawal' }
          & Pick<BrlWithdrawal, 'file_url'>
        )> }
      )>> }
    ), pageInfo: (
      { __typename?: 'PageInfo' }
      & Pick<PageInfo, 'hasPrevPage' | 'hasNextPage'>
    ) }
  ) }
);

export type GetMyTicketsQueryVariables = Exact<{
  category_value?: Maybe<Scalars['String']>;
  status?: Maybe<Scalars['String']>;
  offset?: Maybe<Scalars['Float']>;
  limit?: Maybe<Scalars['Float']>;
}>;


export type GetMyTicketsQuery = (
  { __typename?: 'Query' }
  & { GetMyTickets: (
    { __typename?: 'PaginationType' }
    & Pick<PaginationType, 'totalCount'>
    & { pageInfo: (
      { __typename?: 'PageInfo' }
      & Pick<PageInfo, 'hasPrevPage' | 'hasNextPage'>
    ), edges: (
      { __typename?: 'Edges' }
      & { tickets?: Maybe<Array<(
        { __typename?: 'Ticket' }
        & Pick<Ticket, 'id' | 'file_url' | 'category' | 'status' | 'message' | 'admin_answear' | 'created_at' | 'updated_at' | 'subject'>
      )>> }
    ) }
  ) }
);

export type GetOscilationChartDataQueryVariables = Exact<{
  coin_symbol: Scalars['String'];
  value: Scalars['Float'];
  interval: Scalars['String'];
}>;


export type GetOscilationChartDataQuery = (
  { __typename?: 'Query' }
  & Pick<Query, 'GetOscilationChartData'>
);

export type GetTicketCategoriesQueryVariables = Exact<{ [key: string]: never; }>;


export type GetTicketCategoriesQuery = (
  { __typename?: 'Query' }
  & { GetTicketCategories: Array<(
    { __typename?: 'TicketCategory' }
    & Pick<TicketCategory, 'name' | 'value'>
  )> }
);

export type GetTwoFaDataQueryVariables = Exact<{ [key: string]: never; }>;


export type GetTwoFaDataQuery = (
  { __typename?: 'Query' }
  & { GetTwoFaData: (
    { __typename?: 'TwoFaData' }
    & Pick<TwoFaData, 'base32' | 'otpauth_url'>
  ) }
);

export type GetCustomerNotReprovedCafQueryVariables = Exact<{ [key: string]: never; }>;


export type GetCustomerNotReprovedCafQuery = (
  { __typename?: 'Query' }
  & { getCustomerNotReprovedCaf?: Maybe<(
    { __typename?: 'CafDocument' }
    & Pick<CafDocument, 'id' | 'status'>
  )> }
);


export const SendMyDocumentFileDocument = gql`
    mutation SendMyDocumentFile($document_id: String!, $file: Upload!) {
  SendMyDocumentFile(document_id: $document_id, file: $file)
}
    `;
export type SendMyDocumentFileMutationFn = Apollo.MutationFunction<SendMyDocumentFileMutation, SendMyDocumentFileMutationVariables>;

/**
 * __useSendMyDocumentFileMutation__
 *
 * To run a mutation, you first call `useSendMyDocumentFileMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useSendMyDocumentFileMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [sendMyDocumentFileMutation, { data, loading, error }] = useSendMyDocumentFileMutation({
 *   variables: {
 *      document_id: // value for 'document_id'
 *      file: // value for 'file'
 *   },
 * });
 */
export function useSendMyDocumentFileMutation(baseOptions?: Apollo.MutationHookOptions<SendMyDocumentFileMutation, SendMyDocumentFileMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<SendMyDocumentFileMutation, SendMyDocumentFileMutationVariables>(SendMyDocumentFileDocument, options);
      }
export type SendMyDocumentFileMutationHookResult = ReturnType<typeof useSendMyDocumentFileMutation>;
export type SendMyDocumentFileMutationResult = Apollo.MutationResult<SendMyDocumentFileMutation>;
export type SendMyDocumentFileMutationOptions = Apollo.BaseMutationOptions<SendMyDocumentFileMutation, SendMyDocumentFileMutationVariables>;
export const ConfirmEmailTokenDocument = gql`
    mutation ConfirmEmailToken($email: String!, $token: String!) {
  ConfirmEmailToken(email: $email, token: $token)
}
    `;
export type ConfirmEmailTokenMutationFn = Apollo.MutationFunction<ConfirmEmailTokenMutation, ConfirmEmailTokenMutationVariables>;

/**
 * __useConfirmEmailTokenMutation__
 *
 * To run a mutation, you first call `useConfirmEmailTokenMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useConfirmEmailTokenMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [confirmEmailTokenMutation, { data, loading, error }] = useConfirmEmailTokenMutation({
 *   variables: {
 *      email: // value for 'email'
 *      token: // value for 'token'
 *   },
 * });
 */
export function useConfirmEmailTokenMutation(baseOptions?: Apollo.MutationHookOptions<ConfirmEmailTokenMutation, ConfirmEmailTokenMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<ConfirmEmailTokenMutation, ConfirmEmailTokenMutationVariables>(ConfirmEmailTokenDocument, options);
      }
export type ConfirmEmailTokenMutationHookResult = ReturnType<typeof useConfirmEmailTokenMutation>;
export type ConfirmEmailTokenMutationResult = Apollo.MutationResult<ConfirmEmailTokenMutation>;
export type ConfirmEmailTokenMutationOptions = Apollo.BaseMutationOptions<ConfirmEmailTokenMutation, ConfirmEmailTokenMutationVariables>;
export const CreateBrlDepositDocument = gql`
    mutation CreateBrlDeposit($value_brl: String!, $file: Upload!) {
  CreateBrlDeposit(value_brl: $value_brl, file: $file)
}
    `;
export type CreateBrlDepositMutationFn = Apollo.MutationFunction<CreateBrlDepositMutation, CreateBrlDepositMutationVariables>;

/**
 * __useCreateBrlDepositMutation__
 *
 * To run a mutation, you first call `useCreateBrlDepositMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateBrlDepositMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createBrlDepositMutation, { data, loading, error }] = useCreateBrlDepositMutation({
 *   variables: {
 *      value_brl: // value for 'value_brl'
 *      file: // value for 'file'
 *   },
 * });
 */
export function useCreateBrlDepositMutation(baseOptions?: Apollo.MutationHookOptions<CreateBrlDepositMutation, CreateBrlDepositMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateBrlDepositMutation, CreateBrlDepositMutationVariables>(CreateBrlDepositDocument, options);
      }
export type CreateBrlDepositMutationHookResult = ReturnType<typeof useCreateBrlDepositMutation>;
export type CreateBrlDepositMutationResult = Apollo.MutationResult<CreateBrlDepositMutation>;
export type CreateBrlDepositMutationOptions = Apollo.BaseMutationOptions<CreateBrlDepositMutation, CreateBrlDepositMutationVariables>;
export const CreateBrlTransferDocument = gql`
    mutation CreateBrlTransfer($email_to: String!, $value_brl: String!, $two_fa: String!) {
  CreateBrlTransfer(email_to: $email_to, value_brl: $value_brl, two_fa: $two_fa)
}
    `;
export type CreateBrlTransferMutationFn = Apollo.MutationFunction<CreateBrlTransferMutation, CreateBrlTransferMutationVariables>;

/**
 * __useCreateBrlTransferMutation__
 *
 * To run a mutation, you first call `useCreateBrlTransferMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateBrlTransferMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createBrlTransferMutation, { data, loading, error }] = useCreateBrlTransferMutation({
 *   variables: {
 *      email_to: // value for 'email_to'
 *      value_brl: // value for 'value_brl'
 *      two_fa: // value for 'two_fa'
 *   },
 * });
 */
export function useCreateBrlTransferMutation(baseOptions?: Apollo.MutationHookOptions<CreateBrlTransferMutation, CreateBrlTransferMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateBrlTransferMutation, CreateBrlTransferMutationVariables>(CreateBrlTransferDocument, options);
      }
export type CreateBrlTransferMutationHookResult = ReturnType<typeof useCreateBrlTransferMutation>;
export type CreateBrlTransferMutationResult = Apollo.MutationResult<CreateBrlTransferMutation>;
export type CreateBrlTransferMutationOptions = Apollo.BaseMutationOptions<CreateBrlTransferMutation, CreateBrlTransferMutationVariables>;
export const CreateBrlWithdrawalDocument = gql`
    mutation CreateBrlWithdrawal($bank_account_id: String!, $value_brl: String!, $two_fa: String!) {
  CreateBrlWithdrawal(
    bank_account_id: $bank_account_id
    value_brl: $value_brl
    two_fa: $two_fa
  )
}
    `;
export type CreateBrlWithdrawalMutationFn = Apollo.MutationFunction<CreateBrlWithdrawalMutation, CreateBrlWithdrawalMutationVariables>;

/**
 * __useCreateBrlWithdrawalMutation__
 *
 * To run a mutation, you first call `useCreateBrlWithdrawalMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateBrlWithdrawalMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createBrlWithdrawalMutation, { data, loading, error }] = useCreateBrlWithdrawalMutation({
 *   variables: {
 *      bank_account_id: // value for 'bank_account_id'
 *      value_brl: // value for 'value_brl'
 *      two_fa: // value for 'two_fa'
 *   },
 * });
 */
export function useCreateBrlWithdrawalMutation(baseOptions?: Apollo.MutationHookOptions<CreateBrlWithdrawalMutation, CreateBrlWithdrawalMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateBrlWithdrawalMutation, CreateBrlWithdrawalMutationVariables>(CreateBrlWithdrawalDocument, options);
      }
export type CreateBrlWithdrawalMutationHookResult = ReturnType<typeof useCreateBrlWithdrawalMutation>;
export type CreateBrlWithdrawalMutationResult = Apollo.MutationResult<CreateBrlWithdrawalMutation>;
export type CreateBrlWithdrawalMutationOptions = Apollo.BaseMutationOptions<CreateBrlWithdrawalMutation, CreateBrlWithdrawalMutationVariables>;
export const CreateCryptoBuyDocument = gql`
    mutation CreateCryptoBuy($coin_symbol: String!, $value_brl: String!, $two_fa: String!) {
  CreateCryptoBuy(
    coin_symbol: $coin_symbol
    value_brl: $value_brl
    two_fa: $two_fa
  )
}
    `;
export type CreateCryptoBuyMutationFn = Apollo.MutationFunction<CreateCryptoBuyMutation, CreateCryptoBuyMutationVariables>;

/**
 * __useCreateCryptoBuyMutation__
 *
 * To run a mutation, you first call `useCreateCryptoBuyMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateCryptoBuyMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createCryptoBuyMutation, { data, loading, error }] = useCreateCryptoBuyMutation({
 *   variables: {
 *      coin_symbol: // value for 'coin_symbol'
 *      value_brl: // value for 'value_brl'
 *      two_fa: // value for 'two_fa'
 *   },
 * });
 */
export function useCreateCryptoBuyMutation(baseOptions?: Apollo.MutationHookOptions<CreateCryptoBuyMutation, CreateCryptoBuyMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateCryptoBuyMutation, CreateCryptoBuyMutationVariables>(CreateCryptoBuyDocument, options);
      }
export type CreateCryptoBuyMutationHookResult = ReturnType<typeof useCreateCryptoBuyMutation>;
export type CreateCryptoBuyMutationResult = Apollo.MutationResult<CreateCryptoBuyMutation>;
export type CreateCryptoBuyMutationOptions = Apollo.BaseMutationOptions<CreateCryptoBuyMutation, CreateCryptoBuyMutationVariables>;
export const CreateCryptoSellDocument = gql`
    mutation CreateCryptoSell($coin_symbol: String!, $coin_amount: String!, $two_fa: String!) {
  CreateCryptoSell(
    coin_symbol: $coin_symbol
    coin_amount: $coin_amount
    two_fa: $two_fa
  )
}
    `;
export type CreateCryptoSellMutationFn = Apollo.MutationFunction<CreateCryptoSellMutation, CreateCryptoSellMutationVariables>;

/**
 * __useCreateCryptoSellMutation__
 *
 * To run a mutation, you first call `useCreateCryptoSellMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateCryptoSellMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createCryptoSellMutation, { data, loading, error }] = useCreateCryptoSellMutation({
 *   variables: {
 *      coin_symbol: // value for 'coin_symbol'
 *      coin_amount: // value for 'coin_amount'
 *      two_fa: // value for 'two_fa'
 *   },
 * });
 */
export function useCreateCryptoSellMutation(baseOptions?: Apollo.MutationHookOptions<CreateCryptoSellMutation, CreateCryptoSellMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateCryptoSellMutation, CreateCryptoSellMutationVariables>(CreateCryptoSellDocument, options);
      }
export type CreateCryptoSellMutationHookResult = ReturnType<typeof useCreateCryptoSellMutation>;
export type CreateCryptoSellMutationResult = Apollo.MutationResult<CreateCryptoSellMutation>;
export type CreateCryptoSellMutationOptions = Apollo.BaseMutationOptions<CreateCryptoSellMutation, CreateCryptoSellMutationVariables>;
export const CreateCryptoWithdrawalDocument = gql`
    mutation CreateCryptoWithdrawal($coin_symbol: String!, $coin_amount: String!, $two_fa: String!, $address_to: String!, $dest_flag: String) {
  CreateCryptoWithdrawal(
    coin_symbol: $coin_symbol
    coin_amount: $coin_amount
    two_fa: $two_fa
    address_to: $address_to
    dest_flag: $dest_flag
  )
}
    `;
export type CreateCryptoWithdrawalMutationFn = Apollo.MutationFunction<CreateCryptoWithdrawalMutation, CreateCryptoWithdrawalMutationVariables>;

/**
 * __useCreateCryptoWithdrawalMutation__
 *
 * To run a mutation, you first call `useCreateCryptoWithdrawalMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateCryptoWithdrawalMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createCryptoWithdrawalMutation, { data, loading, error }] = useCreateCryptoWithdrawalMutation({
 *   variables: {
 *      coin_symbol: // value for 'coin_symbol'
 *      coin_amount: // value for 'coin_amount'
 *      two_fa: // value for 'two_fa'
 *      address_to: // value for 'address_to'
 *      dest_flag: // value for 'dest_flag'
 *   },
 * });
 */
export function useCreateCryptoWithdrawalMutation(baseOptions?: Apollo.MutationHookOptions<CreateCryptoWithdrawalMutation, CreateCryptoWithdrawalMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateCryptoWithdrawalMutation, CreateCryptoWithdrawalMutationVariables>(CreateCryptoWithdrawalDocument, options);
      }
export type CreateCryptoWithdrawalMutationHookResult = ReturnType<typeof useCreateCryptoWithdrawalMutation>;
export type CreateCryptoWithdrawalMutationResult = Apollo.MutationResult<CreateCryptoWithdrawalMutation>;
export type CreateCryptoWithdrawalMutationOptions = Apollo.BaseMutationOptions<CreateCryptoWithdrawalMutation, CreateCryptoWithdrawalMutationVariables>;
export const CreateCustomerPfDocument = gql`
    mutation CreateCustomerPF($complement: String!, $number: String!, $street: String!, $district: String!, $city: String!, $state: String!, $country: String!, $zipcode: String!, $document: String!, $nationality: String!, $password: String!, $birth_date: DateTime!, $full_name: String!, $email: String!) {
  CreateCustomerPF(
    complement: $complement
    number: $number
    street: $street
    district: $district
    city: $city
    state: $state
    country: $country
    zipcode: $zipcode
    document: $document
    nationality: $nationality
    password: $password
    birth_date: $birth_date
    full_name: $full_name
    email: $email
  ) {
    id
  }
}
    `;
export type CreateCustomerPfMutationFn = Apollo.MutationFunction<CreateCustomerPfMutation, CreateCustomerPfMutationVariables>;

/**
 * __useCreateCustomerPfMutation__
 *
 * To run a mutation, you first call `useCreateCustomerPfMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateCustomerPfMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createCustomerPfMutation, { data, loading, error }] = useCreateCustomerPfMutation({
 *   variables: {
 *      complement: // value for 'complement'
 *      number: // value for 'number'
 *      street: // value for 'street'
 *      district: // value for 'district'
 *      city: // value for 'city'
 *      state: // value for 'state'
 *      country: // value for 'country'
 *      zipcode: // value for 'zipcode'
 *      document: // value for 'document'
 *      nationality: // value for 'nationality'
 *      password: // value for 'password'
 *      birth_date: // value for 'birth_date'
 *      full_name: // value for 'full_name'
 *      email: // value for 'email'
 *   },
 * });
 */
export function useCreateCustomerPfMutation(baseOptions?: Apollo.MutationHookOptions<CreateCustomerPfMutation, CreateCustomerPfMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateCustomerPfMutation, CreateCustomerPfMutationVariables>(CreateCustomerPfDocument, options);
      }
export type CreateCustomerPfMutationHookResult = ReturnType<typeof useCreateCustomerPfMutation>;
export type CreateCustomerPfMutationResult = Apollo.MutationResult<CreateCustomerPfMutation>;
export type CreateCustomerPfMutationOptions = Apollo.BaseMutationOptions<CreateCustomerPfMutation, CreateCustomerPfMutationVariables>;
export const CreateCustomerPjDocument = gql`
    mutation CreateCustomerPJ($complement: String!, $number: String!, $street: String!, $district: String!, $city: String!, $state: String!, $country: String!, $zipcode: String!, $cnpj: String!, $fantasy_name: String!, $birth_date: DateTime!, $full_name: String!) {
  CreateCustomerPJ(
    complement: $complement
    number: $number
    street: $street
    district: $district
    city: $city
    state: $state
    country: $country
    zipcode: $zipcode
    cnpj: $cnpj
    fantasy_name: $fantasy_name
    birth_date: $birth_date
    full_name: $full_name
  ) {
    id
  }
}
    `;
export type CreateCustomerPjMutationFn = Apollo.MutationFunction<CreateCustomerPjMutation, CreateCustomerPjMutationVariables>;

/**
 * __useCreateCustomerPjMutation__
 *
 * To run a mutation, you first call `useCreateCustomerPjMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateCustomerPjMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createCustomerPjMutation, { data, loading, error }] = useCreateCustomerPjMutation({
 *   variables: {
 *      complement: // value for 'complement'
 *      number: // value for 'number'
 *      street: // value for 'street'
 *      district: // value for 'district'
 *      city: // value for 'city'
 *      state: // value for 'state'
 *      country: // value for 'country'
 *      zipcode: // value for 'zipcode'
 *      cnpj: // value for 'cnpj'
 *      fantasy_name: // value for 'fantasy_name'
 *      birth_date: // value for 'birth_date'
 *      full_name: // value for 'full_name'
 *   },
 * });
 */
export function useCreateCustomerPjMutation(baseOptions?: Apollo.MutationHookOptions<CreateCustomerPjMutation, CreateCustomerPjMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateCustomerPjMutation, CreateCustomerPjMutationVariables>(CreateCustomerPjDocument, options);
      }
export type CreateCustomerPjMutationHookResult = ReturnType<typeof useCreateCustomerPjMutation>;
export type CreateCustomerPjMutationResult = Apollo.MutationResult<CreateCustomerPjMutation>;
export type CreateCustomerPjMutationOptions = Apollo.BaseMutationOptions<CreateCustomerPjMutation, CreateCustomerPjMutationVariables>;
export const CreateCustomerSessionDocument = gql`
    mutation CreateCustomerSession($email: String!, $password: String!) {
  CreateCustomerSession(email: $email, password: $password) {
    token
    customer {
      id
      email
      full_name
      birth_date
      document {
        type
        nationality
        has_complience
        document_value
      }
      fantasy_name
      type
      avatar_url
      created_at
      updated_at
    }
  }
}
    `;
export type CreateCustomerSessionMutationFn = Apollo.MutationFunction<CreateCustomerSessionMutation, CreateCustomerSessionMutationVariables>;

/**
 * __useCreateCustomerSessionMutation__
 *
 * To run a mutation, you first call `useCreateCustomerSessionMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateCustomerSessionMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createCustomerSessionMutation, { data, loading, error }] = useCreateCustomerSessionMutation({
 *   variables: {
 *      email: // value for 'email'
 *      password: // value for 'password'
 *   },
 * });
 */
export function useCreateCustomerSessionMutation(baseOptions?: Apollo.MutationHookOptions<CreateCustomerSessionMutation, CreateCustomerSessionMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateCustomerSessionMutation, CreateCustomerSessionMutationVariables>(CreateCustomerSessionDocument, options);
      }
export type CreateCustomerSessionMutationHookResult = ReturnType<typeof useCreateCustomerSessionMutation>;
export type CreateCustomerSessionMutationResult = Apollo.MutationResult<CreateCustomerSessionMutation>;
export type CreateCustomerSessionMutationOptions = Apollo.BaseMutationOptions<CreateCustomerSessionMutation, CreateCustomerSessionMutationVariables>;
export const CreateMyBankAccountDocument = gql`
    mutation CreateMyBankAccount($bank_id: String!, $account: String!, $agency: String!, $pix: String) {
  CreateMyBankAccount(
    bank_id: $bank_id
    account: $account
    agency: $agency
    pix: $pix
  )
}
    `;
export type CreateMyBankAccountMutationFn = Apollo.MutationFunction<CreateMyBankAccountMutation, CreateMyBankAccountMutationVariables>;

/**
 * __useCreateMyBankAccountMutation__
 *
 * To run a mutation, you first call `useCreateMyBankAccountMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateMyBankAccountMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createMyBankAccountMutation, { data, loading, error }] = useCreateMyBankAccountMutation({
 *   variables: {
 *      bank_id: // value for 'bank_id'
 *      account: // value for 'account'
 *      agency: // value for 'agency'
 *      pix: // value for 'pix'
 *   },
 * });
 */
export function useCreateMyBankAccountMutation(baseOptions?: Apollo.MutationHookOptions<CreateMyBankAccountMutation, CreateMyBankAccountMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateMyBankAccountMutation, CreateMyBankAccountMutationVariables>(CreateMyBankAccountDocument, options);
      }
export type CreateMyBankAccountMutationHookResult = ReturnType<typeof useCreateMyBankAccountMutation>;
export type CreateMyBankAccountMutationResult = Apollo.MutationResult<CreateMyBankAccountMutation>;
export type CreateMyBankAccountMutationOptions = Apollo.BaseMutationOptions<CreateMyBankAccountMutation, CreateMyBankAccountMutationVariables>;
export const CreateMyOneTimeCodeDocument = gql`
    mutation CreateMyOneTimeCode {
  CreateMyOneTimeCode
}
    `;
export type CreateMyOneTimeCodeMutationFn = Apollo.MutationFunction<CreateMyOneTimeCodeMutation, CreateMyOneTimeCodeMutationVariables>;

/**
 * __useCreateMyOneTimeCodeMutation__
 *
 * To run a mutation, you first call `useCreateMyOneTimeCodeMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateMyOneTimeCodeMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createMyOneTimeCodeMutation, { data, loading, error }] = useCreateMyOneTimeCodeMutation({
 *   variables: {
 *   },
 * });
 */
export function useCreateMyOneTimeCodeMutation(baseOptions?: Apollo.MutationHookOptions<CreateMyOneTimeCodeMutation, CreateMyOneTimeCodeMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateMyOneTimeCodeMutation, CreateMyOneTimeCodeMutationVariables>(CreateMyOneTimeCodeDocument, options);
      }
export type CreateMyOneTimeCodeMutationHookResult = ReturnType<typeof useCreateMyOneTimeCodeMutation>;
export type CreateMyOneTimeCodeMutationResult = Apollo.MutationResult<CreateMyOneTimeCodeMutation>;
export type CreateMyOneTimeCodeMutationOptions = Apollo.BaseMutationOptions<CreateMyOneTimeCodeMutation, CreateMyOneTimeCodeMutationVariables>;
export const CreateMyTwoFaDocument = gql`
    mutation CreateMyTwoFa($secret: String!, $token: String!) {
  CreateMyTwoFa(secret: $secret, token: $token)
}
    `;
export type CreateMyTwoFaMutationFn = Apollo.MutationFunction<CreateMyTwoFaMutation, CreateMyTwoFaMutationVariables>;

/**
 * __useCreateMyTwoFaMutation__
 *
 * To run a mutation, you first call `useCreateMyTwoFaMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateMyTwoFaMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createMyTwoFaMutation, { data, loading, error }] = useCreateMyTwoFaMutation({
 *   variables: {
 *      secret: // value for 'secret'
 *      token: // value for 'token'
 *   },
 * });
 */
export function useCreateMyTwoFaMutation(baseOptions?: Apollo.MutationHookOptions<CreateMyTwoFaMutation, CreateMyTwoFaMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateMyTwoFaMutation, CreateMyTwoFaMutationVariables>(CreateMyTwoFaDocument, options);
      }
export type CreateMyTwoFaMutationHookResult = ReturnType<typeof useCreateMyTwoFaMutation>;
export type CreateMyTwoFaMutationResult = Apollo.MutationResult<CreateMyTwoFaMutation>;
export type CreateMyTwoFaMutationOptions = Apollo.BaseMutationOptions<CreateMyTwoFaMutation, CreateMyTwoFaMutationVariables>;
export const CreateNewCustomerPasswordDocument = gql`
    mutation CreateNewCustomerPassword($new_password: String!, $token: String!) {
  CreateNewCustomerPassword(new_password: $new_password, token: $token)
}
    `;
export type CreateNewCustomerPasswordMutationFn = Apollo.MutationFunction<CreateNewCustomerPasswordMutation, CreateNewCustomerPasswordMutationVariables>;

/**
 * __useCreateNewCustomerPasswordMutation__
 *
 * To run a mutation, you first call `useCreateNewCustomerPasswordMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateNewCustomerPasswordMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createNewCustomerPasswordMutation, { data, loading, error }] = useCreateNewCustomerPasswordMutation({
 *   variables: {
 *      new_password: // value for 'new_password'
 *      token: // value for 'token'
 *   },
 * });
 */
export function useCreateNewCustomerPasswordMutation(baseOptions?: Apollo.MutationHookOptions<CreateNewCustomerPasswordMutation, CreateNewCustomerPasswordMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateNewCustomerPasswordMutation, CreateNewCustomerPasswordMutationVariables>(CreateNewCustomerPasswordDocument, options);
      }
export type CreateNewCustomerPasswordMutationHookResult = ReturnType<typeof useCreateNewCustomerPasswordMutation>;
export type CreateNewCustomerPasswordMutationResult = Apollo.MutationResult<CreateNewCustomerPasswordMutation>;
export type CreateNewCustomerPasswordMutationOptions = Apollo.BaseMutationOptions<CreateNewCustomerPasswordMutation, CreateNewCustomerPasswordMutationVariables>;
export const CreateSwitchAccountDocument = gql`
    mutation CreateSwitchAccount($to_customer_id: String!) {
  CreateSwitchAccount(to_customer_id: $to_customer_id) {
    token
    customer {
      id
      email
      full_name
      birth_date
    }
  }
}
    `;
export type CreateSwitchAccountMutationFn = Apollo.MutationFunction<CreateSwitchAccountMutation, CreateSwitchAccountMutationVariables>;

/**
 * __useCreateSwitchAccountMutation__
 *
 * To run a mutation, you first call `useCreateSwitchAccountMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateSwitchAccountMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createSwitchAccountMutation, { data, loading, error }] = useCreateSwitchAccountMutation({
 *   variables: {
 *      to_customer_id: // value for 'to_customer_id'
 *   },
 * });
 */
export function useCreateSwitchAccountMutation(baseOptions?: Apollo.MutationHookOptions<CreateSwitchAccountMutation, CreateSwitchAccountMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateSwitchAccountMutation, CreateSwitchAccountMutationVariables>(CreateSwitchAccountDocument, options);
      }
export type CreateSwitchAccountMutationHookResult = ReturnType<typeof useCreateSwitchAccountMutation>;
export type CreateSwitchAccountMutationResult = Apollo.MutationResult<CreateSwitchAccountMutation>;
export type CreateSwitchAccountMutationOptions = Apollo.BaseMutationOptions<CreateSwitchAccountMutation, CreateSwitchAccountMutationVariables>;
export const CreateTicketDocument = gql`
    mutation CreateTicket($category_value: String!, $subject: String!, $message: String!, $file: Upload) {
  CreateTicket(
    category_value: $category_value
    subject: $subject
    message: $message
    file: $file
  )
}
    `;
export type CreateTicketMutationFn = Apollo.MutationFunction<CreateTicketMutation, CreateTicketMutationVariables>;

/**
 * __useCreateTicketMutation__
 *
 * To run a mutation, you first call `useCreateTicketMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateTicketMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createTicketMutation, { data, loading, error }] = useCreateTicketMutation({
 *   variables: {
 *      category_value: // value for 'category_value'
 *      subject: // value for 'subject'
 *      message: // value for 'message'
 *      file: // value for 'file'
 *   },
 * });
 */
export function useCreateTicketMutation(baseOptions?: Apollo.MutationHookOptions<CreateTicketMutation, CreateTicketMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateTicketMutation, CreateTicketMutationVariables>(CreateTicketDocument, options);
      }
export type CreateTicketMutationHookResult = ReturnType<typeof useCreateTicketMutation>;
export type CreateTicketMutationResult = Apollo.MutationResult<CreateTicketMutation>;
export type CreateTicketMutationOptions = Apollo.BaseMutationOptions<CreateTicketMutation, CreateTicketMutationVariables>;
export const SendEmailConfirmationTokenDocument = gql`
    mutation SendEmailConfirmationToken($email: String!) {
  SendEmailConfirmationToken(email: $email)
}
    `;
export type SendEmailConfirmationTokenMutationFn = Apollo.MutationFunction<SendEmailConfirmationTokenMutation, SendEmailConfirmationTokenMutationVariables>;

/**
 * __useSendEmailConfirmationTokenMutation__
 *
 * To run a mutation, you first call `useSendEmailConfirmationTokenMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useSendEmailConfirmationTokenMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [sendEmailConfirmationTokenMutation, { data, loading, error }] = useSendEmailConfirmationTokenMutation({
 *   variables: {
 *      email: // value for 'email'
 *   },
 * });
 */
export function useSendEmailConfirmationTokenMutation(baseOptions?: Apollo.MutationHookOptions<SendEmailConfirmationTokenMutation, SendEmailConfirmationTokenMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<SendEmailConfirmationTokenMutation, SendEmailConfirmationTokenMutationVariables>(SendEmailConfirmationTokenDocument, options);
      }
export type SendEmailConfirmationTokenMutationHookResult = ReturnType<typeof useSendEmailConfirmationTokenMutation>;
export type SendEmailConfirmationTokenMutationResult = Apollo.MutationResult<SendEmailConfirmationTokenMutation>;
export type SendEmailConfirmationTokenMutationOptions = Apollo.BaseMutationOptions<SendEmailConfirmationTokenMutation, SendEmailConfirmationTokenMutationVariables>;
export const SendForgotPasswordEmailDocument = gql`
    mutation SendForgotPasswordEmail($email: String!) {
  SendForgotPasswordEmail(email: $email)
}
    `;
export type SendForgotPasswordEmailMutationFn = Apollo.MutationFunction<SendForgotPasswordEmailMutation, SendForgotPasswordEmailMutationVariables>;

/**
 * __useSendForgotPasswordEmailMutation__
 *
 * To run a mutation, you first call `useSendForgotPasswordEmailMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useSendForgotPasswordEmailMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [sendForgotPasswordEmailMutation, { data, loading, error }] = useSendForgotPasswordEmailMutation({
 *   variables: {
 *      email: // value for 'email'
 *   },
 * });
 */
export function useSendForgotPasswordEmailMutation(baseOptions?: Apollo.MutationHookOptions<SendForgotPasswordEmailMutation, SendForgotPasswordEmailMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<SendForgotPasswordEmailMutation, SendForgotPasswordEmailMutationVariables>(SendForgotPasswordEmailDocument, options);
      }
export type SendForgotPasswordEmailMutationHookResult = ReturnType<typeof useSendForgotPasswordEmailMutation>;
export type SendForgotPasswordEmailMutationResult = Apollo.MutationResult<SendForgotPasswordEmailMutation>;
export type SendForgotPasswordEmailMutationOptions = Apollo.BaseMutationOptions<SendForgotPasswordEmailMutation, SendForgotPasswordEmailMutationVariables>;
export const UpdateMyPasswordDocument = gql`
    mutation UpdateMyPassword($new_password: String!, $current_password: String!) {
  UpdateMyPassword(
    new_password: $new_password
    current_password: $current_password
  )
}
    `;
export type UpdateMyPasswordMutationFn = Apollo.MutationFunction<UpdateMyPasswordMutation, UpdateMyPasswordMutationVariables>;

/**
 * __useUpdateMyPasswordMutation__
 *
 * To run a mutation, you first call `useUpdateMyPasswordMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateMyPasswordMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateMyPasswordMutation, { data, loading, error }] = useUpdateMyPasswordMutation({
 *   variables: {
 *      new_password: // value for 'new_password'
 *      current_password: // value for 'current_password'
 *   },
 * });
 */
export function useUpdateMyPasswordMutation(baseOptions?: Apollo.MutationHookOptions<UpdateMyPasswordMutation, UpdateMyPasswordMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UpdateMyPasswordMutation, UpdateMyPasswordMutationVariables>(UpdateMyPasswordDocument, options);
      }
export type UpdateMyPasswordMutationHookResult = ReturnType<typeof useUpdateMyPasswordMutation>;
export type UpdateMyPasswordMutationResult = Apollo.MutationResult<UpdateMyPasswordMutation>;
export type UpdateMyPasswordMutationOptions = Apollo.BaseMutationOptions<UpdateMyPasswordMutation, UpdateMyPasswordMutationVariables>;
export const CreateCfaDocumentDocument = gql`
    mutation createCfaDocument($front: Upload!, $back: Upload!, $selfie: Upload!, $type: String!, $cpf: String) {
  createCfaDocument(
    front: $front
    back: $back
    selfie: $selfie
    type: $type
    cpf: $cpf
  )
}
    `;
export type CreateCfaDocumentMutationFn = Apollo.MutationFunction<CreateCfaDocumentMutation, CreateCfaDocumentMutationVariables>;

/**
 * __useCreateCfaDocumentMutation__
 *
 * To run a mutation, you first call `useCreateCfaDocumentMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateCfaDocumentMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createCfaDocumentMutation, { data, loading, error }] = useCreateCfaDocumentMutation({
 *   variables: {
 *      front: // value for 'front'
 *      back: // value for 'back'
 *      selfie: // value for 'selfie'
 *      type: // value for 'type'
 *      cpf: // value for 'cpf'
 *   },
 * });
 */
export function useCreateCfaDocumentMutation(baseOptions?: Apollo.MutationHookOptions<CreateCfaDocumentMutation, CreateCfaDocumentMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateCfaDocumentMutation, CreateCfaDocumentMutationVariables>(CreateCfaDocumentDocument, options);
      }
export type CreateCfaDocumentMutationHookResult = ReturnType<typeof useCreateCfaDocumentMutation>;
export type CreateCfaDocumentMutationResult = Apollo.MutationResult<CreateCfaDocumentMutation>;
export type CreateCfaDocumentMutationOptions = Apollo.BaseMutationOptions<CreateCfaDocumentMutation, CreateCfaDocumentMutationVariables>;
export const CheckMyTwoFaExistsDocument = gql`
    query CheckMyTwoFaExists {
  CheckMyTwoFaExists
}
    `;

/**
 * __useCheckMyTwoFaExistsQuery__
 *
 * To run a query within a React component, call `useCheckMyTwoFaExistsQuery` and pass it any options that fit your needs.
 * When your component renders, `useCheckMyTwoFaExistsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useCheckMyTwoFaExistsQuery({
 *   variables: {
 *   },
 * });
 */
export function useCheckMyTwoFaExistsQuery(baseOptions?: Apollo.QueryHookOptions<CheckMyTwoFaExistsQuery, CheckMyTwoFaExistsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<CheckMyTwoFaExistsQuery, CheckMyTwoFaExistsQueryVariables>(CheckMyTwoFaExistsDocument, options);
      }
export function useCheckMyTwoFaExistsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<CheckMyTwoFaExistsQuery, CheckMyTwoFaExistsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<CheckMyTwoFaExistsQuery, CheckMyTwoFaExistsQueryVariables>(CheckMyTwoFaExistsDocument, options);
        }
export type CheckMyTwoFaExistsQueryHookResult = ReturnType<typeof useCheckMyTwoFaExistsQuery>;
export type CheckMyTwoFaExistsLazyQueryHookResult = ReturnType<typeof useCheckMyTwoFaExistsLazyQuery>;
export type CheckMyTwoFaExistsQueryResult = Apollo.QueryResult<CheckMyTwoFaExistsQuery, CheckMyTwoFaExistsQueryVariables>;
export const GetAllBanksDocument = gql`
    query GetAllBanks {
  GetAllBanks {
    id
    code
    name
  }
}
    `;

/**
 * __useGetAllBanksQuery__
 *
 * To run a query within a React component, call `useGetAllBanksQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetAllBanksQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetAllBanksQuery({
 *   variables: {
 *   },
 * });
 */
export function useGetAllBanksQuery(baseOptions?: Apollo.QueryHookOptions<GetAllBanksQuery, GetAllBanksQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetAllBanksQuery, GetAllBanksQueryVariables>(GetAllBanksDocument, options);
      }
export function useGetAllBanksLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetAllBanksQuery, GetAllBanksQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetAllBanksQuery, GetAllBanksQueryVariables>(GetAllBanksDocument, options);
        }
export type GetAllBanksQueryHookResult = ReturnType<typeof useGetAllBanksQuery>;
export type GetAllBanksLazyQueryHookResult = ReturnType<typeof useGetAllBanksLazyQuery>;
export type GetAllBanksQueryResult = Apollo.QueryResult<GetAllBanksQuery, GetAllBanksQueryVariables>;
export const GetAllCoinsOperationParamsDocument = gql`
    query GetAllCoinsOperationParams {
  GetAllCoinsOperationParams {
    id
    max_brl_value_formatted
    percentage_fee_value_formatted
    validity_period_days
    max_brl_value_formatted
    min_brl_value_formatted
    fixed_fee_brl_value_formatted
    name
    coin {
      name
      symbol
    }
  }
}
    `;

/**
 * __useGetAllCoinsOperationParamsQuery__
 *
 * To run a query within a React component, call `useGetAllCoinsOperationParamsQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetAllCoinsOperationParamsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetAllCoinsOperationParamsQuery({
 *   variables: {
 *   },
 * });
 */
export function useGetAllCoinsOperationParamsQuery(baseOptions?: Apollo.QueryHookOptions<GetAllCoinsOperationParamsQuery, GetAllCoinsOperationParamsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetAllCoinsOperationParamsQuery, GetAllCoinsOperationParamsQueryVariables>(GetAllCoinsOperationParamsDocument, options);
      }
export function useGetAllCoinsOperationParamsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetAllCoinsOperationParamsQuery, GetAllCoinsOperationParamsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetAllCoinsOperationParamsQuery, GetAllCoinsOperationParamsQueryVariables>(GetAllCoinsOperationParamsDocument, options);
        }
export type GetAllCoinsOperationParamsQueryHookResult = ReturnType<typeof useGetAllCoinsOperationParamsQuery>;
export type GetAllCoinsOperationParamsLazyQueryHookResult = ReturnType<typeof useGetAllCoinsOperationParamsLazyQuery>;
export type GetAllCoinsOperationParamsQueryResult = Apollo.QueryResult<GetAllCoinsOperationParamsQuery, GetAllCoinsOperationParamsQueryVariables>;
export const GetCoinOperationParamDocument = gql`
    query GetCoinOperationParam($operation: String!, $coin_symbol: String!) {
  GetCoinOperationParam(operation: $operation, coin_symbol: $coin_symbol) {
    id
    fixed_fee_brl_value
    percentage_fee_value
    network_fee
    min_brl_value
    max_brl_value
    validity_period_days
    has_complience
  }
}
    `;

/**
 * __useGetCoinOperationParamQuery__
 *
 * To run a query within a React component, call `useGetCoinOperationParamQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetCoinOperationParamQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetCoinOperationParamQuery({
 *   variables: {
 *      operation: // value for 'operation'
 *      coin_symbol: // value for 'coin_symbol'
 *   },
 * });
 */
export function useGetCoinOperationParamQuery(baseOptions: Apollo.QueryHookOptions<GetCoinOperationParamQuery, GetCoinOperationParamQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetCoinOperationParamQuery, GetCoinOperationParamQueryVariables>(GetCoinOperationParamDocument, options);
      }
export function useGetCoinOperationParamLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetCoinOperationParamQuery, GetCoinOperationParamQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetCoinOperationParamQuery, GetCoinOperationParamQueryVariables>(GetCoinOperationParamDocument, options);
        }
export type GetCoinOperationParamQueryHookResult = ReturnType<typeof useGetCoinOperationParamQuery>;
export type GetCoinOperationParamLazyQueryHookResult = ReturnType<typeof useGetCoinOperationParamLazyQuery>;
export type GetCoinOperationParamQueryResult = Apollo.QueryResult<GetCoinOperationParamQuery, GetCoinOperationParamQueryVariables>;
export const GetCoinsDocument = gql`
    query GetCoins {
  GetCoins {
    id
    name
    type
    symbol
    created_at
    updated_at
  }
}
    `;

/**
 * __useGetCoinsQuery__
 *
 * To run a query within a React component, call `useGetCoinsQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetCoinsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetCoinsQuery({
 *   variables: {
 *   },
 * });
 */
export function useGetCoinsQuery(baseOptions?: Apollo.QueryHookOptions<GetCoinsQuery, GetCoinsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetCoinsQuery, GetCoinsQueryVariables>(GetCoinsDocument, options);
      }
export function useGetCoinsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetCoinsQuery, GetCoinsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetCoinsQuery, GetCoinsQueryVariables>(GetCoinsDocument, options);
        }
export type GetCoinsQueryHookResult = ReturnType<typeof useGetCoinsQuery>;
export type GetCoinsLazyQueryHookResult = ReturnType<typeof useGetCoinsLazyQuery>;
export type GetCoinsQueryResult = Apollo.QueryResult<GetCoinsQuery, GetCoinsQueryVariables>;
export const GetDepositAccountDocument = gql`
    query GetDepositAccount {
  GetDepositAccount {
    bank {
      id
      code
      name
    }
    agency
    account
    pix
    owner
  }
}
    `;

/**
 * __useGetDepositAccountQuery__
 *
 * To run a query within a React component, call `useGetDepositAccountQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetDepositAccountQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetDepositAccountQuery({
 *   variables: {
 *   },
 * });
 */
export function useGetDepositAccountQuery(baseOptions?: Apollo.QueryHookOptions<GetDepositAccountQuery, GetDepositAccountQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetDepositAccountQuery, GetDepositAccountQueryVariables>(GetDepositAccountDocument, options);
      }
export function useGetDepositAccountLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetDepositAccountQuery, GetDepositAccountQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetDepositAccountQuery, GetDepositAccountQueryVariables>(GetDepositAccountDocument, options);
        }
export type GetDepositAccountQueryHookResult = ReturnType<typeof useGetDepositAccountQuery>;
export type GetDepositAccountLazyQueryHookResult = ReturnType<typeof useGetDepositAccountLazyQuery>;
export type GetDepositAccountQueryResult = Apollo.QueryResult<GetDepositAccountQuery, GetDepositAccountQueryVariables>;
export const GetMyAssociatedAccountsDocument = gql`
    query GetMyAssociatedAccounts {
  GetMyAssociatedAccounts {
    id
    email
    full_name
    birth_date
    fantasy_name
    type
    avatar_url
    created_at
    updated_at
  }
}
    `;

/**
 * __useGetMyAssociatedAccountsQuery__
 *
 * To run a query within a React component, call `useGetMyAssociatedAccountsQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetMyAssociatedAccountsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetMyAssociatedAccountsQuery({
 *   variables: {
 *   },
 * });
 */
export function useGetMyAssociatedAccountsQuery(baseOptions?: Apollo.QueryHookOptions<GetMyAssociatedAccountsQuery, GetMyAssociatedAccountsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetMyAssociatedAccountsQuery, GetMyAssociatedAccountsQueryVariables>(GetMyAssociatedAccountsDocument, options);
      }
export function useGetMyAssociatedAccountsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetMyAssociatedAccountsQuery, GetMyAssociatedAccountsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetMyAssociatedAccountsQuery, GetMyAssociatedAccountsQueryVariables>(GetMyAssociatedAccountsDocument, options);
        }
export type GetMyAssociatedAccountsQueryHookResult = ReturnType<typeof useGetMyAssociatedAccountsQuery>;
export type GetMyAssociatedAccountsLazyQueryHookResult = ReturnType<typeof useGetMyAssociatedAccountsLazyQuery>;
export type GetMyAssociatedAccountsQueryResult = Apollo.QueryResult<GetMyAssociatedAccountsQuery, GetMyAssociatedAccountsQueryVariables>;
export const GetMyBankAccountsDocument = gql`
    query GetMyBankAccounts {
  GetMyBankAccounts {
    id
    bank {
      id
      code
      name
    }
    account
    agency
    pix
  }
}
    `;

/**
 * __useGetMyBankAccountsQuery__
 *
 * To run a query within a React component, call `useGetMyBankAccountsQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetMyBankAccountsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetMyBankAccountsQuery({
 *   variables: {
 *   },
 * });
 */
export function useGetMyBankAccountsQuery(baseOptions?: Apollo.QueryHookOptions<GetMyBankAccountsQuery, GetMyBankAccountsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetMyBankAccountsQuery, GetMyBankAccountsQueryVariables>(GetMyBankAccountsDocument, options);
      }
export function useGetMyBankAccountsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetMyBankAccountsQuery, GetMyBankAccountsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetMyBankAccountsQuery, GetMyBankAccountsQueryVariables>(GetMyBankAccountsDocument, options);
        }
export type GetMyBankAccountsQueryHookResult = ReturnType<typeof useGetMyBankAccountsQuery>;
export type GetMyBankAccountsLazyQueryHookResult = ReturnType<typeof useGetMyBankAccountsLazyQuery>;
export type GetMyBankAccountsQueryResult = Apollo.QueryResult<GetMyBankAccountsQuery, GetMyBankAccountsQueryVariables>;
export const GetMyBrlDepositsDocument = gql`
    query GetMyBrlDeposits($status: String, $offset: Float, $limit: Float) {
  GetMyBrlDeposits(status: $status, offset: $offset, limit: $limit) {
    totalCount
    edges {
      brl_deposits {
        transaction {
          id
          coin {
            id
            name
            type
            symbol
          }
          status
          type
          description
          created_at
          updated_at
          formatted_net_value
          formatted_fee_value
          formatted_total_value
        }
        file_url
      }
    }
    pageInfo {
      hasPrevPage
      hasNextPage
    }
  }
}
    `;

/**
 * __useGetMyBrlDepositsQuery__
 *
 * To run a query within a React component, call `useGetMyBrlDepositsQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetMyBrlDepositsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetMyBrlDepositsQuery({
 *   variables: {
 *      status: // value for 'status'
 *      offset: // value for 'offset'
 *      limit: // value for 'limit'
 *   },
 * });
 */
export function useGetMyBrlDepositsQuery(baseOptions?: Apollo.QueryHookOptions<GetMyBrlDepositsQuery, GetMyBrlDepositsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetMyBrlDepositsQuery, GetMyBrlDepositsQueryVariables>(GetMyBrlDepositsDocument, options);
      }
export function useGetMyBrlDepositsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetMyBrlDepositsQuery, GetMyBrlDepositsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetMyBrlDepositsQuery, GetMyBrlDepositsQueryVariables>(GetMyBrlDepositsDocument, options);
        }
export type GetMyBrlDepositsQueryHookResult = ReturnType<typeof useGetMyBrlDepositsQuery>;
export type GetMyBrlDepositsLazyQueryHookResult = ReturnType<typeof useGetMyBrlDepositsLazyQuery>;
export type GetMyBrlDepositsQueryResult = Apollo.QueryResult<GetMyBrlDepositsQuery, GetMyBrlDepositsQueryVariables>;
export const GetMyBrlWithdrawalsDocument = gql`
    query GetMyBrlWithdrawals($status: String, $offset: Float, $limit: Float) {
  GetMyBrlWithdrawals(status: $status, offset: $offset, limit: $limit) {
    totalCount
    edges {
      brl_withdrawals {
        transaction {
          id
          coin {
            id
            name
            type
            symbol
          }
          status
          type
          description
          created_at
          updated_at
          formatted_net_value
          formatted_fee_value
          formatted_total_value
        }
        file_url
        admin_comment
        bank_account {
          id
          bank {
            id
            code
            name
          }
          account
          agency
          pix
        }
      }
    }
    pageInfo {
      hasPrevPage
      hasNextPage
    }
  }
}
    `;

/**
 * __useGetMyBrlWithdrawalsQuery__
 *
 * To run a query within a React component, call `useGetMyBrlWithdrawalsQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetMyBrlWithdrawalsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetMyBrlWithdrawalsQuery({
 *   variables: {
 *      status: // value for 'status'
 *      offset: // value for 'offset'
 *      limit: // value for 'limit'
 *   },
 * });
 */
export function useGetMyBrlWithdrawalsQuery(baseOptions?: Apollo.QueryHookOptions<GetMyBrlWithdrawalsQuery, GetMyBrlWithdrawalsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetMyBrlWithdrawalsQuery, GetMyBrlWithdrawalsQueryVariables>(GetMyBrlWithdrawalsDocument, options);
      }
export function useGetMyBrlWithdrawalsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetMyBrlWithdrawalsQuery, GetMyBrlWithdrawalsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetMyBrlWithdrawalsQuery, GetMyBrlWithdrawalsQueryVariables>(GetMyBrlWithdrawalsDocument, options);
        }
export type GetMyBrlWithdrawalsQueryHookResult = ReturnType<typeof useGetMyBrlWithdrawalsQuery>;
export type GetMyBrlWithdrawalsLazyQueryHookResult = ReturnType<typeof useGetMyBrlWithdrawalsLazyQuery>;
export type GetMyBrlWithdrawalsQueryResult = Apollo.QueryResult<GetMyBrlWithdrawalsQuery, GetMyBrlWithdrawalsQueryVariables>;
export const GetMyCoinWalletBySymbolDocument = gql`
    query GetMyCoinWalletBySymbol($symbol: String!) {
  GetMyCoinWalletBySymbol(symbol: $symbol) {
    customer_id
    coin_id
    coin {
      id
      name
      type
      symbol
      created_at
      updated_at
    }
    address
    formatted_balance
    balance
    created_at
    updated_at
  }
}
    `;

/**
 * __useGetMyCoinWalletBySymbolQuery__
 *
 * To run a query within a React component, call `useGetMyCoinWalletBySymbolQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetMyCoinWalletBySymbolQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetMyCoinWalletBySymbolQuery({
 *   variables: {
 *      symbol: // value for 'symbol'
 *   },
 * });
 */
export function useGetMyCoinWalletBySymbolQuery(baseOptions: Apollo.QueryHookOptions<GetMyCoinWalletBySymbolQuery, GetMyCoinWalletBySymbolQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetMyCoinWalletBySymbolQuery, GetMyCoinWalletBySymbolQueryVariables>(GetMyCoinWalletBySymbolDocument, options);
      }
export function useGetMyCoinWalletBySymbolLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetMyCoinWalletBySymbolQuery, GetMyCoinWalletBySymbolQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetMyCoinWalletBySymbolQuery, GetMyCoinWalletBySymbolQueryVariables>(GetMyCoinWalletBySymbolDocument, options);
        }
export type GetMyCoinWalletBySymbolQueryHookResult = ReturnType<typeof useGetMyCoinWalletBySymbolQuery>;
export type GetMyCoinWalletBySymbolLazyQueryHookResult = ReturnType<typeof useGetMyCoinWalletBySymbolLazyQuery>;
export type GetMyCoinWalletBySymbolQueryResult = Apollo.QueryResult<GetMyCoinWalletBySymbolQuery, GetMyCoinWalletBySymbolQueryVariables>;
export const GetMyCoinWalletsDocument = gql`
    query GetMyCoinWallets {
  GetMyCoinWallets {
    customer_id
    coin_id
    coin {
      id
      name
      type
      symbol
    }
    address
    formatted_balance
    formatted_brl_balance
    brl_price
    brl_balance
    balance
    created_at
    updated_at
    network
    memo
  }
}
    `;

/**
 * __useGetMyCoinWalletsQuery__
 *
 * To run a query within a React component, call `useGetMyCoinWalletsQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetMyCoinWalletsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetMyCoinWalletsQuery({
 *   variables: {
 *   },
 * });
 */
export function useGetMyCoinWalletsQuery(baseOptions?: Apollo.QueryHookOptions<GetMyCoinWalletsQuery, GetMyCoinWalletsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetMyCoinWalletsQuery, GetMyCoinWalletsQueryVariables>(GetMyCoinWalletsDocument, options);
      }
export function useGetMyCoinWalletsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetMyCoinWalletsQuery, GetMyCoinWalletsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetMyCoinWalletsQuery, GetMyCoinWalletsQueryVariables>(GetMyCoinWalletsDocument, options);
        }
export type GetMyCoinWalletsQueryHookResult = ReturnType<typeof useGetMyCoinWalletsQuery>;
export type GetMyCoinWalletsLazyQueryHookResult = ReturnType<typeof useGetMyCoinWalletsLazyQuery>;
export type GetMyCoinWalletsQueryResult = Apollo.QueryResult<GetMyCoinWalletsQuery, GetMyCoinWalletsQueryVariables>;
export const GetMyDocumentsDocument = gql`
    query GetMyDocuments {
  GetMyDocuments {
    id
    name
    document {
      type
      nationality
      has_complience
      document_value
    }
    status
    admin_answear
    type
    description
    file_url
    created_at
    updated_at
  }
}
    `;

/**
 * __useGetMyDocumentsQuery__
 *
 * To run a query within a React component, call `useGetMyDocumentsQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetMyDocumentsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetMyDocumentsQuery({
 *   variables: {
 *   },
 * });
 */
export function useGetMyDocumentsQuery(baseOptions?: Apollo.QueryHookOptions<GetMyDocumentsQuery, GetMyDocumentsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetMyDocumentsQuery, GetMyDocumentsQueryVariables>(GetMyDocumentsDocument, options);
      }
export function useGetMyDocumentsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetMyDocumentsQuery, GetMyDocumentsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetMyDocumentsQuery, GetMyDocumentsQueryVariables>(GetMyDocumentsDocument, options);
        }
export type GetMyDocumentsQueryHookResult = ReturnType<typeof useGetMyDocumentsQuery>;
export type GetMyDocumentsLazyQueryHookResult = ReturnType<typeof useGetMyDocumentsLazyQuery>;
export type GetMyDocumentsQueryResult = Apollo.QueryResult<GetMyDocumentsQuery, GetMyDocumentsQueryVariables>;
export const GetMyProfileDocument = gql`
    query GetMyProfile {
  GetMyProfile {
    id
    email
    full_name
    birth_date
    document {
      type
      nationality
      has_complience
      document_value
      created_at
      updated_at
    }
    address {
      zip_code
      country
      state
      city
      district
      street
      number
      complement
      created_at
      updated_at
    }
    fantasy_name
    type
    avatar_url
    created_at
    updated_at
  }
}
    `;

/**
 * __useGetMyProfileQuery__
 *
 * To run a query within a React component, call `useGetMyProfileQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetMyProfileQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetMyProfileQuery({
 *   variables: {
 *   },
 * });
 */
export function useGetMyProfileQuery(baseOptions?: Apollo.QueryHookOptions<GetMyProfileQuery, GetMyProfileQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetMyProfileQuery, GetMyProfileQueryVariables>(GetMyProfileDocument, options);
      }
export function useGetMyProfileLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetMyProfileQuery, GetMyProfileQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetMyProfileQuery, GetMyProfileQueryVariables>(GetMyProfileDocument, options);
        }
export type GetMyProfileQueryHookResult = ReturnType<typeof useGetMyProfileQuery>;
export type GetMyProfileLazyQueryHookResult = ReturnType<typeof useGetMyProfileLazyQuery>;
export type GetMyProfileQueryResult = Apollo.QueryResult<GetMyProfileQuery, GetMyProfileQueryVariables>;
export const GetMyStatmentDocument = gql`
    query GetMyStatment($status: String, $coin_symbol: String, $operation: String, $offset: Float, $limit: Float, $final_date: DateTime, $start_date: DateTime) {
  GetMyStatment(
    operation: $operation
    status: $status
    offset: $offset
    coin_symbol: $coin_symbol
    final_date: $final_date
    start_date: $start_date
    limit: $limit
  ) {
    totalCount
    edges {
      transactions {
        id
        type
        description
        formatted_net_value
        formatted_total_value
        formatted_fee_value
        created_at
        status
        coin {
          symbol
          name
        }
        brl_deposit {
          file_url
        }
        brl_withdrawal {
          file_url
        }
      }
    }
    pageInfo {
      hasPrevPage
      hasNextPage
    }
  }
}
    `;

/**
 * __useGetMyStatmentQuery__
 *
 * To run a query within a React component, call `useGetMyStatmentQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetMyStatmentQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetMyStatmentQuery({
 *   variables: {
 *      status: // value for 'status'
 *      coin_symbol: // value for 'coin_symbol'
 *      operation: // value for 'operation'
 *      offset: // value for 'offset'
 *      limit: // value for 'limit'
 *      final_date: // value for 'final_date'
 *      start_date: // value for 'start_date'
 *   },
 * });
 */
export function useGetMyStatmentQuery(baseOptions?: Apollo.QueryHookOptions<GetMyStatmentQuery, GetMyStatmentQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetMyStatmentQuery, GetMyStatmentQueryVariables>(GetMyStatmentDocument, options);
      }
export function useGetMyStatmentLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetMyStatmentQuery, GetMyStatmentQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetMyStatmentQuery, GetMyStatmentQueryVariables>(GetMyStatmentDocument, options);
        }
export type GetMyStatmentQueryHookResult = ReturnType<typeof useGetMyStatmentQuery>;
export type GetMyStatmentLazyQueryHookResult = ReturnType<typeof useGetMyStatmentLazyQuery>;
export type GetMyStatmentQueryResult = Apollo.QueryResult<GetMyStatmentQuery, GetMyStatmentQueryVariables>;
export const GetMyTicketsDocument = gql`
    query GetMyTickets($category_value: String, $status: String, $offset: Float, $limit: Float) {
  GetMyTickets(
    category_value: $category_value
    status: $status
    offset: $offset
    limit: $limit
  ) {
    totalCount
    pageInfo {
      hasPrevPage
      hasNextPage
    }
    edges {
      tickets {
        id
        file_url
        category
        status
        message
        admin_answear
        created_at
        updated_at
        subject
      }
    }
  }
}
    `;

/**
 * __useGetMyTicketsQuery__
 *
 * To run a query within a React component, call `useGetMyTicketsQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetMyTicketsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetMyTicketsQuery({
 *   variables: {
 *      category_value: // value for 'category_value'
 *      status: // value for 'status'
 *      offset: // value for 'offset'
 *      limit: // value for 'limit'
 *   },
 * });
 */
export function useGetMyTicketsQuery(baseOptions?: Apollo.QueryHookOptions<GetMyTicketsQuery, GetMyTicketsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetMyTicketsQuery, GetMyTicketsQueryVariables>(GetMyTicketsDocument, options);
      }
export function useGetMyTicketsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetMyTicketsQuery, GetMyTicketsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetMyTicketsQuery, GetMyTicketsQueryVariables>(GetMyTicketsDocument, options);
        }
export type GetMyTicketsQueryHookResult = ReturnType<typeof useGetMyTicketsQuery>;
export type GetMyTicketsLazyQueryHookResult = ReturnType<typeof useGetMyTicketsLazyQuery>;
export type GetMyTicketsQueryResult = Apollo.QueryResult<GetMyTicketsQuery, GetMyTicketsQueryVariables>;
export const GetOscilationChartDataDocument = gql`
    query GetOscilationChartData($coin_symbol: String!, $value: Float!, $interval: String!) {
  GetOscilationChartData(
    coin_symbol: $coin_symbol
    value: $value
    interval: $interval
  )
}
    `;

/**
 * __useGetOscilationChartDataQuery__
 *
 * To run a query within a React component, call `useGetOscilationChartDataQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetOscilationChartDataQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetOscilationChartDataQuery({
 *   variables: {
 *      coin_symbol: // value for 'coin_symbol'
 *      value: // value for 'value'
 *      interval: // value for 'interval'
 *   },
 * });
 */
export function useGetOscilationChartDataQuery(baseOptions: Apollo.QueryHookOptions<GetOscilationChartDataQuery, GetOscilationChartDataQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetOscilationChartDataQuery, GetOscilationChartDataQueryVariables>(GetOscilationChartDataDocument, options);
      }
export function useGetOscilationChartDataLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetOscilationChartDataQuery, GetOscilationChartDataQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetOscilationChartDataQuery, GetOscilationChartDataQueryVariables>(GetOscilationChartDataDocument, options);
        }
export type GetOscilationChartDataQueryHookResult = ReturnType<typeof useGetOscilationChartDataQuery>;
export type GetOscilationChartDataLazyQueryHookResult = ReturnType<typeof useGetOscilationChartDataLazyQuery>;
export type GetOscilationChartDataQueryResult = Apollo.QueryResult<GetOscilationChartDataQuery, GetOscilationChartDataQueryVariables>;
export const GetTicketCategoriesDocument = gql`
    query GetTicketCategories {
  GetTicketCategories {
    name
    value
  }
}
    `;

/**
 * __useGetTicketCategoriesQuery__
 *
 * To run a query within a React component, call `useGetTicketCategoriesQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetTicketCategoriesQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetTicketCategoriesQuery({
 *   variables: {
 *   },
 * });
 */
export function useGetTicketCategoriesQuery(baseOptions?: Apollo.QueryHookOptions<GetTicketCategoriesQuery, GetTicketCategoriesQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetTicketCategoriesQuery, GetTicketCategoriesQueryVariables>(GetTicketCategoriesDocument, options);
      }
export function useGetTicketCategoriesLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetTicketCategoriesQuery, GetTicketCategoriesQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetTicketCategoriesQuery, GetTicketCategoriesQueryVariables>(GetTicketCategoriesDocument, options);
        }
export type GetTicketCategoriesQueryHookResult = ReturnType<typeof useGetTicketCategoriesQuery>;
export type GetTicketCategoriesLazyQueryHookResult = ReturnType<typeof useGetTicketCategoriesLazyQuery>;
export type GetTicketCategoriesQueryResult = Apollo.QueryResult<GetTicketCategoriesQuery, GetTicketCategoriesQueryVariables>;
export const GetTwoFaDataDocument = gql`
    query GetTwoFaData {
  GetTwoFaData {
    base32
    otpauth_url
  }
}
    `;

/**
 * __useGetTwoFaDataQuery__
 *
 * To run a query within a React component, call `useGetTwoFaDataQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetTwoFaDataQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetTwoFaDataQuery({
 *   variables: {
 *   },
 * });
 */
export function useGetTwoFaDataQuery(baseOptions?: Apollo.QueryHookOptions<GetTwoFaDataQuery, GetTwoFaDataQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetTwoFaDataQuery, GetTwoFaDataQueryVariables>(GetTwoFaDataDocument, options);
      }
export function useGetTwoFaDataLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetTwoFaDataQuery, GetTwoFaDataQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetTwoFaDataQuery, GetTwoFaDataQueryVariables>(GetTwoFaDataDocument, options);
        }
export type GetTwoFaDataQueryHookResult = ReturnType<typeof useGetTwoFaDataQuery>;
export type GetTwoFaDataLazyQueryHookResult = ReturnType<typeof useGetTwoFaDataLazyQuery>;
export type GetTwoFaDataQueryResult = Apollo.QueryResult<GetTwoFaDataQuery, GetTwoFaDataQueryVariables>;
export const GetCustomerNotReprovedCafDocument = gql`
    query getCustomerNotReprovedCaf {
  getCustomerNotReprovedCaf {
    id
    status
  }
}
    `;

/**
 * __useGetCustomerNotReprovedCafQuery__
 *
 * To run a query within a React component, call `useGetCustomerNotReprovedCafQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetCustomerNotReprovedCafQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetCustomerNotReprovedCafQuery({
 *   variables: {
 *   },
 * });
 */
export function useGetCustomerNotReprovedCafQuery(baseOptions?: Apollo.QueryHookOptions<GetCustomerNotReprovedCafQuery, GetCustomerNotReprovedCafQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetCustomerNotReprovedCafQuery, GetCustomerNotReprovedCafQueryVariables>(GetCustomerNotReprovedCafDocument, options);
      }
export function useGetCustomerNotReprovedCafLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetCustomerNotReprovedCafQuery, GetCustomerNotReprovedCafQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetCustomerNotReprovedCafQuery, GetCustomerNotReprovedCafQueryVariables>(GetCustomerNotReprovedCafDocument, options);
        }
export type GetCustomerNotReprovedCafQueryHookResult = ReturnType<typeof useGetCustomerNotReprovedCafQuery>;
export type GetCustomerNotReprovedCafLazyQueryHookResult = ReturnType<typeof useGetCustomerNotReprovedCafLazyQuery>;
export type GetCustomerNotReprovedCafQueryResult = Apollo.QueryResult<GetCustomerNotReprovedCafQuery, GetCustomerNotReprovedCafQueryVariables>;