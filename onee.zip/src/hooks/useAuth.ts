import { useContext } from 'react';

import { AuthContextData, AuthContext } from '~/context/auth';

function useAuth(): AuthContextData {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error('useAuth must be used within as AuthProvider');
  }

  return context;
}

export default useAuth;
