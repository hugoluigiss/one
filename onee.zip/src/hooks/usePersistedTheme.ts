import { useState, useEffect, Dispatch, SetStateAction } from 'react';

type Response = [string, Dispatch<SetStateAction<string>>];

function usePersistedTheme(defaultTheme: string): Response {
  const [theme, setTheme] = useState(() => {
    const storageValue = localStorage.getItem('@Ragnarok:theme');

    if (storageValue) {
      return storageValue;
    }

    return defaultTheme;
  });

  useEffect(() => {
    localStorage.setItem('@Ragnarok:theme', theme);
  }, [theme]);

  return [theme, setTheme];
}

export default usePersistedTheme;
