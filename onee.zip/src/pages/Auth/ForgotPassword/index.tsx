import React from 'react';

import Layout from './layout';

const ForgotPassword: React.FC = () => {
  return <Layout />;
};

export default ForgotPassword;
