import React from 'react';
import * as Yup from 'yup';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';
import ButtonPrimary from '../../../../components/ButtonPrimary';
import InputPrimary from '../../../../components/InputPrimary';
import LogoHorizontal from '../../../../components/LogoHorizontal';
import style from './login.module.scss';
// import useToast from '~/hooks/useToast';
import getValidationErrors from '~/utils/getValidationErrors';
import { useSendForgotPasswordEmailMutation } from '~/graphql/generated/graphql';

const Layout: React.FC = () => {
  // const { addToast } = useToast();
  const { t } = useTranslation();

  const [doSendForgotPassword] = useSendForgotPasswordEmailMutation();

  const [email, setEmail] = React.useState('');

  const handleSubmit = React.useCallback(async () => {
    try {
      const schema = Yup.object().shape({
        email: Yup.string()
          .email(t('E-mail deve ser um e-mail válido'))
          .required(t('O E-mail é obrigatório')),
      });

      await schema.validate({ email }, { abortEarly: false });

      doSendForgotPassword({
        variables: {
          email,
        },
      })
        .then(() => {
          // addToast({
          //   type: 'success',
          //   title: t('E-mail de recuperação enviado'),
          //   description: t(
          //     'Enviamos um e-mail para confirmar a recuperação de senha, cheque sua caixa de entrada.',
          //   ),
          // });
          toast.success(
            'Enviamos um e-mail para confirmar a recuperação de senha, cheque sua caixa de entrada.',
          );
          setEmail('');
        })
        .catch(err => {
          // addToast({
          //   type: 'error',
          //   title: t('Oooops, Ocorreu um erro!'),
          //   description: err.message,
          // });
          toast.error(err.message);
        });
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: key, description: errors[key] }),
          toast.error(errors[key]),
        );
        return;
      }

      const message =
        err?.response && err.response.status !== 500
          ? err.response.data.message
          : t(
              'Desculpe, mas ocorreu algum erro ao se conectar com o servidor.',
            );

      // addToast({
      //   type: 'error',
      //   title: t('Oooops, Ocorreu um erro!'),
      //   description: message,
      // });
      toast.error(message);
    }
  }, [doSendForgotPassword, email, t]);

  return (
    <div className={style.container}>
      <div className={style.boxContainer}>
        <div className={style.actionBox}>
          <LogoHorizontal />

          <h3>
            Digite o E-MAIL da sua conta da exchange e enviaremos um link de
            reinicialização.
          </h3>

          <div className={style.formBox}>
            <InputPrimary
              standard
              value={email}
              onChangeText={setEmail}
              placeholder="Digite seu e-mail"
              labelValue="E-mail"
            />
            {/* <InputPrimary
              isPasswordType
              value={password}
              onChangeText={setPassword}
              placeholder="Senha"
              labelValue="Senha"
            /> */}
            <a href="/">Voltar para o Login</a>
            <ButtonPrimary onPress={() => handleSubmit()} transparency={false}>
              Recuperar
            </ButtonPrimary>
            {/* <ButtonPrimary onPress={goToSignIn} transparency>
              Criar conta
            </ButtonPrimary> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Layout;
