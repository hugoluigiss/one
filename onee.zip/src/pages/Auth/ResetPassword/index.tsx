import React from 'react';

import Layout from './layout';

const ResetPassword: React.FC = () => {
  return <Layout />;
};

export default ResetPassword;
