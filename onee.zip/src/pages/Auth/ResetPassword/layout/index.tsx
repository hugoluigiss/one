import React from 'react';
import * as Yup from 'yup';
import { useTranslation } from 'react-i18next';
import { useHistory, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import ButtonPrimary from '../../../../components/ButtonPrimary';
import InputPrimary from '../../../../components/InputPrimary';
import LogoHorizontal from '../../../../components/LogoHorizontal';
import style from './login.module.scss';
// import useToast from '~/hooks/useToast';
import getValidationErrors from '~/utils/getValidationErrors';
import { useCreateNewCustomerPasswordMutation } from '~/graphql/generated/graphql';

interface IParams {
  recovery_token: string;
}

const Layout: React.FC = () => {
  // const { addToast } = useToast();
  const { t } = useTranslation();
  const { recovery_token } = useParams() as IParams;
  const history = useHistory();

  const [doCreateNewPassword] = useCreateNewCustomerPasswordMutation();

  const [password, setNewPassword] = React.useState('');
  const [confirmPassword, setNewPasswordConfirmation] = React.useState('');
  const handleSubmit = React.useCallback(async () => {
    try {
      const schema = Yup.object().shape({
        token: Yup.string()
          .length(36, t('O código de recuperação deve conter 36 caracteres'))
          .required(t('O código de recuperação é obrigatório')),
        password: Yup.string()
          .required(t('Senha obrigatória'))
          .min(8, 'Senha deve ter no mínimo 8 caracteres'),
        confirmPassword: Yup.string().when(
          'password',
          (p: string, field: any) =>
            p
              ? field
                  .required(t('A confirmação de senha é obrigatória'))
                  .oneOf(
                    [Yup.ref('password')],
                    t('A senha e a confirmação deve ser idênticas'),
                  )
              : field,
        ),
      });

      await schema.validate(
        { token: recovery_token, password, confirmPassword },
        { abortEarly: false },
      );

      doCreateNewPassword({
        variables: {
          token: recovery_token,
          new_password: password,
        },
      })
        .then(() => {
          history.push('/');

          // addToast({
          //   type: 'success',
          //   title: t('Recuperação de senha'),
          //   description: t('Sua senha foi resetada com sucesso.'),
          // });
          toast.success('Sua senha foi resetada com sucesso.');
        })
        .catch(err => {
          // addToast({
          //   type: 'error',
          //   title: t('Oooops, Ocorreu um erro!'),
          //   description: err.message,
          // });
          toast.error(err.message);
        });
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: key, description: errors[key] }),
          toast.error(errors[key]),
        );
        return;
      }

      const message =
        err?.response && err.response.status !== 500
          ? err.response.data.message
          : t(
              'Desculpe, mas ocorreu algum erro ao se conectar com o servidor.',
            );

      // addToast({
      //   type: 'error',
      //   title: t('Oooops, Ocorreu um erro!'),
      //   description: message,
      // });
      toast.error(message);
    }
  }, [
    confirmPassword,
    doCreateNewPassword,
    history,
    password,
    recovery_token,
    t,
  ]);
  return (
    <div className={style.container}>
      <div className={style.boxContainer}>
        <div className={style.actionBox}>
          <LogoHorizontal />

          <h3>Escolha sua nova senha</h3>

          <div className={style.formBox}>
            {/* <InputPrimary
              standard
              value={email}
              onChangeText={setEmail}
              placeholder="Digite seu e-mail"
              labelValue="E-mail"
            /> */}
            <InputPrimary
              isPasswordType
              value={password}
              onChangeText={setNewPassword}
              placeholder="Nova Senha"
              labelValue="Nova Senha"
            />

            <InputPrimary
              isPasswordType
              value={confirmPassword}
              onChangeText={setNewPasswordConfirmation}
              placeholder="Confirme Nova Senha"
              labelValue="Confirmação de Nova Senha"
            />
            <a href="/">Voltar para o Login</a>
            <ButtonPrimary onPress={() => handleSubmit()} transparency={false}>
              Recuperar
            </ButtonPrimary>
            {/* <ButtonPrimary onPress={goToSignUp} transparency>
              Criar conta
            </ButtonPrimary> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Layout;
