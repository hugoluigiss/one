import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
// import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import Layout from './layout';
import useAuth from '~/hooks/useAuth';
// import useToast from '~/hooks/useToast';

import getValidationErrors from '~/utils/getValidationErrors';

const Login: React.FC = () => {
  const { signIn } = useAuth();
  const history = useHistory();

  // const { addToast } = useToast();

  const [email, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = React.useCallback(async () => {
    try {
      const schema = Yup.object().shape({
        email: Yup.string()
          .email('E-mail deve ser um e-mail válido')
          .required('O E-mail é obrigatório'),
        password: Yup.string().required('A senha é obrigatória'),
      });
      await schema.validate({ email, password }, { abortEarly: false });
      await signIn({ email, password });
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: key, description: errors[key] }),
          toast.error(errors[key]),
        );
      }
    }
  }, [email, password, signIn]);

  const goToSignUp = (): void => {
    history.push('/signup');
  };

  return (
    <Layout
      user={email}
      setUser={setUsername}
      setPassword={setPassword}
      password={password}
      goToSignUp={goToSignUp}
      handleSubmit={handleSubmit}
    />
  );
};

export default Login;
