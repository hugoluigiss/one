import React from 'react';
import ButtonPrimary from '../../../../components/ButtonPrimary';
import InputPrimary from '../../../../components/InputPrimary';
import LogoHorizontal from '../../../../components/LogoHorizontal';
import style from './login.module.scss';

type LayoutPropsSignUp = {
  goToSignUp(): void;
  user: string;
  password: string;
  setUser: (user: string) => void;
  setPassword: (pass: string) => void;
  handleSubmit: () => void;
};

const Layout: React.FC<LayoutPropsSignUp> = ({
  goToSignUp,
  user,
  password,
  setUser,
  setPassword,
  handleSubmit,
}: LayoutPropsSignUp) => {
  return (
    <div className={style.container}>
      <div className={style.boxContainer}>
        <div className={style.actionBox}>
          <LogoHorizontal />

          <div className={style.formBox}>
            <InputPrimary
              standard
              value={user}
              onChangeText={setUser}
              placeholder="Digite seu e-mail"
              labelValue="Usuário"
            />
            <InputPrimary
              isPasswordType
              value={password}
              onChangeText={setPassword}
              placeholder="Senha"
              labelValue="Senha"
            />
            <a href="/forgot-password">Esqueci minha senha</a>
            <ButtonPrimary onPress={() => handleSubmit()} transparency={false}>
              Continuar
            </ButtonPrimary>
            <ButtonPrimary onPress={goToSignUp} transparency>
              Criar conta
            </ButtonPrimary>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Layout;
