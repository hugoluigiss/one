import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { subYears } from 'date-fns';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import Layout from './layout';

// import useToast from '~/hooks/useToast';
import getValidationErrors from '~/utils/getValidationErrors';
import {
  useSendEmailConfirmationTokenMutation,
  useConfirmEmailTokenMutation,
  useCreateCustomerPfMutation,
} from '~/graphql/generated/graphql';

const SignUp: React.FC = () => {
  const history = useHistory();
  const { t } = useTranslation();
  const [GenerateToken] = useSendEmailConfirmationTokenMutation();
  const [ConfirmToken] = useConfirmEmailTokenMutation();
  const [DoSignUp] = useCreateCustomerPfMutation();

  // const [loading, setLoading] = useState(false);
  // const { addToast } = useToast();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [code, setCode] = useState('');
  const [nationality, setNationality] = useState('brazilian');
  const [country, setCountry] = useState('BR');
  const [cpf, setCpf] = useState('');
  const [fullname, setFullname] = useState('');
  const [birthdate, setBirthdate] = useState('');
  const [zipcode, setZipcode] = useState('');
  const [district, setDistrict] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [street, setStreet] = useState('');
  const [number, setNumber] = useState('');
  const [complement, setComplement] = useState('');

  const goToSignIn = (): void => {
    history.push('/');
  };

  const handleSubmit = React.useCallback(async () => {
    try {
      // setLoading(true);

      const schema = Yup.object().shape({
        email: Yup.string()
          .email(t('E-mail deve ser um e-mail válido'))
          .required(t('O E-mail é obrigatório')),
        password: Yup.string()
          .min(8, t('A senha deve conter no mínimo 8 caracteres'))
          .required(t('A senha é obrigatória')),
        confirmPassword: Yup.string().when(
          'password',
          (pass: string, field: any) =>
            pass
              ? field
                  .required(t('A confirmação de senha é obrigatória'))
                  .oneOf(
                    [Yup.ref('password')],
                    t('A senha e a confirmação deve ser idênticas'),
                  )
              : field,
        ),
      });

      await schema.validate(
        { email, password, confirmPassword },
        { abortEarly: false },
      );

      const result = GenerateToken({ variables: { email } })
        .then(() => {
          // addToast({
          //   type: 'success',
          //   title: t('E-mail de confirmação enviado'),
          //   description: t(
          //     'Enviamos um e-mail com um token para confirmação de conta, cheque sua caixa de entrada.',
          //   ),
          // });
          toast.success(
            'Enviamos um e-mail com um token para confirmação de conta, cheque sua caixa de entrada.',
          );

          return 'success';
        })
        .catch(err => {
          // addToast({
          //   type: 'error',
          //   title: t('Oooops, Ocorreu um erro!'),
          //   description: err.message,
          // });
          toast.error(err.message);

          return 'error';
        });

      // setLoading(false);
      return result as Promise<'success' | 'error'>;
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: key, description: errors[key] }),
          toast.error(errors[key]),
        );
        // setLoading(false);
      }

      const message =
        err?.response && err.response.status !== 500
          ? err.response.data.message
          : t(
              'Desculpe, mas ocorreu algum erro ao se conectar com o servidor.',
            );

      // addToast({
      //   type: 'error',
      //   title: t('Oooops, Ocorreu um erro!'),
      //   description: message,
      // });
      toast.error(message);

      // setLoading(false);
      return 'error';
    }
  }, [GenerateToken, confirmPassword, email, password, t]);

  const handleSubmitCode = React.useCallback(async () => {
    try {
      // setLoading(true);

      const schema = Yup.object().shape({
        email: Yup.string()
          .email(t('E-mail deve ser um e-mail válido'))
          .required(t('O E-mail é obrigatório')),
        code: Yup.string()
          .length(36, 'O código de verificação deve conter 36 caracteres')
          .required(t('O código de verificação é obrigatório')),
      });

      await schema.validate({ email, code }, { abortEarly: false });

      // await api.put('/confirmations/confirm', {
      //   email,
      //   token: code,
      // });

      const result = ConfirmToken({ variables: { email, token: code } })
        .then(() => {
          return 'success';
        })
        .catch(err => {
          // addToast({
          //   type: 'error',
          //   title: t('Oooops, Ocorreu um erro!'),
          //   description: err.message,
          // });
          toast.error(err.message);

          return 'error';
        });

      return result as Promise<'success' | 'error'>;
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: key, description: errors[key] }),
          toast.error(errors[key]),
        );
        // setLoading(false);
        return 'error';
      }

      const message =
        err?.response && err.response.status !== 500
          ? err.response.data.message
          : t(
              'Desculpe, mas ocorreu algum erro ao se conectar com o servidor.',
            );

      // addToast({
      //   type: 'error',
      //   title: t('Oooops, Ocorreu um erro!'),
      //   description: message,
      // });
      toast.error(message);

      // setLoading(false);
      return 'error';
    }
  }, [ConfirmToken, code, email, t]);

  const handleSubmitFullRecord = React.useCallback(async () => {
    try {
      // setLoading(true);

      const schema = Yup.object().shape({
        // country: Yup.string().required(t('O país é obrigatório')),
        name: Yup.string().required(t('O name é obrigatório')),
        document: Yup.string().required(
          t('O número do documento é obrigatório'),
        ),
        born: Yup.date()
          .max(subYears(new Date(), 18), t('Você teve ter mais de 18 anos'))
          .typeError(t('A data de nascimento deve ser válida')),
        zipcode: Yup.string().required(t('O código postal é obrigatório')),
        district: Yup.string().required(t('O bairro é obrigatório')),
        state: Yup.string().required(t('O estado é obrigatório')),
        city: Yup.string().required(t('A cidade é obrigatória')),
        street: Yup.string().required(t('A rua é obrigatória')),
        number: Yup.string().required(t('O número é obrigatório')),
      });

      await schema.validate(
        {
          name: fullname,
          document: cpf,
          born: new Date(birthdate.split('/').reverse().join('-')),
          zipcode,
          district,
          state,
          city,
          street,
          number,
        },
        { abortEarly: false },
      );

      const result = DoSignUp({
        variables: {
          full_name: fullname,
          email,
          document: cpf,
          password,
          birth_date: new Date(birthdate.split('/').reverse().join('-')),
          nationality,
          country,
          zipcode,
          district,
          state,
          city,
          street,
          number,
          complement,
        },
      })
        .then(() => {
          // addToast({
          //   type: 'success',
          //   title: t('Cadastro realizado'),
          // });
          toast.success('Cadastro realizado');

          return 'success';
        })
        .catch(err => {
          // addToast({
          //   type: 'error',
          //   title: t('Oooops, Ocorreu um erro!'),
          //   description: err.message,
          // });
          toast.success(err.message);

          return 'error';
        });

      // setLoading(false);
      return result as Promise<'success' | 'error'>;
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: key, description: errors[key] }),
          toast.error(errors[key]),
        );
        // setLoading(false);
        return 'error';
      }

      const message =
        err?.response && err.response.status !== 500
          ? err.response.data.message
          : t(
              'Desculpe, mas ocorreu algum erro ao se conectar com o servidor.',
            );

      // addToast({
      //   type: 'error',
      //   title: t('Oooops, Ocorreu um erro!'),
      //   description: message,
      // });
      toast.error(message);

      // setLoading(false);
      return 'error';
    }
  }, [
    DoSignUp,
    // addToast,
    birthdate,
    city,
    complement,
    country,
    cpf,
    district,
    email,
    fullname,
    nationality,
    number,
    password,
    state,
    street,
    t,
    zipcode,
  ]);

  return (
    <Layout
      email={email}
      nationality={nationality}
      password={password}
      confirmPassword={confirmPassword}
      code={code}
      country={country}
      cpf={cpf}
      fullname={fullname}
      birthdate={birthdate}
      zipcode={zipcode}
      district={district}
      state={state}
      city={city}
      street={street}
      number={number}
      complement={complement}
      setEmail={setEmail}
      setNationality={setNationality}
      setPassword={setPassword}
      setConfirmPassword={setConfirmPassword}
      setCode={setCode}
      setCountry={setCountry}
      setCpf={setCpf}
      setFullname={setFullname}
      setBirthdate={setBirthdate}
      setZipcode={setZipcode}
      setDistrict={setDistrict}
      setState={setState}
      setCity={setCity}
      setStreet={setStreet}
      setNumber={setNumber}
      setComplement={setComplement}
      goToSignIn={goToSignIn}
      handleSubmit={handleSubmit}
      handleSubmitCode={handleSubmitCode}
      handleSubmitFullRecord={handleSubmitFullRecord}
    />
  );
};

export default SignUp;
