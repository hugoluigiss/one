/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React, { useState } from 'react';
import cx from 'classnames';
import ReactFlagsSelect from 'react-flags-select';
import { toast } from 'react-toastify';
// import useToast from '~/hooks/useToast';
import ButtonPrimary from '../../../../components/ButtonPrimary';
import InputPrimary from '../../../../components/InputPrimary';
import InputPrimaryDisabled from '../../../../components/InputPrimaryDisabled';
import StepIndicator from '../../../../components/StepIndicator';
import LogoHorizontal from '../../../../components/LogoHorizontal';
import style from './login.module.scss';
import { debounce } from '../../../../utils/debounce';
import api from '../../../../services/api';

type LayoutPropsRegister = {
  goToSignIn(): void;
  email: string;
  password: string;
  confirmPassword: string;
  code: string;
  nationality: string;
  country: string;
  fullname: string;
  birthdate: string;
  cpf: string;
  zipcode: string;
  district: string;
  state: string;
  city: string;
  street: string;
  number: string;
  complement: string;
  setEmail: (value: string) => void;
  setPassword: (value: string) => void;
  setConfirmPassword: (value: string) => void;
  setCode: (value: string) => void;
  setNationality: (value: string) => void;
  setCountry: (value: string) => void;
  setCpf: (value: string) => void;
  setFullname: (value: string) => void;
  setBirthdate: (value: string) => void;
  setZipcode: (value: string) => void;
  setDistrict: (value: string) => void;
  setState: (value: string) => void;
  setCity: (value: string) => void;
  setStreet: (value: string) => void;
  setNumber: (value: string) => void;
  setComplement: (value: string) => void;

  handleSubmit: () => Promise<'success' | 'error'>;
  handleSubmitCode: () => Promise<'success' | 'error'>;
  handleSubmitFullRecord: () => Promise<'success' | 'error'>;
};

const Layout: React.FC<LayoutPropsRegister> = ({
  goToSignIn,
  email,
  setEmail,
  password,
  confirmPassword,
  setPassword,
  setConfirmPassword,
  code,
  setCode,
  nationality,
  setNationality,
  country,
  setCountry,
  cpf,
  setCpf,
  fullname,
  setFullname,
  birthdate,
  setBirthdate,
  zipcode,
  setZipcode,
  district,
  setDistrict,
  state,
  setState,
  city,
  setCity,
  street,
  setStreet,
  number,
  setNumber,
  complement,
  setComplement,
  handleSubmit,
  handleSubmitCode,
  handleSubmitFullRecord,
}: LayoutPropsRegister) => {
  const [step, setStep] = useState(1);
  const [ischeck, setIsCheck] = useState(false);
  const [isCheckTermTwo, setIsCheckTermTwo] = useState(false);
  // const { addToast } = useToast();

  const handleDebounceZipcode = debounce(
    React.useCallback(
      async (zip: string) => {
        const resp = await api.get(`https://viacep.com.br/ws/${zip}/json/`);
        if (resp) {
          setDistrict(resp.data?.bairro);
          setState(resp.data?.uf);
          setCity(resp.data?.localidade);
          setStreet(resp.data?.logradouro);
        }
      },
      [setCity, setDistrict, setState, setStreet],
    ),
    600,
  );

  const handleSetZipcode = (value: string): void => {
    setZipcode(value);
    handleDebounceZipcode(value);
  };

  return (
    <div className={style.container}>
      <div className={style.boxContainer}>
        <div className={style.actionBox}>
          <LogoHorizontal />
          <div className={style.titleBox}>
            <h4 className={style.title}>CADASTRO</h4>
          </div>

          <StepIndicator maxSteps={5} step={step} />

          {(() => {
            switch (step) {
              case 1:
                return (
                  <div className={style.formBox}>
                    <h4 className={style.headStatus}>
                      <b>Etapa 1: </b>Seus dados de acesso
                    </h4>
                    <InputPrimary
                      standard
                      value={email}
                      onChangeText={setEmail}
                      placeholder="Digite seu e-mail"
                      labelValue="E-mail"
                    />
                    <InputPrimary
                      isPasswordType
                      value={password}
                      onChangeText={setPassword}
                      placeholder="Senha"
                      labelValue="Senha"
                    />
                    <InputPrimary
                      isPasswordType
                      value={confirmPassword}
                      onChangeText={setConfirmPassword}
                      placeholder="Repita sua senha"
                      labelValue="Repita sua senha"
                    />
                    <ButtonPrimary
                      onPress={async () => {
                        if ((await handleSubmit()) === 'success')
                          setStep(step + 1);
                      }}
                      transparency={false}
                    >
                      Continuar
                    </ButtonPrimary>
                    <ButtonPrimary onPress={goToSignIn} transparency>
                      Já possui uma conta? Entre!
                    </ButtonPrimary>
                  </div>
                );
              case 2:
                return (
                  <div className={style.formBox}>
                    <h4 className={style.headStatus}>
                      <b>Etapa 2: </b>Confirme seu e-mail
                    </h4>
                    <InputPrimaryDisabled
                      value={email}
                      placeholder=""
                      labelValue="E-mail"
                    />
                    <h6>
                      Enviamos um <b>código</b> para seu e-mail
                    </h6>
                    <InputPrimary
                      standard
                      value={code}
                      onChangeText={setCode}
                      placeholder="Insira o código"
                      labelValue="Código de validação"
                    />
                    <div className={style.right}>
                      <h6>
                        Não recebi o código,{' '}
                        <ButtonPrimary link onPress={handleSubmit}>
                          reenviar
                        </ButtonPrimary>
                        .
                      </h6>
                    </div>
                    <ButtonPrimary
                      onPress={async () => {
                        if ((await handleSubmitCode()) === 'success')
                          setStep(step + 1);
                      }}
                      transparency={false}
                    >
                      Continuar
                    </ButtonPrimary>
                    <ButtonPrimary onPress={goToSignIn} transparency>
                      Já possui uma conta? Entre!
                    </ButtonPrimary>
                  </div>
                );
              case 3:
                return (
                  <div className={style.formBox}>
                    <h4 className={style.headStatus}>
                      <b>Etapa 3: </b>Dados pessoais para o cadastro
                    </h4>
                    <div className={style.section}>
                      <div className={style.formGroup}>
                        <div className={style.select}>
                          <label htmlFor="nationality">Nacionalidade</label>
                          <select
                            id="nationality"
                            name="selectNationality"
                            onChange={
                              e =>
                                setNationality(
                                  e.target.value === '0' ? '' : e.target.value,
                                )
                              // eslint-disable-next-line react/jsx-curly-newline
                            }
                          >
                            <option value="brazilian">Brasileiro</option>
                            <option value="foreign">Estrangeiro</option>
                          </select>
                        </div>

                        <InputPrimary
                          standard
                          value={fullname}
                          onChangeText={setFullname}
                          placeholder="Digite seu nome completo"
                          labelValue="Nome completo"
                        />
                      </div>

                      <div className={style.formGroup}>
                        <InputPrimary
                          cpf={nationality === 'brazilian'}
                          standard={nationality !== 'brazilian'}
                          value={cpf}
                          onChangeText={setCpf}
                          placeholder={`Digite seu ${
                            nationality === 'brazilian' ? 'CPF' : 'Passaporte'
                          }`}
                          labelValue={`${
                            nationality === 'brazilian' ? 'CPF' : 'Passaporte'
                          }`}
                        />
                        <InputPrimary
                          datetype
                          value={birthdate}
                          onChangeText={setBirthdate}
                          placeholder="dd/mm/aaaa"
                          labelValue="Data de nascimento"
                        />
                      </div>
                    </div>

                    <div className={style.section}>
                      <h4 className={style.headStatus}>
                        <b>Endereço</b>
                      </h4>

                      <div className={style.formGroup}>
                        <div className={style.select}>
                          <label htmlFor="country">País</label>
                          <ReactFlagsSelect
                            id="country"
                            selected={country}
                            onSelect={selectedCode => setCountry(selectedCode)}
                            className={style.inputSelectCustom}
                            searchable
                            placeholder="Selecione"
                            searchPlaceholder="Pesquise pelo nome do país"
                            customLabels={{ BR: 'Brasil' }}
                          />
                        </div>
                        <InputPrimary
                          cep
                          value={zipcode}
                          onChangeText={handleSetZipcode}
                          placeholder=""
                          labelValue="CEP"
                        />
                        <InputPrimary
                          standard
                          value={state}
                          onChangeText={setState}
                          placeholder=""
                          labelValue="UF"
                          size="tiny16"
                        />
                      </div>

                      <div className={style.formGroup}>
                        <InputPrimary
                          standard
                          value={city}
                          onChangeText={setCity}
                          placeholder=""
                          labelValue="Cidade"
                        />
                        <InputPrimary
                          standard
                          value={district}
                          onChangeText={setDistrict}
                          placeholder=""
                          labelValue="Bairro"
                        />
                      </div>

                      <div className={style.formGroup}>
                        <InputPrimary
                          standard
                          value={street}
                          onChangeText={setStreet}
                          placeholder=""
                          labelValue="Logradouro"
                        />
                        <InputPrimary
                          standard
                          value={number}
                          onChangeText={setNumber}
                          placeholder=""
                          labelValue="NR"
                          size="tiny14"
                        />
                        <InputPrimary
                          standard
                          value={complement}
                          onChangeText={setComplement}
                          placeholder=""
                          labelValue="Complemento"
                        />
                      </div>
                    </div>

                    <ButtonPrimary
                      onPress={() => setStep(step + 1)}
                      transparency={false}
                    >
                      Continuar
                    </ButtonPrimary>
                    <ButtonPrimary onPress={goToSignIn} transparency>
                      Já possui uma conta? Entre!
                    </ButtonPrimary>
                  </div>
                );
              case 4:
                return (
                  <div className={style.formBox}>
                    <h4 className={style.headStatus}>
                      <b>Etapa 4: </b>Confira seus dados cadastrais
                    </h4>
                    <div className={style.section}>
                      <div className={style.formGroup}>
                        <div className={style.select}>
                          <label htmlFor="nationality">Nacionalidade</label>
                          <select
                            id="nationality"
                            name="selectNationality"
                            onChange={
                              e =>
                                setNationality(
                                  e.target.value === '0' ? '' : e.target.value,
                                )
                              // eslint-disable-next-line react/jsx-curly-newline
                            }
                          >
                            <option value="brazilian">Brasileiro</option>
                            <option value="foreign">Estrangeiro</option>
                          </select>
                        </div>

                        <InputPrimary
                          standard
                          value={fullname}
                          onChangeText={setFullname}
                          placeholder="Digite seu nome completo"
                          labelValue="Nome completo"
                        />
                      </div>

                      <div className={style.formGroup}>
                        <InputPrimary
                          cpf={nationality === 'brazilian'}
                          standard={nationality !== 'brazilian'}
                          value={cpf}
                          onChangeText={setCpf}
                          placeholder={`Digite seu ${
                            nationality === 'brazilian' ? 'CPF' : 'Passaporte'
                          }`}
                          labelValue={`${
                            nationality === 'brazilian' ? 'CPF' : 'Passaporte'
                          }`}
                        />
                        <InputPrimary
                          datetype
                          value={birthdate}
                          onChangeText={setBirthdate}
                          placeholder="dd/mm/aaaa"
                          labelValue="Data de nascimento"
                        />
                      </div>
                    </div>

                    <div className={style.section}>
                      <h4 className={style.headStatus}>
                        <b>Endereço</b>
                      </h4>

                      <div className={style.formGroup}>
                        <div className={style.select}>
                          <label htmlFor="country">País</label>
                          <ReactFlagsSelect
                            id="country"
                            selected={country}
                            onSelect={selectedCode => setCountry(selectedCode)}
                            className={style.inputSelectCustom}
                            searchable
                            placeholder="Selecione"
                            searchPlaceholder="Pesquise pelo nome do país"
                            customLabels={{ BR: 'Brasil' }}
                          />
                        </div>
                        <InputPrimary
                          cep
                          value={zipcode}
                          onChangeText={handleSetZipcode}
                          placeholder=""
                          labelValue="CEP"
                        />
                        <InputPrimary
                          standard
                          value={state}
                          onChangeText={setState}
                          placeholder=""
                          labelValue="UF"
                          size="tiny16"
                        />
                      </div>

                      <div className={style.formGroup}>
                        <InputPrimary
                          standard
                          value={city}
                          onChangeText={setCity}
                          placeholder=""
                          labelValue="Cidade"
                        />
                        <InputPrimary
                          standard
                          value={district}
                          onChangeText={setDistrict}
                          placeholder=""
                          labelValue="Bairro"
                        />
                      </div>

                      <div className={style.formGroup}>
                        <InputPrimary
                          standard
                          value={street}
                          onChangeText={setStreet}
                          placeholder=""
                          labelValue="Logradouro"
                        />
                        <InputPrimary
                          standard
                          value={number}
                          onChangeText={setNumber}
                          placeholder=""
                          labelValue="NR"
                          size="tiny14"
                        />
                        <InputPrimary
                          standard
                          value={complement}
                          onChangeText={setComplement}
                          placeholder=""
                          labelValue="Complemento"
                        />
                      </div>
                    </div>
                    <div className={style.formCheck}>
                      <div style={{ display: 'flex', flexDirection: 'column' }}>
                        <div
                          style={{
                            display: 'flex',
                            flexDirection: 'row',
                            marginBottom: '8px',
                          }}
                        >
                          <div
                            onClick={() => setIsCheck(checked => !checked)}
                            className={cx(
                              style.boxCheck,
                              ischeck ? style.trueCheck : null,
                            )}
                          />
                          <p>
                            Li e aceito os{' '}
                            <a href="/Termos_de_uso.pdf" target="blank">
                              Termos de uso
                            </a>
                            .
                          </p>
                        </div>

                        <div style={{ display: 'flex', flexDirection: 'row' }}>
                          <div
                            onClick={
                              () => setIsCheckTermTwo(checked => !checked)
                              // eslint-disable-next-line react/jsx-curly-newline
                            }
                            className={cx(
                              style.boxCheck,
                              isCheckTermTwo ? style.trueCheck : null,
                            )}
                          />
                          <p>
                            Li e aceito a{' '}
                            <a
                              href="/Política_de_Privacidade.pdf"
                              target="blank"
                            >
                              Política de privacidade
                            </a>
                            .
                          </p>
                        </div>
                      </div>
                      <ButtonPrimary
                        onPress={async () => {
                          if (!ischeck || !isCheckTermTwo) {
                            // addToast({
                            //   type: 'error',
                            //   title: 'Termos de uso',
                            //   description:
                            //     'Você deve aceitar os termos de uso.',
                            // });
                            toast.error('Você deve aceitar os termos de uso.');

                            return;
                          }
                          if ((await handleSubmitFullRecord()) === 'success')
                            setStep(step + 1);
                        }}
                        transparency={false}
                        disabled={!ischeck || !isCheckTermTwo}
                      >
                        Registrar
                      </ButtonPrimary>
                    </div>
                    <ButtonPrimary onPress={goToSignIn} transparency>
                      Já possui uma conta? Entre!
                    </ButtonPrimary>
                  </div>
                );
              case 5:
                return (
                  <div className={style.formBox}>
                    <h4 className={style.headStatus}>
                      <b>Etapa 5: </b>Sua conta está ativada!
                    </h4>
                    <div className={style.completionScreen}>
                      <h4>
                        Agora você faz parte da <b>One Exchange</b>.
                      </h4>
                      <p>
                        Sua maneira de se relacionar com o seu dinheiro mudou!{' '}
                      </p>
                    </div>
                    <ButtonPrimary onPress={goToSignIn} transparency={false}>
                      Acessar
                    </ButtonPrimary>
                  </div>
                );
              default:
                return (
                  <div className={style.formBox}>
                    <h4 className={style.headStatus}>
                      <b>Etapa 1: </b>Seus dados de acesso
                    </h4>
                    <InputPrimary
                      standard
                      value={email}
                      onChangeText={setEmail}
                      placeholder="Digite seu e-mail"
                      labelValue="E-mail"
                    />
                    <InputPrimary
                      isPasswordType
                      value={password}
                      onChangeText={setPassword}
                      placeholder="Senha"
                      labelValue="Senha"
                    />
                    <InputPrimary
                      isPasswordType
                      value={password}
                      onChangeText={setPassword}
                      placeholder="Repita sua senha"
                      labelValue="Repita sua senha"
                    />
                    <ButtonPrimary
                      onPress={() => setStep(step + 1)}
                      transparency={false}
                    >
                      Continuar
                    </ButtonPrimary>
                    <ButtonPrimary onPress={goToSignIn} transparency>
                      Já possui uma conta? Entre!
                    </ButtonPrimary>
                  </div>
                );
            }
          })()}
        </div>
      </div>
    </div>
  );
};

export default Layout;
