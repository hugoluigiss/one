/* eslint-disable react/jsx-curly-newline */
/* eslint-disable jsx-a11y/label-has-associated-control */
import React from 'react';

import * as Yup from 'yup';
import { toast } from 'react-toastify';
import ButtonPrimary from '../../../components/ButtonPrimary';
import getValidationErrors from '~/utils/getValidationErrors';

// import useToast from '~/hooks/useToast';

import style from './help.module.scss';
import {
  GetMyTicketsDocument,
  useCreateTicketMutation,
  useGetTicketCategoriesQuery,
} from '~/graphql/generated/graphql';

const FormTicket: React.FC = () => {
  const [subject, setSubject] = React.useState('');
  const [message, setMessage] = React.useState('');
  const [category, setCategory] = React.useState<string | undefined>(undefined);

  const { data: categories } = useGetTicketCategoriesQuery();

  // const { addToast } = useToast();

  const [createTicket] = useCreateTicketMutation();
  const handleSubmit = React.useCallback(async () => {
    try {
      const schema = Yup.object().shape({
        subject: Yup.string().required('O assunto é obrigatório'),
        category: Yup.string().required('O setor é obrigatório'),
        message: Yup.string().required('A messagem é obrigatória'),
      });

      await schema.validate(
        { subject, category, message },
        { abortEarly: false },
      );

      await createTicket({
        variables: {
          category_value: category || '',
          message,
          subject,
        },
        refetchQueries: [
          {
            query: GetMyTicketsDocument,
          },
        ],
      });

      // addToast({
      //   type: 'success',
      //   title: 'Seu chamado foi enviado com sucesso!',
      // });
      toast.success('Seu chamado foi enviado com sucesso!');

      setSubject('');
      setMessage('');
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: '', description: errors[key] }),
          toast.error(errors[key]),
        );
      }
    }
  }, [category, createTicket, message, subject]);

  return (
    <>
      <div className={style.header}>
        <h3>Abrir um ticket</h3>
      </div>

      <div className={style.formTicket}>
        {categories && categories.GetTicketCategories && (
          <div className={style.formGroup}>
            <label htmlFor="options">Departamento</label>
            <select
              id="options"
              name="selectOptions"
              onChange={e =>
                setCategory(e.target.value === '0' ? undefined : e.target.value)
              }
            >
              <option value="0">Selecione</option>
              {categories.GetTicketCategories.map(c => (
                <option key={c.value} value={c.value}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        )}

        <div className={style.formGroup}>
          <label htmlFor="subject">Assunto</label>
          <input
            type="text"
            placeholder="Assunto"
            id="subject"
            onChange={e => setSubject(e.target.value)}
            value={subject}
          />
        </div>

        {/* <div className={style.formGroup}>
          <label htmlFor="fileAdd">Anexo</label>
          <div className={style.boxFileUpload}>
            <div className={style.iconUpload} />
            <input
              className={style.typeFile}
              type="file"
              id="fileAdd"
              accept="image/png, image/jpeg"
            />
          </div>
        </div> */}

        <div className={style.formGroup}>
          <label htmlFor="message">Mensagem</label>
          <textarea
            value={message}
            id="message"
            onChange={e => setMessage(e.target.value)}
          />
        </div>

        <ButtonPrimary transparency={false} onPress={() => handleSubmit()}>
          Enviar
        </ButtonPrimary>
      </div>
    </>
  );
};

export default FormTicket;
