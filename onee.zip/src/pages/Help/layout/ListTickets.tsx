import React from 'react';
import DateWithHour from '../../../components/UtilsComponents/DateWithHour';

import style from './help.module.scss';
import { useGetMyTicketsQuery } from '~/graphql/generated/graphql';

const ListTickets: React.FC = () => {
  const { data } = useGetMyTicketsQuery();

  return (
    <table>
      <thead>
        <tr>
          <th>Data</th>
          <th>Departamento</th>
          <th>Assunto</th>
          {/* <th>Anexo</th> */}
          <th>Mensagem</th>
          <th>Status</th>
          <th>Ação</th>
        </tr>
      </thead>

      {data && data.GetMyTickets.edges.tickets && (
        <tbody>
          {data.GetMyTickets.edges.tickets?.map(ticket => (
            <tr key={ticket.id} className={style.selectedItems}>
              <td>
                <DateWithHour dateValue={ticket.created_at} />
              </td>
              <td>{ticket.category}</td>
              <td>{ticket.subject}</td>
              <td>{ticket.message}</td>
              <td>{ticket.status}</td>
              <td>-</td>
            </tr>
          ))}
        </tbody>
      )}
    </table>
  );
};

export default ListTickets;
