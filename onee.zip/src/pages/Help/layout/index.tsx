/* eslint-disable jsx-a11y/label-has-associated-control */
import React from 'react';
import FormTicket from './FormTicket';
import ListTickets from './ListTickets';
import style from './help.module.scss';

const Layout: React.FC = () => {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-4">
          <div className={style.tableContainer}>
            <div className={style.tableItem}>
              <FormTicket />
            </div>
          </div>
        </div>

        <div className="col-lg-8">
          <div className={style.tableContainer}>
            <div className={style.tableItem}>
              <ListTickets />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Layout;
