import React from 'react';
import * as Yup from 'yup';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';
import SmallButton from '../../../../../components/SmallButton';
import style from './accountbanks.module.scss';
import getValidationErrors from '~/utils/getValidationErrors';

// import useToast from '~/hooks/useToast';
import {
  useGetAllBanksQuery,
  useCreateMyBankAccountMutation,
  GetMyBankAccountsDocument,
} from '~/graphql/generated/graphql';

const AccountBanks: React.FC = () => {
  const { t } = useTranslation();

  // const { addToast } = useToast();

  const { data: banks } = useGetAllBanksQuery();
  const [doCreateMyBankAccount] = useCreateMyBankAccountMutation();

  const [selectedBank, setSelectedBank] = React.useState<string>('');
  const [agencyNumber, setAgencyNumber] = React.useState<string>('');
  const [pix, setPix] = React.useState<string>('');
  const [accountNumber, setAccountNumber] = React.useState<string>('');

  const handleSubmit = React.useCallback(async () => {
    try {
      const schema = Yup.object().shape({
        bank_id: Yup.string().required(t('O banco é obrigatório.')),
        agency_number: Yup.string().required(
          t('O número da agência é obrigatório'),
        ),
        account_number: Yup.string().required(
          t('O número da conta é obrigatório'),
        ),
      });

      await schema.validate(
        {
          bank_id: selectedBank,
          agency_number: agencyNumber,
          account_number: accountNumber,
          pix,
        },
        { abortEarly: false },
      );

      doCreateMyBankAccount({
        variables: {
          bank_id: selectedBank,
          agency: agencyNumber,
          account: accountNumber,
          pix,
        },
        refetchQueries: [{ query: GetMyBankAccountsDocument }],
      })
        .then(() => {
          // addToast({
          //   type: 'success',
          //   title: t('Dados bancários criado com sucesso.'),
          // });
          toast.error('Dados bancários criado com sucesso.');
        })
        .catch(err => {
          // addToast({
          //   type: 'error',
          //   title: t('Oooops, Ocorreu um erro!'),
          //   description: err.message,
          // });
          toast.error(err.message);
        });
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: '', description: errors[key] }),
          toast.error(errors[key]),
        );
        return;
      }

      const message =
        err?.response && err.response.status !== 500
          ? err.response.data.message
          : t(
              'Desculpe, mas ocorreu algum erro ao se conectar com o servidor.',
            );

      // addToast({
      //   type: 'error',
      //   title: t('Oooops, Ocorreu um erro!'),
      //   description: message,
      // });
      toast.error(message);
    } finally {
      // setLoading(false);
    }
  }, [
    accountNumber,
    agencyNumber,
    doCreateMyBankAccount,
    pix,
    selectedBank,
    t,
  ]);

  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>Cadastrar conta bancária</h3>
      </div>

      <div className={style.tableContainer}>
        <div className={style.formGroupItem}>
          <label htmlFor="bank_options">Banco</label>
          <select
            id="bank_options"
            name="bankOptions"
            onChange={e => setSelectedBank(e.target.value)}
          >
            <option value={undefined}>Selecione</option>
            {banks?.GetAllBanks.map(bank => (
              <option key={bank.id} value={bank.id}>
                {`${bank.name} (${bank.code})`}
              </option>
            ))}
          </select>
        </div>
        <div className={style.formGroupItem}>
          <label>Agência</label>
          <input
            autoComplete="new-password"
            placeholder="Digite aqui"
            value={agencyNumber || ''}
            onChange={e => setAgencyNumber(e.target.value)}
          />
        </div>
        <div className={style.formGroupItem}>
          <label>Conta</label>
          <input
            autoComplete="new-password"
            placeholder="Digite aqui"
            value={accountNumber || ''}
            onChange={e => setAccountNumber(e.target.value)}
          />
        </div>
        <div className={style.formGroupItem}>
          <label>Chave PIX</label>
          <input
            autoComplete="new-password"
            placeholder="Digite aqui"
            value={pix || ''}
            onChange={e => setPix(e.target.value)}
          />
        </div>

        <SmallButton blue onPress={() => handleSubmit()}>
          Cadastrar
        </SmallButton>
      </div>
    </div>
  );
};

export default AccountBanks;
