import React from 'react';
// import { useTranslation } from 'react-i18next';
import style from './listParams.module.scss';
import { useGetAllCoinsOperationParamsQuery } from '~/graphql/generated/graphql';
import CurrencyWithIcon from '~/components/UtilsComponents/CurrencyWithIcon';

const CoinsOperationParamsTable: React.FC = () => {
  const { data: fees } = useGetAllCoinsOperationParamsQuery();

  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>Limites Operacionais e Taxas</h3>
      </div>

      <div className={style.tableContainer}>
        <table>
          <tr>
            <th>Operação</th>
            <th>Moeda</th>
            <th>Limite Mínimo</th>
            <th>Límite Máximo</th>
            <th>Taxa Fixa</th>
            <th>Taxa Variável</th>
            <th>Vigência</th>
          </tr>

          {fees?.GetAllCoinsOperationParams.map(fee => (
            <tr key={fee.id}>
              <td>{fee.name}</td>
              <td>
                <CurrencyWithIcon
                  iconName={fee.coin.symbol.toLowerCase()}
                  currency={fee.coin.name}
                  hover={false}
                />
              </td>
              <td>{fee.min_brl_value_formatted}</td>
              <td>{fee.max_brl_value_formatted}</td>
              <td>{fee.fixed_fee_brl_value_formatted}</td>
              <td>{fee.percentage_fee_value_formatted}</td>
              <td>{`${fee.validity_period_days} dias`}</td>
            </tr>
          ))}
        </table>
      </div>
      <div className={style.footer}>
        <span>
          Gostaria de aumentar seus limites? Simples, submeta a documentação
          abaixo que nosso compliance irá avaliar
        </span>
      </div>
    </div>
  );
};

export default CoinsOperationParamsTable;
