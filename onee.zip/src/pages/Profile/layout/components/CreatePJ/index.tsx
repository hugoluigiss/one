/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';
import cx from 'classnames';
import { toast } from 'react-toastify';
import ButtonPrimary from '../../../../../components/ButtonPrimary';
import InputPrimary from '../../../../../components/InputPrimary';
import style from './CreatePJ.module.scss';
// import useToast from '~/hooks/useToast';
import getValidationErrors from '~/utils/getValidationErrors';
import api from '../../../../../services/api';
import { debounce } from '../../../../../utils/debounce';

import {
  useCreateCustomerPjMutation,
  useGetMyAssociatedAccountsLazyQuery,
} from '~/graphql/generated/graphql';

const CreatePJ: React.FC = () => {
  const [DoCreatePJ] = useCreateCustomerPjMutation();
  const [GetAssociatedAccounts] = useGetMyAssociatedAccountsLazyQuery();

  const { t } = useTranslation();
  const [ischeck, setIsCheck] = useState(false);
  const [isCheckTermTwo, setIsCheckTermTwo] = useState(false);

  // const { addToast } = useToast();

  const [fantasyName, setFantasyName] = useState('');
  const [birth, setBirth] = useState('');
  const [fullName, setFullName] = useState('');
  const [cnpj, setCnpj] = useState('');
  const [email, setEmail] = useState('');
  const [country] = useState('36');
  const [zipcode, setZipcode] = useState('');
  const [state, setState] = useState('');
  const [city, setCity] = useState('');
  const [district, setDistrict] = useState('');
  const [street, setStreet] = useState('');
  const [number, setNumber] = useState('');
  const [complement, setComplement] = useState('');

  // const [loading, setLoading] = React.useState(false);

  const handleSubmit = React.useCallback(async () => {
    try {
      const schema = Yup.object().shape({
        fullName: Yup.string().required(t('A razão social é obrigatória')),
        cnpj: Yup.string().required(t('O CNPJ é obrigatório')),
        email: Yup.string().required(t('O Email é obrigatório')),
        zipcode: Yup.string().required(t('O CEP é obrigatório')),
        state: Yup.string().required(t('O estado é obrigatório')),
        city: Yup.string().required(t('A cidade é obrigatória')),
        district: Yup.string().required(t('O bairro é obrigatório')),
        street: Yup.string().required(t('O logradouro é obrigatório')),
        number: Yup.string().required(t('O número é obrigatório')),
        birth: Yup.date().required(t('A data de fundação é obrigatória')),
      });

      await schema.validate(
        {
          fullName,
          cnpj,
          // email,
          zipcode,
          state,
          city,
          district,
          street,
          number,
          birth: new Date(birth.split('/').reverse().join('-')),
        },
        { abortEarly: false },
      );

      DoCreatePJ({
        variables: {
          full_name: fullName,
          birth_date: new Date(birth.split('/').reverse().join('-')),
          fantasy_name: fantasyName,
          cnpj,
          // email,
          country,
          zipcode,
          district,
          state,
          city,
          street,
          number,
          complement,
        },
      })
        .then(() => {
          // addToast({
          //   type: 'success',
          //   title: t('Cadastro realizado'),
          // });
          toast.success('Cadastro realizado');

          setFullName('');
          setBirth('');
          setFantasyName('');
          setCnpj('');
          setEmail('');
          setZipcode('');
          setDistrict('');
          setState('');
          setCity('');
          setStreet('');
          setNumber('');
          setComplement('');
          GetAssociatedAccounts();

          return 'success';
        })
        .catch(err => {
          // addToast({
          //   type: 'error',
          //   title: t('Oooops, Ocorreu um erro!'),
          //   description: err.message,
          // });
          toast.success(err.message);

          return 'error';
        });
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: '', description: errors[key] }),
          toast.error(errors[key]),
        );

        return;
      }

      if (err.response.status === 500) {
        // addToast({
        //   type: 'error',
        //   title: t('Erro na atualização'),
        //   description: t(
        //     'Desculpe, mas ocorreu algum erro ao se conectar com o servidor.',
        //   ),
        // });
        toast.error(
          'Desculpe, mas ocorreu algum erro ao se conectar com o servidor.',
        );

        return;
      }

      // addToast({
      //   type: 'error',
      //   title: t('Erro na atualização'),
      //   description: err.response.message,
      // });
      toast.error(err.response.message);
    } finally {
      // setLoading(false);
    }
  }, [
    DoCreatePJ,
    GetAssociatedAccounts,
    birth,
    city,
    cnpj,
    complement,
    country,
    district,
    fantasyName,
    fullName,
    number,
    state,
    street,
    t,
    zipcode,
  ]);

  const handleDebounceZipcode = debounce(
    React.useCallback(
      async (zip: string) => {
        const resp = await api.get(`https://viacep.com.br/ws/${zip}/json/`);
        if (resp) {
          setDistrict(resp.data?.bairro);
          setState(resp.data?.uf);
          setCity(resp.data?.localidade);
          setStreet(resp.data?.logradouro);
        }
      },
      [setCity, setDistrict, setState, setStreet],
    ),
    600,
  );

  const handleSetZipcode = (value: string): void => {
    setZipcode(value);
    handleDebounceZipcode(value);
  };

  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>Conta Pessoa Jurídica</h3>
      </div>

      <div className={style.section}>
        <div className={style.formGroup}>
          <InputPrimary
            cnpj
            value={cnpj}
            onChangeText={setCnpj}
            placeholder=""
            labelValue="CNPJ"
          />
          <InputPrimary
            standard
            value={fullName}
            onChangeText={setFullName}
            placeholder=""
            labelValue="Razão Social"
          />
          <InputPrimary
            standard
            value={fantasyName}
            onChangeText={setFantasyName}
            placeholder=""
            labelValue="Nome Fantasia"
          />
          <InputPrimary
            datetype
            value={birth}
            onChangeText={setBirth}
            placeholder="dd/mm/aaaa"
            labelValue="Data de Fundação"
          />
        </div>
        <div className={style.formGroup}>
          <InputPrimary
            standard
            value={email}
            onChangeText={setEmail}
            placeholder=""
            labelValue="E-mail"
          />
          <InputPrimary
            cep
            value={zipcode}
            onChangeText={handleSetZipcode}
            placeholder=""
            labelValue="CEP"
          />
          <InputPrimary
            standard
            value={state}
            onChangeText={setState}
            placeholder=""
            labelValue="UF"
            size="tiny12"
          />
          <InputPrimary
            standard
            value={city}
            onChangeText={setCity}
            placeholder=""
            labelValue="Cidade"
          />
        </div>
        <div className={style.formGroup}>
          <InputPrimary
            standard
            value={district}
            onChangeText={setDistrict}
            placeholder=""
            labelValue="Bairro"
          />
          <InputPrimary
            standard
            value={street}
            onChangeText={setStreet}
            placeholder=""
            labelValue="Logradouro"
          />
          <InputPrimary
            standard
            value={number}
            onChangeText={setNumber}
            placeholder=""
            labelValue="Nr"
            size="tiny12"
          />
          <InputPrimary
            standard
            value={complement}
            onChangeText={setComplement}
            placeholder=""
            labelValue="Complemento"
          />
        </div>
        <div className={style.formCheck}>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div
              style={{
                display: 'flex',
                flexDirection: 'row',
                marginBottom: '8px',
              }}
            >
              <div
                onClick={() => setIsCheck(checked => !checked)}
                className={cx(style.boxCheck, ischeck ? style.trueCheck : null)}
              />
              <p>
                Li e aceito os{' '}
                <a href="/Termos_de_uso.pdf" target="blank">
                  Termos de uso
                </a>
                .
              </p>
            </div>
            <div style={{ display: 'flex', flexDirection: 'row' }}>
              <div
                onClick={() => setIsCheckTermTwo(checked => !checked)}
                className={cx(
                  style.boxCheck,
                  isCheckTermTwo ? style.trueCheck : null,
                )}
              />
              <p>
                Li e aceito a
                <a href="/Política_de_Privacidade.pdf" target="blank">
                  Política de privacidade
                </a>
                .
              </p>
            </div>
          </div>
          <ButtonPrimary
            onPress={() => {
              if (!ischeck) {
                // addToast({
                //   type: 'error',
                //   title: 'Termos de uso',
                //   description: 'Você deve aceitar os termos de uso.',
                // });
                toast.error('Você deve aceitar os termos de uso.');
                return;
              }
              handleSubmit();
            }}
            disabled={!ischeck || !isCheckTermTwo}
          >
            Cadastrar
          </ButtonPrimary>
        </div>
      </div>
    </div>
  );
};

export default CreatePJ;
