import React from 'react';
// import SmallButton from '../../../../../components/SmallButton';
import style from './documentIdentify.module.scss';
import UploadDocument from '../Documents/UploadDocument';

interface IProps {
  title: string;
  description: string;
  lastUpdated?: string;
  typeId: string;
  fileUrl?: string;
  status: string;
  updated_date: string;
  motivation?: string | null;
}

const DocumentIdentify: React.FC<IProps> = ({
  description,
  title,
  lastUpdated = '',
  typeId,
  fileUrl = '',
  status,
  updated_date,
  motivation = '',
}) => {
  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>{title}</h3>
      </div>

      <div className={style.tableContainer}>
        <div className={style.formSendImage}>
          <h3>{lastUpdated}</h3>
          <p>{description}</p>
          {status === 'pending' && (
            <div className={style.boxFileUpload}>
              <UploadDocument typeId={typeId} fileUrl={fileUrl} />
            </div>
          )}
          {status === 'rejected' && (
            <div className={style.boxFileUpload}>
              <div className={style.boxFileResponse}>
                <div className={style.iconError} />
                <div>
                  <p>Arquivo recusado</p>
                  <p>Motivo: {motivation}</p>
                </div>
              </div>
              <UploadDocument typeId={typeId} fileUrl={fileUrl} />
            </div>
          )}
          {status === 'approved' && (
            <div className={style.boxFileResponse}>
              <div className={style.iconSuccess} />
              <p>Aprovado no dia {updated_date}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DocumentIdentify;
