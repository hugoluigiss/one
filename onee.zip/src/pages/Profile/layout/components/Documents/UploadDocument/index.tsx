import React, { useState, useCallback } from 'react';
import filesize from 'filesize';

// import { useHistory } from 'react-router-dom';

import { useTranslation } from 'react-i18next';

import { toast } from 'react-toastify';
// import useToast from '~/hooks/useToast';

import FileList from '~/components/Form/Upload/FileList';
// import Upload from '~/components/Form/Upload';

import SmallButton from '~/components/SmallButton';
import { useSendMyDocumentFileMutation } from '~/graphql/generated/graphql';

// import { ImportFileContainer } from '../styles';

interface FileProps {
  file: File;
  name: string;
  readableSize: string;
}

interface Props {
  typeId: string;
  fileUrl?: string;
}

const UploadDocument: React.FC<Props> = ({ typeId, fileUrl = '' }) => {
  const { t } = useTranslation();

  // const history = useHistory();
  // const { addToast } = useToast();

  // const [loading, setLoading] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<FileProps[]>([]);

  const [DoSendDocument] = useSendMyDocumentFileMutation();

  const handleUpload = useCallback(async (): Promise<void> => {
    try {
      // console.log(!uploadedFiles.length);
      if (!uploadedFiles.length) return;
      // setLoading(true);

      const data = new FormData();

      const [file] = uploadedFiles;

      data.append('document', file.file, file.name);
      data.append('type_id', typeId);

      // await api.post('/documents/upload', data);

      DoSendDocument({
        variables: {
          document_id: typeId,
          file: file.file,
        },
      })
        .then(() => {
          // addToast({
          //   type: 'success',
          //   title: t('Documento enviado com sucesso!'),
          //   description: t(
          //     'Aguarde enquanto nossa equipe de suporte analisa o seu documento',
          //   ),
          // });
          toast.success(
            'Aguarde enquanto nossa equipe de suporte analisa o seu documento',
          );

          window.scrollTo({ top: 0 });

          return 'success';
        })
        .catch((err: { message: any }) => {
          // addToast({
          //   type: 'error',
          //   title: t('Erro no envio do documento'),
          //   description: err.message,
          // });
          toast.error(err.message);

          return 'error';
        });
    } catch (err) {
      const errorMessage =
        err.response.status === 500
          ? t('Desculpe, mas ocorreu algum erro ao se conectar com o servidor')
          : err.response.data.message;

      window.scrollTo({ top: 0 });

      // addToast({
      //   type: 'error',
      //   title: t('Erro no envio do documento'),
      //   description: errorMessage,
      // });
      toast.error(errorMessage);
    }
  }, [uploadedFiles, typeId, DoSendDocument, t]);

  const handleSubmitFile = useCallback((files: File[]): void => {
    const uploadFiles = files.map(file => ({
      file,
      name: file.name,
      readableSize: filesize(file.size),
    }));

    setUploadedFiles(uploadFiles as FileProps[]);
  }, []);

  return (
    <>
      {/* <Upload onUpload={handleSubmitFile} fileUrl={fileUrl} /> */}

      {!!uploadedFiles.length && <FileList files={uploadedFiles} />}

      <SmallButton blue onPress={handleUpload}>
        {t('Enviar')}
      </SmallButton>
    </>
  );
};

export default UploadDocument;
