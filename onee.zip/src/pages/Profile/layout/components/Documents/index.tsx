import React from 'react';
import { useTranslation } from 'react-i18next';
import { parseISO, subHours, formatDistanceToNow, format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import DocumentIdentify from '../DocumentIdentify';
// import SelfieBox from '../SelfieBox';
import style from '../../profile.module.scss';
import { useGetMyDocumentsQuery } from '~/graphql/generated/graphql';

// interface TypeDocument {
//   id: string;
//   name: string;
//   description: string;
// }

// interface Document {
//   value: string;
//   status: string;
//   type_id: string;
//   resent_at: string;
//   motivation: string;
//   updated_at: string;
//   confirmed_at: string;
//   document_url: string;
//   status_id: string;
// }

export default function Documents(): JSX.Element {
  const { t } = useTranslation();
  const { data: myDocuments } = useGetMyDocumentsQuery();

  // const [loading, setLoading] = React.useState(true);

  const documentsFormatted = React.useMemo(() => {
    return myDocuments?.GetMyDocuments.filter(
      typeDocument => typeDocument.name !== 'Comprovante de residência',
    ).map(typeDocument => {
      // const userDocument = myDocuments?.GetMyDocuments.find(
      //   findDocument => findDocument.type === typeDocument.id,
      // );
      const userDocument = typeDocument;

      // const confirmed = userDocument && userDocument.status === 'confirmed';
      const updatedAt =
        userDocument?.updated_at &&
        userDocument?.updated_at !== userDocument.created_at &&
        formatDistanceToNow(subHours(parseISO(userDocument.updated_at), 3), {
          locale: ptBR,
          addSuffix: true,
        });

      return {
        type: typeDocument,
        value: userDocument?.document.document_value,
        status: userDocument.status,
        updated_date: format(parseISO(userDocument?.updated_at), 'dd/MM/yyyy'),
        motivation: userDocument?.admin_answear,
        updated_at: updatedAt || 'Pendente',
        document_url: userDocument?.file_url || '',
      };
    });
  }, [myDocuments]);

  return (
    <div className="row">
      {documentsFormatted?.map(document => (
        <div key={document.type.name} className="col-lg-6">
          <div className={style.tableContainer}>
            <div className={style.tableItem}>
              <DocumentIdentify
                title={t(document.type.name.replace('.', ''))}
                description={t(document.type.description.replace('.', ''))}
                lastUpdated={`${t('Última atualização')}: ${
                  document.updated_at
                }`}
                typeId={document.type.id}
                fileUrl={document.document_url}
                status={document.status}
                updated_date={document.updated_date}
                motivation={document.motivation}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
