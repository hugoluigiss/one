import React from 'react';
// import { useTranslation } from 'react-i18next';
import style from './listAccount.module.scss';
import { useGetMyBankAccountsQuery } from '~/graphql/generated/graphql';

const ListAccountBanks: React.FC = () => {
  const { data: accounts } = useGetMyBankAccountsQuery();

  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>Cadastrar conta bancária</h3>
      </div>

      <div className={style.tableContainer}>
        <table>
          <tr>
            <th>Banco</th>
            <th>Agência</th>
            <th>Conta</th>

            <th>Pix</th>
          </tr>

          {accounts?.GetMyBankAccounts.map(account => (
            <tr key={account.id}>
              <td>{account.bank.name}</td>
              <td>{account.agency}</td>
              <td>{account.account}</td>

              <td>{account.pix || '-'}</td>
            </tr>
          ))}
        </table>
      </div>
    </div>
  );
};

export default ListAccountBanks;
