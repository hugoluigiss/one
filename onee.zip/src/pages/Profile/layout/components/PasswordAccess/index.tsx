import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import ButtonPrimary from '../../../../../components/ButtonPrimary';
import InputPrimary from '../../../../../components/InputPrimary';
import style from './PasswordAccess.module.scss';
// import useToast from '~/hooks/useToast';
import api from '~/services/api';
import getValidationErrors from '~/utils/getValidationErrors';

const PasswordAccess: React.FC = () => {
  const [oldPassword, setOldPassword] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirmation, setPasswordConfirmation] = useState('');
  const { t } = useTranslation();

  // const { addToast } = useToast();

  // const [loading, setLoading] = React.useState(false);

  const handleSubmit = React.useCallback(async () => {
    try {
      // setLoading(true);

      const schema = Yup.object().shape({
        old_password: Yup.string().required(t('A senha é obrigatória')),
        password: Yup.string().required(t('A nova senha é obrigatória')),
        password_confirmation: Yup.string().when(
          'password',
          (pass: string, field: any) =>
            pass
              ? field
                  .required(t('A confirmação da nova senha é obrigatória'))
                  .oneOf(
                    [Yup.ref('password')],
                    t('A senha e a confirmação de senha devem ser idênticas'),
                  )
              : field,
        ),
      });

      await schema.validate(
        {
          old_password: oldPassword,
          password,
          password_confirmation: passwordConfirmation,
        },
        { abortEarly: false },
      );

      await api.put('/profile', {
        old_password: oldPassword,
        password,
      });

      // addToast({
      //   type: 'success',
      //   title: t('Senha atualizada com sucesso!'),
      // });
      toast.success('Senha atualizada com sucesso!');
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: '', description: errors[key] }),
          toast.error(errors[key]),
        );

        return;
      }

      if (err.response.status === 500) {
        // addToast({
        //   type: 'error',
        //   title: t('Erro na atualização'),
        //   description: t(
        //     'Desculpe, mas ocorreu algum erro ao se conectar com o servidor.',
        //   ),
        // });
        toast.error(
          'Desculpe, mas ocorreu algum erro ao se conectar com o servidor.',
        );

        return;
      }

      // addToast({
      //   type: 'error',
      //   title: t('Erro na atualização'),
      //   description: err.response.message,
      // });
      toast.error(err.response.message);
    } finally {
      // setLoading(false);
    }
  }, [oldPassword, password, passwordConfirmation, t]);

  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>Senha de acesso</h3>
      </div>

      <div className={style.itemContain}>
        <InputPrimary
          isPasswordType
          value={oldPassword}
          onChangeText={setOldPassword}
          placeholder="Digite sua senha"
          labelValue="Senha atual"
        />
        <InputPrimary
          isPasswordType
          value={password}
          onChangeText={setPassword}
          placeholder="Digite sua nova senha"
          labelValue="Nova senha"
        />
        <InputPrimary
          isPasswordType
          value={passwordConfirmation}
          onChangeText={setPasswordConfirmation}
          placeholder="Confirme sua nova senha"
          labelValue="Confirme a senha"
        />
        <ButtonPrimary onPress={() => handleSubmit()}>Salvar</ButtonPrimary>
      </div>
    </div>
  );
};

export default PasswordAccess;
