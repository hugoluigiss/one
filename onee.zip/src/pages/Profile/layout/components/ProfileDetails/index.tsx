import React from 'react';
import { format, parseISO } from 'date-fns';
import InputPrimaryDisabled from '../../../../../components/InputPrimaryDisabled';
// import profileExample from '../../../../../assets/images/image.jpeg';
import style from './profileDetails.module.scss';
import { useGetMyProfileQuery } from '~/graphql/generated/graphql';
import { cpfMask, cnpjMask } from '~/components/InputPrimary/mask';

interface ProfileProps {
  id: number;
  name: string;
  born: string;
  email: string;
  document: string;
  mother_name: string;
  avatar_url: string;
  phone?: {
    number: string;
  };
}

const ProfileDetails: React.FC = () => {
  // const [profile, setProfile] = React.useState<ProfileProps>();
  const { data: profile } = useGetMyProfileQuery();

  // React.useEffect(() => {
  //   api.get('/profile').then(response => {
  //     setProfile(response.data);
  //   });
  // }, [setProfile]);

  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>
          Perfil{' '}
          {profile?.GetMyProfile.type === 'PJ'
            ? ' - Pessoa Jurídica'
            : ' - Pessoa Física'}
        </h3>
      </div>

      <div className={style.tableContainer}>
        <div className={style.photoProfile}>
          <img
            src={profile?.GetMyProfile.avatar_url || ''}
            alt={profile?.GetMyProfile.full_name || ''}
          />
        </div>

        <div className={style.containFormProfile}>
          <InputPrimaryDisabled
            labelValue="Nome"
            value={profile?.GetMyProfile.full_name || ''}
            placeholder=""
          />

          <InputPrimaryDisabled
            labelValue={profile?.GetMyProfile.type === 'PJ' ? 'CNPJ' : 'CPF'}
            value={
              profile?.GetMyProfile.type === 'PJ'
                ? cnpjMask(profile?.GetMyProfile.document?.document_value || '')
                : cpfMask(profile?.GetMyProfile.document?.document_value || '')
            }
            placeholder=""
          />

          <InputPrimaryDisabled
            labelValue={
              profile?.GetMyProfile.type === 'PJ'
                ? 'Data de Fundação'
                : 'Data de nascimento'
            }
            value={
              profile
                ? format(
                    parseISO(profile?.GetMyProfile.birth_date),
                    'dd/MM/yyyy',
                  )
                : ''
            }
            placeholder=""
          />

          {profile?.GetMyProfile.type === 'PF' && (
            <InputPrimaryDisabled
              labelValue="E-mail"
              value={profile?.GetMyProfile.email || ''}
              placeholder=""
            />
          )}

          {/* <InputPrimaryDisabled
            labelValue="Telefone"
            value={profile?.phone?.number || ''}
            placeholder=""
          /> */}
        </div>

        <h4 className={style.title}>ENDEREÇO</h4>
        <div className={style.containFormProfile}>
          <InputPrimaryDisabled
            labelValue="País"
            value={profile?.GetMyProfile.address.country || ''}
            placeholder=""
          />

          <InputPrimaryDisabled
            labelValue="Estado"
            value={profile?.GetMyProfile.address.state || ''}
            placeholder=""
          />

          <InputPrimaryDisabled
            labelValue="Cidade"
            value={profile?.GetMyProfile.address.city || ''}
            placeholder=""
          />

          <InputPrimaryDisabled
            labelValue="Bairro"
            value={profile?.GetMyProfile.address.district || ''}
            placeholder=""
          />

          <InputPrimaryDisabled
            labelValue="Número"
            value={profile?.GetMyProfile.address.number || ''}
            placeholder=""
          />

          <InputPrimaryDisabled
            labelValue="complemento"
            value={profile?.GetMyProfile.address.complement || ''}
            placeholder=""
          />

          <InputPrimaryDisabled
            labelValue={
              profile?.GetMyProfile.address.country === '36' ? 'CEP' : 'Zipcode'
            }
            value={profile?.GetMyProfile.address.zip_code || ''}
            placeholder=""
          />
        </div>
      </div>
    </div>
  );
};

export default ProfileDetails;
