import React, { useState } from 'react';
import QRCode from 'qrcode.react';
import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import api from '~/services/api';
import ButtonPrimary from '../../../../../components/ButtonPrimary';
import InputPrimary from '../../../../../components/InputPrimary';
import style from './twoFactorBox.module.scss';

// import useToast from '~/hooks/useToast';

import getValidationErrors from '~/utils/getValidationErrors';

const TwoFactorBox: React.FC = () => {
  // const [code, setCode] = useState('');
  const [qrcode, setQrcode] = useState('');
  const [secret, setSecret] = useState('');
  const [authentication, setAuthentication] = useState(false);
  const [token, setToken] = React.useState('');
  // const { addToast } = useToast();
  // const [loading, setLoading] = useState(false);
  const { t } = useTranslation();

  React.useEffect(() => {
    api.post('settings/2fa/generate').then(response => {
      setSecret(response.data.base32);
      setQrcode(response.data.otpauth_url);
    });
  }, [authentication]);

  React.useEffect(() => {
    api.get('settings/1').then(() => {
      setAuthentication(true);
    });
  }, [authentication]);

  const handleSubmit = React.useCallback(async () => {
    try {
      // setLoading(true);

      const schema = Yup.object().shape({
        token: Yup.string()
          .length(6, t('O código de verificação deve conter 6 caracteres.'))
          .required(t('O código de verificação é obrigatório')),
      });

      await schema.validate({ token }, { abortEarly: false });

      await api.post('/settings', {
        token,
        type_id: 1,
        value: secret,
      });

      setAuthentication(true);

      // addToast({
      //   type: 'success',
      //   title: t('Código de verificação ativado!'),
      //   description: t('O código de verificação foi ativado com sucesso!'),
      // });
      toast.success('O código de verificação foi ativado com sucesso!');
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: '', description: errors[key] }),
          toast.error(errors[key]),
        );
        return;
      }

      const message =
        err?.response && err.response.status !== 500
          ? err.response.data.message
          : t(
              'Desculpe, mas ocorreu algum erro ao se conectar com o servidor.',
            );

      // addToast({
      //   type: 'error',
      //   title: t('Oooops, Ocorreu um erro!'),
      //   description: message,
      // });
      toast.error(message);
    } finally {
      // setLoading(false);
    }
  }, [secret, t, token]);

  const handleClick = React.useCallback(async () => {
    api.delete('settings/2fa/remove').then(() => {
      setAuthentication(false);
    });

    // addToast({
    //   type: 'success',
    //   title: t('Verificação removida com sucesso!'),
    //   description: t('Verificação em duas etapas removida com sucesso!'),
    // });
    toast.success('Verificação em duas etapas removida com sucesso!');
  }, [t]);

  return (
    <div className={style.container}>
      <div className={style.header}>
        <h3>Verificação em duas etapas (2FA)</h3>
      </div>

      <div className={style.tableContainer}>
        {authentication ? (
          <>
            <span />

            <p>{t('A verificação em duas etapas (2fa) está ativa')}.</p>
            <p>{t('Não é recomendado, mas se desejar')},</p>

            <p>
              {t(
                'para iniciar o processo de desativação da Verificação em Duas Etapas (2FA)',
              )}
              .
            </p>
            <ButtonPrimary onPress={() => handleClick()}>
              {t('Cancelar')}
            </ButtonPrimary>
          </>
        ) : (
          <>
            {qrcode && (
              <div style={{ padding: 12, background: '#fff' }}>
                <QRCode size={100} value={qrcode} renderAs="svg" />
              </div>
            )}
            <InputPrimary
              standard
              placeholder="Digite o código de verificação"
              labelValue="Código de dois fatores"
              value={token}
              onChangeText={setToken}
            />
            <ButtonPrimary onPress={() => handleSubmit()}>Salvar</ButtonPrimary>
          </>
        )}
      </div>
    </div>
  );
};

export default TwoFactorBox;
