/* eslint-disable react-hooks/exhaustive-deps */
import React from 'react';
import cx from 'classnames';
import { useGetMyCoinWalletsQuery } from '~/graphql/generated/graphql';
import style from './wallets.module.scss';
// import BitcoinRowCurrency from './BitcoinRowCurrency';
// import EthereumRowCurrency from './EthereumRowCurrency';
import CurrencyWithIcon from '../../../components/UtilsComponents/CurrencyWithIcon';

interface IWallet {
  id: string;
  coinPrice: number;
  walletName: string;
  brl_balance_formatted: string;
  iconName: string;
  address: string;
  memo: string;
  network: string;
  walletBalance: number;
}

interface IProps {
  setSelectedWallet: (wallet: IWallet) => void;
  selectedWalletId: string;
}

const TableSelectCurrency: React.FC<IProps> = ({
  setSelectedWallet,
  selectedWalletId,
}) => {
  const { data: wallets } = useGetMyCoinWalletsQuery();
  React.useEffect(() => {
    if (wallets) {
      const wallet = wallets.GetMyCoinWallets[0];
      setSelectedWallet({
        address: wallet.address || '',
        brl_balance_formatted: wallet.formatted_brl_balance,
        coinPrice: Number(wallet.brl_price),
        iconName: wallet.coin.symbol.toLocaleLowerCase(),
        id: wallet.coin_id,
        walletBalance: Number(wallet.balance),
        walletName: wallet.coin.name,
        memo: wallet.memo,
        network: wallet.network,
      });
    }
  }, [wallets]);
  return (
    <div className={style.tableContainer}>
      <div className={style.tableItem}>
        <table>
          <thead>
            <tr>
              <th>Moeda</th>
              <th>Disponível</th>
              <th>Em reais</th>
            </tr>
          </thead>

          <tbody>
            {wallets &&
              wallets.GetMyCoinWallets.filter(
                wallet => wallet.coin.type === 'spot',
              ).map(wallet => (
                <tr
                  className={cx(
                    selectedWalletId === wallet.coin_id
                      ? style.activeItem
                      : style.selectedItems,
                  )}
                  onClick={() => {
                    setSelectedWallet({
                      address: wallet.address || '',
                      brl_balance_formatted: wallet.formatted_brl_balance,
                      coinPrice: Number(wallet.brl_price),
                      iconName: wallet.coin.symbol.toLocaleLowerCase(),
                      id: wallet.coin_id,
                      walletBalance: Number(wallet.balance),
                      walletName: wallet.coin.name,
                      memo: wallet.memo,
                      network: wallet.network,
                    });
                  }}
                >
                  <td>
                    <CurrencyWithIcon
                      hover={selectedWalletId === wallet.coin_id}
                      iconName={wallet.coin.symbol.toLowerCase()}
                      currency={wallet.coin.name}
                    />
                  </td>
                  <td>{Number(wallet.formatted_balance).toFixed(8)}</td>
                  <td>{wallet.formatted_brl_balance}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TableSelectCurrency;
