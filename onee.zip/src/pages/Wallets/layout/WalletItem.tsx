/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
import QRCode from 'react-qr-code';
import CopyToClipboard from 'react-copy-to-clipboard';
import { MdContentCopy } from 'react-icons/md';
import style from './wallets.module.scss';
import IconCurrencyOnly from '../../../components/UtilsComponents/IconCurrencyOnly';
import SmallButton from '../../../components/SmallButton';
import ModalActionTransfer from '~/components/ModalActionTransfer';
import ModalActionSell from '~/components/ModalActionSell';
import ModalActionBuy from '~/components/ModalActionBuy';

interface IProps {
  coinPrice: number;
  walletName: string;
  brl_balance_formatted: string;
  iconName: string;
  address: string;
  walletBalance: number;
  memo: string;
  network: string;
}

const WalletItem: React.FC<IProps> = ({
  // selectedWallet,
  coinPrice,
  walletName,
  iconName,
  walletBalance,
  address,
  brl_balance_formatted,
  memo,
  network,
}: IProps) => {
  const [activeModalTransfer, setActiveModalTransfer] = React.useState(false);
  const [activeModalBuy, setActiveModalBuy] = React.useState(false);
  const [activeModalSell, setActiveModalSell] = React.useState(false);

  return (
    <div className={style.tableContainerWalletItem}>
      <div className={style.walletItem}>
        <div className={style.headerWallet}>
          <IconCurrencyOnly iconName={iconName} iconType={false} />
          <h4>{`Carteira ${walletName} - ${iconName.toUpperCase()}`}</h4>
        </div>

        <div className={style.walletContain}>
          <div className={style.qrcodeContent}>
            <QRCode value={address} size={130} />
          </div>

          <div className={style.currencyInfo}>
            <div className={style.itemList}>
              <span>
                <b>Endereço:</b> {address}
                <CopyToClipboard onCopy={() => {}} text={address}>
                  <button
                    type="button"
                    style={{ background: 'none', border: 'none' }}
                  >
                    <MdContentCopy />
                  </button>
                </CopyToClipboard>
              </span>
            </div>

            <div className={style.itemList}>
              <span>
                <b>Rede:</b> {network}
              </span>
            </div>

            {iconName === 'xrp' && (
              <div className={style.itemList}>
                <span>
                  <b>MEMO:</b> {memo} <br />
                  <b style={{ color: 'red' }}>
                    O MEMO é necessário ou você perderá suas moedas
                  </b>
                </span>
              </div>
            )}

            <div className={style.itemList}>
              <span>
                <b>Disponível:</b> {walletBalance.toFixed(8)}
              </span>
            </div>

            <div className={style.itemList}>
              <span>
                <b>Valor estimado:</b> {brl_balance_formatted}
              </span>
            </div>
          </div>
        </div>

        <ModalActionTransfer
          activeModal={activeModalTransfer}
          onHandleClose={() => setActiveModalTransfer(false)}
          coinPrice={coinPrice}
          iconName={iconName}
          walletBalance={walletBalance}
          walletName={walletName}
        />
        <ModalActionSell
          activeModal={activeModalSell}
          onHandleClose={() => setActiveModalSell(false)}
          coinPrice={coinPrice}
          iconName={iconName}
          walletBalance={String(walletBalance)}
          walletName={walletName}
        />
        <ModalActionBuy
          activeModal={activeModalBuy}
          onHandleClose={() => setActiveModalBuy(false)}
          coinPrice={coinPrice}
          iconName={iconName}
          walletName={walletName}
        />
        <div className={style.groupBtns}>
          <SmallButton
            green
            blue={false}
            red={false}
            onPress={() => setActiveModalBuy(state => !state)}
          >
            Comprar
          </SmallButton>

          <SmallButton
            green={false}
            blue={false}
            red
            onPress={() => setActiveModalSell(state => !state)}
          >
            Vender
          </SmallButton>

          <SmallButton
            green={false}
            blue
            red={false}
            onPress={() => setActiveModalTransfer(state => !state)}
          >
            Transferir
          </SmallButton>
        </div>
      </div>
    </div>
  );
};

export default WalletItem;
