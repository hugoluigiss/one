import React from 'react';

import style from './stylesExtractCoinSelected.module.scss';
import CurrencyWithIcon from '../../../../../components/UtilsComponents/CurrencyWithIcon';
import DateWithHour from '../../../../../components/UtilsComponents/DateWithHour';
import ButtonSecondary from '../../../../../components/ButtonSecondary';
import IconCurrencyOnly from '~/components/UtilsComponents/IconCurrencyOnly';
import { useGetMyStatmentQuery } from '~/graphql/generated/graphql';

interface IProps {
  coin_symbol: string;
  coin_name: string;
}

interface ITransaction {
  id: string;
  created_at: string;
  description: string;
  formatted_total_value: string;
  formatted_net_value: string;
  formatted_fee_value: string;
  status: string;
  coin: {
    name: string;
    symbol: string;
  };
}

const ExtractCoinSelected: React.FC<IProps> = ({
  coin_symbol,
  coin_name,
}: IProps) => {
  const offset = React.useRef(0);

  const { fetchMore, data } = useGetMyStatmentQuery({
    variables: {
      coin_symbol,
    },
  });
  const handleFetchMore = React.useCallback(async () => {
    offset.current += 1;
    fetchMore({
      variables: {
        offset: offset.current,
        coin_symbol,
      },
      updateQuery: (prev, { fetchMoreResult }) => {
        if (!fetchMoreResult) return prev;

        return {
          GetMyStatment: {
            pageInfo: { ...fetchMoreResult.GetMyStatment.pageInfo },
            totalCount: fetchMoreResult.GetMyStatment.totalCount,
            edges: {
              transactions:
                fetchMoreResult.GetMyStatment.edges.transactions &&
                prev.GetMyStatment.edges.transactions
                  ? [
                      ...prev.GetMyStatment.edges.transactions,
                      ...fetchMoreResult.GetMyStatment.edges.transactions,
                    ]
                  : undefined,
            },
          },
        };
      },
    });
  }, [coin_symbol, fetchMore]);

  const transactions: ITransaction[] =
    data && data.GetMyStatment.edges.transactions
      ? data.GetMyStatment.edges.transactions.map(t => ({
          id: t.id,
          created_at: t.created_at,
          description: t.description,
          formatted_fee_value: t.formatted_fee_value,
          formatted_net_value: t.formatted_net_value,
          formatted_total_value: t.formatted_total_value,
          status: t.status,
          coin: {
            name: t.coin.name,
            symbol: t.coin.symbol,
          },
        }))
      : [];

  return (
    <div className={style.container}>
      <div className={style.header}>
        <IconCurrencyOnly iconName={coin_symbol} iconType />
        <h3>{`Extrato da carteira ${coin_name} - ${coin_symbol}`}</h3>
      </div>

      <div className={style.tableContainer}>
        <table>
          <thead>
            <tr>
              <th>Data</th>
              <th>Moeda</th>
              <th>Transação</th>
              <th>Valor Total</th>
              <th>Taxa</th>
              <th>Valor Líquido</th>
              <th>Status</th>
            </tr>
          </thead>

          <tbody>
            {transactions.map(transaction => (
              <tr key={transaction.id}>
                <td>
                  <DateWithHour dateValue={transaction.created_at} />
                </td>
                <td>
                  <CurrencyWithIcon
                    iconName={transaction.coin.symbol.toLowerCase()}
                    currency={transaction.coin.name}
                    hover={false}
                  />
                </td>
                <td>{transaction.description}</td>
                <td>{transaction.formatted_total_value}</td>
                <td>{transaction.formatted_fee_value}</td>
                <td>{transaction.formatted_net_value}</td>
                <td>{transaction.status}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {data?.GetMyStatment.pageInfo.hasNextPage && (
          <div className={style.seeMoreButton}>
            <ButtonSecondary onPress={() => handleFetchMore()} secondaryBtn>
              Ver mais
            </ButtonSecondary>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExtractCoinSelected;
