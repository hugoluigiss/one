import React from 'react';

import style from './wallets.module.scss';

import TableSelectCurrency from './TableSelectCurrency';

import WalletItem from './WalletItem';
import ExtractCoinSelected from './components/ExtractCoinSelected';

interface IWallet {
  id: string;
  coinPrice: number;
  walletName: string;
  brl_balance_formatted: string;
  iconName: string;
  address: string;
  walletBalance: number;
  memo: string;
  network: string;
}

const Layout: React.FC = () => {
  const [selectedWallet, setSelectedWallet] = React.useState<IWallet>(
    {} as IWallet,
  );

  return (
    <div>
      <div className="container-fluid">
        <div className="row">
          <div className="col-lg-6">
            <TableSelectCurrency
              setSelectedWallet={setSelectedWallet}
              selectedWalletId={selectedWallet.id}
            />
          </div>

          <div className="col-lg-6">
            {selectedWallet.id && <WalletItem {...selectedWallet} />}
            {!selectedWallet.id && (
              <div
                style={{
                  height: 350,
                  position: 'relative',
                  textAlign: 'center',
                  color: '#fff',
                }}
              >
                <h4 style={{ marginTop: 60 }}>
                  Selecione uma carteira para vizualizar detalhes
                </h4>
              </div>
            )}
          </div>
        </div>

        <div className="row no-gutters">
          <div className="col-lg-12">
            <div className={style.tableContainer}>
              <div className={style.tableItem}>
                {selectedWallet && selectedWallet.iconName && (
                  <ExtractCoinSelected
                    coin_name={selectedWallet.walletName}
                    coin_symbol={selectedWallet.iconName.toUpperCase()}
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Layout;
