import React from 'react';
import Layout from './layout';
import Logged from '../_layouts/default';

const WithDraw: React.FC = () => {
  return (
    <Logged>
      <Layout />
    </Logged>
  );
};

export default WithDraw;
