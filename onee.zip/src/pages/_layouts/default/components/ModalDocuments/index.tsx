import React from 'react';
import cx from 'classnames';
import { toast } from 'react-toastify';
import ButtonPrimary from '../../../../../components/ButtonPrimary';
import InputPrimary from '../../../../../components/InputPrimary';
import style from './modalDocument.module.scss';
import Upload from '~/components/Form/Upload';

import {
  GetCustomerNotReprovedCafDocument,
  useCreateCfaDocumentMutation,
} from '~/graphql/generated/graphql';

type ActiveProps = {
  activeModal: boolean;
};

const ModalDocuments: React.FC<ActiveProps> = ({
  activeModal = false,
}: ActiveProps) => {
  const [createCfa, { loading }] = useCreateCfaDocumentMutation();

  const [front, setFront] = React.useState<File>();
  const [back, setBack] = React.useState<File>();
  const [selfie, setSelfie] = React.useState<File>();
  const [cpf, setCpf] = React.useState<string>();
  const [type, setType] = React.useState<string | undefined>('0');

  const handleSubmit = React.useCallback(async () => {
    try {
      if (type === '0') {
        toast.error('Selecione o tipo do documento.');
        return;
      }

      if (type !== 'cnh' && cpf?.length !== 14) {
        toast.error('CPF deve ter 11 digitos.');
        return;
      }

      if (!front) {
        toast.error('Anexe uma imagem legivel da frente do documento.');
        return;
      }

      if (!back) {
        toast.error('Anexe uma imagem legivel do verso do documento.');
        return;
      }

      if (!selfie) {
        toast.error('Anexe uma selfie segurando o documento.');
      }

      const response = await createCfa({
        variables: {
          back,
          front,
          selfie,
          type: type || '',
          cpf,
        },
        refetchQueries: [{ query: GetCustomerNotReprovedCafDocument }],
      });

      toast.success(response.data?.createCfaDocument);
    } catch (err) {
      // do nothing
    }
  }, [back, cpf, createCfa, front, selfie, type]);

  return (
    <>
      <div
        className={cx(style.backLayer, activeModal && style.backLayerOpen)}
        aria-hidden="true"
      />
      <div className={cx(style.container, activeModal && style.containerShow)}>
        {activeModal && (
          <div className={style.containItem}>
            <div className={style.header}>
              <h3>Validacao de documento</h3>
            </div>

            <div className={style.formUploadDocuments}>
              <div className={style.formGroup}>
                <label htmlFor="options">Tipo de documento</label>
                <select
                  id="options"
                  name="selectOptions"
                  onChange={
                    e =>
                      setType(
                        e.target.value === '0' ? undefined : e.target.value,
                      )
                    // eslint-disable-next-line react/jsx-curly-newline
                  }
                >
                  {type === '0' && <option value="0">Selecione</option>}
                  <option value="cnh">CNH</option>
                  <option value="rg">RG</option>
                  <option value="rne">RNE</option>
                </select>
              </div>

              {type !== 'cnh' && (
                <div className={style.formGroup}>
                  <InputPrimary
                    cpf
                    value={cpf || ''}
                    onChangeText={setCpf}
                    placeholder="CPF"
                    labelValue="CPF"
                  />
                </div>
              )}

              <div className={style.formGroup}>
                <label htmlFor="upload-document-front">
                  Frente do documento
                </label>
                <Upload onUpload={setFront} />
              </div>

              <div className={style.formGroup}>
                <label htmlFor="upload-document-back">Verso do documento</label>
                <Upload onUpload={setBack} />
              </div>

              <div className={style.formGroup}>
                <label htmlFor="upload-document-selfie">
                  Selfie com documento
                </label>
                <Upload onUpload={setSelfie} />
              </div>

              <ButtonPrimary
                transparency={false}
                onPress={() => handleSubmit()}
                disabled={loading}
              >
                Enviar
              </ButtonPrimary>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default ModalDocuments;
