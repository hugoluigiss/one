import React, { useState } from 'react';
import QRCode from 'qrcode.react';
import cx from 'classnames';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import ButtonPrimary from '../../../../../components/ButtonPrimary';
import InputPrimary from '../../../../../components/InputPrimary';
import style from './modalTwoFactorBox.module.scss';

// import useToast from '~/hooks/useToast';

import getValidationErrors from '~/utils/getValidationErrors';
import {
  CheckMyTwoFaExistsDocument,
  useCreateMyTwoFaMutation,
  useGetTwoFaDataQuery,
} from '~/graphql/generated/graphql';

type ActiveProps = {
  activeModal: boolean;
};

const ModalTwoFactorBox: React.FC<ActiveProps> = ({
  activeModal = false,
}: ActiveProps) => {
  const { loading, data: TwoFA } = useGetTwoFaDataQuery();

  const [create2FA] = useCreateMyTwoFaMutation();

  const [qrcode, setQrcode] = useState('');
  const [secret, setSecret] = useState('');

  const [token, setToken] = React.useState('');
  // const { addToast } = useToast();

  React.useEffect(() => {
    if (TwoFA?.GetTwoFaData.otpauth_url) {
      setSecret(TwoFA.GetTwoFaData.base32);
      setQrcode(TwoFA.GetTwoFaData.otpauth_url);
    }
  }, [TwoFA]);

  const handleSubmit = React.useCallback(async () => {
    try {
      const schema = Yup.object().shape({
        token: Yup.string()
          .length(6, 'O código de verificação deve conter 6 caracteres.')
          .required('O código de verificação é obrigatório'),
      });

      await schema.validate({ token }, { abortEarly: false });

      await create2FA({
        variables: { token, secret },
        refetchQueries: [{ query: CheckMyTwoFaExistsDocument }],
      }).then(() => {
        // addToast({
        //   type: 'success',
        //   title: 'Cadastro 2FA',
        //   description: '2FA cadastrado com sucesso.',
        // });
        toast.success('2FA cadastrado com sucesso.');
      });
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrors(err);
        Object.keys(errors).forEach(key =>
          // addToast({ type: 'error', title: '', description: errors[key] }),
          toast.error(errors[key]),
        );
      }
    }
  }, [create2FA, secret, token]);

  return (
    <>
      <div
        className={cx(style.backLayer, activeModal && style.backLayerOpen)}
        aria-hidden="true"
      />
      <div className={cx(style.container, activeModal && style.containerShow)}>
        {activeModal && (
          <div className={style.containItem}>
            <div className={style.header}>
              <h3>Verificação em duas etapas (2FA)</h3>
            </div>

            {loading ? (
              <div className={style.tableContainer}>Carregando...</div>
            ) : (
              <div className={style.tableContainer}>
                {qrcode && (
                  <div style={{ padding: 12, background: '#fff' }}>
                    <QRCode size={100} value={qrcode} renderAs="svg" />
                  </div>
                )}
                <InputPrimary
                  standard
                  placeholder="Digite o código de verificação"
                  labelValue="Código de dois fatores"
                  value={token}
                  onChangeText={setToken}
                />
                <ButtonPrimary onPress={() => handleSubmit()}>
                  Salvar
                </ButtonPrimary>
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
};

export default ModalTwoFactorBox;
