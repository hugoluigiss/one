import React from 'react';
import AppBar from '../../../components/AppBar';
import Sidebar from '../../../components/Sidebar';
import InternContainer from '../../../components/InternContainer';

import ModalDocuments from './components/ModalDocuments';
import { useGetCustomerNotReprovedCafQuery } from '~/graphql/generated/graphql';

interface LayoutProps {
  sidebar?: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { data } = useGetCustomerNotReprovedCafQuery();

  return (
    <>
      <AppBar />
      <Sidebar />
      <InternContainer>{children}</InternContainer>
      {/* {data && !data.CheckMyTwoFaExists && <ModalTwoFactorBox activeModal />} */}
      {data && !data.getCustomerNotReprovedCaf?.id && (
        <ModalDocuments activeModal />
      )}
    </>
  );
};

export default Layout;
