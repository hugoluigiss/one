import React, { Suspense, lazy } from 'react';
import { Switch } from 'react-router-dom';

import Route from './Route';

import Spinner from '~/components/Spinner';
import Wallets from '~/pages/Wallets';
import Extract from '~/pages/Extract';
import Help from '~/pages/Help';

const SignUp = lazy(() => import('~/pages/Auth/SignUp'));
const SignIn = lazy(() => import('~/pages/Auth/SignIn'));
const ForgotPassword = lazy(() => import('~/pages/Auth/ForgotPassword'));
const ResetPassword = lazy(() => import('~/pages/Auth/ResetPassword'));

const Dashboard = lazy(() => import('~/pages/Dashboard'));
const Deposit = lazy(() => import('~/pages/Deposit'));
// const Statement = lazy(() => import('~/pages/Statement'));
const Withdrawal = lazy(() => import('~/pages/Withdrawal'));

// const Account = lazy(() => import('~/pages/Account/Profile'));
const Profile = lazy(() => import('~/pages/Profile'));
// const AccountBank = lazy(() => import('~/pages/Account/DadosBancarios'));
// const Documents = lazy(() => import('~/pages/Account/Documents'));
// const Password = lazy(() => import('~/pages/Account/Security/Password'));
// const TwoFactor = lazy(() => import('~/pages/Account/Security/TwoFactor'));
// const Ticket = lazy(() => import('~/pages/Account/Ticket'));
// const TicketDetails = lazy(() => import('~/pages/Account/Ticket/Details'));

// const BitcoinDeposit = lazy(() => import('~/pages/Bitcoin/BitcoinDeposit'));
// const BitcoinTransfer = lazy(() => import('~/pages/Bitcoin/BitcoinTransfer'));
// const BitcoinNegotiate = lazy(() => import('~/pages/Bitcoin/BitcoinNegotiate'));
// const BitcoinOrders = lazy(() => import('~/pages/Bitcoin/BitcoinOrders'));

// const EthereumDeposit = lazy(() => import('~/pages/Ethereum/EthereumDeposit'));
// const EthereumTransfer = lazy(
//   () => import('~/pages/Ethereum/EthereumTransfer'),
// );
// const EthereumNegotiate = lazy(
//   () => import('~/pages/Ethereum/EthereumNegotiate'),
// );
// const EthereumOrders = lazy(() => import('~/pages/Ethereum/EthereumOrders'));

const Routes: React.FC = () => (
  <Suspense fallback={<Spinner />}>
    <Switch>
      <Route path="/" exact component={SignIn} />
      <Route path="/signup" component={SignUp} />

      <Route path="/forgot-password" component={ForgotPassword} />
      <Route path="/reset-password/:recovery_token" component={ResetPassword} />

      <Route path="/dashboard" component={Dashboard} isPrivate />
      <Route path="/wallets" component={Wallets} isPrivate />
      <Route path="/extract" component={Extract} isPrivate />
      <Route path="/deposit" component={Deposit} isPrivate />
      <Route path="/withdraw" component={Withdrawal} isPrivate />
      <Route path="/help" component={Help} isPrivate />
      <Route path="/profile" component={Profile} isPrivate />

      {/* <Route path="/financial/statement" component={Statement} isPrivate /> */}

      {/* <Route path="/account" component={Account} isPrivate /> */}

      {/* <Route path="/account-bank" component={AccountBank} isPrivate /> */}
      {/* <Route path="/documents" component={Documents} isPrivate /> */}
      {/* <Route path="/ticket" component={Ticket} isPrivate /> */}
      {/* <Route path="/ticket-details/:id" component={TicketDetails} isPrivate /> */}

      {/* <Route path="/security/password" component={Password} isPrivate /> */}
      {/* <Route path="/security/twofactor" component={TwoFactor} isPrivate /> */}

      {/* <Route path="/bitcoin/deposit" component={BitcoinDeposit} isPrivate /> */}
      {/* <Route path="/bitcoin/negotiate" component={BitcoinNegotiate} isPrivate /> */}
      {/* <Route path="/bitcoin/transfer" component={BitcoinTransfer} isPrivate /> */}
      {/* <Route path="/bitcoin/orders" component={BitcoinOrders} isPrivate /> */}

      {/* <Route path="/ethereum/deposit" component={EthereumDeposit} isPrivate /> */}
      {/* <Route
        path="/ethereum/negotiate"
        component={EthereumNegotiate}
        isPrivate
      />
      <Route path="/ethereum/transfer" component={EthereumTransfer} isPrivate />
      <Route path="/ethereum/orders" component={EthereumOrders} isPrivate /> */}
    </Switch>
  </Suspense>
);

export default Routes;
